package au.gov.vic.sro.duties.rules.model;

public class PPLFamilyFarm {

	private FamilyFarmRelationshipType relationshipToTransferee;

	private Boolean arrangementOrSchemeFamilyFarm;

	private String relationshipDescription;

	public FamilyFarmRelationshipType getRelationshipToTransferee() {
		return relationshipToTransferee;
	}

	public void setRelationshipToTransferee(FamilyFarmRelationshipType relationshipToTransferee) {
		this.relationshipToTransferee = relationshipToTransferee;
	}

	public Boolean getArrangementOrSchemeFamilyFarm() {
		return arrangementOrSchemeFamilyFarm;
	}

	public void setArrangementOrSchemeFamilyFarm(Boolean arrangementOrSchemeFamilyFarm) {
		this.arrangementOrSchemeFamilyFarm = arrangementOrSchemeFamilyFarm;
	}

	public String getRelationshipDescription() {
		return relationshipDescription;
	}

	public void setRelationshipDescription(String relationshipDescription) {
		this.relationshipDescription = relationshipDescription;
	}


}
