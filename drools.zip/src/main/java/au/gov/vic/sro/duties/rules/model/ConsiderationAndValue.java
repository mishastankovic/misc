package au.gov.vic.sro.duties.rules.model;


import java.math.BigDecimal;
import java.util.Date;

public class ConsiderationAndValue {

	private Boolean marketValueDiffersFromMonetConsid;
	private Date marketValueDate;
	private BigDecimal marketValue;
	private BigDecimal consideration;
	private Boolean nonMonetaryConsiderationGiven;
	private NonMonetaryConsiderationType nonMonetaryConsiderationType;
	private String otherNonMonetaryConsiderationDetails;
	private BigDecimal depositPaidPercent;
	private BigDecimal depositPaidAmount;
	private BigDecimal rebateDiscountAppliedByTransferorAmount;
	public Date getMarketValueDate() {
		return marketValueDate;
	}

	public void setMarketValueDate(Date marketValueDate) {
		this.marketValueDate = marketValueDate;
	}

	public BigDecimal getMarketValue() {
		return marketValue;
	}

	public void setMarketValue(BigDecimal marketValue) {
		this.marketValue = marketValue;
	}

	public BigDecimal getConsideration() {
		return consideration;
	}

	public void setConsideration(BigDecimal consideration) {
		this.consideration = consideration;
	}

	public NonMonetaryConsiderationType getNonMonetaryConsiderationType() {
		return nonMonetaryConsiderationType;
	}

	public void setNonMonetaryConsiderationType(NonMonetaryConsiderationType nonMonetaryConsiderationType) {
		this.nonMonetaryConsiderationType = nonMonetaryConsiderationType;
	}

	public String getOtherNonMonetaryConsiderationDetails() {
		return otherNonMonetaryConsiderationDetails;
	}

	public void setOtherNonMonetaryConsiderationDetails(String otherNonMonetaryConsiderationDetails) {
		this.otherNonMonetaryConsiderationDetails = otherNonMonetaryConsiderationDetails;
	}

	public BigDecimal getDepositPaidPercent() {
		return depositPaidPercent;
	}

	public void setDepositPaidPercent(BigDecimal depositPaidPercent) {
		this.depositPaidPercent = depositPaidPercent;
	}

	public BigDecimal getDepositPaidAmount() {
		return depositPaidAmount;
	}

	public void setDepositPaidAmount(BigDecimal depositPaidAmount) {
		this.depositPaidAmount = depositPaidAmount;
	}

	public BigDecimal getRebateDiscountAppliedByTransferorAmount() {
		return rebateDiscountAppliedByTransferorAmount;
	}

	public void setRebateDiscountAppliedByTransferorAmount(BigDecimal rebateDiscountAppliedByTransferorAmount) {
		this.rebateDiscountAppliedByTransferorAmount = rebateDiscountAppliedByTransferorAmount;
	}

	public Boolean getMarketValueDiffersFromMonetConsid() {
		return marketValueDiffersFromMonetConsid;
	}

	public void setMarketValueDiffersFromMonetConsid(Boolean marketValueDiffersFromMonetConsid) {
		this.marketValueDiffersFromMonetConsid = marketValueDiffersFromMonetConsid;
	}

	public Boolean getNonMonetaryConsiderationGiven() {
		return nonMonetaryConsiderationGiven;
	}

	public void setNonMonetaryConsiderationGiven(Boolean nonMonetaryConsiderationGiven) {
		this.nonMonetaryConsiderationGiven = nonMonetaryConsiderationGiven;
	}

	public boolean isNonMonetaryDetailsRendered() {
		return Boolean.TRUE.equals(nonMonetaryConsiderationGiven);
	}

	public boolean isMarketValueDetailsRendered() {
		return Boolean.TRUE.equals(marketValueDiffersFromMonetConsid);
	}

	public boolean isOtherNonMonetaryConsiderationDetailsRendered() {
		return determineIsOtherNonMonetaryConsiderationType();
	}

	public boolean determineIsOtherNonMonetaryConsiderationType() {
		return NonMonetaryConsiderationType.Other.equals(nonMonetaryConsiderationType);
	}

	public Boolean isConsideration() {
		return (consideration != null && BigDecimal.ZERO.compareTo(consideration) < 0);
	}

}
