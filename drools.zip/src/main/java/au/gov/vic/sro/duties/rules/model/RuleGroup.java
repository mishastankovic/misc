package au.gov.vic.sro.duties.rules.model;

public enum RuleGroup {
    SPOUSE_TRANSFER,
    CHANGE_IN_THE_MANNER_OF_HOLDING,
    DECEASED_ESTATE,
    FAMILY_FARM,
    PRIMARY_PRODUCTION,
    SUB_SALE,
    RELATED_PARTIES,
    UNRELATED_PARTIES,
    SUPERFUND
}
