package au.gov.vic.sro.duties.rules.model;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class OffThePlanMethod  {

	private static final long serialVersionUID = 8281339461732108151L;

	protected MethodType method;

	protected BigDecimal contractPrice = BigDecimal.ZERO;

	protected BigDecimal buildingWorksCost = BigDecimal.ZERO;

	protected BigDecimal afterContractConstructionCompletedPercent;
	protected BigDecimal afterContractConstructionCost = BigDecimal.ZERO;
	protected BigDecimal dutiableValue = BigDecimal.ZERO;
	protected BigDecimal transactionContractPriceIncGST;
	protected BigDecimal transactionGST = BigDecimal.ZERO;
	protected BigDecimal transactionContractExcludingGST = BigDecimal.ZERO;
	protected BigDecimal constructionCostsGST = BigDecimal.ZERO;
	private BigDecimal baseLandValue;
	private BigDecimal infrastructureValuePercent;
	private String lessThan25PercentDetails;
	private String uerNotApplicableDetails;
	private BigDecimal offThePlanLandValue = BigDecimal.ZERO;
	private BigDecimal nonDeductibleCost;
	private BigDecimal afterContractConstructionInclGSTCost = BigDecimal.ZERO;
	protected BigDecimal alternativeWorksCost = BigDecimal.ZERO;

	public MethodType getMethod() {
		return method;
	}

	public void setMethod(MethodType method) {
		this.method = method;
	}

	public BigDecimal getContractPrice() {
		return contractPrice;
	}

	public void setContractPrice(BigDecimal contractPrice) {
		this.contractPrice = contractPrice;
	}

	public BigDecimal getBuildingWorksCost() {
		return buildingWorksCost;
	}

	public void setBuildingWorksCost(BigDecimal buildingWorksCost) {
		this.buildingWorksCost = buildingWorksCost;
	}

	public BigDecimal getAfterContractConstructionCompletedPercent() {
		return afterContractConstructionCompletedPercent;
	}


	public BigDecimal getAfterContractConstructionCost() {
		return afterContractConstructionCost;
	}

	public void setAfterContractConstructionCost(BigDecimal afterContractConstructionCost) {
		this.afterContractConstructionCost = afterContractConstructionCost;
	}

	public BigDecimal getBaseLandValue() {
		return baseLandValue;
	}

	public void setBaseLandValue(BigDecimal baseLandValue) {
		this.baseLandValue = baseLandValue;
	}

	public BigDecimal getInfrastructureValuePercent() {
		return infrastructureValuePercent;
	}

	public void setInfrastructureValuePercent(BigDecimal infrastructureValuePercent) {
		this.infrastructureValuePercent = infrastructureValuePercent;
	}

	public String getLessThan25PercentDetails() {
		return lessThan25PercentDetails;
	}

	public void setLessThan25PercentDetails(String lessThan25PercentDetails) {
		this.lessThan25PercentDetails = lessThan25PercentDetails;
	}

	public String getUerNotApplicableDetails() {
		return uerNotApplicableDetails;
	}

	public void setUerNotApplicableDetails(String uerNotApplicableDetails) {
		this.uerNotApplicableDetails = uerNotApplicableDetails;
	}

	public BigDecimal getOffThePlanLandValue() {
		return offThePlanLandValue;
	}

	public void setOffThePlanLandValue(BigDecimal offThePlanLandValue) {
		this.offThePlanLandValue = offThePlanLandValue;
	}

	public BigDecimal getNonDeductibleCost() {
		return nonDeductibleCost;
	}

	public void setNonDeductibleCost(BigDecimal nonDeductibleCost) {
		this.nonDeductibleCost = nonDeductibleCost;
	}

	public BigDecimal getAfterContractConstructionInclGSTCost() {
		return afterContractConstructionInclGSTCost;
	}

	public void setAfterContractConstructionInclGSTCost(BigDecimal afterContractConstructionInclGSTCost) {
		this.afterContractConstructionInclGSTCost = afterContractConstructionInclGSTCost;
	}

	public BigDecimal getAlternativeWorksCost() {
		return alternativeWorksCost;
	}

	public void setAlternativeWorksCost(BigDecimal alternativeWorksCost) {
		this.alternativeWorksCost = alternativeWorksCost;
	}

	public BigDecimal getAltAfterContractConstructionCost() {
		return afterContractConstructionCost;
	}

	public void setAltAfterContractConstructionCost(BigDecimal altAfterContractConstructionCost) {
		this.afterContractConstructionCost = altAfterContractConstructionCost;
	}

	public BigDecimal getAltDutiableValue() {
		return dutiableValue;
	}

	public void setAltDutiableValue(BigDecimal altDutiableValue) {
		this.dutiableValue = altDutiableValue;
	}

	public BigDecimal getTransactionContractPriceIncGST() {
		return transactionContractPriceIncGST;
	}

	public void setTransactionContractPriceIncGST(BigDecimal transactionContractPriceIncGST) {
		this.transactionContractPriceIncGST = transactionContractPriceIncGST;
	}

	public BigDecimal getTransactionGST() {
		return transactionGST;
	}

	public void setTransactionGST(BigDecimal transactionGST) {
		this.transactionGST = transactionGST;
	}

	public BigDecimal getTransactionContractExcludingGST() {
		return transactionContractExcludingGST;
	}

	public void setTransactionContractExcludingGST(BigDecimal transactionContractExcludingGST) {
		this.transactionContractExcludingGST = transactionContractExcludingGST;
	}

	public BigDecimal getConstructionCostsGST() {
		return constructionCostsGST;
	}

	public void setConstructionCostsGST(BigDecimal constructionCostsGST) {
		this.constructionCostsGST = constructionCostsGST;
	}

	public BigDecimal getDutiableValue() {
		return dutiableValue != null ? dutiableValue.setScale(0, RoundingMode.FLOOR) : dutiableValue;
	}

	public void setDutiableValue(BigDecimal dutiableValue) {
		this.dutiableValue = dutiableValue;
	}


}
