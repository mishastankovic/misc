package au.gov.vic.sro.duties.rules.model;

import java.util.Date;

public class Transferee extends AbstractParty {

	private Long partyId;

	private Boolean remainingOnTitle;

	private Trust trust = new Trust();

	private OwnershipShare transferRightsShare = new OwnershipShare();

	private Date transferRightDate;

	public Long getPartyId() {
		return partyId;
	}

	public void setPartyId(Long partyId) {
		this.partyId = partyId;
	}

	public Boolean getRemainingOnTitle() {
		return remainingOnTitle;
	}

	public void setRemainingOnTitle(Boolean remainingOnTitle) {
		this.remainingOnTitle = remainingOnTitle;
	}

	public Trust getTrust() {
		return trust;
	}

	public void setTrust(Trust trust) {
		this.trust = trust;
	}

	public OwnershipShare getTransferRightsShare() {
		return transferRightsShare;
	}

	public void setTransferRightsShare(OwnershipShare transferRightsShare) {
		this.transferRightsShare = transferRightsShare;
	}

	public Date getTransferRightDate() {
		return transferRightDate;
	}

	public void setTransferRightDate(Date transferRightDate) {
		this.transferRightDate = transferRightDate;
	}

}
