package au.gov.vic.sro.duties.rules.model;

public enum MannerOfHoldingType {

    ChangeInTheMannerOfHoldingToJointProprietor(
            "Change in the manner of holding from tenants in common in equal shares to joint proprietors", "Change in the manner of holding from tenants in common in equal shares to joint proprietors", "1"),
    ChangeInTheMannerOfHoldingToEqualShare (
            "Change in the manner of holding from joint proprietors to tenants in common in equal shares",
            "Change in the manner of holding from joint proprietors to tenants in common in equal shares", "2");


    private String label;
    private String shortLabel;
    private String oracleCode;

    MannerOfHoldingType(String label, String shortLabel, String code) {
        this.label = label;
        this.shortLabel = shortLabel;
        this.oracleCode = code;
    }

    public String getShortLabel() {
        return shortLabel;
    }

    public void setShortLabel(String shortLabel) {
        this.shortLabel = shortLabel;
    }

    public String getOracleCode() {
        return oracleCode;
    }

    public void setOracleCode(String oracleCode) {
        this.oracleCode = oracleCode;
    }

    public String getLabel() {

        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public static MannerOfHoldingType fromOracleCode(String code) {

        if (code == null)
            throw new NullPointerException("Null code passed");

        for (MannerOfHoldingType value : MannerOfHoldingType.values()) {
            if (value.getOracleCode().equals(code)) {
                return value;
            }
        }

        throw new IllegalArgumentException(String.format(
                "Could not find MannerOfHoldingType Enum to match passed value: %s", code));

    }

}
