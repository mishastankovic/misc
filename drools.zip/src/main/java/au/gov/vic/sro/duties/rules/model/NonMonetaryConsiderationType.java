package au.gov.vic.sro.duties.rules.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public enum NonMonetaryConsiderationType {

	DeviseInAccordanceWithAWill("Pursuant to a devise in a will", "Pursuant to a devise in a will", "1"),
	IntestateEstate("Being entitled to the intestate estate", "Being entitled to the intestate estate", "2"),
	EntitledInEquity("Entitled in equity", "Entitled in equity", "3"),
	BreakdownOfMarriageDeFactoRelationship("Breakdown of marriage/de facto relationship",
			"Breakdown of marriage/de facto relationship",
			"4"),
	ChangeInTheMannerOfHolding("Transfer to change manner of holding between registered proprietors",
			"Transfer to change manner of holding between registered proprietors",
			"5"),
	NaturalLoveAndAffection("Natural love and affection", "Natural love and affection", "6"),
	Other("Other", "Other", "7");

	private String label;
	private String shortLabel;
	private String oracleCode;

	private NonMonetaryConsiderationType(String label, String shortLabel, String code) {
		this.label = label;
		this.shortLabel = shortLabel;
		this.oracleCode = code;
	}

	public boolean isOneOf(NonMonetaryConsiderationType... values) {
		for (NonMonetaryConsiderationType value : values)
			if (value == this) return true;
		return false;
	}

	public static List<NonMonetaryConsiderationType> getList() {
		List<NonMonetaryConsiderationType> list = new ArrayList<NonMonetaryConsiderationType>();
		// @formatter:off
		list.addAll(Arrays.asList(new NonMonetaryConsiderationType[] { 
				DeviseInAccordanceWithAWill, 
				IntestateEstate,
				EntitledInEquity,
				BreakdownOfMarriageDeFactoRelationship, 
				ChangeInTheMannerOfHolding,
				NaturalLoveAndAffection,
				Other
				}));
		// @formatter: one
		return list;
	}

	public String getLabel() {
		return label;
	}

	public String getShortLabel() {
		return shortLabel;
	}

	public String getOracleCode() {
		return oracleCode;
	}

	public static NonMonetaryConsiderationType fromOracleCode(String code) {
		if (code == null) throw new NullPointerException("Null code passed");

		for (NonMonetaryConsiderationType value : NonMonetaryConsiderationType.values()) {
			if (value.getOracleCode().equals(code)) {
				return value;
			}
		}

		throw new IllegalArgumentException(String.format(
				"Could not find NatureOfTransfer Enum to match passed value: %s", code));
	}
}
