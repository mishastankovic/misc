package au.gov.vic.sro.duties.rules.model;

import java.util.Date;

public class ForeignNationalDetails {

	private String passportNumber;

	private String visaNumber;

	private String visaSubclass;

	private Date visaExpiryDate;

	private CountryType nationality;

	private CountryType taxResidenceCountry;

	private Boolean splCategoryVisa;

	private Boolean residesAUSettlement;

	private String overseasEntityIdentifier;

	private String firbApplicationNumber;

	public String getPassportNumber() {
		return passportNumber;
	}

	public void setPassportNumber(String passportNumber) {
		this.passportNumber = passportNumber;
	}

	public String getVisaNumber() {
		return visaNumber;
	}

	public void setVisaNumber(String visaNumber) {
		this.visaNumber = visaNumber;
	}

	public String getVisaSubclass() {
		return visaSubclass;
	}

	public void setVisaSubclass(String visaSubclass) {
		this.visaSubclass = visaSubclass;
	}

	public Date getVisaExpiryDate() {
		return visaExpiryDate;
	}

	public void setVisaExpiryDate(Date visaExpiryDate) {
		this.visaExpiryDate = visaExpiryDate;
	}

	public CountryType getNationality() {
		return nationality;
	}

	public void setNationality(CountryType nationality) {
		this.nationality = nationality;
	}

	public CountryType getTaxResidenceCountry() {
		return taxResidenceCountry;
	}

	public void setTaxResidenceCountry(CountryType taxResidenceCountry) {
		this.taxResidenceCountry = taxResidenceCountry;
	}

	public Boolean getSplCategoryVisa() {
		return splCategoryVisa;
	}

	public void setSplCategoryVisa(Boolean splCategoryVisa) {
		this.splCategoryVisa = splCategoryVisa;
	}

	public Boolean getResidesAUSettlement() {
		return residesAUSettlement;
	}

	public void setResidesAUSettlement(Boolean residesAUSettlement) {
		this.residesAUSettlement = residesAUSettlement;
	}

	public String getOverseasEntityIdentifier() {
		return overseasEntityIdentifier;
	}

	public void setOverseasEntityIdentifier(String overseasEntityIdentifier) {
		this.overseasEntityIdentifier = overseasEntityIdentifier;
	}

	public String getFirbApplicationNumber() {
		return firbApplicationNumber;
	}

	public void setFirbApplicationNumber(String firbApplicationNumber) {
		this.firbApplicationNumber = firbApplicationNumber;
	}

	public boolean isVisaPanelRendered() {
		return CountryType.NEW_ZEALAND.equals(nationality);
	}

	public boolean isVisaForeignDetailsRequired() {
		return isVisaPanelRendered()
				&& (Boolean.FALSE.equals(getSplCategoryVisa()) || Boolean.FALSE.equals(getResidesAUSettlement()));
	}

}
