package au.gov.vic.sro.duties.rules.model;

public class Organisation {

	private String organisationName;

	private Boolean foreignOrganisationInd;

	private String acnArbnAbn;

	private String authorisedPersonName;

	private String authorisedPersonEmail;

	private ForeignOrganisation foreignOrganisation = new ForeignOrganisation();

	private PositionType position;

	public String getOrganisationName() {
		return organisationName;
	}

	public void setOrganisationName(String organisationName) {
		this.organisationName = organisationName;
	}

	public String getAuthorisedPersonName() {
		return authorisedPersonName;
	}

	public void setAuthorisedPersonName(String authorisedPersonName) {
		this.authorisedPersonName = authorisedPersonName;
	}

	public String getAuthorisedPersonEmail() {
		return authorisedPersonEmail;
	}

	public void setAuthorisedPersonEmail(String authorisedPersonEmail) {
		this.authorisedPersonEmail = authorisedPersonEmail;
	}

	public PositionType getPosition() {
		return position;
	}

	public void setPosition(PositionType position) {
		this.position = position;
	}

	public String getAcnArbnAbn() {
		return acnArbnAbn;
	}

	public void setAcnArbnAbn(String acnArbnAbn) {
		this.acnArbnAbn = acnArbnAbn;
	}

	public Boolean getForeignOrganisationInd() {
		return foreignOrganisationInd;
	}

	public void setForeignOrganisationInd(Boolean foreignOrganisationInd) {
		this.foreignOrganisationInd = foreignOrganisationInd;
	}

	public ForeignOrganisation getForeignOrganisation() {
		return foreignOrganisation;
	}

	public void setForeignOrganisation(ForeignOrganisation foreignOrganisation) {
		this.foreignOrganisation = foreignOrganisation;
	}

	public boolean determineIsForeignOrganisation() {
		return Boolean.TRUE.equals(getForeignOrganisationInd());
	}
}
