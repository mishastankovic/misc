package au.gov.vic.sro.duties.rules.model;

import java.util.Date;
import java.util.List;

public class FormData {
    private TransferOfLandType transactionInvolvesProperty;
    private TransactionType transactionInvolvesTransaction;
    private SubSale subSale;
    private Boolean saleOfBusiness;
    private Boolean saleOfGoods;
    private Boolean anyOtherTransferOfLand;
    private List<Property> properties;
    private List<Transferee> transferees;
    private List<Transferor> transferors;
    private ConsiderationAndValue consideration;
    private List<Concession> concessions;
    private MannerOfHoldingType mannerOfHoldingType;
    private Boolean multipleConsiderations = false;
    private Date contractDate;
    private RelatedParty relatedParty;
    private Boolean transferInvovesContract;
    private OffThePlan offThePlan;

    public Boolean isThereThirdPartyTransferee() {
        return transferees != null && transferees.size() > 2;
    }
    public List<Property> getProperties() {
        return properties;
    }

    public void setProperties(List<Property> properties) {
        this.properties = properties;
    }

    public List<Transferee> getTransferees() {
        return transferees;
    }

    public void setTransferees(List<Transferee> transferees) {
        this.transferees = transferees;
    }

    public List<Transferor> getTransferors() {
        return transferors;
    }

    public void setTransferors(List<Transferor> transferors) {
        this.transferors = transferors;
    }

    public Boolean getConcessionClaimed() {
        return concessionClaimed;
    }

    public void setConcessionClaimed(Boolean concessionClaimed) {
        this.concessionClaimed = concessionClaimed;
    }

    private Boolean concessionClaimed;

    public SubSale getSubSale() {
        return subSale;
    }

    public void setSubSale(SubSale subSale) {
        this.subSale = subSale;
    }

    public Boolean getSaleOfBusiness() {
        return saleOfBusiness;
    }

    public void setSaleOfBusiness(Boolean saleOfBusiness) {
        this.saleOfBusiness = saleOfBusiness;
    }

    public Boolean getSaleOfGoods() {
        return saleOfGoods;
    }

    public void setSaleOfGoods(Boolean saleOfGoods) {
        this.saleOfGoods = saleOfGoods;
    }

    public Boolean getAnyOtherTransferOfLand() {
        return anyOtherTransferOfLand;
    }

    public void setAnyOtherTransferOfLand(Boolean anyOtherTransferOfLand) {
        this.anyOtherTransferOfLand = anyOtherTransferOfLand;
    }

    public ConsiderationAndValue getConsideration() {
        return consideration;
    }

    public void setConsideration(ConsiderationAndValue consideration) {
        this.consideration = consideration;
    }

    public List<Concession> getConcessions() {
        return concessions;
    }

    public void setConcessions(List<Concession> concessions) {
        this.concessions = concessions;
    }

    public TransferOfLandType getTransactionInvolvesProperty() {
        return transactionInvolvesProperty;
    }

    public void setTransactionInvolvesProperty(TransferOfLandType transactionInvolvesProperty) {
        this.transactionInvolvesProperty = transactionInvolvesProperty;
    }

    public TransactionType getTransactionInvolvesTransaction() {
        return transactionInvolvesTransaction;
    }

    public void setTransactionInvolvesTransaction(TransactionType transactionInvolvesTransaction) {
        this.transactionInvolvesTransaction = transactionInvolvesTransaction;
    }

    public MannerOfHoldingType getMannerOfHoldingType() {
        return mannerOfHoldingType;
    }

    public void setMannerOfHoldingType(MannerOfHoldingType mannerOfHoldingType) {
        this.mannerOfHoldingType = mannerOfHoldingType;
    }

    public Boolean getMultipleConsiderations() {
        return multipleConsiderations;
    }

    public void setMultipleConsiderations(Boolean multipleConsiderations) {
        this.multipleConsiderations = multipleConsiderations;
    }

    public Date getContractDate() {
        return contractDate;
    }

    public void setContractDate(Date contractDate) {
        this.contractDate = contractDate;
    }

    public RelatedParty getRelatedParty() {
        return relatedParty;
    }

    public void setRelatedParty(RelatedParty relatedParty) {
        this.relatedParty = relatedParty;
    }

    public Boolean getTransferInvovesContract() {
        return transferInvovesContract;
    }

    public void setTransferInvovesContract(Boolean transferInvovesContract) {
        this.transferInvovesContract = transferInvovesContract;
    }

    public OffThePlan getOffThePlan() {
        return offThePlan;
    }

    public void setOffThePlan(OffThePlan offThePlan) {
        this.offThePlan = offThePlan;
    }
}
