package au.gov.vic.sro.duties.rules.model;


public abstract class AbstractTransferParty extends AbstractParty {

	private OwnershipShare interestHolding = new OwnershipShare();

	private Boolean behalfOfTrust;

	public OwnershipShare getInterestHolding() {
		return interestHolding;
	}

	public void setInterestHolding(OwnershipShare interestHolding) {
		this.interestHolding = interestHolding;
	}

	public Boolean getBehalfOfTrust() {
		return behalfOfTrust;
	}

	public void setBehalfOfTrust(Boolean behalfOfTrust) {
		this.behalfOfTrust = behalfOfTrust;
	}	

	public boolean determineIsBehalfOfTrust() {
		return Boolean.TRUE.equals(getBehalfOfTrust());
	}

}
