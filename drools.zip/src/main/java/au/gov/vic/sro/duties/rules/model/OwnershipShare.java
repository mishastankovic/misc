package au.gov.vic.sro.duties.rules.model;

import java.math.BigDecimal;

public class OwnershipShare {

	private Long totalShares;

	private Long sharesOwned;

	private BigDecimal sharePercentage;

	public Long getTotalShares() {
		return totalShares;
	}

	public void setTotalShares(Long totalShares) {
		this.totalShares = totalShares;
	}

	public Long getSharesOwned() {
		return sharesOwned;
	}

	public void setSharesOwned(Long sharesOwned) {
		this.sharesOwned = sharesOwned;
	}

	public void setSharePercentage(BigDecimal sharePercentage) {
		this.sharePercentage = sharePercentage;
	}

}
