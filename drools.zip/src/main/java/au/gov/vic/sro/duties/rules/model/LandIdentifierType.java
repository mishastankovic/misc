package au.gov.vic.sro.duties.rules.model;

public enum LandIdentifierType {

	VOLUME_FOLIO("Volume and folio", "Volume and Folio"),
	LOT_PLAN("Lot and plan number", "Lot and Plan Number"),
	BOOK_MEMORIAL("Book and memorial number", "Book and Memorial Number"),
	CROWN_ALLOTMENT("Crown allotment", "Crown Allotment");

	private String label;
	private String code;

	private LandIdentifierType(String label, String code) {
		this.label = label;
		this.code = code;
	}

	public String getLabel() {
		return label;
	}

	public String getCode() {
		return code;
	}
}
