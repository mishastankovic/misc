package au.gov.vic.sro.duties.rules.model;

public class SuperannuationFundExemption {

	private Boolean isComplyingFund;

	private Boolean isAllTransferorFundMember;

	private Boolean isAnyConsideration;

	public Boolean getIsComplyingFund() {
		return isComplyingFund;
	}

	public void setIsComplyingFund(Boolean isComplyingFund) {
		this.isComplyingFund = isComplyingFund;
	}

	public Boolean getIsAllTransferorFundMember() {
		return isAllTransferorFundMember;
	}

	public void setIsAllTransferorFundMember(Boolean isAllTransferorFundMember) {
		this.isAllTransferorFundMember = isAllTransferorFundMember;
	}

	public Boolean getIsAnyConsideration() {
		return isAnyConsideration;
	}

	public void setIsAnyConsideration(Boolean isAnyConsideration) {
		this.isAnyConsideration = isAnyConsideration;
	}

}
