package au.gov.vic.sro.duties.rules.model;

public enum PositionType {

	DIRECTOR("Director", "Director"),
	SECRETARY("Secretary", "Secretary"),
	CHAIRMAN("Chairman", "Chairman"),
	CEO("Chief Executive Officer (CEO)", "Chief Executive Officer (CEO)"),
	CFO("Chief Financial Officer (CFO)", "Chief Financial Officer (CFO)"),
	CIO("Chief Information Officer (CIO)", "Chief Information Officer (CIO)"),
	COMMISSIONER("Commissioner", "Commissioner"),
	MANAGER("Manager", "Manager"),
	PARTNER("Partner", "Partner"),
	PRESIDENT_OR_VICE_PRESIDENT("President/Vice President", "President/Vice President");

	private String code;
	private String label;

	private PositionType(String code, String label) {
		this.code = code;
		this.label = label;
	}

	public String getCode() {
		return code;
	}

	public String getLabel() {
		return label;
	}

	public static PositionType getPositionTypeByCode(String code) {
		for (PositionType positionType : PositionType.values()) {
			if (positionType.getCode().equals(code)) {
				return positionType;
			}
		}

		return null;
	}

}
