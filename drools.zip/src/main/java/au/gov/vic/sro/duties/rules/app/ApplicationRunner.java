package au.gov.vic.sro.duties.rules.app;

import au.gov.vic.sro.duties.rules.model.FormData;
import au.gov.vic.sro.duties.rules.model.TransactionData;
import au.gov.vic.sro.duties.rules.service.DutiesRulesService;
import au.gov.vic.sro.duties.rules.service.DutiesRulesConfiguration;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class ApplicationRunner {

    public static void main(String[] args) {
        ApplicationContext context = new AnnotationConfigApplicationContext(DutiesRulesConfiguration.class);
        DutiesRulesService dutiesRulesService = (DutiesRulesService) context.getBean(DutiesRulesService.class);
        FormData formData = new FormData();
        TransactionData transactionData = dutiesRulesService.formToTransactionData(formData);
    }

}
