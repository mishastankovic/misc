package au.gov.vic.sro.duties.rules.model;

import java.math.BigDecimal;

public enum MethodType {
	FIXED_45("Fixed % - single lot freestanding (45%)", "1", new BigDecimal(45)),
	FIXED_60("Fixed % - multi-lot low rise up to and including three storeys (60%)", "2", new BigDecimal(60)),
	FIXED_75("Fixed % - high rise (75%)", "3", new BigDecimal(75)),
	ALTERNATIVE("Alternative", "4", new BigDecimal(100));

	private String label;
	private String code;
	private BigDecimal percentage;

	private MethodType(String label, String code, BigDecimal percentage) {
		this.label = label;
		this.code = code;
		this.percentage = percentage;
	}

	public String getCode() {
		return code;
	}

	public String getLabel() {
		return label;
	}

	public BigDecimal getPercentage() {
		return percentage;
	}

	public boolean isFixed() {
		return this != ALTERNATIVE;
	}

	public boolean isAlternative() {
		return this == ALTERNATIVE;
	}
}
