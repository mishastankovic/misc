package au.gov.vic.sro.duties.rules.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public enum TransactionType {
	TransferBetweenSpousesDeFactoOrDomesticPartners,
	ChangeInTheMannerOfHolding,
	DeviseInAccordanceWithAWillOrProbate,
	Other
}
