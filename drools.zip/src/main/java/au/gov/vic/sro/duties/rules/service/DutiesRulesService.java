package au.gov.vic.sro.duties.rules.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.drools.core.event.DebugAgendaEventListener;
import org.drools.core.event.DebugRuleRuntimeEventListener;
import org.kie.api.KieServices;
import org.kie.api.logger.KieRuntimeLogger;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import au.gov.vic.sro.duties.rules.model.FormData;
import au.gov.vic.sro.duties.rules.model.TransactionData;

import java.io.IOException;
import java.io.StringWriter;

@Service
public class DutiesRulesService {

    @Autowired
    private KieContainer kContainer;

    public TransactionData formToTransactionData(FormData formData) {
        TransactionData transactionData = new TransactionData();
        KieSession kieSession = kContainer.newKieSession();

        /*
        // The application can also setup listeners
        kieSession.addEventListener( new DebugAgendaEventListener() );
        kieSession.addEventListener( new DebugRuleRuntimeEventListener() );
        KieRuntimeLogger logger =
                KieServices.Factory.get().getLoggers().newFileLogger(kieSession, "mylogfile");
                */

        kieSession.insert(transactionData);
        kieSession.insert(formData);
        // kieSession.setGlobal("txn", transactionData);
        kieSession.fireAllRules();
        kieSession.dispose();
        try {
            ObjectMapper jsonMapper = new ObjectMapper();
            StringWriter writer = new StringWriter();
            jsonMapper.writeValue(writer, transactionData);
            System.out.println(writer.toString());
        } catch (IOException e) {

        }
        return transactionData;
    }
}
