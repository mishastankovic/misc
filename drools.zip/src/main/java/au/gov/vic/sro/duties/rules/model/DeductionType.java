package au.gov.vic.sro.duties.rules.model;

public enum DeductionType {

    LandAndBuildingPackage(
            "Land and Building Package", "Land and Building Package", "1"),
    Refurbishment (
            "Refurbishment","Refurbishment", "2");


    private String label;
    private String shortLabel;
    private String oracleCode;

    DeductionType(String label, String shortLabel, String code) {
        this.label = label;
        this.shortLabel = shortLabel;
        this.oracleCode = code;
    }


    public static DeductionType fromOracleCode(String code) {

        if (code == null)
            throw new NullPointerException("Null code passed");

        for (DeductionType value : DeductionType.values()) {
            if (value.getOracleCode().equals(code)) {
                return value;
            }
        }

        throw new IllegalArgumentException(String.format(
                "Could not find DeductionType Enum to match passed value: %s", code));

    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getShortLabel() {
        return shortLabel;
    }

    public void setShortLabel(String shortLabel) {
        this.shortLabel = shortLabel;
    }

    public String getOracleCode() {
        return oracleCode;
    }

    public void setOracleCode(String oracleCode) {
        this.oracleCode = oracleCode;
    }
}
