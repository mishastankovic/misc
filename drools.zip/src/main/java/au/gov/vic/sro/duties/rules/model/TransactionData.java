package au.gov.vic.sro.duties.rules.model;

import java.util.ArrayList;
import java.util.List;

public class TransactionData {
    private LodgementChannel lodgementChannel;
    private LodgementCategory lodgementCategory;
    private String lodgementSubCategory;
    private NatureOfTransfer natureOfTransfer;
    private Boolean subsaleNotInContract = false;
    private List<String> sectionsOfTheAct = new ArrayList<String>();
    private List<String> offThePlanSectionActs = new ArrayList();
    private List<String> fhbdrSectionAcs = new ArrayList();
    private RuleGroup ruleGroup;
    private AssessmentType assessmentType;
    private List<String> dolTransactionTypes = new ArrayList<String>();
    private List<String> fpadSections = new ArrayList();
    private List<String> pensionerSectionActs = new ArrayList();
    private Boolean transfereesEqualShares = false;
    private Boolean transferorsEqualShares = false;


    public LodgementChannel getLodgementChannel() {
        return this.lodgementChannel;
    }

    public void setLodgementChannel(LodgementChannel lodgementChannel) {
        this.lodgementChannel = lodgementChannel;
    }

    public LodgementCategory getLodgementCategory() {
        return lodgementCategory;
    }

    public void setLodgementCategory(LodgementCategory lodgementCategory) {
        this.lodgementCategory = lodgementCategory;
    }

    public NatureOfTransfer getNatureOfTransfer() {
        return natureOfTransfer;
    }

    public void setNatureOfTransfer(NatureOfTransfer natureOfTransfer) {
        this.natureOfTransfer = natureOfTransfer;
    }

    public Boolean getSubsaleNotInContract() {
        return subsaleNotInContract;
    }

    public void setSubsaleNotInContract(Boolean subsaleNotInContract) {
        this.subsaleNotInContract = subsaleNotInContract;
    }

    public RuleGroup getRuleGroup() {
        return ruleGroup;
    }

    public void setRuleGroup(RuleGroup ruleGroup) {
        this.ruleGroup = ruleGroup;
    }

    public List<String> getSectionsOfTheAct() {
        return sectionsOfTheAct;
    }

    public void addSectionOfTheAct(String sectionOfTheAct) {
        this.sectionsOfTheAct.add(sectionOfTheAct);
    }

    public AssessmentType getAssessmentType() {
        return assessmentType;
    }

    public void setAssessmentType(AssessmentType assessmentType) {
        this.assessmentType = assessmentType;
    }

    public String getLodgementSubCategory() {
        return lodgementSubCategory;
    }

    public void setLodgementSubCategory(String lodgementSubCategory) {
        this.lodgementSubCategory = lodgementSubCategory;
    }

    public List<String> getDolTransactionTypes() {
        return dolTransactionTypes;
    }

    public void setDolTransactionTypes(String[] toBeAdded) {
        for (String dolTransactionType : toBeAdded) {
            this.dolTransactionTypes.add(dolTransactionType);
        }
    }

    public void addDolTransactionType(String newType) {
        this.dolTransactionTypes.add(newType);
    }

    public List<String> getFpadSections() {
        return fpadSections;
    }

    public void setFpadSections(String[] toBeAdded) {
        for (String fpadSection : toBeAdded) {
            this.fpadSections.add(fpadSection);
        }
    }

    public void addFpadSectionAct(String newAct) {
        this.fpadSections.add(newAct);
    }

    public Boolean getTransfereesEqualShares() {
        return transfereesEqualShares;
    }

    public void setTransfereesEqualShares(Boolean transfereesEqualShares) {
        this.transfereesEqualShares = transfereesEqualShares;
    }

    public Boolean getTransferorsEqualShares() {
        return transferorsEqualShares;
    }

    public void setTransferorsEqualShares(Boolean transferorsEqualShares) {
        this.transferorsEqualShares = transferorsEqualShares;
    }

    public void setSectionsOfTheAct(List<String> sectionsOfTheAct) {
        this.sectionsOfTheAct = sectionsOfTheAct;
    }

    public List<String> getOffThePlanSectionActs() {
        return offThePlanSectionActs;
    }

    public void setOffThePlanSectionActs(List<String> offThePlanSectionActs) {
        this.offThePlanSectionActs = offThePlanSectionActs;
    }

    public void addOffThePlanSectionAct(String newAct) {
        this.offThePlanSectionActs.add(newAct);
    }

    public List<String> getFhbdrSectionAcs() {
        return fhbdrSectionAcs;
    }

    public void addFhbdrSectionAct(String newAct) {
        this.fhbdrSectionAcs.add(newAct);
    }

    public void setFhbdrSectionAcs(List<String> fhbdrSectionAcs) {
        this.fhbdrSectionAcs = fhbdrSectionAcs;
    }

    public void setDolTransactionTypes(List<String> dolTransactionTypes) {
        this.dolTransactionTypes = dolTransactionTypes;
    }

    public void setFpadSections(List<String> fpadSections) {
        this.fpadSections = fpadSections;
    }

    public List<String> getPensionerSectionActs() {
        return pensionerSectionActs;
    }

    public void setPensionerSectionActs(List<String> pensionerSectionActs) {
        this.pensionerSectionActs = pensionerSectionActs;
    }

    public void addPensionerSectionAct(String newAct) {
        this.pensionerSectionActs.add(newAct);
    }
}
