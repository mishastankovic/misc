package au.gov.vic.sro.duties.rules.model;

public enum TransferOfLandType {

	TRANSFER_OF_LAND("Transfer of land", "Transfer of land"),
	CHANGE_OF_BENEFICIAL_OWNERSHIP("Change in beneficial ownership", "Change in beneficial ownership"),
	LAND_USE_ENTITLEMENT("Transfer of land use entitlements", "Transfer of land use entitlements");

	private String code;
	private String label;

	private TransferOfLandType(String code, String label) {
		this.code = code;
		this.label = label;
	}

	public String getCode() {
		return code;
	}

	public String getLabel() {
		return label;
	}

}
