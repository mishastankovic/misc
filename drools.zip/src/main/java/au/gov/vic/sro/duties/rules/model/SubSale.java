package au.gov.vic.sro.duties.rules.model;


public class SubSale {

	private Boolean applicable;
	private Boolean purchaserTransferRightsChanged;
	private Integer numberOfPurchasers;
	private Boolean option;
	private Boolean parallelArrangement;
	private Boolean landDevelopmentGranted;
	private Boolean landDevelopmentInContract;
	private Boolean additionalConsideration;
	private Boolean allPurchasersTheSameAsAllTransferees;

	public Boolean getApplicable() {
		return applicable;
	}

	public void setApplicable(Boolean applicable) {
		this.applicable = applicable;
	}

	public Boolean getPurchaserTransferRightsChanged() {
		return purchaserTransferRightsChanged;
	}

	public void setPurchaserTransferRightsChanged(Boolean purchaserTransferRightsChanged) {
		this.purchaserTransferRightsChanged = purchaserTransferRightsChanged;
	}

	public Integer getNumberOfPurchasers() {
		return numberOfPurchasers;
	}

	public void setNumberOfPurchasers(Integer numberOfPurchasers) {
		this.numberOfPurchasers = numberOfPurchasers;
	}

	public Boolean getOption() {
		return option;
	}

	public void setOption(Boolean option) {
		this.option = option;
	}

	public Boolean getParallelArrangement() {
		return parallelArrangement;
	}

	public void setParallelArrangement(Boolean parallelArrangement) {
		this.parallelArrangement = parallelArrangement;
	}

	public Boolean getLandDevelopmentGranted() {
		return landDevelopmentGranted;
	}

	public void setLandDevelopmentGranted(Boolean landDevelopmentGranted) {
		this.landDevelopmentGranted = landDevelopmentGranted;
	}

	public Boolean getAdditionalConsideration() {
		return additionalConsideration;
	}

	public void setAdditionalConsideration(Boolean additionalConsideration) {
		this.additionalConsideration = additionalConsideration;
	}

	public Boolean getAllPurchasersTheSameAsAllTransferees() {
		return allPurchasersTheSameAsAllTransferees;
	}

	public void setAllPurchasersTheSameAsAllTransferees(Boolean allPurchasersTheSameAsAllTransferees) {
		this.allPurchasersTheSameAsAllTransferees = allPurchasersTheSameAsAllTransferees;
	}

	public Boolean getLandDevelopmentInContract() {
		return landDevelopmentInContract;
	}

	public void setLandDevelopmentInContract(Boolean landDevelopmentInContract) {
		this.landDevelopmentInContract = landDevelopmentInContract;
	}
}
