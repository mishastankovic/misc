package au.gov.vic.sro.duties.rules.model;

// this class is a scaled down version of ConcessionAndExemption from the DutiesForm model
public class Concession {

    private ConcessionType concessionType;
    private PPLFamilyFarm familyFarm = new PPLFamilyFarm();
    private SuperannuationFundExemption superannuationFundExemption = new SuperannuationFundExemption();



    public Concession() {}

    public Concession(ConcessionType concessioinType) {
        this.concessionType = concessioinType;
    }

    public ConcessionType getConcessionType() {
        return concessionType;
    }

    public void setConcessionType(ConcessionType concessionType) {
        this.concessionType = concessionType;
    }

    public PPLFamilyFarm getFamilyFarm() {
        return familyFarm;
    }

    public void setFamilyFarm(PPLFamilyFarm familyFarm) {
        this.familyFarm = familyFarm;
    }

    public SuperannuationFundExemption getSuperannuationFundExemption() {
        return superannuationFundExemption;
    }

    public void setSuperannuationFundExemption(SuperannuationFundExemption superannuationFundExemption) {
        this.superannuationFundExemption = superannuationFundExemption;
    }
}
