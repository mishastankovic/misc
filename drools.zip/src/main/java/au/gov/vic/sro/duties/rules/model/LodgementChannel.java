package au.gov.vic.sro.duties.rules.model;

public enum LodgementChannel {
    ELM,
    ELNO,
    EMAIL
}
