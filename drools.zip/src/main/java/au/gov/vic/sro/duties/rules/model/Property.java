package au.gov.vic.sro.duties.rules.model;

import java.util.ArrayList;
import java.util.List;

public class Property  {

	private PropertyType propertyType;
	private Boolean intendedToBecomeResidential;
	private List<LandIdentifier> landIdentifierList = new ArrayList<LandIdentifier>();

	public PropertyType getPropertyType() {
		return propertyType;
	}

	public void setPropertyType(PropertyType propertyType) {
		this.propertyType = propertyType;
	}

	public Boolean getIntendedToBecomeResidential() {
		return intendedToBecomeResidential;
	}

	public void setIntendedToBecomeResidential(Boolean intendedToBecomeResidential) {
		this.intendedToBecomeResidential = intendedToBecomeResidential;
	}

	public List<LandIdentifier> getLandIdentifierList() {
		return landIdentifierList;
	}

}
