package au.gov.vic.sro.duties.rules.model;

public class Transferor extends AbstractTransferParty {

	private Long partyId;

	private Boolean remainingOnTitle;

	private Trust trust = new Trust();

	public Long getPartyId() {
		return partyId;
	}

	public void setPartyId(Long partyId) {
		this.partyId = partyId;
	}

	public Boolean getRemainingOnTitle() {
		return remainingOnTitle;
	}

	public void setRemainingOnTitle(Boolean remainingOnTitle) {
		this.remainingOnTitle = remainingOnTitle;
	}

	public Trust getTrust() {
		return trust;
	}

	public void setTrust(Trust trust) {
		this.trust = trust;
	}


}
