package au.gov.vic.sro.duties.rules.model;

public class LandIdentifier {
	private Long landIdentifierId;
	private LandIdentifierType landIdentifierType;
	private String lot;
	private String plan;
	private String volume;
	private String folio;
	private String bookNumber;
	private String memorial;
	private String crownAllotment;

	public Long getLandIdentifierId() {
		return landIdentifierId;
	}

	public void setLandIdentifierId(Long landIdentifierId) {
		this.landIdentifierId = landIdentifierId;
	}

	public LandIdentifierType getLandIdentifierType() {
		return landIdentifierType;
	}

	public void setLandIdentifierType(LandIdentifierType landIdentifierType) {
		this.landIdentifierType = landIdentifierType;
	}

	public String getLot() {
		return lot;
	}

	public void setLot(String lot) {
		if (lot != null) lot = lot.toUpperCase();
		this.lot = lot;
	}

	public String getPlan() {
		return plan;
	}

	public void setPlan(String plan) {
		if (plan != null) plan = plan.toUpperCase();
		this.plan = plan;
	}

	public String getVolume() {
		return volume;
	}

	public void setVolume(String volume) {
		if (volume != null) volume = volume.toUpperCase();
		this.volume = volume;
	}

	public String getFolio() {
		return folio;
	}

	public void setFolio(String folio) {
		if (folio != null) folio = folio.toUpperCase();
		this.folio = folio;
	}

	public String getBookNumber() {
		return bookNumber;
	}

	public void setBookNumber(String bookNumber) {
		this.bookNumber = bookNumber;
	}

	public String getMemorial() {
		return memorial;
	}

	public void setMemorial(String memorial) {
		this.memorial = memorial;
	}

	public String getCrownAllotment() {
		return crownAllotment;
	}

	public void setCrownAllotment(String crownAllotment) {
		this.crownAllotment = crownAllotment;
	}

	public boolean isNew() {
		return this.landIdentifierId == null;
	}


}
