package au.gov.vic.sro.duties.rules.model;

public class Trust {

	private String trustName;

	private Boolean foreignTrust;

	private TrustType trustType;

	private String trustTypeDetail;

	public String getTrustName() {
		return trustName;
	}

	public void setTrustName(String trustName) {
		this.trustName = trustName;
	}

	public Boolean getForeignTrust() {
		return foreignTrust;
	}

	public void setForeignTrust(Boolean foreignTrust) {
		this.foreignTrust = foreignTrust;
	}

	public TrustType getTrustType() {
		return trustType;
	}

	public void setTrustType(TrustType trustType) {
		this.trustType = trustType;
	}

	public boolean isOtherTrustType() {
		return trustType == TrustType.OTHER;
	}

	public String getTrustTypeDetail() {
		return trustTypeDetail;
	}

	public void setTrustTypeDetail(String trustTypeDetail) {
		this.trustTypeDetail = trustTypeDetail;
	}

}
