package au.gov.vic.sro.duties.rules.model;

public enum PersonTitle {
	MS("Ms", "Ms"),
	MR("Mr", "Mr"),
	MRS("Mrs", "Mrs"),
	MISS("Miss", "Miss"),
	DR("Doctor", "Doctor"),
	ABBOT("Abbot", "Abbot"),
	AB("Able Seaman", "Able Seaman"),
	ADML("Admiral", "Admiral"),
	ACM("Air Chief Marshal", "Air Chief Marshal"),
	AIRCDRE("Air Commodore", "Air Commodore"),
	AM("Air Marshal", "Air Marshal"),
	AVM("Air Vice Marshal", "Air Vice Marshal"),
	AC("Aircraftman", "Aircraftman"),
	ACW("Aircraftwoman", "Aircraftwoman"),
	ALD("Alderman", "Alderman"),
	AMBSR("Ambassador", "Ambassador"),
	ARCHBISHOP("Archbishop", "Archbishop"),
	ARCHDEACON("Archdeacon", "Archdeacon"),
	ASSOC_PROF("Associate Professor", "Associate Professor"),
	BARON("Baron", "Baron"),
	BARONESS("Baroness", "Baroness"),
	BISHOP("Bishop", "Bishop"),
	BDR("Bombardier", "Bombardier"),
	BRIG("Brigadier", "Brigadier"),
	BR("Brother", "Brother"),
	CDT("Cadet", "Cadet"),
	CANON("Canon", "Canon"),
	CAPT("Captain", "Captain"),
	CARDNL("Cardinal", "Cardinal"),
	CHAP("Chaplain", "Chaplain"),
	CPO("Chief Petty Officer", "Chief Petty Officer"),
	COL("Colonel", "Colonel"),
	CMDR("Commander", "Commander"),
	CMM("Commissioner", "Commissioner"),
	CDRE("Commodore", "Commodore"),
	CONST("Constable", "Constable"),
	CONSUL("Consul", "Consul"),
	CPL("Corporal", "Corporal"),
	COUNT("Count", "Count"),
	COUNTESS("Countess", "Countess"),
	DAME("Dame", "Dame"),
	DEACON("Deacon", "Deacon"),
	DEACONESS("Deaconess", "Deaconess"),
	DEAN("Dean", "Dean"),
	DEPUTY_SUPT("Deputy Superintendent", "Deputy Superintendent"),
	DIRECTOR("Director", "Director"),
	EARL("Earl", "Earl"),
	ENGR("Engineer", "Engineer"),
	FR("Father", "Father"),
	FLTLT("Flight Lieutenant", "Flight Lieutenant"),
	FSGT("Flight Sergeant", "Flight Sergeant"),
	FLGOFF("Flying Officer", "Flying Officer"),
	GEN("General", "General"),
	GOV("Governor", "Governor"),
	GP_CAPT("Group Captain", "Group Captain"),
	HON("Honourable", "Honourable"),
	JUDGE("Judge", "Judge"),
	JUSTICE("Justice", "Justice"),
	LADY("Lady", "Lady"),
	LBDR("Lance Bombardier", "Lance Bombardier"),
	LCPL("Lance Corporal", "Lance Corporal"),
	LAC("Leading Aircraftman", "Leading Aircraftman"),
	LACW("Leading Aircraftwoman", "Leading Aircraftwoman"),
	LS("Leading Seaman", "Leading Seaman"),
	LT("Lieutenant (Army)", "Lieutenant (Army)"),
	LEUT("Lieutenant (Navy)", "Lieutenant (Navy)"),
	LTCOL("Lieutenant Colonel", "Lieutenant Colonel"),
	LTCDR("Lieutenant Commander", "Lieutenant Commander"),
	LTGEN("Lieutenant General", "Lieutenant General"),
	LTGOV("Lieutenant Governor", "Lieutenant Governor"),
	LORD("Lord", "Lord"),
	MADAM("Madam", "Madam"),
	MADAME("Madame", "Madame"),
	MAJ("Major", "Major"),
	MAJGEN("Major General", "Major General"),
	MGR("Manager", "Manager"),
	MSTR("Master", "Master"),
	MAYOR("Mayor", "Mayor"),
	MAYORESS("Mayoress", "Mayoress"),
	MIDN("Midshipman", "Midshipman"),
	MON("Monsignor", "Monsignor"),
	MOST_REV("Most Reverend", "Most Reverend"),
	MTHR("Mother", "Mother"),
	NURSE("Nurse", "Nurse"),
	OCDT("Officer Cadet", "Officer Cadet"),
	PASTOR("Pastor", "Pastor"),
	PO("Petty Officer", "Petty Officer"),
	PLTOFF("Pilot Officer", "Pilot Officer"),
	PTE("Private", "Private"),
	PROF("Professor", "Professor"),
	RABBI("Rabbi", "Rabbi"),
	RADM("Rear Admiral", "Rear Admiral"),
	RECTOR("Rector", "Rector"),
	RSM_A("Regimental Sergeant-Major of the Army", "Regimental Sergeant-Major of the Army"),
	REV("Reverend", "Reverend"),
	RTHON("Right Honourable", "Right Honourable"),
	RT_REV("Right Reverend", "Right Reverend"),
	SMN("Seaman", "Seaman"),
	SECOND_LT("Second Lieutenant", "Second Lieutenant"),
	SEN("Senator", "Senator"),
	SNR("Senior", "Senior"),
	SGT("Sergeant", "Sergeant"),
	SIR("Sir", "Sir"),
	SR("Sister", "Sister"),
	SISTER_SUP("Sister Superior", "Sister Superior"),
	SQNLDR("Squadron Leader", "Squadron Leader"),
	SCDT("Staff Cadet", "Staff Cadet"),
	SSGT("Staff Sergeant", "Staff Sergeant"),
	SM("Station Master", "Station Master"),
	SBLT("Sublieutenant", "Sublieutenant"),
	SUPT("Superintendent", "Superintendent"),
	SWAMI("Swami", "Swami"),
	VADM("Vice Admiral", "Vice Admiral"),
	VCE_CMNDR("Vice Commander", "Vice Commander"),
	VISCOUNT("Viscount", "Viscount"),
	WOFF("Warrant Officer (Air Force)", "Warrant Officer (Air Force)"),
	WO("Warrant Officer (Navy)", "Warrant Officer (Navy)"),
	WO1("Warrant Officer Class 1", "Warrant Officer Class 1"),
	WO2("Warrant Officer Class 2", "Warrant Officer Class 2"),
	WOFF_AF("Warrant Officer of the Air Force", "Warrant Officer of the Air Force"),
	WO_N("Warrant Officer of the Navy", "Warrant Officer of the Navy"),
	WCDR("Wing Commander", "Wing Commander");

	private String code;
	private String label;

	private PersonTitle(String code, String label) {
		this.code = code;
		this.label = label;
	}

	public String getCode() {
		return code;
	}

	public String getLabel() {
		return label;
	}

	public static PersonTitle getPersonTitleByCode(String code) {
		for (PersonTitle personTitle : PersonTitle.values()) {
			if (personTitle.getCode().equals(code)) {
				return personTitle;
			}
		}

		return null;
	}

}
