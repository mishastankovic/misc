package au.gov.vic.sro.duties.rules.model;

import java.util.ArrayList;
import java.util.List;

import static au.gov.vic.sro.duties.rules.model.ConcessionGroupType.OTHER_COMPLEX;
import static au.gov.vic.sro.duties.rules.model.ConcessionGroupType.OTHER_SIMPLE;
import static au.gov.vic.sro.duties.rules.model.ConcessionGroupType.SPOUSAL;
import static au.gov.vic.sro.duties.rules.model.ConcessionGroupType.TRANSACTION;

public enum ConcessionType {

	SPOUSES_DOMESTIC_PARTNERS_LOVE("Transfer between spouses or domestic partners - love and affection", "1", SPOUSAL),
	SPOUSES_DOMESTIC_PARTNERS_BREAKDOWN(
			"Transfer between spouses or domestic partners - breakdown of relationship", "2", SPOUSAL),
	PPR("Principal place of residence concession", "3", ConcessionGroupType.PPR),
	FIRST_HOME_BUYER_DUTY_REDUCTION("First home buyer duty concession or exemption", "4",
			ConcessionGroupType.PPR),
	FIRST_HOME_OWNER_CONCESSION("First home owner with dependent children concession", "5",
			ConcessionGroupType.PPR),
	PENSIONER_CONCESSION("Pensioner concession", "6", ConcessionGroupType.PPR),
	PPL_DISAGGREGATION_GOODS_WATER_ENTITLEMENT("Primary production land - disaggregation, goods and water entitlements",
			"7", OTHER_COMPLEX),
	FAMILY_FARM_EXEMPTION("Family farm exemption", "8", OTHER_COMPLEX),
	YOUNG_FARMER_EXEMPTION_OR_CONCESSION("Young farmer exemption or concession", "9", OTHER_COMPLEX),
	EXEMPT_BODIES_GOVERNMENT_BODIES_DIPLOMATS("Exempt bodies - government bodies and diplomats", "10", OTHER_SIMPLE),
	EXEMPT_BODIES_STATUTORY_BODIES("Exempt bodies - statutory bodies", "11", OTHER_SIMPLE),
	EXEMPT_BODIES_CHARITABLE("Exempt bodies - charitable", "12", OTHER_SIMPLE),
	EXEMPT_BODIES_HEALTH_CENTRE_SERVICES("Exempt bodies - health centre and services", "13", OTHER_SIMPLE),
	EXEMPTION_OR_CONCESSION_FOR_SUPERANNUATION_FUND("Exemption or concession for superannuation fund", "14",
			TRANSACTION),
	EXEMPTION_BANKRUPTCY("Exemption - bankruptcy", "15", OTHER_SIMPLE),
	DECEASED_ESTATE_EXEMPTION_AND_CONCESSION("Deceased estate exemption and concession", "16", OTHER_SIMPLE),
	TRANSFEREE_IMPROVEMENT_DEDUCTION("Transferee’s improvement deduction", "17", OTHER_SIMPLE),
	CHANGE_OF_TRUSTEES("Change of trustees", "18", OTHER_SIMPLE),
	TRANSFER_FROM_TRUST_TO_BENEFICIARIES("Transfer from trust to beneficiaries", "19", OTHER_SIMPLE),
	DISABILITY_TRUST_EXEMPTION_OR_CONCESSION("Disability trust exemption or concession", "20", OTHER_SIMPLE),
	TRANSFER_TO_AND_FROM_TRUSTEE_OR_NOMINEE("Transfer to and from trustee or nominee", "21", OTHER_SIMPLE),
	TRANSFER_FROM_APPARENT_PURCHASER_TO_REAL_PURCHASER("Transfer from apparent purchaser to real purchaser", "22",
			OTHER_SIMPLE),
	EQUITY_RELEASE_PROGRAMME("Equity release programme", "23", OTHER_SIMPLE),
	PARTITION_AND_NICO("Partition and NICO", "24", OTHER_SIMPLE),
	CORRECTION_OF_ERROR("Correction of error", "25", OTHER_SIMPLE),
	EXEMPTION_FOR_DUTIABLE_TRANSACTION_EFFECTED_ON_MORE_THAN_ONE_INSTRUMENT(
			"Exemption for dutiable transaction effected on more than one instrument", "26", OTHER_SIMPLE),
	CHANGE_IN_MANNER_OF_HOLDING("Change in manner of holding", "27", OTHER_SIMPLE),
	SHARIAH_FINANCING("Shariah financing", "28", OTHER_SIMPLE),
	CONVERSION_OF_LAND_USE_ENTITLEMENT("Conversion of land use entitlement", "29", OTHER_SIMPLE),
	FOREIGN_PURCHASER_ADDITIONAL_DUTY_EXEMPTION("Foreign purchaser additional duty exemption", "30", OTHER_COMPLEX),
	CORPORATE_RECONSTRUCTION_CONSOLIDATION_CONCESSION("Corporate reconstruction or consolidation concession", "33",
			TRANSACTION),
	REGIONAL_COMMERCIAL_INDUSTRIAL_CONCESSION("Regional commercial and industrial concesssion", "32", TRANSACTION),
	OTHER("Other", "31", OTHER_SIMPLE);

	private String label;
	private String code;
	private ConcessionGroupType groupType;

	ConcessionType(String label, String code, ConcessionGroupType groupType) {
		this.label = label;
		this.code = code;
		this.groupType = groupType;
	}

	public String getCode() {
		return code;
	}

	public boolean isOneOf(List<ConcessionType> items) {
		for (ConcessionType item : items) {
			if (item == this) return true;
		}
		return false;
	}

	public boolean isOneOf(ConcessionGroupType concessionExemptionsGroupType) {
		return isOneOf(getConcessionExemptionsTypesByGroup(concessionExemptionsGroupType));
	}

	public String getLabel() {
		return label;
	}

	public boolean isOther() {
		return isOneOf(OTHER_SIMPLE);
	}

	public boolean isTransactionLevelConcessionExemption() {
		return this.isOther() || this == PPR || this.isOneOf(TRANSACTION);
	}

	public static List<ConcessionType> getConcessionExemptionsTypesByGroup(
			ConcessionGroupType groupType) {
		List<ConcessionType> list = new ArrayList<ConcessionType>();

		for (ConcessionType concessionExemptionsType : ConcessionType.values()) {
			if (concessionExemptionsType.getGroupType().equals(groupType)) {
				list.add(concessionExemptionsType);
			}
		}

		return list;
	}

	public static ConcessionType fromCode(String code) {
		if (code == null) throw new NullPointerException("Null code passed");

		for (ConcessionType value : ConcessionType.values()) {
			if (value.getCode().equals(code)) {
				return value;
			}
		}

		throw new IllegalArgumentException(String.format(
				"Could not find ConcessionExemptionsType Enum to match passed value: %s", code));
	}

	public ConcessionGroupType getGroupType() {
		return groupType;
	}

	public void setGroupType(ConcessionGroupType groupType) {
		this.groupType = groupType;
	}

}
