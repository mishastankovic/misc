package au.gov.vic.sro.duties.rules.model;

public enum TrustType {

	FIXED("Fixed", "1"),
	UNIT("Unit", "2"),
	DISCRETIONARY("Discretionary", "3"),
	SELF_MANAGED_SUPERANNUATION_FUND("Self managed superannuation fund", "4"),
	SUPERANNUATION_FUND("Superannuation fund", "5"),
	PUBLIC_UNIT_TRUST("Public Unit Trust", "6"),
	WHOLESALE_UNIT_TRUST("Wholesale Unit Trust", "7"),
	OTHER("Other", "8");

	private String label;
	private String code;

	TrustType(String label, String code) {
		this.label = label;
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public String getLabel() {
		return label;
	}
}
