package au.gov.vic.sro.duties.rules.model;

import java.util.Date;

public class NaturalPerson {

	private PersonName personName = new PersonName();

	private Date dateOfBirth;

	private String mobileNumber;

	private String emailAddress;

	private String abn;

	private Boolean foreignNaturalPerson;

	private ForeignNationalDetails foreignNationalDetails = new ForeignNationalDetails();

	public PersonName getPersonName() {
		return personName;
	}

	public void setPersonName(PersonName personName) {
		this.personName = personName;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getAbn() {
		return abn;
	}

	public void setAbn(String abn) {
		this.abn = abn;
	}

	public Boolean getForeignNaturalPerson() {
		return foreignNaturalPerson;
	}

	public void setForeignNaturalPerson(Boolean foreignNaturalPerson) {
		this.foreignNaturalPerson = foreignNaturalPerson;
	}

	public ForeignNationalDetails getForeignNationalDetails() {
		return foreignNationalDetails;
	}

	public void setForeignNationalDetails(ForeignNationalDetails foreignNationalDetails) {
		this.foreignNationalDetails = foreignNationalDetails;
	}

	public boolean determineIsForeignNaturalPerson() {
		return Boolean.TRUE.equals(getForeignNaturalPerson());
	}
}
