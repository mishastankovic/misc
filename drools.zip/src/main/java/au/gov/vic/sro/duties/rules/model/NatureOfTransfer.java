package au.gov.vic.sro.duties.rules.model;

public enum NatureOfTransfer {
}
