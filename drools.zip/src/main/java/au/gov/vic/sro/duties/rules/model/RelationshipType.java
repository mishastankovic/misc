package au.gov.vic.sro.duties.rules.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public enum RelationshipType {

	BloodRelatives("Blood relatives", "Blood relatives", "1"),
	LegalRelatives("Legal relatives", "Legal relatives", "2"),
	Spouses("Spouses", "Spouses", "3"),
	DomesticPartners("Domestic partners", "Domestic partners", "4"),
	ParentChild("Parent/child", "Parent/child", "5"),
	GrandparentGrandchild("Grandparent/grandchild", "Grandparent/grandchild", "6"),
	Siblings("Siblings/partner's sibling", "Sibling/partner's sibling", "SI"),
	AuntUncleNieceNephew("Aunt/uncle - Niece/nephew", "Aunt/uncle - Niece/nephew", "8"),
	Cousins("Cousins", "Cousins", "10"),
	AdoptedOrStepChildrenAndTheirParents("Parents/adopted or step children",
			"Parents/adopted or step children", "11"),
	DomesticRelationshipOrFriends("People related by a domestic relationship or friends",
			"People related by a domestic relationship or friends", "12"),
	BusinessRelationships("Business relationships including partnerships and companies who are related by common shareholders/directors",
			"Business relationships including partnerships and companies who are related by common shareholders/directors", "13");

	private String label;
	private String shortLabel;
	private String oracleCode;

	RelationshipType(String label, String shortLabel, String code) {
		this.label = label;
		this.shortLabel = shortLabel;
		this.oracleCode = code;
	}

	public boolean isOneOf(RelationshipType... values) {
		for (RelationshipType value : values)
			if (value == this) return true;
		return false;
	}

	public static List<RelationshipType> getList() {
		List<RelationshipType> list = new ArrayList<RelationshipType>();
		list.addAll(Arrays.asList(new RelationshipType[] { BloodRelatives, LegalRelatives,
				Spouses, DomesticPartners, ParentChild, GrandparentGrandchild, Siblings,
				AuntUncleNieceNephew, Cousins, AdoptedOrStepChildrenAndTheirParents, 
				DomesticRelationshipOrFriends, BusinessRelationships }));
		return list;
	}

	public String getLabel() {
		return label;
	}

	public String getShortLabel() {
		return shortLabel;
	}

	public String getOracleCode() {
		return oracleCode;
	}

	public static RelationshipType fromOracleCode(String code) {

		if (code == null) throw new NullPointerException("Null code passed");

		for (RelationshipType value : RelationshipType.values()) {
			if (value.getOracleCode().equals(code)) {
				return value;
			}
		}

		throw new IllegalArgumentException(String.format(
				"Could not find RelationshipType Enum to match passed value: %s", code));

	}
}
