package au.gov.vic.sro.duties.rules.model;

public class RelatedParty {

	private Boolean relatedParty;

	private RelationshipType relationshipType;

	public Boolean getRelatedParty() {
		return relatedParty;
	}

	public void setRelatedParty(Boolean relatedParty) {
		this.relatedParty = relatedParty;
	}

	public RelationshipType getRelationshipType() {
		return relationshipType;
	}

	public void setRelationshipType(RelationshipType relationshipType) {
		this.relationshipType = relationshipType;
	}

	public boolean isRelationshipTypeRendered() {
		return Boolean.TRUE.equals(relatedParty);
	}
	

}
