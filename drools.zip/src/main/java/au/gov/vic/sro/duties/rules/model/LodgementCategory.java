package au.gov.vic.sro.duties.rules.model;

public enum LodgementCategory {
	ADJUSTMENT_TO_DUTIABLE_VALUE,
	AGGREGATION,
	BANKRUPTCY_MATTERS,
	CHANGE_IN_THE_MANNER_OF_HOLDING_EQUAL_SHARES,
	DECEASED_ESTATE_TRANSFERS,
	HISTORICAL_TERMS_CONTRACTS,
	ON_SALES,
	OTHER,
	PARTITION_OR_NICO,
	PRIMARY_PRODUCTION_LAND,
	REALIGNMENT_OF_BOUNDARIES,
	REGIONAL_COMMERCIAL_INDUSTRIAL_CONCESSION,
	SALE_OF_BUSINESS_OR_GOODS,
	SPOUSE_OR_DOMESTIC_PARTNER_TRANSFER,
	SUBSALE,
	TRANSFER_TO_SUPERFUNDS,
	TRANSFER_TO_RELATED_PARTY,
	TRANSFER_TO_AN_APPROVED_CHARITY,
	TRANSFER_TO_PARTIES_THAT_ARE_NOT_RELATED_OR_ASSOCIATED,
	TRUST_EXEMPTIONS_AND_CONCESSIONS

	/*		
	CHANGE_IN_THE_MANNER_OF_HOLDING("Change in the manner of holding", "108"),
	DECEASED_ESTATE("Deceased estate", "109"),
	FAMILY_FARM_EXEMPTION_PRIMARY_PRODUCTION("Family farm exemption/primary production", "107"),
	GIFT_BETWEEN_RELATED_PARTIES("Gift between related parties", "102"),
	OTHER("Other (land transfer)", "110"),
	TRANSFER_BETWEEN_RELATED_PARTIES_WITH_CONCESSION("Transfer between related parties with concessions ", "105"),
	TRANSFER_BETWEEN_RELATED_PARTIES_WITHOUT_CONCESSION("Transfer between related parties without concessions", "103"),
	TRANSFER_BETWEEN_SPOUSES("Transfer between spouses", "101"),
	TRANSFER_BETWEEN_UNRELATED_PARTIES_WITH_CONCESSION("Transfer between unrelated parties with concessions", "106"),
	TRANSFER_BETWEEN_UNRELATED_PARTIES_WITHOUT_CONCESSION("Transfer between unrelated parties without concessions",
			"104"),

	//!!!!!!!!!! new categories below that do not exist in DutiesForm at present. Check esys database as well.
	PARTITION_OR_NICO("Partitioning or NICO", "10001"),
	TRUST_EXEMPTION("Trust exemption and concession", "10002"),
	BANKRUPTCY_MATTERS("Bankruptcy Matters", "10003"),
	TRANSFER_TO_SUPERFUND("Transfer to superfund", "10004"),
	TRANSFER_TO_APPROVED_CHARITY_GOVERNMENT_BODY_OR_AUTHORITY("Transfer to an approved Charity, Government Body or Authority", "10005"),
	PRIMARY_PRODUCTION_LAND_YOUNG_FAMILY_EXEMPTION("Primary Production Land – Young Farmers Exemption", "10006"),
	TRANSFEREE_IMPROVEMENT("Adjustment to Dutiable Value – Transferee Improvements", "10007"),
	NO_DOUBLE_DUTY("Adjustment to Dutiable Value – No Double Duty", "1008"),
	SUBSALE_OR_NOMINATION_TRANSFERS("Sub-Sale and/or Nomination transfers", "1009"),
	SALE_OF_BUSINESS_OR_GOODS("Sale of Business or Goods","1010"),
	AGGREGATION("Aggregation","1011"),
	CHANGE_IN_THE_MANNER_OF_HOLDING_MORE_THAN_TWO_PARTIES("Change in the manner of holding - more than two parties", "1012"),
	SUBSALE_OR_NOMINATION_TRANSFERS_OPTIONS_ADDITIONAL_CONSIDERATION_NOT_INCLUDED(
			"Sub-sale and/or Nomination transfer - Options, Additional Development and/or Consideration not included in the contract price", "1013")

	;

	private String label;
	private String oracleDbValue;

	private LodgementCategory(String label, String oracleDbValue) {
		this.label = label;
		this.oracleDbValue = oracleDbValue;
	}

	public String getLabel() {
		return label;
	}

	public String getOracleDbValue() {
		return oracleDbValue;
	}

	public static LodgementCategory findByOracleDbValue(String oracleDbValue) {
		for (LodgementCategory lodgementCategoryType : LodgementCategory.values()) {
			if (lodgementCategoryType.getOracleDbValue().equals(oracleDbValue)) {
				return lodgementCategoryType;
			}
		}
		return null;
	}

	public static LodgementCategory findByLabel(String label) {
		for (LodgementCategory lodgementCategoryType : LodgementCategory.values()) {
			if (lodgementCategoryType.getLabel().equals(label)) {
				return lodgementCategoryType;
			}
		}
		return null;
	}
	*/

}
