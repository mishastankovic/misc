package au.gov.vic.sro.duties.rules.model;

public abstract class AbstractParty {

	private PartyType partyType;

	private NaturalPerson naturalPerson = new NaturalPerson();

	private Organisation organisation = new Organisation();

	private Integer version;

	public abstract Long getPartyId();

	public abstract void setPartyId(Long partyId);

	public PartyType getPartyType() {
		return partyType;
	}

	public void setPartyType(PartyType partyType) {
		this.partyType = partyType;
	}

	public NaturalPerson getNaturalPerson() {
		return naturalPerson;
	}

	public void setNaturalPerson(NaturalPerson naturalPerson) {
		this.naturalPerson = naturalPerson;
	}

	public Organisation getOrganisation() {
		return organisation;
	}

	public void setOrganisation(Organisation organisation) {
		this.organisation = organisation;
	}

	public boolean isCompanyOrganisationAssociation() {
		return partyType != null && partyType.isCompanyOrganisationAssociation();
	}

	public boolean isOrganisationAssociation() {
		return partyType != null && partyType.isOrganisationAssociation();
	}

	public boolean isIndividual() {
		return partyType != null && partyType.isIndividual();
	}

	public boolean isIndividualOther() {
		return partyType != null && partyType == PartyType.INDIVIDUAL_OTHER;
	}

}
