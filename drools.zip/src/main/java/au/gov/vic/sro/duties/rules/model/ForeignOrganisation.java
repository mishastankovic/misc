package au.gov.vic.sro.duties.rules.model;

public class ForeignOrganisation {

	private CountryType countryOfIncorporation;

	private String overseasEntityRegNumber;

	private String firbApplicationNumber;

	public CountryType getCountryOfIncorporation() {
		return countryOfIncorporation;
	}

	public void setCountryOfIncorporation(CountryType countryOfIncorporation) {
		this.countryOfIncorporation = countryOfIncorporation;
	}

	public String getOverseasEntityRegNumber() {
		return overseasEntityRegNumber;
	}

	public void setOverseasEntityRegNumber(String overseasEntityRegNumber) {
		this.overseasEntityRegNumber = overseasEntityRegNumber;
	}

	public String getFirbApplicationNumber() {
		return firbApplicationNumber;
	}

	public void setFirbApplicationNumber(String firbApplicationNumber) {
		this.firbApplicationNumber = firbApplicationNumber;
	}

}
