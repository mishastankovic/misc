package au.gov.vic.sro.duties.rules.model;

import java.math.BigDecimal;

public class OffThePlan {

	private Long offThePlanId;
	private Long dutiesFormId;
	private Boolean offThePlanConcessionSubjected;
	private BigDecimal transactionGst;
	private DeductionType deductionType;
	private BigDecimal contractPrice;
	private boolean isReadOnlyLessTheTotalGst;
	private OffThePlanMethod offThePlanMethod = new OffThePlanMethod();
	private Integer version;

	// used as a temporary id
	private String id;

	public OffThePlan() {
	}

	public OffThePlan(BigDecimal contractPrice) {
		this();
		this.contractPrice = contractPrice;
	}

	public boolean isReadOnlyLessTheTotalGst() {
		return isReadOnlyLessTheTotalGst;
	}

	public void setReadOnlyLessTheTotalGst(boolean readOnlyLessTheTotalGst) {
		isReadOnlyLessTheTotalGst = readOnlyLessTheTotalGst;
	}

	public Long getOffThePlanId() {
		return offThePlanId;
	}

	public void setOffThePlanId(Long offThePlanId) {
		this.offThePlanId = offThePlanId;
	}

	public Long getDutiesFormId() {
		return dutiesFormId;
	}

	public void setDutiesFormId(Long dutiesFormId) {
		this.dutiesFormId = dutiesFormId;
	}

	public BigDecimal getContractPrice() {
		return contractPrice;
	}

	public void setContractPrice(BigDecimal contractPrice) {
		this.contractPrice = contractPrice;
		if (offThePlanMethod != null)
			offThePlanMethod.setContractPrice(contractPrice);
	}

	public BigDecimal getTransactionGst() {
		return transactionGst;
	}

	public void setTransactionGst(BigDecimal transactionGst) {
		this.transactionGst = transactionGst;
		if (offThePlanMethod != null)
			offThePlanMethod.setTransactionGST(transactionGst);
	}

	public void transactionContractExcludingGST(BigDecimal transactionContractExcludingGST) {
		if (offThePlanMethod != null)
			offThePlanMethod.setTransactionContractExcludingGST(transactionContractExcludingGST);
	}

	public Boolean getOffThePlanConcessionSubjected() {
		return offThePlanConcessionSubjected;
	}

	public void setOffThePlanConcessionSubjected(Boolean offThePlanConcessionSubjected) {
		this.offThePlanConcessionSubjected = offThePlanConcessionSubjected;
	}

	public MethodType getMethod() {
		return offThePlanMethod == null ? null : offThePlanMethod.getMethod();
	}

	public void setMethod(MethodType method) {
		if (method == null) {
			offThePlanMethod = new OffThePlanMethod();
		} else {
			if (offThePlanMethod == null)
				offThePlanMethod = new OffThePlanMethod();
			offThePlanMethod.setContractPrice(contractPrice);
			offThePlanMethod.setTransactionGST(transactionGst);
			offThePlanMethod.setMethod(method);
		}
	}

	public OffThePlanMethod getOffThePlanMethod() {
		return offThePlanMethod;
	}

	public void setOffThePlanMethod(OffThePlanMethod offThePlanMethod) {
		this.offThePlanMethod = offThePlanMethod;
	}


	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public String getId() {
		return offThePlanId == null ? id : offThePlanId.toString();
	}

	public DeductionType getDeductionType() {
		return deductionType;
	}

	public void setDeductionType(DeductionType deductionType) {
		this.deductionType = deductionType;
	}

	public BigDecimal getDutiableValue() {
		return Boolean.TRUE.equals(offThePlanConcessionSubjected) && offThePlanMethod != null ?
				offThePlanMethod.getDutiableValue() :
				null;
	}


	public OffThePlanMethod getFixedPercentage() {
		OffThePlanMethod offThePlanMethodFixedPercentage = null;
		if (determineIsOffThePlanConcessionSubjected() && determineIsMethodType()
				&& getOffThePlanMethod().getMethod() != MethodType.ALTERNATIVE)
			offThePlanMethodFixedPercentage = getOffThePlanMethod();
		return offThePlanMethodFixedPercentage;
	}

	public OffThePlanMethod getAlternativeMethod() {
		OffThePlanMethod alternativeMethod = null;
		if (determineIsOffThePlanConcessionSubjected() && determineIsMethodType()
				&& getOffThePlanMethod().getMethod() == MethodType.ALTERNATIVE)
			alternativeMethod = getOffThePlanMethod();
		return alternativeMethod;
	}

	public boolean determineIsOffThePlanConcessionSubjected() {
		return Boolean.TRUE.equals(getOffThePlanConcessionSubjected());
	}

	public boolean determineIsMethodType() {
		return determineIsOffThePlanConcessionSubjected() && getOffThePlanMethod() != null
				&& getOffThePlanMethod().getMethod() != null;
	}


}
