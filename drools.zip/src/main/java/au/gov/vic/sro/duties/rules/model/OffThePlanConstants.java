package au.gov.vic.sro.duties.rules.model;

import java.math.BigDecimal;

public interface OffThePlanConstants {

	static BigDecimal HUNDRED_PERCENT = new BigDecimal(100);
	static BigDecimal GST_PERCENTAGE = new BigDecimal(10);
	static BigDecimal INFRA_VALUE_PERCENTAGE_MIN = new BigDecimal(25);
}
