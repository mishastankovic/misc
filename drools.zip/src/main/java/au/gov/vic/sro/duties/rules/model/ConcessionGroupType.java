package au.gov.vic.sro.duties.rules.model;

import java.util.List;

public enum ConcessionGroupType {

	OTHER_COMPLEX("Other-Complex", "1"),
	OTHER_SIMPLE("Other", "2"),
	PPR("PPR", "3"),
	SPOUSAL("Spousal", "4"),
	TRANSACTION("Transaction", "5");

	private String label;
	private String code;

	ConcessionGroupType(String label, String code) {
		this.label = label;
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public boolean isOneOf(List<ConcessionGroupType> items) {
		for (ConcessionGroupType item : items) {
			if (item == this) return true;
		}
		return false;
	}

	public String getLabel() {
		return label;
	}

	public static ConcessionGroupType fromCode(String code) {
		if (code == null) throw new NullPointerException("Null code passed");

		for (ConcessionGroupType value : ConcessionGroupType.values()) {
			if (value.getCode().equals(code)) {
				return value;
			}
		}

		throw new IllegalArgumentException(String.format(
				"Could not find ConcessionExemptionsGroupType Enum to match passed value: %s", code));
	}

}
