package au.gov.vic.sro.duties.rules.model;

import org.apache.commons.lang3.StringUtils;

public class PersonName {

	private PersonTitle title;

	private String firstName;

	private String middleName;

	private String surname;

	private String previousName;

	private Integer acceptBlankSurname;

	private boolean surnameNotEntered;

	public PersonTitle getTitle() {
		return title;
	}

	public void setTitle(PersonTitle title) {
		this.title = title;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getPreviousName() {
		return previousName;
	}

	public void setPreviousName(String previousName) {
		this.previousName = previousName;
	}

	public boolean isAcceptBlankSurname() {
		return Integer.valueOf(1).equals(acceptBlankSurname);
	}

	public void setAcceptBlankSurname(boolean acceptBlankSurname) {
		this.acceptBlankSurname = acceptBlankSurname ? Integer.valueOf(1) : null;
	}

	public boolean isSurnameBlank() {
		return StringUtils.isBlank(firstName) && StringUtils.isBlank(surname);
	}
}
