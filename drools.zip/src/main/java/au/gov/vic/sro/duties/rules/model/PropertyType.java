package au.gov.vic.sro.duties.rules.model;

public enum PropertyType {

	// @formatter:off
	ResidentialPrivateDwelling(
			"Residential - private dwelling", 
			"RPD"),
	ResidentialVacantLand(
			"Residential - vacant land", 
			"RVL"),
	CommercialRetailPremises(
			"Commercial - retail premises", 
			"CRP"),
	CommercialVacantLand(
			"Commercial - vacant land", 
			"CVL"),
	ResidentialAndCommercialMixedUse(
			"Residential and commercial - mixed use", 
			"RCMU"),
	IndustrialWithBuilding(
			"Industrial - with building", 
			"IWB"),
	IndustrialVacantLand(
			"Industrial - vacant land", 
			"IVL"),
	PrimaryProductionWithBuildingImplementsStockOrWaterEntitlements(
			"Primary production with building, implements, stock or water entitlements",
			"PPB"),
	PrimaryProductionVacantLandWithNoImplementsStockOrWaterEntitlements(
			"Primary production - no concessions claimed",
			"PPVL"),
	AnyPropertyTypeWithWaterEntitlements(
			"Any property type - with water entitlements",
			"APT");
	// @formatter:on

	private String label;
	private String code;

	private PropertyType(String label, String code) {
		this.label = label;
		this.code = code;
	}

	public String getLabel() {
		return label;
	}

	public String getCode() {
		return code;
	}

	/*
	public boolean isOneOf(PropertyType... items) {
		for (PropertyType item : items) {
			if (item == this) return true;
		}
		return false;
	}

	public boolean isResidential() {
		return this == PropertyType.ResidentialPrivateDwelling || this == ResidentialVacantLand
				|| this == PropertyType.ResidentialAndCommercialMixedUse;
	}

	public static PropertyType fromCode(String code) {

		if (code == null) throw new NullPointerException("Null code type passed");

		for (PropertyType value : PropertyType.values()) {
			if (value.getCode().equals(code)) {
				return value;
			}
		}

		return null;
	}

	public static boolean isResidential(PropertyType propertyType) {
		return propertyType != null
				&& (propertyType == PropertyType.ResidentialPrivateDwelling || propertyType == ResidentialVacantLand || propertyType == PropertyType.ResidentialAndCommercialMixedUse);
	}
	*/

}
