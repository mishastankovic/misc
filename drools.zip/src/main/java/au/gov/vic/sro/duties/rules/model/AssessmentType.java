package au.gov.vic.sro.duties.rules.model;

public enum AssessmentType {
    MANUAL,
    SYSTEM,
    EXEMPT_FROM_DUTY,
    FULL_DUTY
}
