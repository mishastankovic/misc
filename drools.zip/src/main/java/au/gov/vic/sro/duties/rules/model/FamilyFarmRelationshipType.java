package au.gov.vic.sro.duties.rules.model;

public enum FamilyFarmRelationshipType {

	DomesticPartners("De facto/domestic partner", "1"),
	Spouses("Married spouse", "2"),
	ChildGrandchild("Child or Grandchild", "3"),
	ParentGrandParent("Parent or Grandparent", "4"),
	Siblings("Sibling or Partner's Sibling", "5"),
	AuntUncle("Uncle or Aunt", "6"),
	NieceNephew("Niece or Nephew", "7"),
	BeneficiaryFixedTrust("Beneficiary/relative of a beneficiary of a fixed trust", "8"),
	TrusteeFixedTrust("A trustee of a fixed trust - beneficiaries are natural persons and are a relative of each other",
			"9"),
	TrusteeDiscretionaryTrust(
			"A trustee of a discretionary trust - capital beneficiaries are natural persons and are a relative of each other",
			"10"),
	CharitableInstitution("Charitable institution", "11"),
	BusinessRelationships(
			"Business relationships including partnerships and companies who are related by common shareholders/directors",
			"12"),
	Other("Other", "13");

	private String label;
	private String code;

	private FamilyFarmRelationshipType(String label, String code) {
		this.label = label;
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public String getLabel() {
		return label;
	}

	public static FamilyFarmRelationshipType getByCode(String code) {
		if (code == null) throw new IllegalArgumentException("Null code passed");

		for (FamilyFarmRelationshipType value : FamilyFarmRelationshipType.values()) {
			if (value.getCode().equals(code)) {
				return value;
			}
		}

		throw new IllegalArgumentException(
				String.format("Could not find FamilyFarmRelationshipType Enum to match passed value: %s", code));
	}
}
