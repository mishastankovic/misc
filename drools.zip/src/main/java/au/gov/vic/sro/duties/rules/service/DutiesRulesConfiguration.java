package au.gov.vic.sro.duties.rules.service;

import org.kie.api.KieServices;
import org.kie.api.builder.KieBuilder;
import org.kie.api.builder.KieFileSystem;
import org.kie.api.builder.KieModule;
import org.kie.api.runtime.KieContainer;
import org.kie.internal.io.ResourceFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("au.gov.vic.sro.duties.rules.service")
public class DutiesRulesConfiguration {

    private String rulesFolder = "rules";
    private String[] drlFiles = {
        "DUTIES_RULES.drl",
        "SPOUSAL_TRANSFER.drl",
        "CHANGE_IN_THE_MANNER_OF_HOLDING.drl",
        "DECEASED_ESTATE.drl",
        "FAMILY_FARM.drl",
        "PRIMARY_PRODUCTION.drl",
        "SUB_SALE.drl",
        "RELATED_PARTIES.drl",
        "UNRELATED_PARTIES.drl",
        "SUPERFUND.drl"
    };

    @Bean
    public KieContainer kieContainer() {
        KieServices kieServices = KieServices.Factory.get();

        KieFileSystem kieFileSystem = kieServices.newKieFileSystem();
        for (String drlFile : drlFiles) {
            kieFileSystem.write(ResourceFactory.newClassPathResource(rulesFolder + "/" + drlFile));
        }
        KieBuilder kieBuilder = kieServices.newKieBuilder(kieFileSystem);
        kieBuilder.buildAll();
        KieModule kieModule = kieBuilder.getKieModule();

        return kieServices.newKieContainer(kieModule.getReleaseId());
        
    }
}
