package au.gov.vic.sro.duties.rules.model;

public enum PartyType {

	INDIVIDUAL_NATURAL_PERSON("Individual - natural person", "I"),
	INDIVIDUAL_OTHER("Individual - other", "O"),
	COMPANY("Company", "C"),
	ORGANISATION("Organisation", "R"),
	ASSOCIATION("Association", "A");

	private String label;
	private String code;

	PartyType(String label, String code) {
		this.label = label;
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public boolean isOneOf(PartyType... items) {
		for (PartyType item : items) {
			if (item == this) return true;
		}
		return false;
	}

	public String getLabel() {
		return label;
	}
	
	public String getLowerCaseLabel() {
		if(label != null) {
			return label.toLowerCase();
		}
		return label;
	}

	public boolean hasAbnOrAcn() {
		return this == PartyType.ASSOCIATION || this == PartyType.COMPANY || this == PartyType.INDIVIDUAL_OTHER
				|| this == PartyType.ORGANISATION;
	}

	public boolean isCompanyOrganisationAssociation() {
		return this == ASSOCIATION || this == ORGANISATION || this == PartyType.COMPANY;
	}

	public boolean isOrganisationAssociation() {
		return this == ASSOCIATION || this == ORGANISATION;
	}

	public boolean isIndividual() {
		return this == INDIVIDUAL_NATURAL_PERSON || this == INDIVIDUAL_OTHER;
	}

	public static PartyType fromCode(String code) {
		if (code == null) throw new NullPointerException("Null code passed");

		for (PartyType value : PartyType.values()) {
			if (value.getCode().equals(code)) {
				return value;
			}
		}

		throw new IllegalArgumentException(String.format("Could not find PartyType Enum to match passed value: %s",
				code));
	}

}
