package au.gov.vic.sro.duties.rules.service;

import au.gov.vic.sro.duties.rules.model.ConcessionType;
import au.gov.vic.sro.duties.rules.model.FormData;
import au.gov.vic.sro.duties.rules.model.LodgementChannel;
import au.gov.vic.sro.duties.rules.model.TransactionData;
import au.gov.vic.sro.duties.rules.model.TransactionType;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static org.junit.Assert.assertEquals;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = DutiesRulesConfiguration.class)
public class PrimaryProductionTest {

    @Autowired
    private DutiesRulesService dutiesRuleService;


	// Primary Production Switch
	@Test
	public void testRule_1() throws Exception {
        // given
        FormData formData = TestDataFixture.createFormDataWithConcessions(TransactionType.Other,
                new ConcessionType[]{ConcessionType.EQUITY_RELEASE_PROGRAMME});
        // when
        TransactionData transactionData = dutiesRuleService.formToTransactionData(formData);
        // then
        assertEquals(transactionData.getLodgementChannel(), LodgementChannel.EMAIL);
	}
    /*
	when
        TransactionData(lodgementCategory == LodgementCategory.PRIMARY_PRODUCTION_LAND) and
        $formData : FormData(transactionInvolvesProperty == TransferOfLandType.TRANSFER_OF_LAND &&
            transactionInvolvesTransaction == TransactionType.Other) and
        Property(propertyType == PropertyType.PrimaryProductionVacantLandWithNoImplementsStockOrWaterEntitlements) from $formData.properties and
        exists Concession(concessionType == ConcessionType.FAMILY_FARM_EXEMPTION) from $formData.concessions
    then
        txn.setRuleGroup(RuleGroup.FAMILY_FARM);
    end
	*/


	// Primary Production Land with no concessions claimed.
	@Test
	public void testRule_2() throws Exception {
	}
    /*
	when
        $formData : FormData() and
        exists Concession(concessionType == ConcessionType.PPR) from $formData.concessions and
        not Concession(concessionType == ConcessionType.PPL_DISAGGREGATION_GOODS_WATER_ENTITLEMENT) from $formData.concessions
    then
        txn.addSectionOfTheAct("s10(1)(a)&(d)");
        txn.setLodgementSubCategory("Primary Production Land without concessions");
    end
	*/


	// Primary Production Land with no concessions claimed. - Complex
	@Test
	public void testRule_3() throws Exception {
	}
    /*
	when
        $formData : FormData() and
        not Concession(concessionType == ConcessionType.PPR) from $formData.concessions and
        not Concession(concessionType == ConcessionType.PPL_DISAGGREGATION_GOODS_WATER_ENTITLEMENT) from $formData.concessions
    then
        txn.setAssessmentType(AssessmentType.MANUAL);
        txn.setLodgementSubCategory("Primary Production Land without concessions");
    end
	*/


	// Primary Production - Disaggregation, Water Entitlements, Goods and Livestock - Complex
	@Test
	public void testRule_4() throws Exception {
	}
    /*
	when
        $formData : FormData() and
        not Concession(concessionType == ConcessionType.PPR) from $formData.concessions and
        not Concession(concessionType == ConcessionType.PPL_DISAGGREGATION_GOODS_WATER_ENTITLEMENT) from $formData.concessions
    then
        txn.setAssessmentType(AssessmentType.MANUAL);
        txn.setLodgementSubCategory("Primary Production - Disaggregation, Water Entitlements, Goods and Livestock");
    end
	*/
	


}
