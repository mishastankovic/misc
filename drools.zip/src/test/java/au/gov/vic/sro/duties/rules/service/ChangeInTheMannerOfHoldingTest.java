package au.gov.vic.sro.duties.rules.service;

import au.gov.vic.sro.duties.rules.model.AssessmentType;
import au.gov.vic.sro.duties.rules.model.ConcessionType;
import au.gov.vic.sro.duties.rules.model.FormData;
import au.gov.vic.sro.duties.rules.model.LodgementCategory;
import au.gov.vic.sro.duties.rules.model.LodgementChannel;
import au.gov.vic.sro.duties.rules.model.OwnershipShare;
import au.gov.vic.sro.duties.rules.model.RuleGroup;
import au.gov.vic.sro.duties.rules.model.TransactionData;
import au.gov.vic.sro.duties.rules.model.TransactionType;
import au.gov.vic.sro.duties.rules.model.TransferOfLandType;
import au.gov.vic.sro.duties.rules.model.Transferee;
import au.gov.vic.sro.duties.rules.model.Transferor;
import org.eclipse.aether.spi.connector.Transfer;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = DutiesRulesConfiguration.class)
public class ChangeInTheMannerOfHoldingTest {

    @Autowired
    private DutiesRulesService dutiesRuleService;


    // Transferees equal shares
	@Test
	public void testRule_1() throws Exception {
        // given
        FormData formData = new FormData();
        addTransfereesWithEqualShares(formData, 2);
        // 	when
        TransactionData transactionData = dutiesRuleService.formToTransactionData(formData);
        // then
        assertTrue(transactionData.getTransfereesEqualShares());
	}
    /*
	when
    $formData: FormData() and
    not Transferee($formData.transferees != null &&
            transferRightsShare != null &&
            !transferRightsShare.sharesOwned.equals(transferRightsShare.totalShares / $formData.transferees.size())) from $formData.transferees
            then
        txn.setTransfereesEqualShares(true);
    end
	*/


    // Transferrors equal shares
	@Test
	public void testRule_2() throws Exception {
		// given
		FormData formData = new FormData();
		addTransferorsWithEqualShares(formData, 2);
		// 	when
		TransactionData transactionData = dutiesRuleService.formToTransactionData(formData);
		// then
		assertTrue(transactionData.getTransferorsEqualShares());
	}
    /*
	when
    $formData: FormData() and
    not Transferor($formData.transferors != null &&
            interestHolding != null && $formData.transferees != null &&
            !interestHolding.sharesOwned.equals(interestHolding.totalShares / $formData.transferors.size())) from $formData.transferors
            then
        txn.setTransferorsEqualShares(true);
    end
	*/


//
// Transaction flow rules
//

    // Change in the manner of holding lodgement category
	@Test
	public void testRule_3() throws Exception {
		// given
		FormData formData = TestDataFixture.createFormDataWithConcessions(TransactionType.ChangeInTheMannerOfHolding,
				new ConcessionType[]{});
		// 	when
		TransactionData transactionData = dutiesRuleService.formToTransactionData(formData);
		// then
		assertEquals(LodgementCategory.CHANGE_IN_THE_MANNER_OF_HOLDING_EQUAL_SHARES, transactionData.getLodgementCategory());
	}
    /*
	when
    TransactionData(lodgementChannel == LodgementChannel.ELNO);
    FormData(transactionInvolvesTransaction == TransactionType.ChangeInTheMannerOfHolding);
    then
        txn.setLodgementCategory(LodgementCategory.CHANGE_IN_THE_MANNER_OF_HOLDING_EQUAL_SHARES);
    end
	*/


    // Change in the manner of holding switch
	@Test
	public void testRule_4() throws Exception {

		// given
		FormData formData = createFormDataForChangeInTheMannerOfHolding();

		// 	when
		TransactionData transactionData = dutiesRuleService.formToTransactionData(formData);

		// then
		assertEquals(LodgementCategory.CHANGE_IN_THE_MANNER_OF_HOLDING_EQUAL_SHARES, transactionData.getLodgementCategory());
		assertEquals(RuleGroup.CHANGE_IN_THE_MANNER_OF_HOLDING, transactionData.getRuleGroup());
	}
    /*
	when
    TransactionData(lodgementCategory == LodgementCategory.CHANGE_IN_THE_MANNER_OF_HOLDING_EQUAL_SHARES) and
    FormData(transactionInvolvesProperty == TransferOfLandType.TRANSFER_OF_LAND &&
            mannerOfHoldingType == MannerOfHoldingType.ChangeInTheMannerOfHoldingToEqualShare )
    then
        txn.setRuleGroup(RuleGroup.CHANGE_IN_THE_MANNER_OF_HOLDING);
    end
	*/


    // Change in the manner of holding two parties in equal shares - 1
	@Test
	public void testRule_5() throws Exception {
		FormData formData = createFormDataForChangeInTheMannerOfHolding();
		addTransfereesWithEqualShares(formData, 1);
		addTransferorsWithEqualShares(formData, 1);

		// 	when
		TransactionData transactionData = dutiesRuleService.formToTransactionData(formData);

		// then
		assertEquals(LodgementCategory.CHANGE_IN_THE_MANNER_OF_HOLDING_EQUAL_SHARES, transactionData.getLodgementCategory());
		assertEquals(RuleGroup.CHANGE_IN_THE_MANNER_OF_HOLDING, transactionData.getRuleGroup());
		assertTrue(transactionData.getSectionsOfTheAct().contains("s54"));
		assertTrue(transactionData.getDolTransactionTypes().contains("9"));
		assertEquals(transactionData.getLodgementSubCategory(),"Change in the manner of holding two parties in equal shares (joint tenants in common or vice versa)");
	}
    /*
	when
    TransactionData(ruleGroup == RuleGroup.CHANGE_IN_THE_MANNER_OF_HOLDING) and
    TransactionData(transferorsEqualShares == true && transfereesEqualShares == true) and
    FormData(transferees != null && transferees.size() <= 2 && transferors != null && transferors.size() <= 2)
    then
        txn.addSectionOfTheAct("s54");
        txn.setDolTransactionTypes(new String[] {"9"});
        txn.setLodgementSubCategory("Change in the manner of holding two parties in equal shares (joint tenants in common or vice versa)");
    end
	*/


// TODO - Revisit within the Rleated Party flow
    // Change in the manner of holding two parties in equal shares - 2
	@Test
	public void testRule_6() throws Exception {
	}
    /*
	when
    TransactionData(ruleGroup == RuleGroup.CHANGE_IN_THE_MANNER_OF_HOLDING) and
    TransactionData(transferorsEqualShares == true && transfereesEqualShares == false)
    then
        txn.setLodgementSubCategory("Change in the manner of holding two parties in equal shares (joint tenants in common or vice versa)");
    end
	*/


    // Change in the manner of holding  - more than two parties
	@Test
	public void testRule_7() throws Exception {
		FormData formData = createFormDataForChangeInTheMannerOfHolding();
		addTransfereesWithEqualShares(formData, 3);
		addTransferorsWithEqualShares(formData, 3);

		// 	when
		TransactionData transactionData = dutiesRuleService.formToTransactionData(formData);

		// then
		assertEquals(LodgementCategory.CHANGE_IN_THE_MANNER_OF_HOLDING_EQUAL_SHARES, transactionData.getLodgementCategory());
		assertEquals(RuleGroup.CHANGE_IN_THE_MANNER_OF_HOLDING, transactionData.getRuleGroup());
		assertTrue(transactionData.getSectionsOfTheAct().isEmpty());
		assertTrue(transactionData.getDolTransactionTypes().isEmpty());
		assertEquals(transactionData.getLodgementSubCategory(),
				"Change in the manner of holding - more than two parties (joint tenants in common or vice versa)");
		assertEquals(AssessmentType.MANUAL, transactionData.getAssessmentType());
	}
    /*
	when
    TransactionData(ruleGroup == RuleGroup.CHANGE_IN_THE_MANNER_OF_HOLDING) and
    TransactionData(transferorsEqualShares == true && transfereesEqualShares == true) and
    FormData(transferees != null && transferees.size() > 2 || transferors != null && transferors.size() > 2)
    then
        txn.setLodgementSubCategory("Change in the manner of holding - more than two parties (joint tenants in common or vice versa)");
        txn.setAssessmentType(AssessmentType.MANUAL);
    end
	*/


    //
	// Data fixture
	//
	public FormData createFormDataForChangeInTheMannerOfHolding() {
		FormData formData = TestDataFixture.createFormDataWithConcessions(TransactionType.ChangeInTheMannerOfHolding,
				new ConcessionType[]{});
		formData.setTransactionInvolvesProperty(TransferOfLandType.TRANSFER_OF_LAND);
		return formData;
	}

	public void addTransfereesWithEqualShares(FormData formData, int numberOfTransferees) {
		List<Transferee> transferees = new ArrayList();
		formData.setTransferees(transferees);
		OwnershipShare share = new OwnershipShare();
		share.setSharesOwned(1L);
		share.setTotalShares(Long.valueOf(numberOfTransferees));
		for (int i = 0; i < numberOfTransferees; i++) {
			Transferee transferee = new Transferee();
			transferee.setTransferRightsShare(share);
			transferees.add(transferee);
		}
	}

	public void addTransferorsWithEqualShares(FormData formData, int numberOfTransferors) {
		List<Transferor> transferors = new ArrayList();
		formData.setTransferors(transferors);
		OwnershipShare share = new OwnershipShare();
		share.setSharesOwned(1L);
		share.setTotalShares(Long.valueOf(numberOfTransferors));
		for (int i = 0; i < numberOfTransferors; i++) {
			Transferor transferor = new Transferor();
			transferor.setInterestHolding(share);
			transferors.add(transferor);
		}
	}


}
