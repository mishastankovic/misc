package au.gov.vic.sro.duties.rules.service;

import au.gov.vic.sro.duties.rules.model.ConcessionType;
import au.gov.vic.sro.duties.rules.model.FormData;
import au.gov.vic.sro.duties.rules.model.LodgementCategory;
import au.gov.vic.sro.duties.rules.model.LodgementChannel;
import au.gov.vic.sro.duties.rules.model.TransactionData;
import au.gov.vic.sro.duties.rules.model.TransactionType;
import au.gov.vic.sro.duties.rules.model.TransferOfLandType;
import org.apache.tools.ant.taskdefs.SQLExec;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.assertEquals;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = DutiesRulesConfiguration.class)
public class BasicRuleTest {

    @Autowired
    private DutiesRulesService dutiesRuleService;

    // Knockout - ELM flow
    @Test
    public void testElmFlow() throws Exception {

        ConcessionType[] concessionTypes = { ConcessionType.CONVERSION_OF_LAND_USE_ENTITLEMENT, ConcessionType.SHARIAH_FINANCING };
        for (ConcessionType concessionType : concessionTypes) {

            // given
            FormData formData = TestDataFixture.createFormDataWithConcessions(TransactionType.Other,
                    new ConcessionType[]{concessionType});
            // when
            TransactionData transactionData = dutiesRuleService.formToTransactionData(formData);
            // then
            assertEquals(transactionData.getLodgementChannel(), LodgementChannel.ELM);
        }

        // given
        FormData formData = TestDataFixture.createFormDataWithConcessions(TransactionType.Other,
                new ConcessionType[]{});
        formData.setTransactionInvolvesProperty(TransferOfLandType.TRANSFER_OF_LAND);
        // when
        TransactionData transactionData = dutiesRuleService.formToTransactionData(formData);
        // then
        assertEquals(transactionData.getLodgementChannel(), LodgementChannel.ELM);

    }


    // Email lodgement@Test
    @Test
    public void testEmailLodgement() throws Exception {
        // given
        FormData formData = TestDataFixture.createFormDataWithConcessions(TransactionType.Other,
                new ConcessionType[]{ConcessionType.EQUITY_RELEASE_PROGRAMME});
        // when
        TransactionData transactionData = dutiesRuleService.formToTransactionData(formData);
        // then
        assertEquals(transactionData.getLodgementChannel(), LodgementChannel.EMAIL);
    }


    //Knockout - ELNO flow@Test
    @Test
    public void testKnockoutElnoFlow() throws Exception {

        TransactionType[] transferInvolvesList  = new TransactionType[] {
                TransactionType.TransferBetweenSpousesDeFactoOrDomesticPartners,
                TransactionType.ChangeInTheMannerOfHolding,
                TransactionType.DeviseInAccordanceWithAWillOrProbate};

        for (TransactionType transferInvolves : transferInvolvesList) {
            // given
            FormData formData = TestDataFixture.createFormData(transferInvolves);
            // when
            TransactionData transactionData = dutiesRuleService.formToTransactionData(formData);
            // then
            assertEquals(transactionData.getLodgementChannel(), LodgementChannel.ELNO);
        }
    }


    //Deceased estate transfer@Test
    @Test
    public void testDeceasedEstateTransfer() throws Exception {
        {
            // given
            FormData formData = TestDataFixture.createFormDataWithConcessions(
                    TransactionType.DeviseInAccordanceWithAWillOrProbate, new ConcessionType[]{});
            // when
            TransactionData transactionData = dutiesRuleService.formToTransactionData(formData);
            // then
            assertEquals(transactionData.getLodgementCategory(), LodgementCategory.DECEASED_ESTATE_TRANSFERS);
        }

        {
            // given
            FormData formData = TestDataFixture.createFormDataWithConcessions(
                    TransactionType.Other,
                    new ConcessionType[]{ConcessionType.DECEASED_ESTATE_EXEMPTION_AND_CONCESSION});
            // when
            TransactionData transactionData = dutiesRuleService.formToTransactionData(formData);
            // then
            assertEquals(transactionData.getLodgementCategory(), LodgementCategory.DECEASED_ESTATE_TRANSFERS);
        }
    }


//    //Transfers involving a spouse or domestic partner or former spouse of domestic partner@Test
//    @Test
//    public void testTransfersInvolvingSspouse() throws Exception {
//
//    }
//
//
//    //Change in the manner of holding@Test
//    @Test
//    public void testChangeInTheMannerOffHolding() throws Exception {
//
//    }


    //Partition and NICO@Test
    @Test
    public void testPartitionAndNICO() throws Exception {
        // given
        FormData formData = TestDataFixture.createFormDataWithConcessions(
                TransactionType.Other,
                new ConcessionType[]{ConcessionType.PARTITION_AND_NICO});
        // when
        TransactionData transactionData = dutiesRuleService.formToTransactionData(formData);
        // then
        assertEquals(transactionData.getLodgementCategory(), LodgementCategory.PARTITION_OR_NICO);
    }


    //Trust Examption@Test
    @Test
    public void testTrustExamption() throws Exception {

    }


    //Bencrupcy Matters@Test
    @Test
    public void testBencrupcyMatters() throws Exception {

    }


    //Transfer to Superfunds@Test
    @Test
    public void testTransferToSuperfunds() throws Exception {

    }


    //Transfer to an approved Charity, Government Body or Authority@Test
    @Test
    public void testTransferToCharity() throws Exception {

    }


    //Production Land  -  Family Farm Transfer to other than a relative OR Primary Production Land  -Family Farm Transfer to a Relative@Test
    @Test
    public void testFamilyFarmTransferToOtherThanRrelative() throws Exception {

    }


    //Young farmers exemption@Test
    @Test
    public void testYoungFarmersExemption() throws Exception {

    }


    //Primary Production Land – Primary Production –Disaggregation, Water Entitlements, Goods and Livestock@Test
    @Test
    public void testDisaggregationWaterEntitlementsGoodsAndLivestock() throws Exception {

    }


    //Adjustment to Dutiable Value – Transferee Improvements@Test
    @Test
    public void testAdjustmentToDutiableValue_TransfereeImprovements() throws Exception {

    }


    //Adjustment to Dutiable Value – No Double Duty@Test
    @Test
    public void testAdjustmentToDutiableValue_NoDoubleDuty() throws Exception {

    }


    //Sub-Sale and/or Nomination transfers@Test
    @Test
    public void testSubSale() throws Exception {

    }


    //Sale of Business or Goods@Test
    @Test
    public void testSaleOfBusinessOrGoods() throws Exception {

    }


    //Aggregation@Test
    @Test
    public void testAggregation() throws Exception {

    }


    //Change in manner of holding  - more than two parties@Test
    @Test
    public void testChangeInMannerOfHolding_MoreThanTwoParties() throws Exception {

    }


    //Transfers involving a Spouse or Domestic Partner or former Spouse or Domestic Partner@Test
    @Test
    public void testTransfersInvolvingASpouse() throws Exception {

    }


    //Sub-sale and/or Nomination transfer - Options, Additional Development and/or Consideration not included in the contract price@Test
    @Test
    public void testSubSale_OptionsAdditionalDevelopmentConsideration() throws Exception {

    }


    //Intermediate result = Sub-sale not included in contract@Test
    @Test
    public void testIntermediateRresultSubSsaleNotIncludedIinCcontract() throws Exception {

    }
}
