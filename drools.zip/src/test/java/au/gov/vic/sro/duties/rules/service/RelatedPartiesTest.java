package au.gov.vic.sro.duties.rules.service;

import au.gov.vic.sro.duties.rules.model.ConcessionType;
import au.gov.vic.sro.duties.rules.model.FormData;
import au.gov.vic.sro.duties.rules.model.LodgementChannel;
import au.gov.vic.sro.duties.rules.model.TransactionData;
import au.gov.vic.sro.duties.rules.model.TransactionType;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static org.junit.Assert.assertEquals;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = DutiesRulesConfiguration.class)
public class RelatedPartiesTest {

    @Autowired
    private DutiesRulesService dutiesRuleService;


	// Related Parties Rule Group
	@Test
	public void testRule_1() throws Exception {
        // given
        FormData formData = TestDataFixture.createFormDataWithConcessions(TransactionType.Other,
                new ConcessionType[]{ConcessionType.EQUITY_RELEASE_PROGRAMME});
        // when
        TransactionData transactionData = dutiesRuleService.formToTransactionData(formData);
        // then
        assertEquals(transactionData.getLodgementChannel(), LodgementChannel.EMAIL);
	}
    /*
	when
        TransactionData(lodgementCategory == LodgementCategory.TRANSFER_TO_RELATED_PARTY) and
        $formData : FormData(transactionInvolvesProperty == TransferOfLandType.TRANSFER_OF_LAND &&
            transactionInvolvesTransaction == TransactionType.Other) and
        exists RelatedParty(relatedParty == true) from $formData.relatedParty
    then
        txn.setRuleGroup(RuleGroup.RELATED_PARTIES);
        txn.setAssessmentType(AssessmentType.MANUAL);
    end
	*/

	// Transfer to a related or associated party with concession
	@Test
	public void testRule_2() throws Exception {
	}
    /*
	when
        exists TransactionData(ruleGroup == RuleGroup.RELATED_PARTIES) and
        $formData : FormData() and
        exists Concession(concessionType != ConcessionType.FOREIGN_PURCHASER_ADDITIONAL_DUTY_EXEMPTION) from $formData.concessions
    then
        txn.setAssessmentType(AssessmentType.MANUAL);
        txn.setLodgementSubCategory("Transfer to a related or associated party with concession");
    end
	*/


	// Transfer to a related or associated party with no concession - FPAD exempt - more than two transferees
	@Test
	public void testRule_3() throws Exception {
	}
    /*
	when
        exists TransactionData(ruleGroup == RuleGroup.RELATED_PARTIES) and
        $formData : FormData(transferees != null && transferees.size() > 2 && contractDate != null && contractDate >= "14-Jun-2018") and
        not Concession(concessionType != ConcessionType.FOREIGN_PURCHASER_ADDITIONAL_DUTY_EXEMPTION) from $formData.concessions and
        exists Transferee(naturalPerson != null && naturalPerson.foreignNaturalPerson == true) from $formData.transferees and
        exists Concession(concessionType == ConcessionType.FOREIGN_PURCHASER_ADDITIONAL_DUTY_EXEMPTION) from $formData.concessions

    then
        txn.setFpadSections(new String[] {"s18A","s28A","s69AJ"});
        txn.addSectionOfTheAct("s10(1)(a)&(d)");
        txn.setLodgementSubCategory("Transfer to a related or associated party with no concession");
    end
	*/


	// Transfer to a related or associated party with no concession - FPAD exempt
	@Test
	public void testRule_4() throws Exception {
	}
    /*
	when
        exists TransactionData(ruleGroup == RuleGroup.RELATED_PARTIES) and
        $formData : FormData(transferees != null && transferees.size() <= 2  && contractDate != null && contractDate >= "14-Jun-2018") and
        exists Concession(concessionType == ConcessionType.FOREIGN_PURCHASER_ADDITIONAL_DUTY_EXEMPTION) from $formData.concessions and
        not Concession(concessionType != ConcessionType.FOREIGN_PURCHASER_ADDITIONAL_DUTY_EXEMPTION) from $formData.concessions and
        exists Transferee(naturalPerson != null && naturalPerson.foreignNaturalPerson == true) from $formData.transferees
    then
        txn.setFpadSections(new String[] {"s18A","s28A","s69AJ"});
        txn.addSectionOfTheAct("s10(1)(a)&(d)");
        txn.setDolTransactionTypes(new String[] {"3"});
        txn.setLodgementSubCategory("Transfer to a related or associated party with no concession");
    end
	*/


	// Transfer to a related or associated party with no concession - No FPAD exempt
	@Test
	public void testRule_5() throws Exception {
	}
    /*
	when
        exists TransactionData(ruleGroup == RuleGroup.RELATED_PARTIES) and
        $formData : FormData(contractDate != null && contractDate >= "14-Jun-2018") and
        not Concession(concessionType == ConcessionType.FOREIGN_PURCHASER_ADDITIONAL_DUTY_EXEMPTION) from $formData.concessions and
        not Concession(concessionType != ConcessionType.FOREIGN_PURCHASER_ADDITIONAL_DUTY_EXEMPTION) from $formData.concessions and
        exists Transferee(naturalPerson != null && naturalPerson.foreignNaturalPerson == true ||
            organisation != null && organisation.foreignOrganisationInd == true) from $formData.transferees
    then
        txn.setFpadSections(new String[] {"s18A","s28A"});
        txn.addSectionOfTheAct("s10(1)(a)&(d)");
        txn.setDolTransactionTypes(new String[] {"3"});
        txn.setLodgementSubCategory("Transfer to a related or associated party with no concession");
    end
	*/


	// Transfer to a related or associated party with no concession - transferee not foreign
	@Test
	public void testRule_6() throws Exception {
	}
    /*
	when
        exists TransactionData(ruleGroup == RuleGroup.RELATED_PARTIES) and
        $formData : FormData() and
        not Concession(concessionType != ConcessionType.FOREIGN_PURCHASER_ADDITIONAL_DUTY_EXEMPTION) from $formData.concessions and
        not Transferee(naturalPerson != null && naturalPerson.foreignNaturalPerson == false ||
            organisation != null && organisation.foreignOrganisationInd == false) from $formData.transferees
    then
        txn.addSectionOfTheAct("s10(1)(a)&(d)");
        txn.setDolTransactionTypes(new String[] {"3"});
        txn.setLodgementSubCategory("Transfer to a related or associated party with no concession");
    end
	*/


}
