package au.gov.vic.sro.duties.rules.service;

import au.gov.vic.sro.duties.rules.model.ConcessionType;
import au.gov.vic.sro.duties.rules.model.FormData;
import au.gov.vic.sro.duties.rules.model.LodgementChannel;
import au.gov.vic.sro.duties.rules.model.TransactionData;
import au.gov.vic.sro.duties.rules.model.TransactionType;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static org.junit.Assert.assertEquals;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = DutiesRulesConfiguration.class)
public class SuperfundTest {

    @Autowired
    private DutiesRulesService dutiesRuleService;


	// Superfund Switch
	@Test
	public void testRule_1() throws Exception {
        // given
        FormData formData = TestDataFixture.createFormDataWithConcessions(TransactionType.Other,
                new ConcessionType[]{ConcessionType.EQUITY_RELEASE_PROGRAMME});
        // when
        TransactionData transactionData = dutiesRuleService.formToTransactionData(formData);
        // then
        assertEquals(transactionData.getLodgementChannel(), LodgementChannel.EMAIL);
		
	}
	/*
	when
    TransactionData(lodgementCategory == LodgementCategory.TRANSFER_TO_SUPERFUNDS) and
    $formData :  FormData(transactionInvolvesTransaction == TransactionType.Other &&
                        transactionInvolvesProperty == TransferOfLandType.TRANSFER_OF_LAND) and
    exists Concession(concessionType == ConcessionType.EXEMPTION_OR_CONCESSION_FOR_SUPERANNUATION_FUND) from $formData.concessions
    not Transferor(naturalPerson == null || isIndividual() == false)
 then
    txn.setRuleGroup(RuleGroup.SUPERFUND);
 end
	*/


	// Transfer to Superfund - 1 - Complex
	@Test
	public void testRule_2() throws Exception {
	}
    /*
	when
        TransactionData(ruleGroup == RuleGroup.SUPERFUND) and
        $formData : FormData() and
        not RelatedParty(relatedParty == true) from $formData.relatedParty
        exists Concession(superannuationFundExemption != null && superannuationFundExemption.isAllTransferorFundMember == true &&
                            superannuationFundExemption.isAnyConsideration == false) and
        not Transferee(trust != null)  from $formData.transferees
    then
        txn.setAssessmentType(AssessmentType.MANUAL);
    end
	*/


	// Transfer to Superfund - 2 - Complex
	@Test
	public void testRule_3() throws Exception {
	}
    /*
	when
        TransactionData(ruleGroup == RuleGroup.SUPERFUND) and
        $formData : FormData() and
        exists Concession(superannuationFundExemption != null && superannuationFundExemption.isAllTransferorFundMember == true &&
                            superannuationFundExemption.isAnyConsideration == false)
        exists RelatedParty(relatedParty == true) from $formData.relatedParty and
        not Transferee(trust != null)  from $formData.transferees
    then
        txn.setAssessmentType(AssessmentType.MANUAL);
    end
	*/


	// Transfer to Superfund - 3 - Complex
	@Test
	public void testRule_4() throws Exception {
	}
    /*
	when
        TransactionData(ruleGroup == RuleGroup.SUPERFUND) and
        $formData : FormData() and
        exists Concession(superannuationFundExemption != null && superannuationFundExemption.isAllTransferorFundMember == true &&
            superannuationFundExemption.isAnyConsideration == true)
        exists RelatedParty(relatedParty == true) from $formData.relatedParty and
        exists Transferee(trust != null)  from $formData.transferees
    then
        txn.setAssessmentType(AssessmentType.MANUAL);
    end
	*/


	// Transfer to Superfund - 4 - Complex
	@Test
	public void testRule_5() throws Exception {
	}
    /*
	when
        TransactionData(ruleGroup == RuleGroup.SUPERFUND) and
        $formData : FormData() and
        exists Concession(superannuationFundExemption != null && superannuationFundExemption.isAllTransferorFundMember == true &&
                            superannuationFundExemption.isAnyConsideration == false)
        exists RelatedParty(relatedParty == true) from $formData.relatedParty and
        exists Transferee(trust != null) from $formData.transferees
    then
        txn.addSectionOfTheAct("s41");
        txn.setDolTransactionTypes(new String[] {"26"});
    end
	*/


}
