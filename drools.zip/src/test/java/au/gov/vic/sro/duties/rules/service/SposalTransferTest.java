package au.gov.vic.sro.duties.rules.service;

import au.gov.vic.sro.duties.rules.model.ConcessionType;
import au.gov.vic.sro.duties.rules.model.FormData;
import au.gov.vic.sro.duties.rules.model.LodgementCategory;
import au.gov.vic.sro.duties.rules.model.LodgementChannel;
import au.gov.vic.sro.duties.rules.model.TransactionData;
import au.gov.vic.sro.duties.rules.model.TransactionType;
import au.gov.vic.sro.duties.rules.model.TransferOfLandType;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static org.junit.Assert.assertEquals;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = DutiesRulesConfiguration.class)
public class SposalTransferTest {

    @Autowired
    private DutiesRulesService dutiesRuleService;


    // Transfers involving a Spouse or Domestic Partner or former Spouse or Domestic Partner
	@Test
	public void testRule_1() throws Exception {
        // given
        FormData formData = TestDataFixture.createFormDataWithConcessions(TransactionType.Other,
                new ConcessionType[]{ConcessionType.EQUITY_RELEASE_PROGRAMME});
        // when
        TransactionData transactionData = dutiesRuleService.formToTransactionData(formData);
        // then
        assertEquals(transactionData.getLodgementChannel(), LodgementChannel.EMAIL);
	}

	/*
    when
    FormData(transactionInvolvesTransaction == TransactionType.TransferBetweenSpousesDeFactoOrDomesticPartners) and exists Concession(concessionType in (
            ConcessionType.SPOUSES_DOMESTIC_PARTNERS_BREAKDOWN,
            ConcessionType.SPOUSES_DOMESTIC_PARTNERS_LOVE));
    then
        txn.setLodgementCategory(LodgementCategory.SPOUSE_OR_DOMESTIC_PARTNER_TRANSFER);
    end
    */


    // Spouse Transfer switch
	@Test
	public void testRule_2() throws Exception {
	}

	/*
    when
    TransactionData(lodgementCategory == LodgementCategory.SPOUSE_OR_DOMESTIC_PARTNER_TRANSFER) and
        ($formData : FormData(transactionInvolvesProperty == TransferOfLandType.TRANSFER_OF_LAND && concessionClaimed == true) and
    not Concession(concessionType != ConcessionType.PPR) from $formData.getConcessions()) or
            ($formData : FormData(transactionInvolvesProperty == TransferOfLandType.TRANSFER_OF_LAND)
    and exists Concession(concessionType == ConcessionType.PPR) from $formData.getConcessions() and
    not Property(propertyType not in (PropertyType.ResidentialVacantLand, PropertyType.ResidentialPrivateDwelling)) from $formData.properties)
    and not (Transferee(partyType != PartyType.INDIVIDUAL_NATURAL_PERSON) from $formData.transferees);
    then
        txn.setRuleGroup(RuleGroup.SPOUSE_TRANSFER);
    end
    */


    // Breakdown of Relationship Transfer – to other than spouse/domestic partner (Concession Type -2)
	@Test
	public void testRule_3() throws Exception {
	}

	/*
    when
    TransactionData(ruleGroup == RuleGroup.SPOUSE_TRANSFER) and
    $formData : FormData(concessionClaimed == true && isThereThirdPartyTransferee() == true) and
    exists Concession(concessionType == ConcessionType.SPOUSES_DOMESTIC_PARTNERS_BREAKDOWN) from $formData.getConcessions()
    then
        txn.setLodgementSubCategory("Breakdown of Relationship Transfer – to other than spouse/domestic partner (Concession Type -2)");
        txn.setAssessmentType(AssessmentType.MANUAL);
    end
    */


    // Breakdown of Relationship Transfer (Concession Type  -2)
	@Test
	public void testRule_4() throws Exception {
	}

	/*
    when
    TransactionData(ruleGroup == RuleGroup.SPOUSE_TRANSFER) and
    $formData : FormData(concessionClaimed == true && isThereThirdPartyTransferee() == false) and
    exists Concession(concessionType == ConcessionType.SPOUSES_DOMESTIC_PARTNERS_BREAKDOWN) from $formData.getConcessions()
    then
        txn.setLodgementSubCategory("Breakdown of Relationship Transfer (Concession Type  -2)");
        txn.addSectionOfTheAct("s44(1)(a)(b)(i)&(c)(i)");
        txn.setAssessmentType(AssessmentType.EXEMPT_FROM_DUTY);
        txn.setDolTransactionTypes(new String[] {"8"});
    end
    */


    // Spouse transfer involving parties other than Spouse/Domestic Partner (Concession Type  - 1) - MANUAL 1
	@Test
	public void testRule_5() throws Exception {
	}

	/*
    when
    TransactionData(ruleGroup == RuleGroup.SPOUSE_TRANSFER) and
    $formData : FormData(concessionClaimed == true && isThereThirdPartyTransferee() == true) and
    not Concession(concessionType == ConcessionType.SPOUSES_DOMESTIC_PARTNERS_BREAKDOWN) from $formData.getConcessions()
    then
        txn.setLodgementSubCategory("Spouse transfer involving parties other than Spouse/Domestic Partner (Concession Type  - 1)");
        txn.setAssessmentType(AssessmentType.MANUAL);
    end
    */


    // Spouse Transfer between Spouses/Domestic Partners (Concession Type  - 1) - TXN 7 transfer pre-July 2017
	@Test
	public void testRule_6() throws Exception {
	}

	/*
    when
    TransactionData(ruleGroup == RuleGroup.SPOUSE_TRANSFER) and
    $formData : FormData(concessionClaimed == true && isThereThirdPartyTransferee() == false) and
    not Concession(concessionType == ConcessionType.SPOUSES_DOMESTIC_PARTNERS_BREAKDOWN) from $formData.getConcessions() and
    not Property(propertyType not in (PropertyType.ResidentialVacantLand, PropertyType.ResidentialPrivateDwelling)) from $formData.properties;
    then
        txn.setLodgementSubCategory("Spouse Transfer between Spouses/Domestic Partners (Concession Type - 1)");
        txn.addSectionOfTheAct("s43(1)");
        txn.setAssessmentType(AssessmentType.EXEMPT_FROM_DUTY);
        txn.setDolTransactionTypes(new String[] {"7 transfer pre-July 2017"});
    end
    */


    // Spouse Transfer between Spouses/Domestic Partners (Concession Type  - 1) - MANUAL 2
	@Test
	public void testRule_7() throws Exception {
	}

	/*
    when
    TransactionData(ruleGroup == RuleGroup.SPOUSE_TRANSFER) and
    $formData : FormData(concessionClaimed == true && isThereThirdPartyTransferee() == true && consideration.isConsideration() == true) and
    not Concession(concessionType == ConcessionType.SPOUSES_DOMESTIC_PARTNERS_BREAKDOWN) from $formData.getConcessions() and
    exists Concession(concessionType == ConcessionType.PPR)  from $formData.getConcessions() and
    not Property(propertyType not in (PropertyType.ResidentialVacantLand, PropertyType.ResidentialPrivateDwelling)) from $formData.properties;
    then
        txn.setLodgementSubCategory("Spouse Transfer between Spouses/Domestic Partners (Concession Type - 1)");
        txn.setAssessmentType(AssessmentType.MANUAL);
    end
    */


    // Spouse Transfer between Spouses/Domestic Partners (Concession Type  - 1) - TXN 7A
	@Test
	public void testRule_8() throws Exception {
	}

	/*
    when
    TransactionData(ruleGroup == RuleGroup.SPOUSE_TRANSFER) and
    $formData : FormData(concessionClaimed == true && isThereThirdPartyTransferee() == true && consideration.isConsideration() == false) and
    not Concession(concessionType == ConcessionType.SPOUSES_DOMESTIC_PARTNERS_BREAKDOWN) from $formData.getConcessions() and
    exists Concession(concessionType == ConcessionType.PPR) from $formData.getConcessions() and
    not Property(propertyType not in (PropertyType.ResidentialVacantLand, PropertyType.ResidentialPrivateDwelling)) from $formData.properties;
    then
        txn.setLodgementSubCategory("Spouse Transfer between Spouses/Domestic Partners (Concession Type - 1)");
        txn.addSectionOfTheAct("s43(1)");
        txn.setAssessmentType(AssessmentType.EXEMPT_FROM_DUTY);
        txn.setDolTransactionTypes(new String[] {"7A"});
    end
    */


    // Spouse Transfer between Spouses/Domestic Partners (Concession Type  - 1) - TXN 7B
	@Test
	public void testRule_9() throws Exception {
	}

	/*
    when
    TransactionData(ruleGroup == RuleGroup.SPOUSE_TRANSFER) and
    $formData : FormData(concessionClaimed == true && isThereThirdPartyTransferee() == true && consideration.isConsideration() == false) and
    not Concession(concessionType == ConcessionType.SPOUSES_DOMESTIC_PARTNERS_BREAKDOWN) from $formData.getConcessions() and
    not Concession(concessionType != ConcessionType.PPR) from $formData.getConcessions() and
    not Property(propertyType not in (PropertyType.ResidentialVacantLand, PropertyType.ResidentialPrivateDwelling)) from $formData.properties;
    then
        txn.setLodgementSubCategory("Spouse Transfer between Spouses/Domestic Partners (Concession Type - 1)");
        txn.addSectionOfTheAct("s10(1)(a)&(d)");
        txn.setAssessmentType(AssessmentType.EXEMPT_FROM_DUTY);
        txn.setDolTransactionTypes(new String[] {"7B"});
    end
    */


    // Spouse Transfer between Spouses/Domestic Partners (Concession Type  - 1) - TXN 7C
	@Test
	public void testRule_10() throws Exception {
	}

	/*
    when
    TransactionData(ruleGroup == RuleGroup.SPOUSE_TRANSFER) and
    $formData : FormData(concessionClaimed == true && isThereThirdPartyTransferee() == true && consideration.isConsideration() == true) and
    not Concession(concessionType == ConcessionType.SPOUSES_DOMESTIC_PARTNERS_BREAKDOWN) from $formData.getConcessions() and
    not Concession(concessionType == ConcessionType.PPR) from $formData.getConcessions() and
    not Property(propertyType not in (PropertyType.ResidentialVacantLand, PropertyType.ResidentialPrivateDwelling)) from $formData.properties;
    then
        txn.setLodgementSubCategory("Spouse Transfer between Spouses/Domestic Partners (Concession Type - 1)");
        txn.addSectionOfTheAct("s10(1)(a)&(d)");
        txn.setAssessmentType(AssessmentType.FULL_DUTY);
        txn.setDolTransactionTypes(new String[] {"7C"});
        txn.setFpadSections(new String[] {"s18A","s28A","s69AJ"});
    end
    */


}
