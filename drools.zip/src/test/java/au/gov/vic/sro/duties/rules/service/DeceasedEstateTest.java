package au.gov.vic.sro.duties.rules.service;

import au.gov.vic.sro.duties.rules.model.ConcessionType;
import au.gov.vic.sro.duties.rules.model.FormData;
import au.gov.vic.sro.duties.rules.model.LodgementChannel;
import au.gov.vic.sro.duties.rules.model.TransactionData;
import au.gov.vic.sro.duties.rules.model.TransactionType;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static org.junit.Assert.assertEquals;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = DutiesRulesConfiguration.class)
public class DeceasedEstateTest {

    @Autowired
    private DutiesRulesService dutiesRuleService;


    // Deceased estate transfer
	@Test
	public void testRule_1() throws Exception {
        // given
        FormData formData = TestDataFixture.createFormDataWithConcessions(TransactionType.Other,
                new ConcessionType[]{ConcessionType.EQUITY_RELEASE_PROGRAMME});
        // when
        TransactionData transactionData = dutiesRuleService.formToTransactionData(formData);
        // then
        assertEquals(transactionData.getLodgementChannel(), LodgementChannel.EMAIL);
	}
    /*
	when
    FormData(transactionInvolvesTransaction == TransactionType.DeviseInAccordanceWithAWillOrProbate)  or
    $formData : FormData() and
    exists Concession(concessionType == ConcessionType.DECEASED_ESTATE_EXEMPTION_AND_CONCESSION) from $formData.concessions;
    then
        txn.setLodgementCategory(LodgementCategory.DECEASED_ESTATE_TRANSFERS);
    end
	*/


    // Deceased Estate (outside of the term of the Will) - Complex
	@Test
	public void testRule_2() throws Exception {
	}
    /*
	when
    TransactionData(lodgementCategory == LodgementCategory.DECEASED_ESTATE_TRANSFERS) and
    FormData(transactionInvolvesTransaction != TransactionType.DeviseInAccordanceWithAWillOrProbate
            && consideration != null && ((consideration.isConsideration() == true && multipleConsiderations == false) ||
            consideration.isConsideration() == false));
    then
        txn.setAssessmentType(AssessmentType.MANUAL);
        txn.setLodgementSubCategory("Deceased Estate (outside of the term of the Will)");
    end
	*/


    // Deceased Estate (outside of the term of the Will) - ELM
	@Test
	public void testRule_3() throws Exception {
	}
    /*
	when
    TransactionData(lodgementCategory == LodgementCategory.DECEASED_ESTATE_TRANSFERS) and
    FormData(transactionInvolvesTransaction != TransactionType.DeviseInAccordanceWithAWillOrProbate
            && consideration != null && consideration.isConsideration() == true && multipleConsiderations == false);
    then
        txn.setLodgementChannel(LodgementChannel.ELM);
        txn.setLodgementSubCategory("Deceased Estate (outside of the term of the Will)");
    end
	*/


    // Deceased Estate Exemption - Complex
	@Test
	public void testRule_4() throws Exception {
	}
    /*
	when
    TransactionData(lodgementCategory == LodgementCategory.DECEASED_ESTATE_TRANSFERS) and
    FormData(transactionInvolvesTransaction == TransactionType.DeviseInAccordanceWithAWillOrProbate &&
            consideration != null && consideration.isConsideration() == true &&
    multipleConsiderations == false)
    then
        txn.setAssessmentType(AssessmentType.MANUAL);
        txn.setLodgementSubCategory("Deceased Estate Exemption");
    end
	*/


    // Deceased Estate Exemption - ELM
	@Test
	public void testRule_5() throws Exception {
	}
    /*
	when
    TransactionData(lodgementCategory == LodgementCategory.DECEASED_ESTATE_TRANSFERS) and
    FormData(transactionInvolvesTransaction == TransactionType.DeviseInAccordanceWithAWillOrProbate &&
            consideration != null && consideration.isConsideration() == true &&
    multipleConsiderations == true)
    then
        txn.setLodgementChannel(LodgementChannel.ELM);
        txn.setLodgementSubCategory("Deceased Estate Exemption");
    end
	*/


    // Deceased Estate Exemption - Exempt from Duty
	@Test
	public void testRule_6() throws Exception {
	}
    /*
	when
    TransactionData(lodgementCategory == LodgementCategory.DECEASED_ESTATE_TRANSFERS) and
    FormData(transactionInvolvesTransaction == TransactionType.DeviseInAccordanceWithAWillOrProbate &&
            consideration != null && consideration.isConsideration() == false)
    then
        txn.addSectionOfTheAct("s42(1)(a)");
        txn.addDolTransactionType("6");
        txn.setAssessmentType(AssessmentType.EXEMPT_FROM_DUTY);
        txn.setLodgementSubCategory("Deceased Estate Exemption");
    end
	*/


}
