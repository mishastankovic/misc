package au.gov.vic.sro.duties.rules.service;

import au.gov.vic.sro.duties.rules.model.Concession;
import au.gov.vic.sro.duties.rules.model.ConcessionType;
import au.gov.vic.sro.duties.rules.model.FormData;
import au.gov.vic.sro.duties.rules.model.TransactionType;
import au.gov.vic.sro.duties.rules.model.TransferOfLandType;


import java.util.ArrayList;
import java.util.List;

public class TestDataFixture {

    public static FormData createFormData(TransactionType transferInvolves) {
        FormData formData = new FormData();
        formData.setTransactionInvolvesTransaction(transferInvolves);
        return formData;
    }

    public static FormData createFormDataWithConcessions(TransactionType transferInvolves, ConcessionType[] concessionTypes) {
        return addConcessions(createFormData(transferInvolves), concessionTypes);
    }

    public static FormData addConcessions(FormData formData, ConcessionType[] concessionTypes) {
        List<Concession> concessions = formData.getConcessions();
        if (concessions == null) {
            concessions = new ArrayList();
            formData.setConcessions(concessions);
        }

        for(ConcessionType concessionType : concessionTypes) {
            concessions.add(new Concession(concessionType));
        }

        return formData;
    }

}
