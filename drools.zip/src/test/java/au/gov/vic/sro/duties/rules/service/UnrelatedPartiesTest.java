package au.gov.vic.sro.duties.rules.service;

import au.gov.vic.sro.duties.rules.model.ConcessionType;
import au.gov.vic.sro.duties.rules.model.FormData;
import au.gov.vic.sro.duties.rules.model.LodgementChannel;
import au.gov.vic.sro.duties.rules.model.TransactionData;
import au.gov.vic.sro.duties.rules.model.TransactionType;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static org.junit.Assert.assertEquals;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = DutiesRulesConfiguration.class)
public class UnrelatedPartiesTest {

    @Autowired
    private DutiesRulesService dutiesRuleService;


	// Unrelated Parties switch
	@Test
	public void testRule_1() throws Exception {
        // given
        FormData formData = TestDataFixture.createFormDataWithConcessions(TransactionType.Other,
                new ConcessionType[]{ConcessionType.EQUITY_RELEASE_PROGRAMME});
        // when
        TransactionData transactionData = dutiesRuleService.formToTransactionData(formData);
        // then
        assertEquals(transactionData.getLodgementChannel(), LodgementChannel.EMAIL);
		
	}
    /*
	when
        exists TransactionData(lodgementCategory == LodgementCategory.TRANSFER_TO_PARTIES_THAT_ARE_NOT_RELATED_OR_ASSOCIATED) and
        $formData : FormData(transferInvovesContract == true &&
            transactionInvolvesProperty == TransferOfLandType.TRANSFER_OF_LAND &&
            transactionInvolvesTransaction == TransactionType.Other)
        not RelatedParty(relatedParty == true) from $formData.relatedParty
    then
        txn.setRuleGroup(RuleGroup.UNRELATED_PARTIES);
        txn.setLodgementSubCategory("Transfer to parties that are not related or associated");
    end
	*/


// OTP - Off the Plan
// FPAD - Foreign Purchaser Additional Duty
// FHBDR - First Home Buyer Duty Reduction
	// Unrelated Party Transfers with/without concessions including ORP and with FPAD - 1
	@Test
	public void testRule_2() throws Exception {
	}
    /*
	when
        $formData: FormData(transferees != null && transferees.size <= 2) and
        exists Property(propertyType in (PropertyType.ResidentialPrivateDwelling, PropertyType.ResidentialVacantLand)) from $formData.properties
        not Transferee(naturalPerson != null && naturalPerson.foreignNaturalPerson == true ||
            organisation != null && organisation.foreignOrganisationInd == true) from $formData.transferees and
        exists Concession(concessionType == ConcessionType.PPR) from $formData.concessions and
        exists Concession(concessionType == ConcessionType.FIRST_HOME_BUYER_DUTY_REDUCTION) from $formData.concessions and
        exists Concession(concessionType == ConcessionType.FOREIGN_PURCHASER_ADDITIONAL_DUTY_EXEMPTION) from $formData.concessions and
        exists Concession(concessionType == ConcessionType.PENSIONER_CONCESSION) from $formData.concessions and
        exists OffThePlan() from $formData.offThePlan
    then
        txn.addSectionOfTheAct("s10(1)(a)&(d)");
        txn.addSectionOfTheAct("s57H-I");
        txn.addSectionOfTheAct("s57J-s57JA");
        txn.addOffThePlanSectionAct("s21(2)(3)&(4)&(4A)&(5)");
        txn.addPensionerSectionAct("s58-60");
        txn.setDolTransactionTypes(new String[] {"1", "4A", "11", "11A", "12", "13", "13A", "20", "20A"});
        txn.addFpadSectionAct("s69AJ");
        txn.setFpadSections(new String[] {"s18A", "s28A"});
    end
	*/


	// Unrelated Party Transfers with/without concessions including ORP and with FPAD - 2
	@Test
	public void testRule_3() throws Exception {
	}
    /*
	when
        $formData: FormData(transferees != null && transferees.size() > 2) and
        exists Property(propertyType in (PropertyType.ResidentialPrivateDwelling, PropertyType.ResidentialVacantLand)) from $formData.properties
        not Transferee(naturalPerson != null && naturalPerson.foreignNaturalPerson == true ||
            organisation != null && organisation.foreignOrganisationInd == true) from $formData.transferees and
        exists Concession(concessionType == ConcessionType.PPR) from $formData.concessions and
        exists Concession(concessionType == ConcessionType.FIRST_HOME_BUYER_DUTY_REDUCTION) from $formData.concessions and
        exists OffThePlan() from $formData.offThePlan
    then
        txn.addSectionOfTheAct("s10(1)(a)&(d)");
        txn.addSectionOfTheAct("s57H-I");
        txn.addSectionOfTheAct("s57J-s57JA");
        txn.addOffThePlanSectionAct("s21(2)(3)&(4)&(4A)&(5)");
        txn.setFpadSections(new String[] {"s18A", "s28A"});
        txn.setAssessmentType(AssessmentType.MANUAL);
    end
	*/

	// Unrelated Party Transfers with/without concessions including ORP and with FPAD - 3
	@Test
	public void testRule_4() throws Exception {
	}
    /*
	when
        $formData: FormData() and
        exists Property(propertyType in (PropertyType.ResidentialPrivateDwelling, PropertyType.ResidentialVacantLand)) from $formData.properties
        not Transferee(naturalPerson != null && naturalPerson.foreignNaturalPerson == true ||
            organisation != null && organisation.foreignOrganisationInd == true) from $formData.transferees and
        not Concession(concessionType == ConcessionType.PPR) from $formData.concessions and
        not Concession(concessionType == ConcessionType.FIRST_HOME_BUYER_DUTY_REDUCTION) from $formData.concessions and
        not Concession(concessionType == ConcessionType.FOREIGN_PURCHASER_ADDITIONAL_DUTY_EXEMPTION) from $formData.concessions and
        not Concession(concessionType == ConcessionType.PENSIONER_CONCESSION) from $formData.concessions and
        not OffThePlan() from $formData.offThePlan
    then
        txn.addSectionOfTheAct("s10(1)(a)&(d)");
        txn.addOffThePlanSectionAct("s21(2)(3)&(4)&(4A)&(5)");
        txn.addFpadSectionAct("s69AJ");
        txn.setDolTransactionTypes(new String[] {"2","4"});
        txn.setFpadSections(new String[] {"s18A", "s28A" });
    end
	*/

	// Unrelated Party Transfers with/without concessions including ORP and with FPAD - 4
	@Test
	public void testRule_5() throws Exception {
	}
    /*
	when
        $formData: FormData(transferees != null && transferees.size() <= 2) and
        exists Property(propertyType in (PropertyType.ResidentialPrivateDwelling, PropertyType.ResidentialVacantLand)) from $formData.properties
        not Transferee(naturalPerson != null && naturalPerson.foreignNaturalPerson == false ||
            organisation != null && organisation.foreignOrganisationInd == false) from $formData.transferees and
        exists Concession(concessionType == ConcessionType.PPR) from $formData.concessions and
        exists Concession(concessionType == ConcessionType.FIRST_HOME_BUYER_DUTY_REDUCTION) from $formData.concessions and
        exists Concession(concessionType == ConcessionType.PENSIONER_CONCESSION) from $formData.concessions and
        exists Concession(concessionType == ConcessionType.PENSIONER_CONCESSION) from $formData.concessions
        exists OffThePlan() from $formData.offThePlan
    then
        txn.addSectionOfTheAct("s10(1)(a)&(d)");
        txn.addSectionOfTheAct("s57H-I");
        txn.addSectionOfTheAct("s57J-s57JA");
        txn.addOffThePlanSectionAct("s21(2)(3)&(4)&(4A)&(5)");
        txn.addFpadSectionAct("s69AJ");
        txn.setDolTransactionTypes(new String[] {"1", "4A", "11", "11A", "12", "13", "13A", "20", "20A"});
    end
	*/


	// Unrelated Party Transfers with/without concessions including ORP and with FPAD - 5
	@Test
	public void testRule_6() throws Exception {
	}
    /*
	when
        $formData: FormData(transferees != null && transferees.size() > 2) and
        exists Property(propertyType in (PropertyType.ResidentialPrivateDwelling, PropertyType.ResidentialVacantLand)) from $formData.properties
        not Transferee(naturalPerson != null && naturalPerson.foreignNaturalPerson == false ||
            organisation != null && organisation.foreignOrganisationInd == false) from $formData.transferees and
        exists Concession(concessionType == ConcessionType.PPR) from $formData.concessions and
        exists Concession(concessionType == ConcessionType.FIRST_HOME_BUYER_DUTY_REDUCTION) from $formData.concessions and
        exists Concession(concessionType == ConcessionType.PENSIONER_CONCESSION) from $formData.concessions and
        exists OffThePlan() from $formData.offThePlan
    then
        txn.addSectionOfTheAct("s10(1)(a)&(d)");
        txn.addOffThePlanSectionAct("s21(2)(3)&(4)&(4A)&(5)");
        txn.addSectionOfTheAct("s57H-I");
        txn.addSectionOfTheAct("s57J-s57JA");
        txn.addFpadSectionAct("s69AJ");
        txn.setAssessmentType(AssessmentType.MANUAL);
    end
	*/


	// Unrelated Party Transfers with/without concessions including ORP and with FPAD - 6
	@Test
	public void testRule_7() throws Exception {
	}
    /*
	when
        $formData: FormData() and
        exists Property(propertyType in (PropertyType.ResidentialPrivateDwelling, PropertyType.ResidentialVacantLand)) from $formData.properties
        not Transferee(naturalPerson != null && naturalPerson.foreignNaturalPerson == false ||
            organisation != null && organisation.foreignOrganisationInd == false) from $formData.transferees and
        not Concession(concessionType == ConcessionType.PPR) from $formData.concessions and
        not Concession(concessionType == ConcessionType.FIRST_HOME_BUYER_DUTY_REDUCTION) from $formData.concessions and
        not Concession(concessionType == ConcessionType.PENSIONER_CONCESSION) from $formData.concessions and
        exists OffThePlan() from $formData.offThePlan
    then
        txn.addSectionOfTheAct("s10(1)(a)&(d)");
        txn.addOffThePlanSectionAct("s21(2)(3)&(4)&(4A)&(5)");
        txn.setDolTransactionTypes(new String[] {"2","4"});
    end
	*/


	// Unrelated Party Transfers with/without concessions including ORP and with FPAD - 7
	@Test
	public void testRule_8() throws Exception {
	}
    /*
	when
        $formData: FormData() and
        not Property(propertyType in (PropertyType.ResidentialPrivateDwelling, PropertyType.ResidentialVacantLand)) from $formData.properties
        not Concession(concessionType == ConcessionType.PPR) from $formData.concessions and
        not Concession(concessionType == ConcessionType.FIRST_HOME_BUYER_DUTY_REDUCTION) from $formData.concessions and
        not Concession(concessionType == ConcessionType.PENSIONER_CONCESSION) from $formData.concessions and
        exists OffThePlan() from $formData.offThePlan
    then
        txn.addSectionOfTheAct("s10(1)(a)&(d)");
        txn.addOffThePlanSectionAct("s21(2)(3)&(4)&(4A)&(5)");
        txn.setDolTransactionTypes(new String[] {"2","4"});
    end
	*/

}
