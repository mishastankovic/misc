package au.gov.vic.sro.duties.rules.service;

import au.gov.vic.sro.duties.rules.model.ConcessionType;
import au.gov.vic.sro.duties.rules.model.FormData;
import au.gov.vic.sro.duties.rules.model.LodgementChannel;
import au.gov.vic.sro.duties.rules.model.TransactionData;
import au.gov.vic.sro.duties.rules.model.TransactionType;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static org.junit.Assert.assertEquals;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = DutiesRulesConfiguration.class)
public class FamilyFarmTest {

    @Autowired
    private DutiesRulesService dutiesRuleService;


    // Production Land  -  Family Farm Transfer to other than a relative OR Primary Production Land  -Family Farm Transfer to a Relative
	@Test
	public void testRule_1() throws Exception {
        // given
        FormData formData = TestDataFixture.createFormDataWithConcessions(TransactionType.Other,
                new ConcessionType[]{ConcessionType.EQUITY_RELEASE_PROGRAMME});
        // when
        TransactionData transactionData = dutiesRuleService.formToTransactionData(formData);
        // then
        assertEquals(transactionData.getLodgementChannel(), LodgementChannel.EMAIL);
	}
    /*
	when
    $formData : FormData(transactionInvolvesTransaction == TransactionType.Other) and
    exists Concession(concessionType == ConcessionType.FAMILY_FARM_EXEMPTION) from $formData.concessions;
    then
        txn.setLodgementCategory(LodgementCategory.PRIMARY_PRODUCTION_LAND);
        txn.setLodgementSubCategory("Family Farm Exemption");
    end
	*/


    // Primary Production Land – Primary Production –Disaggregation, Water Entitlements, Goods and Livestock
	@Test
	public void testRule_2() throws Exception {
	}
    /*
	when
    $formData : FormData(transactionInvolvesTransaction == TransactionType.Other) and
    exists Concession(concessionType == ConcessionType.PPL_DISAGGREGATION_GOODS_WATER_ENTITLEMENT) from $formData.concessions;
    then
        txn.setLodgementCategory(LodgementCategory.PRIMARY_PRODUCTION_LAND);
        txn.setLodgementSubCategory("Primary Production - Disaggregation, Water Entitlements, Goods and Livestock");
    end
	*/


    // Family Farm Switch
	@Test
	public void testRule_3() throws Exception {
	}
    /*
	when
    TransactionData(lodgementCategory == LodgementCategory.PRIMARY_PRODUCTION_LAND) and
    $formData : FormData(transactionInvolvesProperty == TransferOfLandType.TRANSFER_OF_LAND &&
            transactionInvolvesTransaction == TransactionType.Other) and
    Property(propertyType in (
            PropertyType.PrimaryProductionWithBuildingImplementsStockOrWaterEntitlements,
             PropertyType.PrimaryProductionVacantLandWithNoImplementsStockOrWaterEntitlements
             )) from $formData.properties and
    not Transferee(partyType != PartyType.INDIVIDUAL_NATURAL_PERSON) from $formData.transferees and
    not Transferor(partyType != PartyType.INDIVIDUAL_NATURAL_PERSON) from $formData.transferors and
    exists Concession(concessionType == ConcessionType.FAMILY_FARM_EXEMPTION) from $formData.concessions
            // TODO - Transfer to a relative = Y if relationship type is not a beneficiary, trustee or business relationship
            then
        txn.setRuleGroup(RuleGroup.FAMILY_FARM);
    end
	*/


    // Family Farm Transfer to Other Than a Relative (natural person)
	@Test
	public void testRule_4() throws Exception {
	}
    /*
	when
    $formData : FormData() and
    not Concession(familyFarm != null && familyFarm.relationshipToTransferee != null) from $formData.concessions
            then
    txn.setAssessmentType(AssessmentType.MANUAL);
    txn.setLodgementSubCategory("Family Farm transfer to a company, trust or association");
    end
	*/


    // Family Farm Transfer to a Relative
	@Test
	public void testRule_5() throws Exception {
	}
    /*
	when
    $formData : FormData() and
    not Concession(familyFarm != null && familyFarm.relationshipToTransferee != null) from $formData.concessions
            then
    txn.addSectionOfTheAct("s56");
    txn.setDolTransactionTypes(new String[] {"10"});
    txn.setAssessmentType(AssessmentType.EXEMPT_FROM_DUTY);
    // TODO - verify with Maria
    txn.setLodgementSubCategory("Family Farm Exemption");
    end
	*/


}
