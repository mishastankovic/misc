## Spring Drools

This modules contains articles about Spring with Drools

## Relevant articles:

- [Drools Spring Integration](https://www.baeldung.com/drools-spring-integration)
