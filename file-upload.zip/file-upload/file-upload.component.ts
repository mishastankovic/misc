import {Component, OnInit} from '@angular/core';
import {FileUploader, FileUploaderOptions} from "ng2-file-upload";
import {environment} from "../../../environments/environment";

const URL = 'http://localhost:3000/api/upload'; // this should come from the environment

@Component({
	selector: 'sro-file-upload',
	templateUrl: './file-upload.component.html',
	styleUrls: ['./file-upload.component.scss']
})
export class FileUploadComponent implements OnInit {

	public uploader: FileUploader = new FileUploader({ url: URL});

	constructor() {
	}

	ngOnInit() {
		this.uploader.onAfterAddingFile = (file) => {
			file.withCredentials = false;
		};
		this.uploader.onCompleteItem = (item: any, response: any, status: any, headers: any) => {
			console.log('ImageUpload:uploaded:', item, status, response);
			alert('File uploaded successfully');
		};
	}
}
