package au.gov.vic.sro.duties.transfer.dao.configuration;

import javax.sql.DataSource;

import au.gov.vic.sro.duties.transfer.repository.ElnoLodgementCaseRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import au.gov.vic.sro.duties.transfer.aspect.UserAspect;

import java.util.Properties;

@Configuration
@ComponentScan(basePackageClasses = { JdbcDaoSupport.class, UserAspect.class })
@EnableTransactionManagement
@EnableAspectJAutoProxy
@EnableJpaRepositories(basePackages = {"au.gov.vic.sro.duties.transfer.repository"})
public class PersistenceConfiguration {

	private static final Logger log = LoggerFactory.getLogger(PersistenceConfiguration.class);

	public static final String ELNO_PERSISTENCE_UNIT_NAME = "elnoPU";

	@Autowired
	private DataSource elnoDataSource;

	@Bean
	public JdbcTemplate jdbcTemplate(@Qualifier("eSysDutiesDataSource") DataSource dataSource) {
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		//jdbcTemplate.setResultsMapCaseInsensitive(true);
		return jdbcTemplate;
	}

	@Bean
	public LocalContainerEntityManagerFactoryBean elnoEnitityManagerFactory() {

		LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
		JpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
		em.setJpaVendorAdapter(vendorAdapter);
		em.setDataSource(elnoDataSource);
		em.setPackagesToScan(new String[] {"au.gov.vic.sro.duties.model"});
		em.setPersistenceUnitName(ELNO_PERSISTENCE_UNIT_NAME);
		em.setJpaProperties(additionalProperties());

		return em;
	}

	Properties additionalProperties() {
		Properties properties = new Properties();
		properties.setProperty("hibernate.hbm2ddl.auto", "create-drop");
		properties.setProperty("hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
		return properties;
	}

}
