package au.gov.vic.sro.duties.transfer.service;

import java.util.List;

import au.gov.vic.sro.duties.dao.exception.GenericDaoException;
import au.gov.vic.sro.duties.transfer.model.AssessingType;
import au.gov.vic.sro.duties.transfer.model.ClaimCategory;

public interface ReferenceDataService {
	List<ClaimCategory> getAllClaimCategoryList() throws GenericDaoException;
	List<ClaimCategory> getClaimCategoryList(AssessingType assessingType) throws GenericDaoException;
}
