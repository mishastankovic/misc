package au.gov.vic.sro.duties.transfer.aspect;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import au.gov.vic.sro.duties.transfer.service.UserService;

@Aspect
@Component
public class UserAspect {

	private static final Logger log = LoggerFactory.getLogger(UserAspect.class);

	@Autowired
	private UserService userService;

	private boolean batchMode;

	@Pointcut("execution(* au.gov.vic.sro.duties.transfer.dao.LodgementDao.*(..))")
	public void eSysDaoPointcut() {}

	@Before("eSysDaoPointcut()")
	public void before() {
		if (batchMode) {
			log.debug("Running in batch mode - using default user");
			userService.setCurrentUser(null); // delegate to the service layer to determine the default user.
//		} else if (userRegistrationHolder == null || userRegistrationHolder.getUserRegistration() == null) { // Not logged in?
//			log.debug("User not logged in");
//			userService.setCurrentUser(null);
		} else {
			// TODO: Where / How do I get the user ID?
			log.debug("Setting user " + "DAMBOU0001");
			userService.setCurrentUser("DAMBOU0001");
		}
	}

	@After("eSysDaoPointcut()")
	public void after() {
		// Unset in all cases
		log.debug("Un-setting user.");
		userService.setCurrentUser(null);
	}

	public UserService getUserService() {
		return userService;
	}

	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	public boolean isBatchMode() {
		return batchMode;
	}

	public void setBatchMode(boolean batchMode) {
		this.batchMode = batchMode;
	}
}