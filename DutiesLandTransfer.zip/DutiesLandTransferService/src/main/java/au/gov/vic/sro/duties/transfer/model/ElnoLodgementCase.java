package au.gov.vic.sro.duties.transfer.model;

import com.sun.javafx.beans.IDProperty;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.Lob;
import javax.persistence.PersistenceContext;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import java.util.Date;

@Entity
@Table(name = "ELNO_LODGEMENT_CASE",
        indexes = {
            @Index(name="ELNO_ID_ELNO_LODGEMENT_CASE_ID_IDX", unique=true, columnList="elno_id, elno_lodgement_case_id")
        }
)

public class ElnoLodgementCase {

    public static final String CASE_REFERENCE_PREFIX = "N";

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CASE_REFERENCE_SEQ")
    @GenericGenerator(
            name = "CASE_REFERENCE_SEQ",
            strategy = "au.gov.vic.sro.duties.transfer.model.ElnoCaseReferenceGenerator",
            parameters = {
                    @Parameter(name = ElnoCaseReferenceGenerator.INCREMENT_PARAM, value = "50"),
                    @Parameter(name = ElnoCaseReferenceGenerator.VALUE_PREFIX_PARAMETER, value = CASE_REFERENCE_PREFIX),
                    @Parameter(name = ElnoCaseReferenceGenerator.NUMBER_FORMAT_PARAMETER, value = "%05d") })
    @Column(name = "CASE_REFERENCE_ID", precision = 16, scale = 0, unique = true, insertable = false)
    private String caseReferenceId;

    @Column(name = "ELNO_ID")
    private String elnoId;

    @Column(name = "ELNO_LODGEMENT_CASE_ID")
    private String elnoLodgementCaseId;


    @Lob
    @Column(name = "LATEST_REQUEST_XML")
    private byte[] latestRequestXml;

    @Column(name = "ESYS_LODGEMENT_ID")
    private Long esysLodgementId;

    @Column(name = "LAST_MODIFIED")
    private Date lastModified;

    public String getElnoId() {
        return elnoId;
    }

    public void setElnoId(String elnoId) {
        this.elnoId = elnoId;
    }

    public String getElnoLodgementCaseId() {
        return elnoLodgementCaseId;
    }

    public void setElnoLodgementCaseId(String elnoLodgementCaseId) {
        this.elnoLodgementCaseId = elnoLodgementCaseId;
    }

    public String getCaseReferenceId() {
        return caseReferenceId;
    }

    public void setCaseReferenceId(String caseReferenceId) {
        this.caseReferenceId = caseReferenceId;
    }

    public byte[] getLatestRequestXml() {
        return latestRequestXml;
    }

    public void setLatestRequestXml(byte[] latestRequestXml) {
        this.latestRequestXml = latestRequestXml;
    }

    public Long getEsysLodgementId() {
        return esysLodgementId;
    }

    public void setEsysLodgementId(Long esysLodgementId) {
        this.esysLodgementId = esysLodgementId;
    }

    public Date getLastModified() {
        return lastModified;
    }

    public void setLastModified(Date lastModified) {
        this.lastModified = lastModified;
    }
}