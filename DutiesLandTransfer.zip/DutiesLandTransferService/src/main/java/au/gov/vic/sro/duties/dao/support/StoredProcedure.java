package au.gov.vic.sro.duties.dao.support;

import java.util.Calendar;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.SQLExceptionTranslator;

import au.gov.vic.sro.duties.dao.exception.DatabaseValidationMessage;
import au.gov.vic.sro.duties.dao.exception.GenericDaoException;
import au.gov.vic.sro.duties.dao.mapper.transaction.facades.MessageRec;
import au.gov.vic.sro.duties.transfer.dao.mapper.MessageRecMapper;

public abstract class StoredProcedure extends org.springframework.jdbc.object.StoredProcedure {

	protected static final String ESYS_COMMON_PKG = "esys_common_pkg";

	protected static final String PTO_MESSAGE_TAB = "pto_message_tab";

	protected static final String DO_TRANSACTION_REC = "DO_TRANSACTION_REC";
	protected static final String DO_LODGEMENT_REC = "DO_LODGEMENT_REC";
	protected static final String DO_MESSAGE_TAB = "DO_MESSAGE_TAB";

	protected static final String PTI_DOCUMENT_ID = "pti_document_id";
	protected static final String PTI_LODGEMENT_ID = "pti_lodgement_id";
	protected static final String PTI_PEXA_DOCUMENT_ID = "pti_pexa_document_id";

	/**
	 * Allow use as a bean.
	 */
	protected StoredProcedure() {
		super();
	}

	/**
	 * Create a new object wrapper for a stored procedure.
	 * @param ds DataSource to use throughout the lifetime
	 * of this object to obtain connections
	 * @param name name of the stored procedure in the database
	 */
	protected StoredProcedure(DataSource ds, String name) {
		super(ds, name);
	}

	/**
	 * Create a new object wrapper for a stored procedure.
	 * @param jdbcTemplate JdbcTemplate which wraps DataSource
	 * @param name name of the stored procedure in the database
	 */
	protected StoredProcedure(JdbcTemplate jdbcTemplate, String name) {
		super(jdbcTemplate, name);
	}

	protected StoredProcedure(JdbcTemplate jdbcTemplate, String name, SQLExceptionTranslator sqlExceptionTranslator) {
		super(jdbcTemplate, name);
		getJdbcTemplate().setExceptionTranslator(sqlExceptionTranslator);
	}

	protected Map<?, ?> defaultExecuteHandler(Map<String, Object> inParams, String returnMessagesParameterName)
			throws GenericDaoException {
		return defaultExecuteHandler(inParams, returnMessagesParameterName, null);
	}

	protected Map<?, ?> defaultExecuteHandler(Map<String, Object> inParams, String returnMessagesParameterName,
			String requiredOutputParameter) throws GenericDaoException {

		if (inParams == null) throw new NullPointerException("Passed inParams was null");

		Map<?, ?> outParams = execute(inParams);

		if (outParams.isEmpty()) {
			throw createGenericDaoException("No output parameters returned!", inParams, outParams);
		}

		if (returnMessagesParameterName != null) {
//			throwOracleExceptionMessagesIfPresent(inParams, outParams, returnMessagesParameterName);
		}

		if (requiredOutputParameter != null) {

			Object requiredOutput = outParams.get(requiredOutputParameter);

			if (requiredOutput == null) {
//				throw createGenericDaoException(String.format(
//						"%s; Required output parameter (parameter name=%s) was null",
//						getMessageOnUnrecoverableDatabaseException(inParams), requiredOutputParameter), inParams,
//						outParams);
			}

		}

		return outParams;
	}

	private static final int START = 0;
	private static final int END = 6;

	// TODO: Yuke: What time is eSys unavailable
	@SuppressWarnings("rawtypes")
	@Override
	public Map execute(Map inParams) throws DataAccessException {
		try {
			return super.execute(inParams);
		} catch (DataAccessResourceFailureException ex) {
			int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
			if (hour >= START && hour <= END) {
				throw new DataAccessResourceFailureException(
						"eSys is unavailable between " + START + ":00 and " + END
								+ ":00", ex);
			} else {
				throw ex;
			}
		}
	}

	@SuppressWarnings({ "rawtypes" })
	protected GenericDaoException createGenericDaoException(String message, Map inParams, Map outParams,
			Object[] _messages) {
		return createGenericDaoException(null, message, inParams, outParams, _messages);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	protected GenericDaoException createGenericDaoException(Throwable cause, String message, Map inParams,
			Map outParams, Object[] _messages) {

		GenericDaoException exception = null;

		if (cause == null) {
			exception = new GenericDaoException(message, getSql(), inParams, outParams);
		} else {
			exception = new GenericDaoException(cause, message, getSql(), inParams, outParams);
		}

		if (_messages != null) {

			MessageRecMapper mapper = new MessageRecMapper();
			MessageRec[] messages = mapper.mapOracleMessages(_messages);

			for (MessageRec _message : messages) {
				if (_message != null) {
					exception.getMessages()
							.add(new DatabaseValidationMessage(_message.getMSG_TYPE(), _message.getMSG_TEXT(),
									_message.getRELATED_DATA_FIELD(), _message.getMSG_CLASS(), _message.getDATA_ID(),
									_message.getID_TYPE()));
				}
			}

		}

		return exception;
	}

	@SuppressWarnings("rawtypes")
	protected GenericDaoException createGenericDaoException(String message, Map inParams, Map outParams) {
		return createGenericDaoException(message, inParams, outParams, null);
	}

	@SuppressWarnings("rawtypes")
	protected GenericDaoException createGenericDaoException(Throwable cause, String message, Map inParams,
			Map outParams) {
		return createGenericDaoException(cause, message, inParams, outParams, null);
	}
}
