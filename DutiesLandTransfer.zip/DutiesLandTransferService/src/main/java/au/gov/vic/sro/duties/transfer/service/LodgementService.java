package au.gov.vic.sro.duties.transfer.service;

import au.gov.vic.sro.duties.dao.exception.GenericDaoException;
import au.gov.vic.sro.duties.transfer.model.Lodgement;

public interface LodgementService {
	Lodgement getLodgement(Long lodgementId) throws GenericDaoException;
}
