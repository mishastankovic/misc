package au.gov.vic.sro.duties.transfer.dao.mapper;

import java.util.ArrayList;
import java.util.List;

import au.gov.vic.sro.duties.dao.mapper.refdata.ReferenceDataRecMapper;
import au.gov.vic.sro.duties.lodgement.LodgementCategory;
import au.gov.vic.sro.duties.transfer.model.AssessingType;
import au.gov.vic.sro.duties.transfer.model.ClaimCategory;

public class ReferenceDataMapper extends ReferenceDataRecMapper {

	public List<ClaimCategory> mapLodgementCategoryToClaimCategory(List<LodgementCategory> lodgementCategoryList) {
		List<ClaimCategory> claimCategoryList = new ArrayList<ClaimCategory>();
		for (LodgementCategory lodgementCategory : lodgementCategoryList) {
			ClaimCategory claimCategory = new ClaimCategory();
			switch(lodgementCategory.getType()) {
			case MANUAL_TRANSFER:
				claimCategory.setAssessingType(AssessingType.INTERNAL);
				break;
			case SYSTEM_TRANSFER:
				claimCategory.setAssessingType(AssessingType.EXTERNAL);
				break;
			default:
				continue; // or should error?
			}
			claimCategory.setCategoryCode(lodgementCategory.getOracleDbValue());
			claimCategory.setCategoryName(lodgementCategory.getLabel());
			claimCategory.setActive(lodgementCategory.getActive());
			claimCategoryList.add(claimCategory);
		}
		return claimCategoryList;
	}
}
