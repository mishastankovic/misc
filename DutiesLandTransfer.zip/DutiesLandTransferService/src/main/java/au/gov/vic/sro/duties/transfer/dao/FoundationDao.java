package au.gov.vic.sro.duties.transfer.dao;

public interface FoundationDao {
	void setUser(String user);
}
