package au.gov.vic.sro.duties.dao.exception;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import oracle.sql.ARRAY;
import oracle.sql.STRUCT;

import org.apache.commons.lang3.StringUtils;

/** 
 * A copy of au.gov.vic.sro.duties.dao.exception.GenericDaoException
 *
 * @see au.gov.vic.sro.duties.dao.exception.GenericDaoException
 */
public class GenericDaoException extends Exception {

	private static final long serialVersionUID = -1420211653231189685L;

	private final List<DatabaseValidationMessage> messages = new ArrayList<DatabaseValidationMessage>();

	private final Map<String, String> parameters = new HashMap<String, String>();

	private final Map<String, String> returnValues = new HashMap<String, String>();

	private final String sql;

	public GenericDaoException(Throwable cause, String message, String sql) {
		super(message, cause);
		this.sql = StringUtils.trimToNull(sql);
	}

	public GenericDaoException(String message, String sql) {
		super(message);
		this.sql = StringUtils.trimToNull(sql);
	}

	public GenericDaoException(String message, String sql, Map<String, Object> _inParameters) {
		this(message, sql);
		if (_inParameters == null)
			return;
		for (String key : _inParameters.keySet()) {
			addParameter(key, _inParameters.get(key));
		}
	}

	public GenericDaoException(String message, String sql, Throwable cause) {
		super(message, cause);
		this.sql = StringUtils.trimToNull(sql);
	}

	public GenericDaoException(Throwable cause, String message, String sql, Map<String, Object> _inParameters) {
		this(message, sql, cause);
		if (_inParameters == null)
			return;
		for (String key : _inParameters.keySet()) {
			addParameter(key, _inParameters.get(key));
		}
	}

	public GenericDaoException(String message, String sql, Map<String,
			Object> _inParameters, Map<String, Object> _outParameters) {
		this(message, sql, _inParameters);
		if (_outParameters == null)
			return;
		for (String key : _outParameters.keySet()) {
			addReturnValue(key, _outParameters.get(key));
		}
	}

	public GenericDaoException(Throwable cause, String message, String sql, Map<String,
			Object> _inParameters, Map<String, Object> _outParameters) {
		this(cause, message, sql, _inParameters);
		if (_outParameters == null)
			return;
		for (String key : _outParameters.keySet()) {
			addReturnValue(key, _outParameters.get(key));
		}
	}

	public void addParameter(String key, Object value) {
		parameters.put(key, coerceToString(value));
	}

	private String coerceToString(Object value) {
		if (value == null)
			return null;
		if (value instanceof String)
			return (String) value;
		if (value instanceof STRUCT) {
			try {
				return (((STRUCT) value).dump());
			} catch (SQLException ex) {
				// Can't throw an exception
				return value.toString();
			}
		}
		if (value instanceof ARRAY) {
			try {
				return ((ARRAY) value).dump();
			} catch (SQLException ex) {
				// Can't throw an exception
				return value.toString();
			}
		}

		return value.toString();
	}

	public void addReturnValue(String key, Object value) {
		returnValues.put(key, coerceToString(value));
	}

	public List<DatabaseValidationMessage> getMessages() {
		return messages;
	}

	public String outputMessages() {
		StringBuffer buffer = new StringBuffer();
		for (DatabaseValidationMessage message : messages) {
			buffer.append(String.format("Identifier: %s, Type: %s, Message: %s\n", 
					message.getMessageIdentifier(), message.getType(), message.getMessage()));
		}
		return buffer.toString();
	}

	public String outputDetail() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("GenericDaoException Detailed Output: START\n");
		buffer.append(getMessage() + "\n");
		if (sql != null) buffer.append(String.format("Invoked SQL: [%s]\n", sql));
		buffer.append("\nInput Parameters:\n");
		for (String key : parameters.keySet()) {
			buffer.append(String.format("\tParameter Name: [%s], Parameter Value: [%s]\n", key, parameters.get(key)));	
		}
		buffer.append("\nReturn Values :\n");
		for (String key : returnValues.keySet()) {
			buffer.append(String.format("\tReturn Value Key: [%s], Return Value: [%s]\n", key, returnValues.get(key)));	
		}
		buffer.append("\nMessages:\n");
		buffer.append(outputMessages());
		buffer.append("GenericDaoException Detailed Output: END\n");
		return buffer.toString();
	}

	public boolean hasMessage(String messageIdentifier) {
		boolean found = false;
		for (DatabaseValidationMessage message : messages) {
			if (messageIdentifier.equals(message.getMessageIdentifier())) {
				found = true;
				break;
			}
		}

		return found;
	}

	@Override public String toString() {
		return outputDetail();
	}

}