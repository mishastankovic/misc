package au.gov.vic.sro.duties.transfer.service;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import au.gov.vic.sro.duties.transfer.dao.FoundationDao;

@Service("userService")
@Transactional(propagation = Propagation.REQUIRED)
public class UserServiceImpl implements UserService {

	@Autowired
	private FoundationDao foundationDao;

//
//	public UserServiceImpl(FoundationDao foundationDao) {
//		this.foundationDao = foundationDao;
//	}

	@Transactional
	@Override
	public void setCurrentUser(String userId) {
		foundationDao.setUser(StringUtils.isEmpty(userId) ? "NOTLOGGEDIN" : userId);
	}
}
