package au.gov.vic.sro.duties.transfer.dao;

import au.gov.vic.sro.duties.dao.exception.GenericDaoException;
import au.gov.vic.sro.duties.transfer.model.AssessingType;
import au.gov.vic.sro.duties.transfer.model.ClaimCategory;

import java.util.List;

public interface ReferenceDataDao {

	List<ClaimCategory> getAllClaimCategoryList() throws GenericDaoException;
	List<ClaimCategory> getClaimCategoryList(AssessingType assessingType) throws GenericDaoException;
}
