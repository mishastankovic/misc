package au.gov.vic.sro.duties.transfer.dao;

import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.support.SQLExceptionTranslator;
import org.springframework.stereotype.Repository;

import au.gov.vic.sro.duties.dao.exception.GenericDaoException;
import au.gov.vic.sro.duties.dao.support.OracleSQLExceptionTranslator;
import au.gov.vic.sro.duties.transfer.dao.mapper.ReferenceDataMapper;
import au.gov.vic.sro.duties.transfer.model.AssessingType;
import au.gov.vic.sro.duties.transfer.model.ClaimCategory;

@Repository("referenceDataDao")
public class ReferenceDataDaoImpl extends JdbcDaoSupport implements ReferenceDataDao {

	private SQLExceptionTranslator sqlExceptionTranslator = new OracleSQLExceptionTranslator();
	private QueryRefDataProcedure queryRefDataProcedure;
	private ReferenceDataMapper mapper = new ReferenceDataMapper();

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@PostConstruct
	private void initialize() {
		setJdbcTemplate(jdbcTemplate);
	}

	@Override
	protected void initTemplateConfig() {
		queryRefDataProcedure = new QueryRefDataProcedure(getJdbcTemplate(), sqlExceptionTranslator);
	}

	@Override
	public List<ClaimCategory> getAllClaimCategoryList() throws GenericDaoException {
		return mapper.mapLodgementCategoryToClaimCategory(queryRefDataProcedure.getAllElnoLodgementCategoryList());
	}

	@Override
	public List<ClaimCategory> getClaimCategoryList(AssessingType assessingType) throws GenericDaoException {
		return mapper.mapLodgementCategoryToClaimCategory(queryRefDataProcedure.getElnoLodgementCategoryList(assessingType));
	}
}
