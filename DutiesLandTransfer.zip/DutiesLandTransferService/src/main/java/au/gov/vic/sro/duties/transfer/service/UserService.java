package au.gov.vic.sro.duties.transfer.service;

public interface UserService {
	void setCurrentUser(String userId);
}
