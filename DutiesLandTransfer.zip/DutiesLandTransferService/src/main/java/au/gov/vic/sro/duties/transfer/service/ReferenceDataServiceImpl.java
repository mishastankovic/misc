package au.gov.vic.sro.duties.transfer.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import au.gov.vic.sro.duties.dao.exception.GenericDaoException;
import au.gov.vic.sro.duties.transfer.dao.ReferenceDataDao;
import au.gov.vic.sro.duties.transfer.model.AssessingType;
import au.gov.vic.sro.duties.transfer.model.ClaimCategory;

@Service("referenceDataService")
@Transactional(propagation = Propagation.REQUIRED)
public class ReferenceDataServiceImpl implements ReferenceDataService {

	private static final Logger log = LoggerFactory.getLogger(ReferenceDataServiceImpl.class);

	private ReferenceDataDao referenceDataDao;

	@Autowired
	public ReferenceDataServiceImpl(ReferenceDataDao referenceDataDao) {
		this.referenceDataDao = referenceDataDao;
	}

	@Transactional(readOnly = true)
	@Override
	public List<ClaimCategory> getAllClaimCategoryList() throws GenericDaoException {
		return referenceDataDao.getAllClaimCategoryList();
	}

	@Transactional(readOnly = true)
	@Override
	public List<ClaimCategory> getClaimCategoryList(AssessingType assessingType) throws GenericDaoException {
		return referenceDataDao.getClaimCategoryList(assessingType);
	}
}
