package au.gov.vic.sro.duties.transfer.model;

public enum AssessingType {
	EXTERNAL("SYSTEM"), INTERNAL("MANUAL");

	private final String name;

	private AssessingType(String name) {
		this.name = name;
	}

	public String toString() {
		return this.name;
	}
}
