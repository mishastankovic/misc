package au.gov.vic.sro.duties.transfer.dao;

import java.sql.SQLException;
import java.sql.Struct;
import java.sql.Types;
import java.util.LinkedHashMap;
import java.util.Map;

import oracle.sql.STRUCT;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.support.SQLExceptionTranslator;

import au.gov.vic.sro.duties.dao.exception.GenericDaoException;
import au.gov.vic.sro.duties.dao.mapper.lodgement.LodgementMapper;
import au.gov.vic.sro.duties.dao.support.StoredProcedure;
import au.gov.vic.sro.duties.lodgement.Lodgement;

public class GetLodgementDetailsProcedure extends StoredProcedure {

	private static final String STORED_PROC_NAME = "do_query_pkg.get_lodgement_details_f";

	public GetLodgementDetailsProcedure(JdbcTemplate jdbcTemplate) {//, SQLExceptionTranslator sqlExceptionTranslator) {
		super(jdbcTemplate, STORED_PROC_NAME);
		setFunction(true);		
		declareParameter(new SqlOutParameter(DO_LODGEMENT_REC, Types.STRUCT, DO_LODGEMENT_REC));
		declareParameter(new SqlParameter(PTI_LODGEMENT_ID, Types.NUMERIC));
		declareParameter(new SqlOutParameter(PTO_MESSAGE_TAB, Types.ARRAY,
				DO_MESSAGE_TAB));
		compile();
	}

	public Lodgement getLodgement(Long lodgementId) throws GenericDaoException {
		Map<String, Object> inParams = new LinkedHashMap<String, Object>();
		inParams.put(PTI_LODGEMENT_ID, lodgementId);
		Map<?, ?> outParams = defaultExecuteHandler(inParams, PTO_MESSAGE_TAB, DO_LODGEMENT_REC);
		try {
			return lodgementFromOracleStructures(
					(STRUCT) outParams.get(DO_LODGEMENT_REC));
		} catch (Exception ex) {
			throw createGenericDaoException(ex,
					"Exception occurred during mapping", inParams, outParams);
		}
	}

	protected Lodgement lodgementFromOracleStructures(Struct doLodgementRec) throws SQLException {
		LodgementMapper lodgementMapper = new LodgementMapper();
		Object[] structAsArray = doLodgementRec.getAttributes();
		return lodgementMapper.mapLodgement(structAsArray);
	}
}