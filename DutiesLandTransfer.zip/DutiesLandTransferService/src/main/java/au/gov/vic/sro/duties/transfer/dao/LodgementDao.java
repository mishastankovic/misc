package au.gov.vic.sro.duties.transfer.dao;

import au.gov.vic.sro.duties.dao.exception.GenericDaoException;
import au.gov.vic.sro.duties.transfer.model.Lodgement;

public interface LodgementDao {
	Lodgement getLodgement(Long lodgementId) throws GenericDaoException;
}
