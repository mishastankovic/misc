package au.gov.vic.sro.duties.transfer.dao;

import java.sql.Types;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.stereotype.Repository;

@Repository("foundationDao")
public class FoundationDaoImpl extends JdbcDaoSupport implements FoundationDao {

	private SetUserProcedure setUserProcedure;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@PostConstruct
	private void initialize() {
		setJdbcTemplate(jdbcTemplate);
	}

	@Override
	protected void initTemplateConfig() {
		setUserProcedure = new SetUserProcedure(getJdbcTemplate());
	}

	@Override
	public void setUser(String user) {
		Map<String, Object> inParams = new LinkedHashMap<String, Object>();
		inParams.put("p_user", user);
		setUserProcedure.execute(inParams);
	}

	private static class SetUserProcedure extends StoredProcedure {

		private static final String STORED_PROC_NAME = "egui_foundation_pkg.setUser";

		public SetUserProcedure(JdbcTemplate jdbcTemplate) {
			super(jdbcTemplate, STORED_PROC_NAME);
			setFunction(false);

			// Record type must be in upper case
			declareParameter(new SqlParameter("p_user", Types.VARCHAR));
			compile();
		}
	}
}
