package au.gov.vic.sro.duties.transfer.dao.configuration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.FilterType;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import au.gov.vic.sro.duties.transfer.dao.ReferenceDataDaoImpl;

@Deprecated // TODO To be removed as categories shall be coming from eSys
@EnableTransactionManagement
//@formatter:off
@ComponentScan(
        basePackageClasses = { ReferenceDataDaoImpl.class },
        useDefaultFilters = false,
        includeFilters = {
                @ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE, value = ReferenceDataDaoImpl.class),
        })
@Configuration
public class ReferenceDataConfiguration {

    private static final Logger log = LoggerFactory.getLogger(ReferenceDataConfiguration.class);

    @Value("${persistence.reference-data}")
    private String persistenceXmlLocation;

    @Bean
    public LocalContainerEntityManagerFactoryBean referenceDataManagerFactory() {
        log.debug("Configuring entity manager factory; bean=[referenceDataManagerFactory]");
        log.debug("useing persistence xml file : " + this.persistenceXmlLocation);

        LocalContainerEntityManagerFactoryBean factory = new LocalContainerEntityManagerFactoryBean();
        factory.setPersistenceUnitName("referenceDataPU");
        factory.setPersistenceXmlLocation(persistenceXmlLocation);

        return factory;
    }
}
