package au.gov.vic.sro.duties.transfer.dao.configuration;

import javax.sql.DataSource;
import javax.transaction.SystemException;
import javax.transaction.UserTransaction;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.TransactionManagementConfigurer;
import org.springframework.transaction.jta.JtaTransactionManager;

import com.atomikos.icatch.jta.UserTransactionImp;
import com.atomikos.icatch.jta.UserTransactionManager;

@Configuration
@EnableTransactionManagement
@Profile({ "local" })
public class TomcatConfiguration implements TransactionManagementConfigurer {

	private static final Logger log = LoggerFactory.getLogger(TomcatConfiguration.class);

//	@Bean
//	@ConfigurationProperties(prefix = "spring.jta.atomikos.datasource.esys")
//	public DataSource eSysDutiesDataSource() {
//		return new AtomikosDataSourceBean();
//	}

	@Bean
	@ConfigurationProperties(prefix = "spring.datasource.esys")
	public DataSource eSysDutiesDataSource() {
		return DataSourceBuilder.create().build();
	}

	@Bean
	public PlatformTransactionManager transactionManager() {
		if (log.isDebugEnabled()) log.debug("Configured transaction manager; bean=[transactionManager]");
		JtaTransactionManager jtaTransactionManager = new JtaTransactionManager();
		try {
			UserTransactionManager transactionManager = new UserTransactionManager();
			transactionManager.init();
			transactionManager.setForceShutdown(false);
			jtaTransactionManager.setTransactionManager(transactionManager);
			UserTransaction userTransaction = new UserTransactionImp();
			userTransaction.setTransactionTimeout(300);
			jtaTransactionManager.setUserTransaction(userTransaction);
		} catch(SystemException e) {
			log.error("Failed to initialise transaction manager", e);
		}
		return jtaTransactionManager;
	}

	@Override
	public PlatformTransactionManager annotationDrivenTransactionManager() {
		return transactionManager();
	}

	@Bean
	@ConfigurationProperties(prefix = "spring.datasource.elno")
	public DataSource elnoDataSource() {
		return DataSourceBuilder.create().build();
	}

}
