package au.gov.vic.sro.duties.transfer.dao;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import au.gov.vic.sro.duties.dao.exception.GenericDaoException;
import au.gov.vic.sro.duties.transfer.dao.mapper.LodgementMapper;
import au.gov.vic.sro.duties.transfer.model.Lodgement;

@Repository("lodgementDao")
public class LodgementDaoImpl extends JdbcDaoSupport implements LodgementDao {

	private static final String IDENTIFIER_MUST_NOT_BE_NULL = "identifier must not be null";

	private GetLodgementDetailsProcedure getLodgementDetailsProcedure;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@PostConstruct
	private void initialize() {
		setJdbcTemplate(jdbcTemplate);
	}

	@Override
	protected void initTemplateConfig() {
		getLodgementDetailsProcedure = new GetLodgementDetailsProcedure(getJdbcTemplate());
	}

	@Override
	public Lodgement getLodgement(Long lodgementId) throws GenericDaoException {
		if (lodgementId == null) throw new IllegalArgumentException(IDENTIFIER_MUST_NOT_BE_NULL);
		return LodgementMapper.map(getLodgementDetailsProcedure.getLodgement(lodgementId));
	}
}
