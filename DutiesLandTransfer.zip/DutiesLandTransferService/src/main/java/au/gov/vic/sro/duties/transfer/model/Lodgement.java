package au.gov.vic.sro.duties.transfer.model;

public class Lodgement extends au.gov.vic.sro.duties.lodgement.Lodgement {

	private static final long serialVersionUID = 863812148241927124L;
}
