package au.gov.vic.sro.duties.transfer.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import au.gov.vic.sro.duties.dao.exception.GenericDaoException;
import au.gov.vic.sro.duties.transfer.dao.LodgementDao;
import au.gov.vic.sro.duties.transfer.model.Lodgement;

public class LodgementServiceImpl implements LodgementService {
	private LodgementDao lodgementDao;

	@Autowired
	public LodgementServiceImpl(LodgementDao lodgementDao) {
		this.lodgementDao = lodgementDao;
	}

	@Transactional(readOnly = true)
	@Override
	public Lodgement getLodgement(Long lodgementId) throws GenericDaoException {
		return lodgementDao.getLodgement(lodgementId);
	}
}
