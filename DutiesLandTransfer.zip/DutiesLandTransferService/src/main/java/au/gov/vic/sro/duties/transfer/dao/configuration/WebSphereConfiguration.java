package au.gov.vic.sro.duties.transfer.dao.configuration;

import javax.naming.NamingException;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.TransactionManagementConfigurer;
import org.springframework.transaction.jta.WebSphereUowTransactionManager;

@Configuration
@EnableTransactionManagement
@Profile({ "localtest", "development", "integration", "integration2", "training", "production" })
//@ImportResource("classpath:/dutiesContextDataSource.xml")	// Yuke: Won't work! Why?
public class WebSphereConfiguration implements TransactionManagementConfigurer {

	private static final Logger log = LoggerFactory.getLogger(PersistenceConfiguration.class);

	private static final String ESYS_DATA_SOURCE_JNDI = "jdbc/esysDS_DOL";
	private static final String ELNO_DATA_SOURCE_JNDI = "jdbc/elnoDS_DOL";

	@Bean
	public DataSource eSysDutiesDataSource() throws IllegalArgumentException, NamingException {
		JndiDataSourceLookup dsLookup = new JndiDataSourceLookup();
		dsLookup.setResourceRef(true);
		return dsLookup.getDataSource(ESYS_DATA_SOURCE_JNDI);
	}

	@Bean
	public DataSource elnoDataSource() throws IllegalArgumentException, NamingException {
		JndiDataSourceLookup dsLookup = new JndiDataSourceLookup();
		dsLookup.setResourceRef(true);
		return dsLookup.getDataSource(ELNO_DATA_SOURCE_JNDI);
	}


	@Bean
	public PlatformTransactionManager transactionManager() {
		if (log.isDebugEnabled()) log.debug("Configured transaction manager; bean=[transactionManager]");
		WebSphereUowTransactionManager transactionManager = new WebSphereUowTransactionManager();
		transactionManager.setAutodetectTransactionManager(false);
		return transactionManager;
	}

	@Override
	public PlatformTransactionManager annotationDrivenTransactionManager() {
		return transactionManager();
	}
}