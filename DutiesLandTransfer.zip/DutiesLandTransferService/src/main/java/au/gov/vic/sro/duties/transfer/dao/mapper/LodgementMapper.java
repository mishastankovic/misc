package au.gov.vic.sro.duties.transfer.dao.mapper;

import au.gov.vic.sro.duties.transfer.model.Lodgement;

public class LodgementMapper {

	public static Lodgement map(au.gov.vic.sro.duties.lodgement.Lodgement legacy) {
		Lodgement lodgement = new Lodgement();
		lodgement.setIdentifier(legacy.getIdentifier());
		lodgement.setStatus(legacy.getStatus());
		lodgement.setLodgementCategoryDbValue(legacy.getLodgementCategoryDbValue());
		lodgement.getTransactions().addAll(legacy.getTransactions());
		return lodgement;
	}
}
