package au.gov.vic.sro.duties.dao.support;

import java.sql.SQLException;

import org.springframework.dao.ConcurrencyFailureException;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.InvalidDataAccessApiUsageException;
import org.springframework.dao.PessimisticLockingFailureException;
import org.springframework.jdbc.support.SQLErrorCodeSQLExceptionTranslator;

public class OracleSQLExceptionTranslator extends SQLErrorCodeSQLExceptionTranslator {

	private static final int SQL_CODE_NO_ARGUMENTS_PASSED = 20079;
	private static final int SQL_CODE_OPTIMISTIC_LOCKING_FAILED = 20080;
	private static final int SQL_CODE_RESOURCE_BUSY = 20081;

	/**
	 * @see org.springframework.jdbc.support.SQLErrorCodeSQLExceptionTranslator#customTranslate(
	 *      java.lang.String, java.lang.String, java.sql.SQLException)
	 */
	@Override
	public DataAccessException customTranslate(String task, String sql, SQLException ex) {

		switch (ex.getErrorCode()) {
		case SQL_CODE_NO_ARGUMENTS_PASSED:
			return new InvalidDataAccessApiUsageException(task, ex);
		case SQL_CODE_OPTIMISTIC_LOCKING_FAILED:
			return new ConcurrencyFailureException(task, ex);
		case SQL_CODE_RESOURCE_BUSY:
			return new PessimisticLockingFailureException(task, ex);

		default:
			// Fall back to Spring's default exception handling
			return null;
		}
	}
}
