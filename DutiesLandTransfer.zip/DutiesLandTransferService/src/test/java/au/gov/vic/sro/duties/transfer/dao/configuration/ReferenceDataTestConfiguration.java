package au.gov.vic.sro.duties.transfer.dao.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.FilterType;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import au.gov.vic.sro.duties.transfer.dao.ReferenceDataDaoImpl;

import javax.persistence.EntityManagerFactory;

@EnableTransactionManagement
//@formatter:off
@ComponentScan(
		basePackageClasses = {ReferenceDataDaoImpl.class },
		useDefaultFilters = false,
		includeFilters = {
				@ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE, value = ReferenceDataDaoImpl.class),
		})
//@formatter:on
@Configuration
public class ReferenceDataTestConfiguration {
	@Bean
	public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
		LocalContainerEntityManagerFactoryBean factory = new LocalContainerEntityManagerFactoryBean();
		factory.setPersistenceUnitName("referenceDataPU");
		factory.setPersistenceXmlLocation("classpath:/META-INF/persistence-test.xml");
		return factory;
	}

	@Bean
	public JpaTransactionManager transactionManager(EntityManagerFactory emf) {
		JpaTransactionManager jpaTransactionManager = new JpaTransactionManager();
		jpaTransactionManager.setEntityManagerFactory(emf);
		return jpaTransactionManager;
	}
}
