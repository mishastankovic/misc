package au.gov.vic.sro.duties.transfer.dao.configuration;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.support.AnnotationConfigContextLoader;

@Configuration
@EnableAutoConfiguration
@PropertySource("classpath:META-INF/persistence-test.properties")
@ContextConfiguration(classes = { PersistenceConfiguration.class }, loader = AnnotationConfigContextLoader.class)
@ActiveProfiles({ "local" }) // To activate TomcatConfiguration
@EnableJpaRepositories(basePackages = {"au.gov.vic.sro.duties.transfer.repository"})
public class PersistenceTestConfiguration extends TomcatConfiguration {
}
