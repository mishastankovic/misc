package au.gov.vic.sro.duties.transfer.dao;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;
import org.springframework.transaction.annotation.Transactional;

import au.gov.vic.sro.duties.dao.exception.GenericDaoException;
import au.gov.vic.sro.duties.transfer.dao.configuration.PersistenceTestConfiguration;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(
		classes = { PersistenceTestConfiguration.class, LodgementDaoImpl.class },
		loader = AnnotationConfigContextLoader.class)
// TODO: Perhaps, this is not the correct way to load up test configurations? 
// https://stackoverflow.com/questions/50612589/two-spring-junit-test-classes-instancealreadyexistsexception-when-testproperty
@TestPropertySource(
		properties = { "spring.application.name=LodgementDaoImplTest",
				"spring.jmx.default-domain=LodgementDaoImplTest" })
@Transactional
@Rollback
public class LodgementDaoImplTest {

	@Autowired
	private LodgementDao lodgementDao;

	@Test(expected = GenericDaoException.class)
	public void testGetLodgement() throws GenericDaoException {
		lodgementDao.getLodgement(0l);
	}

	@Test
	public void testClaim() throws GenericDaoException {
		
	}
}
