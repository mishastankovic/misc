package au.gov.vic.sro.duties.transfer.model;

import static org.hamcrest.Matchers.hasToString;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertThat;

import org.apache.commons.lang3.SerializationUtils;
import org.hamcrest.MatcherAssert;
import org.junit.Before;
import org.junit.Test;

public class ClaimCategoryTest {
	private ClaimCategory bean1;
	private ClaimCategory bean2;

	@Before
	public void setUp() throws Exception {
		bean1 = new ClaimCategory();
		bean1.setCategoryCode("code");
		bean1.setCategoryName("subCategory");
		bean1.setParentCategoryCode("parentCode");
		bean1.setAssessingType(AssessingType.EXTERNAL);

		bean2 = SerializationUtils.clone(bean1);
	}

	@Test
	public void testGetters() throws Exception {
		assertThat(bean1.getCategoryCode(), equalTo("code"));
		assertThat(bean1.getParentCategoryCode(), equalTo("parentCode"));
		assertThat(bean1.getCategoryName(), equalTo("subCategory"));
		assertThat(bean1.getAssessingType(), equalTo(AssessingType.EXTERNAL));
	}

	@Test
	public void testHashCode() throws Exception {
		int result = bean1.hashCode();
		assertThat(result, equalTo(bean2.hashCode()));
	}

	@Test
	public void testToString() throws Exception {
		MatcherAssert.assertThat(bean1, hasToString(bean1.toString()));
	}

	@Test
	public void testEqualsObject() throws Exception {
		MatcherAssert.assertThat(bean1.equals(bean1), equalTo(true));
		MatcherAssert.assertThat(bean1.equals(null), equalTo(false));
		MatcherAssert.assertThat(bean1.equals("nope"), equalTo(false));
		MatcherAssert.assertThat(bean1.equals(bean2), equalTo(true));
	}
}
