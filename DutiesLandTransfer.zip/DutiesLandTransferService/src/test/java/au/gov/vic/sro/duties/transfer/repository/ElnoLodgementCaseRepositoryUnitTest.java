package au.gov.vic.sro.duties.transfer.repository;

import au.gov.vic.sro.duties.transfer.configuration.ElnoPersistenceTestConfiguration;
import au.gov.vic.sro.duties.transfer.model.ElnoLodgementCase;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

@RunWith(SpringRunner.class)
@DataJpaTest
@ContextConfiguration(
        classes = {ElnoPersistenceTestConfiguration.class},
        loader = AnnotationConfigContextLoader.class)
public class ElnoLodgementCaseRepositoryUnitTest {

    @Autowired
    private TestEntityManager entityManager;

    @Autowired
    private ElnoLodgementCaseRepository elnoLodgementCaseRepository;

    @Test
    public void testFindByElnoIdAndCaseId() {

        String elnoId = "elnoId1";
        String elnoLodgementCaseId = "elnoLodgementCaseId1";

        // given
        elnoLodgementCaseRepository.save(createElnoLodgementCase(elnoId, elnoLodgementCaseId));

        // when
        List<ElnoLodgementCase> result = elnoLodgementCaseRepository.findByElnoIdAndCaseId(elnoId, elnoLodgementCaseId);

        // then
        assertNotNull(result);
        assertEquals(result.size(), 1);
        assertEquals(result.get(0).getElnoId(), elnoId);
        assertEquals(result.get(0).getElnoLodgementCaseId(), elnoLodgementCaseId);
    }


    @Test
    public void testCreateDelete() {

        String elnoId = "elnoId1";
        String elnoLodgementCaseId = "elnoLodgementCaseId1";

        // given
        ElnoLodgementCase elnoLodgementCase = createElnoLodgementCase(elnoId, elnoLodgementCaseId);
        elnoLodgementCaseRepository.save(elnoLodgementCase);

        // when
        Iterable<ElnoLodgementCase> result = elnoLodgementCaseRepository.findAll();

        // then
        assertNotNull(result);
        result.forEach(r -> {
            assertEquals(r.getElnoId(), elnoId);
            assertEquals(r.getElnoLodgementCaseId(), elnoLodgementCaseId);
            elnoLodgementCaseRepository.delete(r);
        });

        result = elnoLodgementCaseRepository.findAll();
        assertTrue(result == null || !result.iterator().hasNext());
    }


    private ElnoLodgementCase createAndSaveElnoLodgementCase(String elnoId, String elnoLodgementCaseId) {
        ElnoLodgementCase elnoCase = createElnoLodgementCase(elnoId, elnoLodgementCaseId);
        entityManager.persist(elnoCase);
        entityManager.flush();
        return elnoCase;
    }

    private ElnoLodgementCase createElnoLodgementCase(String elnoId, String elnoLodgementCaseId) {
        ElnoLodgementCase elnoCase = new ElnoLodgementCase();
        elnoCase.setElnoId(elnoId);
        elnoCase.setElnoLodgementCaseId(elnoLodgementCaseId);
        return elnoCase;
    }

}
