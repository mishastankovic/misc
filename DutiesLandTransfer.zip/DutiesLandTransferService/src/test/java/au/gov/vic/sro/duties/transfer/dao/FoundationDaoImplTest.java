package au.gov.vic.sro.duties.transfer.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;
import org.springframework.transaction.annotation.Transactional;

import au.gov.vic.sro.duties.transfer.dao.configuration.PersistenceTestConfiguration;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(
		classes = { PersistenceTestConfiguration.class, FoundationDaoImpl.class },
		loader = AnnotationConfigContextLoader.class)
@TestPropertySource(
		properties = { "spring.application.name=FoundationDaoImplTest",
				"spring.jmx.default-domain=FoundationDaoImplTest" })
@Transactional
@Rollback
public class FoundationDaoImplTest {

	public static final String EBIZ_PUBLIC_USER = "EBIZ_PUBLIC_USER";

	@Autowired
	@Qualifier("eSysDutiesDataSource")
	private DataSource dataSource;

	@Autowired
	private FoundationDao foundationDao;

	@Before
	public void setUp() {
		resetUser();
	}

	@Test
	public void testSetUser() throws SQLException {
		String clientIDToSet = "BILL";	
		String expectedClientIDBefore = EBIZ_PUBLIC_USER;
		String actualClientIDBefore = getClientIdentifier(DataSourceUtils.getConnection(dataSource));
		Assert.assertEquals(expectedClientIDBefore.substring(0, 15), actualClientIDBefore);

		foundationDao.setUser(clientIDToSet);
		String afterClientID = getClientIdentifier(DataSourceUtils.getConnection(dataSource));

		Assert.assertEquals(clientIDToSet, afterClientID);
	}

	@After
	public void tearDown() {
		resetUser();
	}

	public void resetUser() {
		foundationDao.setUser(EBIZ_PUBLIC_USER);
	}

	private String getClientIdentifier(Connection conn) throws SQLException {
		PreparedStatement ps = conn
				.prepareStatement("SELECT NVL(SYS_CONTEXT('USERENV','CLIENT_IDENTIFIER'), USER) as CLIENT_ID FROM DUAL");
		ResultSet rs = ps.executeQuery();
		rs.next();
		String clientID = rs.getString("CLIENT_ID");
		rs.close();
		ps.close();
		return clientID;
	}
}
