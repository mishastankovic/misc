DROP SEQUENCE case_reference_seq;
DROP INDEX elno_lodgement_case_id_idx;
DROP TABLE elno_lodgement_case
