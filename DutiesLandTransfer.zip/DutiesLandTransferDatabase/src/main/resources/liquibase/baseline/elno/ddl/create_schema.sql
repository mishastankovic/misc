CREATE SEQUENCE case_reference_seq START WITH 100000 MAXVALUE 99999999999999999999 MINVALUE 100000 NOCYCLE NOCACHE NOORDER;
CREATE TABLE elno_lodgement_case (
  elno_id VARCHAR(50),
  elno_lodgement_case_id VARCHAR(50),
  case_reference_id VARCHAR(50),
  latest_request_xml BLOB,
  esys_lodgement_id NUMBER(16,0),
  last_modified DATE,
  CONSTRAINT elno_lodgement_case_pk PRIMARY KEY (case_reference_id)
);
CREATE UNIQUE INDEX elno_lodgement_case_id_idx ON elno_lodgement_case(elno_id, elno_lodgement_case_id);