CREATE OR REPLACE SYNONYM case_reference_seq FOR ${liquibase.baseschema}.case_reference_seq;
CREATE OR REPLACE SYNONYM elno_lodgement_case FOR ${liquibase.baseschema}.elno_lodgement_case;
CREATE OR REPLACE SYNONYM elno_lodgement_case_id_idx FOR ${liquibase.baseschema}.elno_lodgement_case_id_idx;