DROP SYNONYM case_reference_seq;
DROP SYNONYM elno_lodgement_case;
DROP SYNONYM elno_lodgement_case_id_idx;