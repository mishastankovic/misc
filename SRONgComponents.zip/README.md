# SRONgComponents

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 6.0.8.

## Local development environment

### Development process

When testing changes to the SRONGComponentLibrary locally, follow this procedure:

1. `npm run linkLocal`  
	This will link the SRONgComponentLibrary in the node_modules with the folder  dist/sro-ngcomponent-library. 
2. `npm run start`, open your favorite browser.
3. Do code change as required
4. `npm run builLibDev`  
	The changes are now hot deployed in the running node server.
5. When the changes are completed and tested locally, increment library version number and publish to sinopia
6. Change `sro-ngcomponents-library` version in `package.json` and run   
	`npm install sro-ngcomponent-library`
7. Do final testing against the published library
	
Step 1, 5, 6 and 7 are typically executed once for a change cycle. Steps 3 and 4 are repeated for every code change.


## Code scaffolding

### Create new library component
- Run `ng generate component component-name --project=SRONgComponentLibrary` to generate a new library component. 
- You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

### Build library
- Run `ng build SRONgComponentLibrary` to build the library. The build artifacts will be stored in the `dist/` directory.

- Use the `--prod` flag for a production build.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via [Protractor](http://www.protractortest.org/).

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).

