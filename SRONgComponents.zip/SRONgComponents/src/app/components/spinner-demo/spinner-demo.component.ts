import { Component, OnInit } from '@angular/core';
import { SpinnerService } from "SRONgComponentLibrary";

@Component({
	selector: 'app-spinner-demo',
	templateUrl: './spinner-demo.component.html',
	styleUrls: ['./spinner-demo.component.scss']
})
export class SpinnerDemoComponent implements OnInit {

	constructor(private spinnerService: SpinnerService) { }

	ngOnInit() {
	}

	onShowSpinner() {
		this.spinnerService.showSpinner();

		setTimeout(() => {
			this.spinnerService.hideSpinner();
		}, 4000);
	}
}
