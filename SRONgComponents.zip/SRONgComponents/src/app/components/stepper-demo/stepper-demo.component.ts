import { ViewChild, Component, OnInit } from '@angular/core';

import { StepperComponent} from "SRONgComponentLibrary";

@Component({
  selector: 'app-stepper-demo',
  templateUrl: './stepper-demo.component.html',
  styleUrls: ['./stepper-demo.component.scss']
})
export class StepperDemoComponent implements OnInit {

  @ViewChild('staticSteppers') staticSteppers: StepperComponent;
  @ViewChild('staticSteppersDisable') staticSteppersDisable: StepperComponent;

  steps: any[] = [
    { title: 'Dynamic Title 1', content: 'Dynamic content 1' },
    { title: 'Dynamic Title 2', content: 'Dynamic content 2' },
    { title: 'Dynamic Title 3', content: 'Dynamic content 3', removable: true }
  ];
  

  constructor() { }

  ngOnInit() {
    
  }

  selectNextStepper() {
    const currentStepIndex = this.staticSteppers.steps.indexOf(this.staticSteppers.currentStep);
    if(this.staticSteppers.steps[currentStepIndex + 1]) {
      this.staticSteppers.steps[currentStepIndex + 1].active = true;
    }    
  }

  selectPreviousStepper() {
    const currentStepIndex = this.staticSteppers.steps.indexOf(this.staticSteppers.currentStep);
    if(this.staticSteppers.steps[currentStepIndex - 1]) {
      this.staticSteppers.steps[currentStepIndex - 1].active = true;
    }    
  }

  disableEnableStepper() {
    this.staticSteppersDisable.steps[0].disabled = !this.staticSteppersDisable.steps[0].disabled;
  }

  addNewStep(): void {
    const newTabIndex = this.steps.length + 1;
    this.steps.push({
      title: `Dynamic Title ${newTabIndex}`,
      content: `Dynamic content ${newTabIndex}`,
      disabled: false,
      removable: true
    });
  }
 
  removeStepHandler(tab: any): void {
    const index = this.steps.indexOf(tab);
    console.log('Remove index '+index);
    this.steps.splice(this.steps.indexOf(tab), 1);
    console.log('Remove Tab handler');
  }

  removeStepByIndex(index: number): void {
    this.steps.splice(this.steps.indexOf(index), 1);
  }

}
