import {Component, ElementRef, OnInit, ViewChild, ViewContainerRef} from '@angular/core';
import {FormBuilder, FormGroup, Validators, FormControl, AbstractControl} from "@angular/forms";
import {SroValidators} from "../../../../projects/sro-ngcomponent-library/src/lib/validation/sro-validators";
import {$} from "protractor";

@Component({
  selector: 'app-validation-demo-reactive',
  templateUrl: './validation-demo-reactive.component.html',
  styleUrls: ['./validation-demo-reactive.component.scss']
})
export class ValidationDemoReactiveComponent implements OnInit {
    @ViewChild("vc", {read: ViewContainerRef}) vc: ViewContainerRef;

    form: FormGroup;
    submitted: boolean = false;

    constructor(private formBuilder: FormBuilder, private _host:ElementRef) { }

    ngOnInit() {
        this.buildForm();
    }

    buildForm() {
        this.form = this.formBuilder.group({
            email: ['', [Validators.required, Validators.email]],
            phone: ['', [Validators.required, SroValidators.ausphone]],
            dummy: ['', null]
        })
    }

    get email() {
        return this.form.get('email');
    }

    get phone() {
        return this.form.get('phone');
    }

    onSubmit(): void {
        this.submitted = true;

        if (this.form.invalid) {

            // Set all invalid elements as touched so that the style for the red border gets applied
            Object.values(this.form.controls).forEach(c => {
                //if (c.invalid) {
                    c.markAsTouched();
                //}
            });

            // set focus on first invalid element
            let firstInvalid = this._host.nativeElement.querySelector('.ng-invalid:not(form)');
            if (firstInvalid) {
                firstInvalid.focus();
            }
        }
    }


}
