import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {SroValidators} from "../../../../projects/sro-ngcomponent-library/src/lib/validation/sro-validators";

@Component({
  selector: 'app-validation-demo',
  templateUrl: './validation-demo.component.html',
  styleUrls: ['./validation-demo.component.scss']
})
export class ValidationDemoComponent {

    //form: FormGroup;
    email:string="";
    phone:string="";

    submitted: boolean = false;

    onSubmit() {
        this.submitted = true;
    }

    //constructor(private formBuilder: FormBuilder) { }

    /*
    ngOnInit() {
        this.buildForm();
    }

    buildForm() {
        this.form = this.formBuilder.group({
            email: [null, [Validators.required, Validators.email]],
            phone: [null, [Validators.required, SroValidators.ausmobile]],
        })
    }
    */


}
