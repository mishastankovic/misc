import {Component, OnInit, TemplateRef} from '@angular/core';
import {BsModalRef, BsModalService} from "SRONgComponentLibrary";

@Component({
  selector: 'app-modal-demo',
  templateUrl: './modal-demo.component.html',
  styleUrls: ['./modal-demo.component.scss']
})
export class ModalDemoComponent {

    modalRef: BsModalRef;
    static modalClass: string = "sro-modal-dialog ";

    constructor(private modalService: BsModalService) {}

    openModal(template: TemplateRef<any>, sizeClass: string) {
        this.modalRef = this.modalService.show(template, Object.assign({}, {class: 'sro-modal-dialog modal-dialog-centered ' + sizeClass,
            ignoreBackdropClick: true, backdrop: true}));
    }

}