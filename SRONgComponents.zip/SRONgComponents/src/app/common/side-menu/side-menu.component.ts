import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
	selector: 'app-side-menu',
	templateUrl: './side-menu.component.html',
	styleUrls: ['./side-menu.component.scss']
})
export class SideMenuComponent implements OnInit {

	list: any[] = [];
	clicked: any;

	constructor(private router: Router) {
		this.list = [
			{ link: "/tabs", label: "Tabs" },
			{ link: "/tooltip", label: "Tooltip" },
			{ link: "/spinner", label: "Spinner" },
			{ link: "/typeahead", label: "Typeahead" },
			{ link: "/panels", label: "Panels" },
			{ link: "/address", label: "Address" },
			{ link: "/validation", label: "Validation" },
			{ link: "/dateinput", label: "Date" },
			{ link: "/stepper", label: "Stepper" },
			{ link: "/modal", label: "Modal(Draft)" },
			{ link: "/alert", label: "Alert" },
			{ link: "/tables", label: "Tables" },
			{ link: "/dropdown", label: "Dropdown(Draft)" }
		];
	}

	ngOnInit() {


	}

}
