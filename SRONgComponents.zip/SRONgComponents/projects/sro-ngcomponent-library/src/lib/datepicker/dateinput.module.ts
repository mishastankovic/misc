import { ModuleWithProviders, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { DateInputComponent } from './dateinput.component';
import { DatepickerModule } from './datepicker.module';
import { BsDatepickerModule } from "./bs-datepicker.module";
import { ReactiveFormsModule } from '@angular/forms';

@NgModule({
	declarations: [DateInputComponent],
	imports: [
		BrowserModule,
		FormsModule,
		BsDatepickerModule.forRoot(),
		DatepickerModule.forRoot(),
		ReactiveFormsModule
	],
	exports: [DateInputComponent],
	bootstrap: [DateInputComponent],
	entryComponents: [DateInputComponent]
})
export class DateInputModule { }
