import { PhoneDirective } from './phone.directive';
import {AbstractControl} from "@angular/forms";

describe('PhoneDirective', () => {
  let directive: PhoneDirective;

  beforeEach(() => {
      directive = new PhoneDirective();
  })

  it('should create an instance', () => {
    expect(directive).toBeTruthy();
  });

  it('modile number success', () => {
    let mobile: string = '0414909090';
    let control: AbstractControl = <AbstractControl>{'value': mobile};
    expect(directive.validate(control)).toBeNull();
  })

  it('modile number invalid', () => {
      let mobileNumbers: string[] = ['414909090', '04149090909090', 'abcd'];

      for(let mobile of mobileNumbers) {
          let control: AbstractControl = <AbstractControl>{'value': mobile};
          expect(directive.validate(control)).not.toBeNull();
      }
  })


});
