import { ModuleWithProviders, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

// Components
import { AlertComponent } from "./alert/alert.component"
import { AddressComponent } from "./address/address.component";
import { SpinnerComponent } from './spinner/spinner.component';
import { StepperComponent } from './stepper/stepper.component';
import { StepperConfig } from './stepper/stepper.config';


// Modules
import { HeaderModule } from "./header/header.module";
import { FooterModule } from "./footer/footer.module";
import { TabsModule } from "./tabs/tabs.module";
import { StepsModule } from "./stepper/steps.module"
import { TooltipModule } from "./tooltip/tooltip.module";
import { TypeaheadModule } from "./typeahead/typeahead.module";
import { DateInputModule } from "./datepicker/dateinput.module";
import { PanelModule } from "./panel/panel.component";
import { ValidationModule } from "./validation/validation-module";
import { ModalModule } from "./modal/modal.module";
import { CommonModule } from "@angular/common";
import { ApplayoutModule } from "./app-layout/app-layout.module";

// Pipes
import { ReferenceDataPipe } from './pipe/reference-data.pipe';
import { ReferenceDataSortingPipe } from './pipe/reference-data-sorting.pipe';

// Utils
import { FormUtils } from './utils/form-utils';
import { ReferenceDataUtils } from './utils/reference-data-utils';

// Services
import { AlertService } from './service/alert.service';
import { IntechService } from './service/intech.service';
import { ReferenceDataService } from './service/reference-data.service';
import { SpinnerService } from './spinner/spinner.service';
import { TabsetConfig } from "./tabs/tabset.config";
import { TooltipConfig } from "./tooltip/tooltip.config";
import { BsDropdownModule } from "./dropdown/bs-dropdown.module";
import { BsDropdownConfig } from "./dropdown/bs-dropdown.config";

const bootstrapModules = [
];

@NgModule({
	imports: [
		BrowserModule,
		FormsModule,
		ReactiveFormsModule,
		HttpClientModule,
		DateInputModule,
		CommonModule,
		TabsModule,
		TooltipModule,
		TypeaheadModule,
		ModalModule,
		StepsModule,
		BsDropdownModule
	],
	declarations: [
		AlertComponent,
		AddressComponent,
		// Pipes
		ReferenceDataPipe,
		//TranslatePipe,
		ReferenceDataSortingPipe,
		SpinnerComponent
	],
	providers: [
		AlertService,
		FormUtils,
		IntechService,
		SpinnerService,
		ReferenceDataService,
		ReferenceDataUtils,
		TabsetConfig,
		TooltipConfig,
		SpinnerService,
		StepperConfig
	],
	exports: [
		AlertComponent,
		AddressComponent,
		TabsModule,
		TooltipModule,
		TypeaheadModule,
		DateInputModule,
		ModalModule,
		StepsModule,
		PanelModule,
		SpinnerComponent,
		ValidationModule,
		HeaderModule,
		FooterModule,
		ApplayoutModule,
		BsDropdownModule
	]
})
export class SRONgComponentLibraryModule {

	public static forRoot(environment: any): ModuleWithProviders {

		return {
			ngModule: SRONgComponentLibraryModule,
			providers: [
				AlertService,
				FormUtils,
				IntechService,
				SpinnerService,
				ReferenceDataService,
				ReferenceDataUtils,
				TabsetConfig,
				TooltipConfig,
				SpinnerService,
				StepperConfig,
				{
					provide: 'env', // you can also use InjectionToken
					useValue: environment
				}
			]
		};
	}
}
