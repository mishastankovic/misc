import { Injectable } from "@angular/core";
import { Subject, Observable } from "rxjs";


@Injectable()
export class SpinnerService {

	private spinnerSubject = new Subject<boolean>();

	spinnerState = this.spinnerSubject.asObservable();

	constructor() { }

	showSpinner() {
		this.spinnerSubject.next(true);
	}

	hideSpinner() {
		this.spinnerSubject.next(false);
	}
}