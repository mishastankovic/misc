export class Address {

	static readonly FREETEXT: string = 'F';
	static readonly STREET: string = 'B';
	static readonly LOT: string = 'L';
	static readonly POSTAL: string = 'P';
	static readonly OVERSEAS: string = 'O';

	static readonly INTECH_STREET: string = 'STREET';
	static readonly INTECH_LOT: string = 'LOT';
	static readonly INTECH_POSTAL: string = 'POSTAL_BOX';
	static readonly INTECH_OVERSEAS: string = 'OVERSEAS';


	static readonly VIC: string = 'VIC';

	constructor(
		public addressFormatType: string,
		public addressLine: string,
		public flatUnitType: string,
		public flatUnitNumber: string,
		public floorLevelType: string,
		public floorLevelNumber: string,
		public buildingName: string, /* also applies to postal box */
		public lotNumber: string,
		public roadNumberFrom: string,
		public roadNumberFromSuffix: string,
		public roadNumberTo: string,
		public roadNumberToSuffix: string,
		public roadName: string,
		public roadType: string,
		public roadSuffixType: string,
		public postalDeliveryType: string,
		public postalDeliveryPrefix: string,
		public postalDeliveryNumber: string,
		public postalDeliverySuffix: string,
		public localityName: string,
		public postcode: string,
		public stateTerritory: string,
		public overseasAddressLine1: string,
		public overseasAddressLine2: string,
		public overseasAddressLine3: string,
		public country: string
	) { }

	isFreeTextAddress(): boolean {
		return this.addressFormatType === Address.FREETEXT;
	}

	isStreetAddress(): boolean {
		return this.addressFormatType === Address.STREET || this.addressFormatType === Address.INTECH_STREET;
	}

	isLotAddress(): boolean {
		return this.addressFormatType === Address.LOT || this.addressFormatType === Address.INTECH_LOT;
	}

	isPostalAddress(): boolean {
		return this.addressFormatType === Address.POSTAL || this.addressFormatType === Address.INTECH_POSTAL;
	}

	isOverseasAddress(): boolean {
		return this.addressFormatType === Address.OVERSEAS || this.addressFormatType === Address.INTECH_OVERSEAS;
	}

	static createAddress(): Address {
		return new Address(
			Address.FREETEXT, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
	};

	static createVictorianAddress(): Address {
		return new Address(
			Address.FREETEXT, '', '', '', '', '', '', '', '', '', '', '', '', Address.VIC, '', '', '', '', '', '', '', '', '', '', '', '');
	};

	static createFreetextAddress(addressLine: string): Address {
		return new Address(
			Address.FREETEXT, addressLine, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
	};
}