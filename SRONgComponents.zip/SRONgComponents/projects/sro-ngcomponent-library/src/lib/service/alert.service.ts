import { Injectable } from '@angular/core';
import { Router, NavigationStart } from '@angular/router';
import { Observable, Subject } from 'rxjs';
import { filter } from 'rxjs/operators';
import { Alert, AlertType } from '../model/alert';

@Injectable()
export class AlertService {
	private subject = new Subject<Alert>();
	private keepAfterRouteChange = false;

	constructor(private router: Router) {
		// clear alert messages on route change unless 'keepAfterRouteChange' flag is true
		router.events.subscribe(event => {
			if (event instanceof NavigationStart) {
				if (this.keepAfterRouteChange) {
					// only keep for a single route change
					this.keepAfterRouteChange = false;
				} else {
					// clear alert messages
					this.clear();
				}
			}
		});
	}

	// subscribe to alerts
	getAlert(alertId?: string): Observable<any> {
		return this.subject.asObservable().pipe(filter((x: Alert) => x && x.alertId === alertId));
	}

	// convenience methods
	success(message: string, keepAfterRouteChange = false, alertId?: string) {
		this.alert(new Alert({ type: AlertType.Success, message, alertId, keepAfterRouteChange }));
	}

	error(message: string, keepAfterRouteChange = false, alertId?: string) {
		this.alert(new Alert({ type: AlertType.Error, message, alertId, keepAfterRouteChange }));
	}

	info(message: string, keepAfterRouteChange = false, alertId?: string) {
		this.alert(new Alert({ type: AlertType.Info, message, alertId, keepAfterRouteChange }));
	}

	warn(message: string, keepAfterRouteChange = false, alertId?: string) {
		this.alert(new Alert({ type: AlertType.Warning, message, alertId, keepAfterRouteChange }));
	}

	// for dismissable alerts
	successDismissable(message: string, keepAfterRouteChange = false, alertId?: string) {
		this.alert(new Alert({ type: AlertType.Success, message, alertId, keepAfterRouteChange, dismissable: true }));
	}

	errorDismissable(message: string, keepAfterRouteChange = false, alertId?: string) {
		this.alert(new Alert({ type: AlertType.Error, message, alertId, keepAfterRouteChange, dismissable: true }));
	}

	infoDismissable(message: string, keepAfterRouteChange = false, alertId?: string) {
		this.alert(new Alert({ type: AlertType.Info, message, alertId, keepAfterRouteChange, dismissable: true }));
	}

	warnDismissable(message: string, keepAfterRouteChange = false, alertId?: string) {
		this.alert(new Alert({ type: AlertType.Warning, message, alertId, keepAfterRouteChange, dismissable: true }));
	}

	// main alert method
	alert(alert: Alert) {
		this.keepAfterRouteChange = alert.keepAfterRouteChange;
		this.subject.next(alert);
	}

	// clear alerts
	clear(alertId?: string) {
		this.subject.next(new Alert({ alertId }));
	}

}
