import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import {
	SRONgComponentLibraryModule, AddressComponent, AlertComponent, AlertService, BsModalService, IntechService, ReferenceDataService, SpinnerService,
	ReferenceDataUtils, SpinnerComponent, FormUtils, BsDropdownConfig
} from 'sro-ngcomponent-library';
import { AppComponent } from './app.component';
import { SideMenuComponent } from './common/side-menu/side-menu.component';
import { ButtonDemoComponent } from './components/button-demo/button-demo.component';
import { TabsDemoComponent } from './components/tabs-demo/tabs-demo.component';
import { TooltipDemoComponent } from './components/tooltip-demo/tooltip-demo.component';
import { SpinnerDemoComponent } from './components/spinner-demo/spinner-demo.component';
import { TypeaheadDemoComponent } from './components/typeahead-demo/typeahead-demo.component';
import { PanelDemoComponent } from './components/panel-demo/panel-demo.component';
import { AddressDemoComponent } from './components/address-demo/address-demo.component';
import { ValidationDemoComponent } from './components/validation-demo/validation-demo.component';
import { StepperDemoPage1Component } from './components/stepper-demo/stepper-demopage1.component';
import { ValidationDemoReactiveComponent } from './components/validation-demo/validation-demo-reactive.component';
import { ModalDemoComponent } from './components/modal-demo/modal-demo.component';
import { StepperDemoComponent } from './components/stepper-demo/stepper-demo.component';
import { DateInputDemoComponent } from './components/dateinput-demo/dateinput-demo.component';
import { AlertDemoComponent } from './components/alert-demo/alert-demo.component';
import { TableDemoComponent } from './components/table-demo/table-demo.component';
import { DropdownDemoComponent } from './components/dropdown-demo/dropdown-demo.component';
import { environment } from '../environments/environment';


const routes: Routes = [
	{ path: 'buttons', component: ButtonDemoComponent },
	{ path: 'tabs', component: TabsDemoComponent },
	{ path: 'tooltip', component: TooltipDemoComponent },
	{ path: 'spinner', component: SpinnerDemoComponent },
	{ path: 'typeahead', component: TypeaheadDemoComponent },
	{ path: 'panels', component: PanelDemoComponent },
	{ path: 'address', component: AddressDemoComponent },
	{ path: 'validation', component: ValidationDemoReactiveComponent },
	{ path: 'modal', component: ModalDemoComponent },
	{ path: 'stepper', component: StepperDemoComponent },
	{ path: 'stepperpage1', component: StepperDemoPage1Component },
	{ path: 'dateinput', component: DateInputDemoComponent },
	{ path: 'alert', component: AlertDemoComponent },
	{ path: 'tables', component: TableDemoComponent },
	{ path: 'dropdown', component: DropdownDemoComponent }
];

@NgModule({
	declarations: [
		AppComponent,
		SideMenuComponent,
		ButtonDemoComponent,
		TabsDemoComponent,
		TooltipDemoComponent,
		SpinnerDemoComponent,
		TypeaheadDemoComponent,
		PanelDemoComponent,
		AddressDemoComponent,
		ValidationDemoComponent,
		ValidationDemoReactiveComponent,
		ModalDemoComponent,
		StepperDemoComponent,
		StepperDemoPage1Component,
		DateInputDemoComponent,
		AlertDemoComponent,
		TableDemoComponent,
		DropdownDemoComponent
	],
	imports: [
		ReactiveFormsModule,
		FormsModule,
		BrowserModule,
		SRONgComponentLibraryModule.forRoot(environment),
		RouterModule.forRoot(routes, { useHash: false })
	],
	providers: [
		BsModalService,
		AlertComponent,
		AddressComponent,
		FormUtils,
		AlertService,
		IntechService,
		ReferenceDataService,
		ReferenceDataUtils,
		SpinnerService,
		SpinnerComponent,
		BsDropdownConfig
	],
	bootstrap: [AppComponent]
})
export class AppModule { }
