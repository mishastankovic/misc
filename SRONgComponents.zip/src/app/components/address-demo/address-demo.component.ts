import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup } from '@angular/forms';
import { AddressComponent, FormUtils } from 'sro-ngcomponent-library';

@Component({
	selector: 'app-address-demo',
	templateUrl: './address-demo.component.html',
	styleUrls: ['./address-demo.component.scss']
})
export class AddressDemoComponent implements OnInit {
	form: FormGroup;

	constructor(private formBuilder: FormBuilder, private addressComponent: AddressComponent) { }

	ngOnInit() {
		this.buildForm();
	}

	buildForm() {
		this.form = this.formBuilder.group({
		});

	}

	onSubmit() {
		const addressComponents = this.getFreeTextAddressComponents();
		if (addressComponents.length > 0) {
			this.validateAddressComponent(addressComponents);
		} else {
			this.completeFormValidation();
		}
	}

	addAddressControl(name: string, formGroup: FormGroup) {
		this.form.setControl(name, formGroup);
	}

	getFreeTextAddressComponents(): FormGroup[] {
		const addressComponents = [];

		if (this.addressComponent.isFreeTextAddressFormatType(<FormGroup>this.form.get('residentialAddress'))) {
			addressComponents.push(this.form.get('residentialAddress'));
		}

		if (this.addressComponent.isFreeTextAddressFormatType(<FormGroup>this.form.get('businessAddress'))) {
			addressComponents.push(this.form.get('businessAddress'));
		}
		return addressComponents;
	}

	validateAddressComponent(componentNames: AbstractControl[]) {
		if (componentNames.length > 0) {
			const addressComponentName = componentNames[0];
			const result = this.addressComponent.standardiseAddressOnSubmit(addressComponentName)
				.subscribe(
					results => {
						this.addressComponent.setStructuredAddress(<FormGroup>addressComponentName, this.addressComponent.toAddressObject(results));
						addressComponentName.get('addressLine').setValue(this.addressComponent.toFormattedAddress(this.addressComponent.toAddressObject(results)), { onlySelf: true });

						if (componentNames.length > 1) {
							this.validateAddressComponent(componentNames.slice(1));
						} else {
							this.completeFormValidation();
						}
						addressComponentName.updateValueAndValidity();
					},
					error => {
						console.log('standardiseAddress Error:' + error);
					});
		}
	}

	completeFormValidation() {
		console.log('Validated remaining fields and submit');
		this.validateForm();
	}

	validateForm() {
		FormUtils.validate(this.form);
		this.form.updateValueAndValidity();
		if (!this.form.valid) {
			FormUtils.focusError(document);
		}
	}
}
