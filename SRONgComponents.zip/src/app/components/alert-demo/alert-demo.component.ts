import { Component, OnInit } from '@angular/core';
import { AlertService } from 'sro-ngcomponent-library';

@Component({
	selector: 'app-alert-demo',
	templateUrl: './alert-demo.component.html',
	styleUrls: ['./alert-demo.component.scss']
})
export class AlertDemoComponent {

	constructor(private alertService: AlertService) {
	}

	onSuccessClicked() {
		this.alertService.success('Your action has been successfully completed.');
	}

	onErrorClicked() {
		this.alertService.error('You have made a critical error.');
	}

	onInformationClicked() {
		this.alertService.info('For more information please read <a href="#" target="_blank" class="alert-link">this page</a> <em class="fa fa-external-link-alt">');
	}

	onWarningClicked() {
		this.alertService.warn('You were warned not to click on Warning button.');
	}

	onDismissClicked() {
		this.alertService.successDismissable('You can close this success alert.');
		this.alertService.errorDismissable('You can close this error alert.');
		this.alertService.infoDismissable('You can close this informational alert.');
		this.alertService.warnDismissable('You can close this warning alert.');
	}

	onClearClicked() {
		this.alertService.clear();
	}

	onAlerts2LotsOfAlertsClicked() {
		this.alertService.success('Your action has been successfully completed.', false, 'alerts2');
		this.alertService.error('You have made a critical error.', false, 'alerts2');
		this.alertService.info('For more information please read <a href="#" target="_blank" class="alert-link">this page</a> <em class="fa fa-external-link-alt">', false, 'alerts2');
		this.alertService.warn('You were warned not to click on Warning button.', false, 'alerts2');
		this.alertService.successDismissable('You can close this success alert.', false, 'alerts2');
		this.alertService.errorDismissable('You can close this error alert.', false, 'alerts2');
		this.alertService.infoDismissable('You can close this informational alert.', false, 'alerts2');
		this.alertService.warnDismissable('You can close this warning alert.', false, 'alerts2');
		// provide alertMessageId
		this.alertService.success('Your action has been successfully completed with alertMessageId.', false, 'alerts2', 'myMessageId1');
		this.alertService.warnDismissable('You can close this warning alert with alertMessageId.', false, 'alerts2', 'myMessageId2');
	}

	onAlerts2ClearClicked() {
		this.alertService.clear('alerts2');
	}

}
