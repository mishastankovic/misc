import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-panel-demo',
  templateUrl: './panel-demo.component.html',
  styleUrls: ['./panel-demo.component.scss']
})
export class PanelDemoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
