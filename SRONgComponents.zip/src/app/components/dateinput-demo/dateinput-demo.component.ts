import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup } from '@angular/forms';
import { FormControl } from '@angular/forms';

@Component({
	selector: 'app-dateinput-demo',
	templateUrl: './dateinput-demo.component.html',
	styleUrls: ['./dateinput-demo.component.scss']
})
export class DateInputDemoComponent implements OnInit {
	today: Date;
	minDate: Date;
	maxDate: Date;
	form: FormGroup;
	demoDatepicker: FormControl;

	constructor(private formBuilder: FormBuilder) {
		this.today = new Date();
		this.minDate = new Date(2018, 6, 13);
		this.maxDate = new Date(this.today.getTime() + (24 * 60 * 60 * 1000));
	}

	ngOnInit() {
		this.buildForm();
	}

	buildForm() {
		this.form = this.formBuilder.group({});
	}

	addControlDemo2(name: string, formGroup: FormGroup) {
		this.form.setControl(name, formGroup);
	}

	addControlDemo1(name: string, formGroup: FormGroup) {
		this.form.setControl(name, formGroup);
	}

	getDateValues() {
		const dateForm1 = <FormGroup>this.form.get('demoDatepicker1');
		const value1 = dateForm1.get('dateSelected').value;

		const dateForm2 = <FormGroup>this.form.get('demoDatepicker2');
		const value2 = dateForm2.get('dateSelected').value;

		return value1 || value2 ? value1 + '\n' + value2 : '';

	}
}
