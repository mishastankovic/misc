import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'step-page1',
  templateUrl: './stepper-demopage1.component.html'
})
export class StepperDemoPage1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
