import { Component, OnInit, TemplateRef } from '@angular/core';
import { BsModalRef, BsModalService } from 'sro-ngcomponent-library';

@Component({
	selector: 'app-modal-demo',
	templateUrl: './modal-demo.component.html',
	styleUrls: ['./modal-demo.component.scss']
})
export class ModalDemoComponent {

	static modalClass = 'sro-modal-dialog ';
	modalRef: BsModalRef;

	constructor(private modalService: BsModalService) { }

	openModal(template: TemplateRef<any>, sizeClass: string) {
		this.modalRef = this.modalService.show(template, Object.assign({}, {
			class: 'sro-modal-dialog modal-dialog-centered ' + sizeClass,
			ignoreBackdropClick: true, backdrop: true
		}));
	}

}
