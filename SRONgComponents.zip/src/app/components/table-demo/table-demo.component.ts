import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'app-table-demo',
	templateUrl: './table-demo.component.html',
	styleUrls: ['./table-demo.component.scss']
})
export class TableDemoComponent implements OnInit {

	private rowData: any;
	tableStripedRowData: any;
	expandableTableStripedRowData: any;

	constructor() { }

	ngOnInit() {
		this.rowData = [
			{
				showDetail: false,
				cheese: 'Cheddar',
				company: 'Alfreds Futterkiste',
				contact: 'Maria Anders',
				country: 'Germany',
				description: `Caerphilly cheese and biscuits. Say cheese say cheese cheese slices roquefort when the
				cheese comes out everybody's happy cut the cheese cheese slices goat. St. agur blue cheese rubber cheese brie
				taleggio ricotta taleggio cheese and biscuits the big cheese. Manchego.`
			},
			{
				showDetail: false,
				cheese: 'Manchego',
				company: 'Centro comercial Moctezuma',
				contact: 'Francisco Chang',
				country: 'Mexico',
				description: `Pecorino say cheese pecorino. Say cheese halloumi red leicester stinking bishop roquefort fondue halloumi cow.
				Mascarpone roquefort cheese strings camembert de normandie when the cheese comes out everybody's happy
				cheeseburger mozzarella cheddar. Mozzarella queso airedale danish fontina cheese strings.`
			},
			{
				showDetail: false,
				cheese: 'Camembert',
				company: 'Ernst Handel',
				contact: 'Roland Mendel',
				country: 'Austria',
				description: `Fromage goat dolcelatte. Swiss squirty cheese dolcelatte caerphilly pepper jack brie who moved my cheese
				cheddar. Lancashire halloumi cheese strings cheesy grin paneer boursin gouda cheese and wine. Cut the cheese jarlsberg
				parmesan mozzarella everyone loves mascarpone.`
			},
			{
				showDetail: false,
				cheese: 'Mozzarella',
				company: 'Island Trading',
				contact: 'Helen Bennett',
				country: 'UK',
				description: `Gouda st. agur blue cheese babybel. Fromage fondue mascarpone croque monsieur cut the cheese bavarian bergkase
				bavarian bergkase fromage. Camembert de normandie when the cheese comes out everybody's happy gouda say cheese
				caerphilly cheese on toast cream cheese everyone loves. Feta mascarpone.`
			},
			{
				showDetail: false,
				cheese: 'Parmesan',
				company: 'Laughing Bacchus Winecellars',
				contact: 'Yoshi Tannamuri',
				country: 'Canada',
				description: `Dolcelatte cheese and wine babybel. Caerphilly cheese strings cheesecake cottage cheese who moved my cheese edam
				cream cheese pepper jack. Stinking bishop chalk and cheese croque monsieur swiss manchego say cheese cheeseburger
				who moved my cheese. Boursin taleggio cheeseburger say cheese caerphilly cheese slices mascarpone cheese strings. Goat.`
			},
			{
				showDetail: false,
				cheese: 'Gruyere',
				company: 'Magazzini Alimentari Riuniti',
				contact: 'Giovanni Rovelli',
				country: 'Italy',
				description: `Cow lancashire feta. Cheese slices say cheese croque monsieur chalk and cheese airedale croque monsieur fromage
				cheddar. Cheese triangles mozzarella who moved my cheese halloumi cut the cheese pepper jack fromage red
				leicester. Macaroni cheese monterey jack feta stilton.`
			}
		];
		this.tableStripedRowData = this.rowData.slice();
		this.expandableTableStripedRowData = this.rowData.slice();
	}

	tableStripedRowAdd() {
		const i = Math.floor(Math.random() * this.rowData.length);
		this.tableStripedRowData.push({
			showDetail: false,
			cheese: this.rowData[i].cheese,
			company: this.rowData[i].company,
			contact: this.rowData[i].contact,
			country: this.rowData[i].country,
			description: this.rowData[i].description
		});
	}

	tableStripedRowRemove() {
		this.tableStripedRowData.pop();
	}

	expandableTableStripedRowAdd() {
		const i = Math.floor(Math.random() * this.rowData.length);
		this.expandableTableStripedRowData.push({
			showDetail: false,
			cheese: this.rowData[i].cheese,
			company: this.rowData[i].company,
			contact: this.rowData[i].contact,
			country: this.rowData[i].country,
			description: this.rowData[i].description
		});
	}

	expandableTableStripedRowRemove() {
		this.expandableTableStripedRowData.pop();
	}

}
