import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'app-button-demo',
	templateUrl: './button-demo.component.html'
})
export class ButtonDemoComponent implements OnInit {

	constructor() { }

	ngOnInit() { }

}
