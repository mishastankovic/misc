import { Component } from '@angular/core';
import { TemplateRef } from '@angular/core';
import { BsModalRef, BsModalService } from 'sro-ngcomponent-library';

@Component({
	selector: 'app-root',
	templateUrl: './app.component.html',
	styleUrls: ['./app.component.scss']
})
export class AppComponent {

	modalRef: BsModalRef;

	tomorrow: Date;
	minDate: Date;
	maxDate: Date;

	constructor(private modalService: BsModalService) {
		this.tomorrow = new Date();
		this.tomorrow.setDate(this.tomorrow.getDate() + 1);
		this.minDate = new Date();
		this.maxDate = new Date();
		this.maxDate.setDate(this.minDate.getDate() + 14);
	}

	onLogout(template: TemplateRef<any>) {
		this.modalRef = this.modalService.show(template, Object.assign({}, { class: 'sro-modal-dialog sro-modal-sm' }));
	}

}
