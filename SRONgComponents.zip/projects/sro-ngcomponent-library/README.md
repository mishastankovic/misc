# SRONgComponentsLibrary

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 6.0.8.

## Code scaffolding
- Run `ng generate component component-name --project=SRONgComponentLibrary` to generate a new library component. 
- You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build
- Use `npm run buildLib` from the top folder to build the library with assets.
Copying of assets is currently not supported by ng-packager. Hopefully it will be provided in the future versions 
of angular-cli, but in the mean time this step is handled by a custom script.


## Publish
To publish this library to the Sinopia npm repository:
- Make sure you have the sinopia repository configured in npm. Run `npm config list` to check, you should see the repository configuration
  `registry = "http://ebizserver02.sro.vic.gov.au:4873/"`
- Login to the repository by running `npm login` and follow the prompts
- Update version `npm version patch|minor|major`. This will increment the version number for the next publish.
- Navigate to the library dist folder `cd dist\sro-ngcomponents-library`
- Run `npm publish`
- Check in the sinopia repository `http://ebizserver02.sro.vic.gov.au:4873` that the library has been published 

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).


## Components

### Tabs

Example :

```html
            <sro-tabs>
              <tab heading="Tab 1" id="tab1" customClass="tab-style">
                <div>
                  <p>Raw denim you </p>
                </div>
              </tab>
              <tab heading="Tab 2" customClass="tab-style">
                <div>
                  <p>Food truck fixie locavore, </p>
                </div>
              </tab>
              <tab heading="Tab 3" customClass="tab-style">
                <div>
                  <p>Etsy mixtape wayfarers, </p>
                </div>
              </tab>
            </sro-tabs>

```
### Tooltip

Example:

Tooltip on button:

```html

	<button class="sro-btn-primary" tooltip="Button tooltip">Hover for tooltip</button>

```

Tooltip with info icon:

```html

	 <em class="fa fa-question-circle" aria-hidden="true" tooltip="We will send all email communication regarding the arrangement to this address."></em>

```

### Typeahead

Example:

```html

	 <input formControlName="selectedCountry" [typeahead]="countries" [typeaheadOptionsLimit]="7" [typeaheadMinLength]="2" placeholder="Typeahead inside a form" class="form-control">

```

### Panel
Provides a single Angular component with the selector **`<sro-panel>`**. This component has a small number of styling parameters
like background-color and padding in the component stylesheet panel.component.scss. 
There are several different styling versions of this component as follows:

Plain panel:
```
<sro-panel>
    ... some content goes here
</sro-panel>
```

Panel with header:

```
<sro-panel title="Panel title">
    ... some content goes here
</sro-panel>
```
Callout:

```
<sro-panel callout="true">
    ... some content goes here
</sro-panel>
```

It is possible to customise the styling of a panel by specifying a custom css class. The custom class replaces
the default panel class.

```
<sro-panel stylingClass="my-custom-class">
    ... some content goes here
</sro-panel>
```

### Address

Example:

```html
	 <sro-app-address [address]="residentialAddress" id="ir" [label]="'Residential address'" [noPostal]="true" (formReady)="addAddressControl('residentialAddress', $event)"></sro-app-address>
```
- Requires handling in the component typescript and dependency to IntechService, ReferenceDataService.
- Searching of address and standardising addresses requires IntechService as backend REST API
- Refer to 'address-demo.component.ts'

### Modal
There are two ways to open a modal as follows:
- Using service BsModalService
- Using bsModal directive on a div

The modal component provides the following lifecycle events that the application can tap into:
- onShow 
- onShown 
- onHide 
- onHidden

When a modal is closed, user action can be examined through the **`dismissReason`** property.

This implementation is based on ngx-bootstrap. For more documentation see <https://valor-software.com/ngx-bootstrap/#/modals>.

### Spinner

Spinner can be added to the application using the selector **`<sro-spinner>`**.
Using the methods showSpinner() and hideSpinner() provided in the SpinnerService spinner can be activated and deactivated.

Example:

```html

import { Component, OnInit } from '@angular/core';
import { SpinnerService } from "SRONgComponentLibrary";

@Component({
	selector: 'app-spinner-demo',
	templateUrl: './spinner-demo.component.html',
	styleUrls: ['./spinner-demo.component.scss']
})
export class SpinnerDemoComponent implements OnInit {

	constructor(private spinnerService: SpinnerService) { }

	ngOnInit() {
	}

	onShowSpinner() {
		this.spinnerService.showSpinner();

		setTimeout(() => {
			this.spinnerService.hideSpinner();
		}, 4000);
	}
}

```

### Application Layout

Using the selector **`<sro-app-layout>`** default application layout can be set with the SRO header, SRO footer and an optional application title.

Example:

```html

	<sro-app-layout title="Application Title">
		add your page content here
	</sro-app-layout>

````

Application header with username and logout button:

Set **`enableLogout`** to true to display the username and logout button on the application header and provide the **`username`** and **`logout`** function .

```html

<sro-app-layout title="SRO Angular Components" [enableLogout]="true" username="Misko Hevery" (logout)="onLogout()">
	add your page content here
</sro-app-layout>

````
### Alert

Example:

```html	 
	<sro-app-alert></sro-app-alert>
```
- Add the above snippet to the page layout for where the page level messages alert should be displayed.
- The AlertService is exported from the library to push alerts.

Example:

```html	 
	constructor(private alertService: AlertService) {
	}

	onSuccessClicked() {
		this.alertService.success("Your action has been successfully completed.");
	}

	onErrorClicked() {
		this.alertService.error("You have made a critical error.");
	}
```

### Modal

##### Template based modal with a form. 
It does NOT close when the user clicks on the backdrop.

``` html
  <button type="button mt-2" class="btn btn-primary" (click)="staticModal.show()">Modal with a form</button>

  <div class="modal" bsModal #staticModal="bs-modal" [config]="{backdrop: 'static'}"
       tabindex="-1" role="dialog" aria-labelledby="dialog-static-name">
    <div class="sro-modal-dialog sro-modal-md">
      <div class="modal-content">
        <div class="modal-header">
          <h1 id="dialog-static-name" class="modal-title pull-left">Static modal</h1>
          <button type="button" class="close pull-right" aria-label="Close" (click)="staticModal.hide()">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <app-validation-demo-reactive></app-validation-demo-reactive>
        </div>
      </div>
    </div>
  </div>

```

##### Modal withot backdrop
- Rendered with a shadow 
- No dimmied overlay
- Clicking on the overlay closes the modal

``` html
  <button type="button" class="btn btn-primary mt-1" (click)="staticModal2.show()">Modal without backdrop</button>

  <div class="modal" bsModal #staticModal2="bs-modal" [config]="{backdrop: false, ignoreBackdropClick: false}"
       tabindex="-1" role="dialog" aria-labelledby="dialog-static-name">
    <div class="sro-modal-dialog sro-modal-md sro-shadow">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title pull-left">Modal without backdrop</h1>
          <button type="button" class="close pull-right" aria-label="Close" (click)="staticModal2.hide()">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <app-validation-demo-reactive></app-validation-demo-reactive>
        </div>
      </div>
    </div>
  </div>

```
