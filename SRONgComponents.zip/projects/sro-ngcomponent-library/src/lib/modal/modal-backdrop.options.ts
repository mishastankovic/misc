export class ModalBackdropOptions {
  animate = true;

  constructor(options: ModalBackdropOptions) {
    Object.assign(this, options);
  }
}
