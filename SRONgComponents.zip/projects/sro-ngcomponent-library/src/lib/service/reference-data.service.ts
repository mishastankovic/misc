import { Injectable } from "@angular/core";

import { REFERENCE_DATA } from '../model/reference-data-static';
import { ReferenceData } from '../model/reference-data';


@Injectable()
export class ReferenceDataService {

	// fixed reference data
	static readonly ADDRESS_TYPES = 'ADDRESS_TYPES';
	static readonly NON_POSTAL_ADDRESS_TYPES = 'NON_POSTAL_ADDRESS_TYPES';

	static readonly COUNTRIES = 'COUNTRIES';
	static readonly FLAT_UNIT_TYPES = 'FLAT_UNIT_TYPES';
	static readonly FLOOR_LEVEL_TYPES = 'FLOOR_LEVEL_TYPES';
	static readonly POSTAL_BOX_TYPES = 'POSTAL_BOX_TYPES';
	static readonly STATES = 'STATES';
	static readonly STREET_SUFFIXES = 'STREET_SUFFIXES';
	static readonly STREET_TYPES = 'STREET_TYPES';
	static readonly TRUST_TYPES = 'TRUST_TYPES';

	private referenceData: ReferenceData[];
	private baseServiceUrl: string = '';

	constructor() {
		this.referenceData = REFERENCE_DATA;
	}

	getReferenceData(): ReferenceData[] {
		return this.referenceData;
	}
}