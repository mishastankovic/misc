export class Alert {
	type: AlertType;
	message: string;
	alertId: string;
	keepAfterRouteChange: boolean;
	dismissable = false;
	alertMessageId: string;

	constructor(init?: Partial<Alert>) {
		Object.assign(this, init);
		this.alertMessageId = !init.alertMessageId ? 'alertMessageId' : init.alertMessageId;
	}
}

export enum AlertType {
	Success,
	Error,
	Info,
	Warning
}
