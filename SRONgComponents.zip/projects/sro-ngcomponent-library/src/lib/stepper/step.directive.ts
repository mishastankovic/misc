import {
  Directive,
  EventEmitter,
  HostBinding,
  Input,
  Output,
  TemplateRef,
  OnInit,
  OnDestroy,
  ElementRef,
  Renderer2
} from '@angular/core';
import { Subscription } from 'rxjs';

import { StepperComponent } from './stepper.component';


@Directive({ selector: 'step, [step]' })
export class StepDirective implements OnInit, OnDestroy {
  /** tab header text */
  @Input() heading: string;
  /** tab id. The same id with suffix '-link' will be added to the corresponding &lt;li&gt; element  */
  @HostBinding('attr.id')
  @Input() id: string;
  /** if true tab can not be activated */
  @Input() disabled: boolean;
  /** if true tab can be removable, additional button will appear */
  @Input() removable: boolean;
  /** if set, will be added to the tab's class attribute. Multiple classes are supported. */
  @Input()
  get customClass(): string {
    return this._customClass;
  }

  @Input() page: string;
  @Input() optional: boolean;
  @Input() visited: boolean;

  private subscription: Subscription;
  currentStep: string;


  set customClass(customClass: string) {
    if (this.customClass) {
      this.customClass.split(' ').forEach((cssClass: string) => {
        this.renderer.removeClass(this.elementRef.nativeElement, cssClass);
      });
    }

    this._customClass = customClass ? customClass.trim() : null;

    if (this.customClass) {
      this.customClass.split(' ').forEach((cssClass: string) => {
        this.renderer.addClass(this.elementRef.nativeElement, cssClass);
      });
    }
  }

  /** tab active state toggle */
  @HostBinding('class.active')
  @Input()
  get active(): boolean {
    return this._active;
  }

  set active(active: boolean) {
    if (this._active === active) {
      return;
    }
    if ((this.disabled && active) || !active) {
      if (this._active && !active) {
        this.deselect.emit(this);
        this._active = active;
      }

      return;
    }
    this.visited = true;
    this.select.emit(this);
    this.stepperArray.steps.forEach((step: StepDirective) => {
        
      if (step !== this) {
        const index = this.stepperArray.steps.indexOf(step);
        const currentStepIndex = this.stepperArray.steps.indexOf(this.stepperArray.currentStep);     
        step.active = false;
        if(index >= currentStepIndex) {
          this.stepperArray.steps[index]._done = false;
        }
      } else {
        
        const currentStepIndex = this.stepperArray.steps.indexOf(this.stepperArray.currentStep);
        const index = this.stepperArray.steps.indexOf(step);
        let prevStepIndex = this.getPrevStepIndex(this.stepperArray.steps, index);
        const nextCurrentStepIndex = this.getNextTabIndex(this.stepperArray.steps, currentStepIndex);
        if(nextCurrentStepIndex > 0 && index > 0) {
         
          if (nextCurrentStepIndex < index) {
            this.stepperArray.steps.forEach((innnerSteps: StepDirective) => {
              const otherIndex = this.stepperArray.steps.indexOf(innnerSteps);
              if(this.stepperArray.steps[otherIndex]) {
                 if(!(this.stepperArray.steps[otherIndex].active || this.stepperArray.steps[otherIndex].done || index == otherIndex) && !currentStepIndex ) {
                  this.stepperArray.steps[otherIndex].disabled = true;
                }
              }

            });
            this.stepperArray.steps[currentStepIndex]._active = true;
            this.stepperArray.steps[currentStepIndex + 1].disabled = false;
            
          } else {
            if (prevStepIndex === -1) {
              prevStepIndex = 0;
            }
            this.stepperArray.steps.forEach((innnerSteps: StepDirective) => {
              const innerIndex = this.stepperArray.steps.indexOf(innnerSteps);
              this.stepperArray.steps[innerIndex].disabled = false;
            });
            this._active = active;
            this._done = false;
            this.stepperArray.currentStep = step;
            if(this.stepperArray.steps[prevStepIndex]) {
              this.stepperArray.steps[prevStepIndex]._done = active;
            }
          }
        } else {
          if(this.stepperArray.steps[index].disabled) {
            this.stepperArray.steps[index].disabled = true;
          }
          this._active = active;
          this._done = false;
          this.stepperArray.currentStep = step;
          if(this.stepperArray.steps[prevStepIndex]) {
            this.stepperArray.steps[prevStepIndex]._done = active;
         }
        }
       
      }
    });
  }

  /** tab done state toggle */
  @HostBinding('class.done')
  @Input()
  get done(): boolean {
    return this._done;
  }

  set done(done: boolean) {
   
  }

  protected getPrevStepIndex(steps: StepDirective[],index: number): number {
    const stepsLength = steps.length;
    if (!stepsLength) {
      return -1;
    }

    for (let step = 1; step <= stepsLength; step += 1) {
      const prevIndex = index - step;
      if (steps[prevIndex] && !steps[prevIndex].disabled) {
        return prevIndex;
      }
    }
    return -1;
  }
  
  protected getNextTabIndex(steps: StepDirective[],index: number): number {
    const stepsLength = steps.length;
    if (!stepsLength) {
      return -1;
    }

    for (let step = 1; step <= stepsLength; step += 1) {
      const nextIndex = index + step;
      if (steps[nextIndex] && !steps[nextIndex].disabled) {
        return nextIndex;
      }
    }

    return -1;
  }

  /** fired when tab became active, $event:Tab equals to selected instance of Tab component */
  @Output() select: EventEmitter<StepDirective> = new EventEmitter();
  /** fired when tab became inactive, $event:Tab equals to deselected instance of Tab component */
  @Output() deselect: EventEmitter<StepDirective> = new EventEmitter();
  /** fired before tab will be removed, $event:Tab equals to instance of removed tab */
  @Output() removed: EventEmitter<StepDirective> = new EventEmitter();

  @HostBinding('class.tab-pane') addClass = true;

  headingRef: TemplateRef<any>;
  stepperArray: StepperComponent;
  protected _active: boolean;
  protected _done: boolean;
  protected _customClass: string;

  constructor(
    stepperArray: StepperComponent,
    public elementRef: ElementRef,
    public renderer: Renderer2
  ) {
    this.stepperArray = stepperArray;
    this.stepperArray.addTab(this);
  }

  ngOnInit(): void {
    this.removable = this.removable;
  }

  ngOnDestroy(): void {
    this.stepperArray.removeTab(this, { reselect: false, emit: false });
  }

}
