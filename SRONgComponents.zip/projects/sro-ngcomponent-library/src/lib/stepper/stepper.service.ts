import { Injectable } from "@angular/core";
import { Subject, Observable } from "rxjs";

import { StepperPage } from "./stepper.page";

@Injectable()
export class StepperService {

	private stepperSubject = new Subject<StepperPage>();

	stepperState = this.stepperSubject.asObservable();

	constructor() { }

	updateStepper(currentPage: string) {
		this.stepperSubject.next(<StepperPage>{ page: currentPage });
	}
}