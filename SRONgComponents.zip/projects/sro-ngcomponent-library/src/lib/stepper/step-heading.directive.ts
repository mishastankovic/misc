import { Directive, TemplateRef } from '@angular/core';

import { StepDirective } from './step.directive';

/** Should be used to mark <ng-template> element as a template for tab heading */
@Directive({ selector: '[tabHeading]' })
export class StepHeadingDirective {
  templateRef: TemplateRef<any>;

  constructor(templateRef: TemplateRef<any>, tab: StepDirective) {
    tab.headingRef = templateRef;
  }
}
