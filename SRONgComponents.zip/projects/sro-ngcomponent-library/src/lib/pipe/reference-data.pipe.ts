import { Pipe, PipeTransform } from '@angular/core';

import { ReferenceData } from "../model/reference-data";

@Pipe({
	name: 'referenceDataFilter'
})
export class ReferenceDataPipe implements PipeTransform {

	transform(referenceData: ReferenceData[], type: string): ReferenceData[] {
		if (!referenceData || !type) return null;

		return referenceData.filter(item => item.type === type);
	}

}
