import {AbstractControl, ValidationErrors, Validator, ValidatorFn, Validators} from "@angular/forms";
import {Injectable} from "@angular/core";

export class SroValidators {
    public static mobileRegexp: RegExp = new RegExp("^04\\d{2}\\s*\\d{3}\\s*\\d{3}$");
    public static phoneRegexp: RegExp = new RegExp("^\\({0,1}((0|\\+61)(2|4|3|7|8)){0,1}\\){0,1}(\\ |-){0,1}[0-9]{2}(\\ |-){0,1}[0-9]{2}(\\ |-){0,1}[0-9]{1}(\\ |-){0,1}[0-9]{3}$");

    static ausphone(control: AbstractControl): ValidationErrors | null {
        if (control && control.value) {
            const val: boolean = SroValidators.phoneRegexp.test(control.value) ;
            return val ? null : {'phoneFormat': {value: control.value}};
        }
        return null;
    }

    static ausmobile(control: AbstractControl): ValidationErrors | null {
        if (control && control.value) {
            const val = SroValidators.mobileRegexp.test(control.value);
            return val ? null : {'mobileFormat': {value: control.value}};
        }
        return null;
    }

}
