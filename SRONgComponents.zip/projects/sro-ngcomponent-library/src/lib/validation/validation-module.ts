import {ModuleWithProviders, NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import {EmailDirective} from "./email/email.directive";
import {PhoneDirective} from "./phone/phone.directive";
import {SroValidators} from "./sro-validators";

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [
      EmailDirective,
      PhoneDirective
  ],
  exports: [
      EmailDirective,
      PhoneDirective
  ]
})
export class ValidationModule {
    static forRoot(): ModuleWithProviders {
        return {
            ngModule: ValidationModule,
            providers: []
        };
    }
}
