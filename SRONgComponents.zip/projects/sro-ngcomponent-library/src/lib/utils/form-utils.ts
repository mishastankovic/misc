import { AbstractControl, FormControl, FormGroup, Validators, ValidatorFn } from '@angular/forms';

export class FormUtils {

	static enableControl(control: AbstractControl | AbstractControl[]) {
		const controls: AbstractControl[] = (control instanceof Array) ? control : [control];

		controls.forEach(item => {
			if (item instanceof FormGroup) {
				const formGroup: FormGroup = <FormGroup>item;

				Object.keys(formGroup.controls).forEach(
					key => { FormUtils.enableControl(formGroup.get(key)); }
				);

			} else {
				FormUtils.setControlItem(item, true);
			}
		});
	}

	static enableAndTouchControl(control: AbstractControl | AbstractControl[]) {
		const controls: AbstractControl[] = (control instanceof Array) ? control : [control];

		controls.forEach(item => {
			if (item instanceof FormGroup) {
				const formGroup: FormGroup = <FormGroup>item;

				Object.keys(formGroup.controls).forEach(
					key => { FormUtils.enableAndTouchControl(formGroup.get(key)); }
				);

			} else {
				item.enable();
				item.markAsTouched();
				item.updateValueAndValidity({ onlySelf: true, emitEvent: false });
			}
		});
	}

	static disableControl(control: AbstractControl | AbstractControl[]) {
		const controls: AbstractControl[] = (control instanceof Array) ? control : [control];

		controls.forEach(item => {
			if (item instanceof FormGroup) {
				const formGroup: FormGroup = <FormGroup>item;

				Object.keys(formGroup.controls).forEach(
					key => { FormUtils.disableControl(formGroup.get(key)); }
				);

			} else {
				FormUtils.setControlItem(item, false);
			}
		});
	}

	static disableAndResetControl(control: AbstractControl | AbstractControl[]) {
		const controls: AbstractControl[] = (control instanceof Array) ? control : [control];

		controls.forEach(item => {
			if (item instanceof FormGroup) {
				const formGroup: FormGroup = <FormGroup>item;

				Object.keys(formGroup.controls).forEach(
					key => { FormUtils.disableAndResetControl(formGroup.get(key)); }
				);

			} else {
				FormUtils.setControlItem(item, false, true);
			}
		});
	}


	static isNotValid(control: AbstractControl, type?: string): boolean {
		let controlInvalid = !control.valid && control.touched;

		if (controlInvalid) {
			return type ? control.hasError(type) : true;
		} else
			return false;
	}

	static hasErrors(control: AbstractControl): boolean {
		if (!(control instanceof FormGroup)) return true;
		const formGroup: FormGroup = <FormGroup>control;

		let hasErrors = false;
		Object.keys(formGroup.controls).forEach(
			key => {
				if (!formGroup.get(key).valid && formGroup.get(key).touched)
					hasErrors = true
			});

		return hasErrors;
	}

	static validate(control: AbstractControl) {
		if (!(control instanceof FormGroup)) return;

		const formGroup: FormGroup = <FormGroup>control;
		Object.keys(formGroup.controls).forEach(
			key => {
				if (formGroup.get(key) instanceof FormGroup) {
					FormUtils.validate(formGroup.get(key));
				} else {
					//TODO: Capture client side validation error 
					if (formGroup.get(key).invalid) console.log(key + " is invalid");
					formGroup.get(key).disabled ? formGroup.get(key).markAsUntouched() : formGroup.get(key).markAsTouched();
				}
			});
	}

	static contactNumberValidator(group: FormGroup): { contactNumberRequired: boolean } {
		const mobileNumber: AbstractControl = group.get('mobileNumber');
		const phoneNumber: AbstractControl = group.get('phoneNumber');

		return (mobileNumber && mobileNumber.value != '') ||
			(phoneNumber && phoneNumber.value != '') ? null : { contactNumberRequired: true };
	}

	static abnArbnAcnValidator(group: FormGroup): { abnArbnAcnRequired: boolean } {
		const abn: AbstractControl = group.get('abn');
		const arbn: AbstractControl = group.get('arbn');
		const acn: AbstractControl = group.get('acn');

		return (abn && abn.value != '') ||
			(arbn && arbn.value != '') ||
			(acn && acn.value != '') ? null : { abnArbnAcnRequired: true };
	}

	static focusError(document: Document) {
		setTimeout(() => {
			let element = document.querySelector(".bs-callout-danger");
			if (element) element.scrollIntoView({ behavior: "smooth" });
			element = document.querySelector(".alert-danger");
			if (element) element.scrollIntoView({ behavior: "smooth" });
		}, 100);
	}

	static getBooleanString(value: boolean): string {
		return value && value === true ? 'Yes' : 'No';
	}

	private static setControlItem(item: AbstractControl, enableControl: boolean, reset?: boolean) {
		if (enableControl) {
			item.enable();
			item.markAsUntouched();

		} else {
			item.disable();
			if (reset) item.reset();
		}
		item.updateValueAndValidity({ onlySelf: true, emitEvent: false });
	}
}