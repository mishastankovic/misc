import { TestBed, inject } from '@angular/core/testing';

import { SRONgComponentLibraryService } from './sro-ngcomponent-library.service';

describe('SRONgComponentLibraryService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SRONgComponentLibraryService]
    });
  });

  it('should be created', inject([SRONgComponentLibraryService], (service: SRONgComponentLibraryService) => {
    expect(service).toBeTruthy();
  }));
});
