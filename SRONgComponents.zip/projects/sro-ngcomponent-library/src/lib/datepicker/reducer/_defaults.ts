import {
  MonthViewOptions
} from '../models/index';

export const defaultMonthOptions: MonthViewOptions = {
  width: 7,
  height: 6
};
