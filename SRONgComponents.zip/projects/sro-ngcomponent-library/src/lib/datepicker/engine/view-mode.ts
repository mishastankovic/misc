import { BsDatepickerViewMode } from '../models/index';

export function canSwitchMode(mode: BsDatepickerViewMode): boolean {
  return true;
}
