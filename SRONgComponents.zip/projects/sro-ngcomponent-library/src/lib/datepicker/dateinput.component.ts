import { Component, ViewChild, HostListener, Input, Output, EventEmitter } from '@angular/core';
import { BsDatepickerDirective } from './bs-datepicker.component';
import { BsDatepickerConfig } from './bs-datepicker.config';
import { FormGroup } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { OnInit } from '@angular/core';
import { OnDestroy } from '@angular/core';

@Component({
	selector: 'sro-dateinput',
	templateUrl: './dateinput.component.html',
	styleUrls: ['./dateinput.component.css']
})

export class DateInputComponent implements OnInit, OnDestroy {
	@ViewChild(BsDatepickerDirective) datepicker: BsDatepickerDirective;
	@Input() dateValue: Date;
	@Input() minDate: Date;
	@Input() maxDate: Date;
	@Input() isDisabled: Boolean = false;
	@Input() placement: 'top' | 'bottom' | 'left' | 'right' = 'bottom';
	@Input() hideOnScroll: Boolean = false;
	// https://developer.mozilla.org/en-US/docs/Web/Events
	@Input() triggers: String = 'click';
	@Input() showWeekNumbers: Boolean = false;

	@Output()
	dateAdd: EventEmitter<FormGroup> = new EventEmitter<FormGroup>();

	@Output()
	dateRemove: EventEmitter<FormGroup> = new EventEmitter<FormGroup>();

	private _outsideClick: Boolean = true;

	get outsideClick(): Boolean {
		return this._outsideClick;
	}

	@Input()
	set outsideClick(value: Boolean) {
		this._outsideClick = value;
	}

	public config: Partial<BsDatepickerConfig> = new BsDatepickerConfig();

	form: FormGroup;

	constructor(private formBuilder: FormBuilder) {
		this.config.dateInputFormat = 'DD/MM/YYYY';
		this.config.showWeekNumbers = this.showWeekNumbers.valueOf();
	}

	@HostListener('window:scroll')
	onScrollEvent() {
		if (this.hideOnScroll)
			this.datepicker.hide();
	}

	ngOnInit() {
		this.form = this.formBuilder.group({
			dateSelected: null
		});

		this.dateAdd.emit(this.form);
	}

	ngOnDestroy() {
		this.dateRemove.emit(this.form);
	}
}
