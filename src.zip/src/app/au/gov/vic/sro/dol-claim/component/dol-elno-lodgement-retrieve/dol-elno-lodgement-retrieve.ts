import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl, FormBuilder, Validators, AbstractControl } from '@angular/forms';
import { FormUtils } from 'sro-ngcomponent-library';
import { UIMessageService } from 'src/app/au/gov/vic/sro/dol-claim/service/ui-message.service';
import { DolClaimUIService } from 'src/app/au/gov/vic/sro/dol-claim/service/dol-claim-ui-service';

@Component({
    selector: 'dol-elno-lodgement-retreive',
    templateUrl: './dol-elno-lodgement-retrieve.html',
    styleUrls: ['./dol-elno-lodgement-retrieve.scss']
})
export class DolElnoLodgementRetrieve implements OnInit {


	private form: FormGroup;
	private lodgementCaseId: FormControl;
	private sroReferenceId: FormControl;

	constructor(private formBuilder: FormBuilder,
				private router: Router,
				private uiMessageService: UIMessageService,
				private dolClaimUIService : DolClaimUIService) { }

	ngOnInit() {
		this.buildForm();
	}

	buildForm() {
		this.lodgementCaseId = new FormControl('', Validators.compose([Validators.required, Validators.pattern('^[0-9]{1,9}$')]));
		this.sroReferenceId = new FormControl('', Validators.compose([Validators.required, Validators.pattern('^N[0-9]{1,8}$')]));

		this.form = this.formBuilder.group({
			lodgementCaseId: this.lodgementCaseId,
			sroReferenceId: this.sroReferenceId
		});
	}

	onSubmit() {
		FormUtils.validate(this.form);
		if (this.form.valid) {
			this.dolClaimUIService.clear();
			this.dolClaimUIService.lodgementCaseId = this.lodgementCaseId.value;
			this.dolClaimUIService.sroReferenceId = this.sroReferenceId.value;
			this.router.navigate(['/clame-lodgement']);
		}

	}


	isNotValid(control: AbstractControl, type?: string): boolean {
		if (!control) { return; }
		return FormUtils.isNotValid(control, type);
	}



}

