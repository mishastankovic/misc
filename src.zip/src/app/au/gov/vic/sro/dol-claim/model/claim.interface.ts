export interface Category1 {
    id: string,
    value: string,
    subCategories: SubCategory[]
}

export interface Category {
    categoryCode: string,
    categoryName: string,
    categoryOrder: number,
    parentCategoryCode: string,
    subCategories: Category[],
    assessingType: string
}



export interface SubCategory {
    id: string,
    value: string
}

export interface Document {
    documentId: string;
}

export interface Form {
    property: Property;
}

export interface Lodgement {
    documents : Document [];
}

export interface Property {
    address: string;
}

export interface ClaimedForm {
    formId: string,
    documentId: string
}