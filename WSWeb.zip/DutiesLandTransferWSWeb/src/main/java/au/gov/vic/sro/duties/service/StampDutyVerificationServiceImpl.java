package au.gov.vic.sro.duties.service;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import au.gov.messages.osr.schema._2.JurisdictionCategoryType;
import au.gov.messages.osr.schema._2.MessageCategoryCategoryType;
import au.gov.messages.osr.schema._2.MessageHeaderType;
import au.gov.messages.osr.schema._2.MessageHeaderType.MessageStatus;
import au.gov.messages.osr.schema._2.MessageStatusDescriptionCategoryType;
import au.gov.messages.osr.schema._2.SettlementStatusCategoryType;
import au.gov.messages.osr.schema._2.StampDutyVerificationRequestType;
import au.gov.messages.osr.schema._2.StampDutyVerificationResponseType;
import au.gov.messages.osr.service._2_4.StampDutyVerificationPortType;
import au.gov.vic.sro.duties.transfer.model.ElnoLodgementCase;
import au.gov.vic.sro.duties.transfer.model.Error;
import au.gov.vic.sro.duties.transfer.model.Lodgement;
import au.gov.vic.sro.duties.transfer.model.Message;
import au.gov.vic.sro.duties.transfer.service.ElnoLodgementCaseService;
import au.gov.vic.sro.duties.transfer.service.ElnoLodgementService;
import au.gov.vic.sro.duties.util.MapperUtils;
import au.gov.vic.sro.duties.validation.StampDutyVerificationSROValidator;
import au.gov.vic.sro.duties.validation.ValidationResult;

@Service("stampDutyVerificationService")
@Component
public class StampDutyVerificationServiceImpl implements StampDutyVerificationPortType {

	public static final String SOAP_REQUEST_PAYLOAD = "soapRequestPayload";

	@Resource
	private HttpServletRequest servletRequest;

	@Autowired
	private ElnoLodgementCaseService elnoLodgementCaseService;

	@Autowired
	private ElnoLodgementService elnoLodgementService;

	@Autowired
	private StampDutyVerificationSROValidator sroValidator;

	@Autowired
	private MapperUtils mapperUtil;

	@Override
	public StampDutyVerificationResponseType stampDutyVerification(StampDutyVerificationRequestType request) {

		StampDutyVerificationResponseType response = new StampDutyVerificationResponseType();

		response.setJurisdiction(JurisdictionCategoryType.VIC);
		response.setElnLodgementCaseId(request.getElnLodgementCaseId());

		ValidationResult validationResult = sroValidator.validateStampDutyVerificationRequest(request);
		MessageHeaderType messageHeaderType = createMessageHeaderType();
		response.setMessageHeader(messageHeaderType);
		String payload = getMessagePayload();
		if (!validationResult.isValid()) {
			for (Error error : validationResult.getErrors()) {
				messageHeaderType.getMessageStatus().add(createNewMessageStatus(error));
			}
		} else if (request.getTransactionId() == null) {
			// New request
			// Create ElnoLodgementCase from request
			ElnoLodgementCase elnoLodgementCase = new ElnoLodgementCase();
			elnoLodgementCase.setCaseReferenceId(request.getTransactionId());
			elnoLodgementCase.setElnoId(request.getSubscriberDetails().getSubscriberId());
			elnoLodgementCase.setElnoLodgementCaseId(request.getElnLodgementCaseId());

			elnoLodgementCase.setLatestRequestXml(payload);

			// Call our service
			ElnoLodgementCase saved = saveElnLodgementCase(elnoLodgementCase, payload);

			// Create response
			response.setTransactionId(saved.getCaseReferenceId());

		} else if (SettlementStatusCategoryType.VERIFY.equals(request.getSettlementStatus())) {

			ElnoLodgementCase elnoLodgementCase = elnoLodgementCaseService.findByPk(request.getTransactionId());

			// esys operation
			if (elnoLodgementCase.getEsysLodgementId() != null) {

				// Claimed
				if (StringUtils.isNotEmpty(request.getActionRequested())) {
					if (request.getActionRequested().trim().equals("Commence Assessment")) {
						Lodgement lodgement =
								elnoLodgementService.submitElnoLodgement(elnoLodgementCase.getCaseReferenceId(),
										mapperUtil.toDate(request.getIntendedSettlementDate()), payload);
						List<Message> messages = lodgement.getMessages(); // eSys messages list
					} else {
						// Future actions
					}
				} else {
					// Update
					elnoLodgementService.updateLodgement(elnoLodgementCase);
				}

			} else {
				// Future events like Update, Settle etc.
			}

			// save to elno database
			saveElnLodgementCase(elnoLodgementCase, payload);
		}
		return response;
	}

	private ElnoLodgementCase saveElnLodgementCase(ElnoLodgementCase elnoLodgementCase, String payload) {
		elnoLodgementCase.setLatestRequestXml(payload);
		return elnoLodgementCaseService.save(elnoLodgementCase);
	}

	private MessageHeaderType createMessageHeaderType() {
		MessageHeaderType messageHeaderType = new MessageHeaderType();
		messageHeaderType.setMessageCategory(MessageCategoryCategoryType.RESPONSE);
		messageHeaderType.setMessageOrigin("sro:vic:gov:au");
		messageHeaderType.setTransmissionTimestamp(mapperUtil.getTimestamp());
		return messageHeaderType;
	}

	private MessageStatus createNewMessageStatus(Error error) {
		MessageStatus messageStatus = new MessageStatus();
		messageStatus.setMessageStatusCode("201");
		messageStatus.setMessageStatusDescription(MessageStatusDescriptionCategoryType.CONTENT_ERROR);
		messageStatus.setMessageStatusReason(error.getErrorMsg());
		return messageStatus;
	}

	private String getMessagePayload() {
		return servletRequest != null ? (String) servletRequest.getAttribute(SOAP_REQUEST_PAYLOAD) : null;
	}
}
