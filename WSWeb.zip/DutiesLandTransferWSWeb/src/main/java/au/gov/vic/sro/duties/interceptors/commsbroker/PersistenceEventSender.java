package au.gov.vic.sro.duties.interceptors.commsbroker;

import au.gov.vic.sro.communication.model.Communication;
import au.gov.vic.sro.communication.service.CommunicationService;
import au.gov.vic.sro.duties.service.StampDutyVerificationServiceImpl;
import au.gov.vic.sro.duties.transfer.dao.configuration.PersistenceConfiguration;
import org.apache.cxf.ext.logging.event.LogEvent;
import org.apache.cxf.ext.logging.event.LogEventSender;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;


@Service
public class PersistenceEventSender implements LogEventSender {

    private static final Logger log = LoggerFactory.getLogger(PersistenceConfiguration.class);

    @Autowired
    private CommsBrokerEventMapper commsBrokerEventMapper;

    @Autowired
    private CommunicationService communicationService;

    @Resource
    private HttpServletRequest servletRequest;

    @Transactional
    public void send(LogEvent event) {
        try {
            Communication communication = commsBrokerEventMapper.createCommunication(event);

            // Store XML payload as request attribute for use by the persistence service
            if (servletRequest != null) {
                servletRequest.setAttribute(StampDutyVerificationServiceImpl.SOAP_REQUEST_PAYLOAD, event.getPayload());
            }
            communicationService.logCommunication(communication);
        } catch (RuntimeException e) {
            log.error("exception writing to commsbroker ", e);
        }
    }
}
