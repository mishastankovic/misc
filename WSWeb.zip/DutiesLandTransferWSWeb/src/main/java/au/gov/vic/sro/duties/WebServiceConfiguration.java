package au.gov.vic.sro.duties;

import java.util.Collections;

import javax.xml.ws.Endpoint;

import org.apache.cxf.Bus;
import org.apache.cxf.bus.spring.SpringBus;
import org.apache.cxf.ext.logging.LoggingFeature;
import org.apache.cxf.jaxws.EndpointImpl;
import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;
import org.apache.cxf.transport.servlet.CXFServlet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import au.gov.messages.osr.service._2_4.StampDutyVerificationPortType;
import au.gov.vic.sro.duties.interceptors.commsbroker.CommBrokerInfoInterceptor;
import au.gov.vic.sro.duties.interceptors.commsbroker.PersistenceEventSender;
import au.gov.vic.sro.duties.service.StampDutyVerificationServiceImpl;

@Configuration
public class WebServiceConfiguration {

	@Autowired
	private CommBrokerInfoInterceptor commBrokerInfoInterceptor;

	@Autowired
	private PersistenceEventSender persistenceEventSender;

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Bean
	public ServletRegistrationBean<CXFServlet> cxfServlet() {
		return new ServletRegistrationBean(new CXFServlet(), "/services/*");
	}

	@Bean(name = Bus.DEFAULT_BUS_ID)
	public SpringBus springBus() {
		return new SpringBus();
	}

	@Bean
	public StampDutyVerificationPortType stampDutyVerificationService() {
		return new StampDutyVerificationServiceImpl();
	}

	@Bean
	public Endpoint endpoint() {
		EndpointImpl endpoint = new EndpointImpl(springBus(), stampDutyVerificationService());

		endpoint.getInInterceptors().add(commBrokerInfoInterceptor);
		LoggingFeature loggingFeature = new LoggingFeature();
		loggingFeature.setSender(this.persistenceEventSender);
		endpoint.setFeatures(Collections.singletonList(loggingFeature));

		endpoint.publish("/stampDutyVerification");
		endpoint.setWsdlLocation("/DutiesLandTransferWSWeb/src/main/resources/wsdl/StampDutyVerification.wsdl");

		return endpoint;
	}

	@Bean(name = "stampDutyVerificationProxy")
	public StampDutyVerificationPortType stampDutyVerificationProxy() {
		JaxWsProxyFactoryBean jaxWsProxyFactoryBean = new JaxWsProxyFactoryBean();
		jaxWsProxyFactoryBean.setServiceClass(StampDutyVerificationPortType.class);

		return (StampDutyVerificationPortType) jaxWsProxyFactoryBean.create();
	}
}
