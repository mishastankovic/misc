package au.gov.vic.sro.duties.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import au.gov.messages.osr.schema._2.StampDutyVerificationRequestType;
import au.gov.messages.osr.schema._2.StampDutyVerificationResponseType;
import au.gov.messages.osr.service._2_4.StampDutyVerificationPortType;

@Component
public class StampDutyVerificationCXFClient {

	@Autowired
	private StampDutyVerificationPortType stampdutyVerificationClient;

	public StampDutyVerificationResponseType stampdutyVerification(StampDutyVerificationRequestType request) {

		return stampdutyVerificationClient.stampDutyVerification(request);
	}
}
