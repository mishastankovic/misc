package au.gov.vic.sro.duties.config;

import javax.sql.DataSource;

import org.apache.catalina.Context;
import org.apache.catalina.startup.Tomcat;
import org.apache.tomcat.util.descriptor.web.ContextResource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.boot.web.embedded.tomcat.TomcatWebServer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Configuration
@Profile({ "local" })
public class TomcatWebConfiguration  {

	@Value("${spring.datasource.srouser.jdbc-url}")
	private String srouserDataSourceUrl;

	@Value("${spring.datasource.srouser.username}")
	private String srouserDataSourceUsername;

	@Value("${spring.datasource.srouser.password}")
	private String srouserDataSourcePassword;

	@Value("${spring.datasource.srouser.jndi-name}")
	private String srouserDataSourceJndi;

	@Bean
	public TomcatServletWebServerFactory tomcatFactory() {
		return new TomcatServletWebServerFactory() {
			@Override
			protected TomcatWebServer getTomcatWebServer(Tomcat tomcat) {
				tomcat.enableNaming();
				return super.getTomcatWebServer(tomcat);
			}

			@Override
			protected void postProcessContext(Context context) {
				ContextResource resource = new ContextResource();
				resource.setName(srouserDataSourceJndi);
				resource.setType(DataSource.class.getName());
				resource.setProperty("url", srouserDataSourceUrl);
				resource.setProperty("username", srouserDataSourceUsername);
				resource.setProperty("password", srouserDataSourcePassword);
				context.getNamingResources().addResource(resource);
			}
		};
	}
}
