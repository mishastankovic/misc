package au.gov.vic.sro.duties.interceptors.commsbroker;

import au.gov.vic.sro.communication.model.Communication;
import au.gov.vic.sro.communication.model.CommunicationContent;
import org.apache.cxf.ext.logging.event.EventType;
import org.apache.cxf.ext.logging.event.LogEvent;
import org.springframework.stereotype.Service;

import java.util.Collections;

/**
 * maps a log event to a commsbroker communication object.
 */
@Service
public class CommsBrokerEventMapper {

    protected static final String COMMUNICATION_TYPE_REQUEST = "ELNO_VERFICATION_REQUEST";
    protected static final String COMMUNICATION_TYPE_RESPONSE = "ELNO_VERFICATION_RESPONSE";


    public Communication createCommunication(LogEvent event) {
        Communication communication = new Communication();
        CommunicationContent content = new CommunicationContent();
        communication.setCommunicationContents(Collections.singletonList(content));

        String exchangeId = event.getExchangeId();
        CommsBrokerId commsBrokerId = new CommsBrokerId(exchangeId);

        communication.setPrimaryCommunicationIdentifier(commsBrokerId.getElnoCaseId());
        communication.setSecondaryCommunicationIdentifier(commsBrokerId.getCxfMessageId());
        communication.setUserId(commsBrokerId.getElnoIdentifier());
        communication.setSource("elno");
        communication.setDestination("e-Business");

        String communicationType = null;
        if (EventType.REQ_IN.equals(event.getType())) {
            communicationType = COMMUNICATION_TYPE_REQUEST;
        } else if (EventType.RESP_OUT.equals(event.getType())) {
            communicationType = COMMUNICATION_TYPE_RESPONSE;
        }
        communication.setCommunicationType(communicationType);
        content.setCommunicationContentType(communicationType);

        content.setCommunicationClobContent(event.getPayload());
        return communication;
    }

}
