package au.gov.vic.sro.duties.validation;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import au.gov.messages.osr.schema._2.DocumentDataType;
import au.gov.messages.osr.schema._2.DocumentDataType.PartyReceivingDetail;
import au.gov.messages.osr.schema._2.DocumentDataType.PartyRelinquishingDetail;
import au.gov.messages.osr.schema._2.DocumentDataType.SubjectLandTitle;
import au.gov.messages.osr.schema._2.FractionType;
import au.gov.messages.osr.schema._2.JurisdictionCategoryType;
import au.gov.messages.osr.schema._2.PartyDetailType;
import au.gov.messages.osr.schema._2.PartyTypeCategoryType;
import au.gov.messages.osr.schema._2.StampDutyVerificationRequestType;
import au.gov.messages.osr.schema._2.TenancyDetailType.TenancyGroup;
import au.gov.messages.osr.schema._2.TenancyDetailType.TenancyGroup.TenantHolding;
import au.gov.vic.sro.duties.transaction.Fraction;
import au.gov.vic.sro.duties.transfer.model.Error;

@Component
public class StampDutyVerificationSROValidator {

	@Value("${party.share.fraction:99999999}")
	private String maxFraction;

	@Value("${application.stampduty.environment:Development}")
	private String environment;

	private static final String VOLUME = "volume";
	private static final String FOLIO = "folio";
	private static final String RELINQUISHING_PARTY = "relinquishing";
	private static final String RECEIVING_PARTY = "receiving";

	public ValidationResult validateStampDutyVerificationRequest(StampDutyVerificationRequestType request) {
		ValidationResult validated = new ValidationResult();

		if (request == null) {
			validated.addError(new Error("Empty request", "Request", "Null"));
			validated.setValid(false);
			return validated;

		}

		List<PartyDetailType> receivingParties = getReceivingParties(request);
		List<PartyDetailType> relinquishingParties = getRelinquishingParties(request);

		if (!JurisdictionCategoryType.VIC.equals(request.getJurisdiction())) {
			validated.addError(new Error("Invalid Jurisdiction: Expected 'VIC' but was " + request.getJurisdiction(),
					"Jurisdiction", request.getJurisdiction().value()));
			validated.setValid(false);

		}

		if (!environment.equalsIgnoreCase(request.getMessageHeader().getEnvironment().value())) {
			validated.addError(new Error(
					"Invalid Environment: Expected " + environment + " but was "
							+ request.getMessageHeader().getEnvironment(),
					"Environment", request.getMessageHeader().getEnvironment().value()));
			validated.setValid(false);
		}

		validateShareFractions(request, validated);
		validateReceivingParties(receivingParties, validated);
		validateRelinquishingParties(relinquishingParties, validated);
		validatePropertyLandIdentifiers(request, validated);
		return validated;
	}

	private ValidationResult validatePropertyLandIdentifiers(StampDutyVerificationRequestType request,
			ValidationResult validated) {
		for (DocumentDataType documentDataType : request.getDocumentData()) {
			for (SubjectLandTitle subjectLandTitle : documentDataType.getSubjectLandTitle()) {
				au.gov.messages.osr.schema._2.LandTitleReferenceType.Component volumeComponent = subjectLandTitle
						.getLandTitleReference().getComponent().stream()
						.filter(component -> VOLUME.equalsIgnoreCase(component.getName())).findFirst().orElse(null);
				au.gov.messages.osr.schema._2.LandTitleReferenceType.Component folioComponent = subjectLandTitle
						.getLandTitleReference().getComponent().stream()
						.filter(component -> FOLIO.equalsIgnoreCase(component.getName())).findFirst().orElse(null);

				if (volumeComponent == null || folioComponent == null || StringUtils.isEmpty(volumeComponent.getValue())
						|| StringUtils.isEmpty(folioComponent.getValue())) {
					validated.addError(new Error("Missing Volume/Folio Land title reference", "Volume/Folio",
							documentDataType.getDocumentId()));
					validated.setValid(false);
					return validated;
				}
			}

		}

		return validated;
	}

	private ValidationResult validateReceivingParties(List<PartyDetailType> receivingParties,
			ValidationResult validated) {
		return validateInvolvedParties(receivingParties, validated);
	}

	private ValidationResult validateInvolvedParties(List<PartyDetailType> involvedParties,
			ValidationResult validated) {
		for (PartyDetailType involvedParty : involvedParties) {
			if (PartyTypeCategoryType.INDIVIDUAL.equals(involvedParty.getPartyType())) {

				validatePersonFullName(involvedParty, validated);

				if (involvedParty.getBirthDate() == null) {
					validated.addError(new Error("Missing Date of Birth for " + involvedParty.getPartyId(),
							"Date of Birth", involvedParty.getBirthDate().toString()));
					validated.setValid(false);
				}
			}
		}
		return validated;
	}

	private ValidationResult validatePersonFullName(PartyDetailType involvedParty, ValidationResult validated) {

		involvedParty.getPersonFullName().getGivenName().sort((g1, g2) -> g1.getOrder().compareTo(g2.getOrder()));
		if (StringUtils.isEmpty(involvedParty.getPersonFullName().getGivenName().get(0).getValue())) {
			validated.addError(
					new Error("Missing First name for " + involvedParty.getLegalEntityName(), "First name", null));
			validated.setValid(false);
		}
		return validated;
	}

	private ValidationResult validateRelinquishingParties(List<PartyDetailType> relinquishingParties,
			ValidationResult validated) {

		return validateInvolvedParties(relinquishingParties, validated);
	}

	private List<PartyDetailType> getReceivingParties(StampDutyVerificationRequestType request) {
		Set<String> partyIds = new HashSet<>();
		List<PartyDetailType> receivingPartiesList = new ArrayList<>();

		for (DocumentDataType documentDataType : request.getDocumentData()) {
			for (PartyReceivingDetail partyReceivingDetail : documentDataType.getPartyReceivingDetail()) {
				for (TenancyGroup tenancyGroup : partyReceivingDetail.getTenancy().getTenancyGroup()) {
					Set<String> partyIdSet = (tenancyGroup.getTenantHolding().stream().map(TenantHolding::getPartyId)
							.collect(Collectors.toSet()));
					partyIds.addAll(partyIdSet);
				}
			}
		}

		for (PartyDetailType involvedParty : request.getInvolvedParty()) {
			if (partyIds.contains(involvedParty.getPartyId())) {
				receivingPartiesList.add(involvedParty);
			}
		}
		return receivingPartiesList;
	}

	private List<PartyDetailType> getRelinquishingParties(StampDutyVerificationRequestType request) {
		Set<String> partyIds = new HashSet<>();
		List<PartyDetailType> relinquishingPartiesList = new ArrayList<>();

		for (DocumentDataType documentDataType : request.getDocumentData()) {
			for (PartyRelinquishingDetail partyRelinquishingDetail : documentDataType.getPartyRelinquishingDetail()) {
				for (TenancyGroup tenancyGroup : partyRelinquishingDetail.getTenancy().getTenancyGroup()) {
					Set<String> partyIdSet = tenancyGroup.getTenantHolding().stream().map(TenantHolding::getPartyId)
							.collect(Collectors.toSet());
					partyIds.addAll(partyIdSet);
				}
			}
		}

		for (PartyDetailType involvedParty : request.getInvolvedParty()) {
			if (partyIds.contains(involvedParty.getPartyId())) {
				relinquishingPartiesList.add(involvedParty);
			}
		}
		return relinquishingPartiesList;
	}

	private ValidationResult validateShareFractions(StampDutyVerificationRequestType request,
			ValidationResult validated) {
		for (DocumentDataType documentDataType : request.getDocumentData()) {

			validateReceivingPartiesShareFractions(validated, documentDataType);
			validateRelinquishingPartiesShareFractions(validated, documentDataType);
		}
		return validated;
	}

	private ValidationResult validateReceivingPartiesShareFractions(ValidationResult validated,
			DocumentDataType documentDataType) {
		List<Fraction> fractions = new ArrayList<>();
		for (PartyReceivingDetail partyReceivingDetail : documentDataType.getPartyReceivingDetail()) {
			for (TenancyGroup tenancyGroup : partyReceivingDetail.getTenancy().getTenancyGroup()) {
				if (tenancyGroup.getShareFraction() != null) {
					fractions.add(new Fraction(tenancyGroup.getShareFraction().getNumerator().longValue(),
							tenancyGroup.getShareFraction().getDenominator().longValue()));
					isValidShareFraction(validated, documentDataType, tenancyGroup);

				}
			}

		}
		if (!CollectionUtils.isEmpty(fractions)) {
			isFractionSumEqualOne(validated, documentDataType, fractions, RECEIVING_PARTY);
		}
		return validated;
	}

	private ValidationResult validateRelinquishingPartiesShareFractions(ValidationResult validated,
			DocumentDataType documentDataType) {
		List<Fraction> fractions = new ArrayList<>();
		for (PartyRelinquishingDetail partyRelinquishingDetail : documentDataType.getPartyRelinquishingDetail()) {
			for (TenancyGroup tenancyGroup : partyRelinquishingDetail.getTenancy().getTenancyGroup()) {
				if (tenancyGroup.getShareFraction() != null) {
					fractions.add(new Fraction(tenancyGroup.getShareFraction().getNumerator().longValue(),
							tenancyGroup.getShareFraction().getDenominator().longValue()));
					isValidShareFraction(validated, documentDataType, tenancyGroup);
				}
			}
		}
		if (!CollectionUtils.isEmpty(fractions)) {
			isFractionSumEqualOne(validated, documentDataType, fractions, RELINQUISHING_PARTY);
		}
		return validated;
	}

	private ValidationResult isFractionSumEqualOne(ValidationResult validated, DocumentDataType documentDataType,
			List<Fraction> fractions, String partyCategory) {

		Fraction addedFraction = Fraction.aggregate(fractions.stream().toArray(Fraction[]::new));

		if (addedFraction.getNumerator() % addedFraction.getDenominator() != 0) {
			validated.setValid(false);
			validated.addError(new Error("Sum of ShareFraction values for party does not equal 1 for " + partyCategory,
					"ShareFraction", documentDataType.getDocumentId()));
		}
		return validated;
	}

	private boolean isValidShareFraction(ValidationResult validated, DocumentDataType documentDataType,
			TenancyGroup tenancyGroup) {
		boolean isValid = true;
		if (tenancyGroup.getShareFraction() != null) {
			FractionType shareFraction = tenancyGroup.getShareFraction();
			if (shareFraction.getNumerator().compareTo(new BigInteger(maxFraction)) > 0
					|| shareFraction.getDenominator().compareTo(new BigInteger(maxFraction)) > 0) {

				isValid = false;
				validated.setValid(false);
				validated.addError(new Error("Value greater than 99999999 in Share Fraction numerator or denominator ",
						"ShareFraction", documentDataType.getDocumentId()));
			}
		}
		return isValid;
	}

}