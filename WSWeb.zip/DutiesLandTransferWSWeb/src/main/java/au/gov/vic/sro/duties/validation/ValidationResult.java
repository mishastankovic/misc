package au.gov.vic.sro.duties.validation;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.cxf.common.util.CollectionUtils;

import au.gov.vic.sro.duties.transfer.model.Error;

public class ValidationResult implements Serializable {

	private static final long serialVersionUID = 1L;

	private boolean isValid = true;

	private List<Error> errors;

	public boolean isValid() {
		return isValid;
	}

	public ValidationResult setValid(boolean isValid) {
		this.isValid = isValid;
		return this;
	}

	public List<Error> getErrors() {
		return errors;
	}

	public void addError(Error error) {
		if (CollectionUtils.isEmpty(errors)) {
			errors = new ArrayList<>();
		}
		errors.add(error);
	}

	public static <T> boolean checkNotNull(T reference) {
		return reference == null ? true : false;
	}

}