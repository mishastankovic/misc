package au.gov.vic.sro.duties;

import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import au.gov.messages.osr.service._2_4.StampDutyVerificationPortType;

@Configuration
public class ApplicationCXFClientConfiguration {

	@Value("${spring.appclient.endpoint.address}")
	private String address;

	@Bean(name = "stampdutyVerificationClient")
	public StampDutyVerificationPortType stampdutyVerificationClient() {
		JaxWsProxyFactoryBean jaxWsProxyFactoryBean = new JaxWsProxyFactoryBean();
		jaxWsProxyFactoryBean.setServiceClass(StampDutyVerificationPortType.class);
		jaxWsProxyFactoryBean.setAddress(address);

		return (StampDutyVerificationPortType) jaxWsProxyFactoryBean.create();
	}
}
