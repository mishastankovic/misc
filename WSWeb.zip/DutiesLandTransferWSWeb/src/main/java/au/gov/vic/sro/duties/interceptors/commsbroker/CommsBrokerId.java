package au.gov.vic.sro.duties.interceptors.commsbroker;

import org.apache.commons.lang3.StringUtils;

public class CommsBrokerId
{
    private static final String DELEMITER = ":";

    private String cxfMessageId;
    private String elnoCaseId;
    private String elnoMessageId;
    private String elnoIdentifier;

    private String id;

    public CommsBrokerId(String cxfMessageId, String elnoMessageId, String elnoCaseId, String elnoIdentifier) {
        this.cxfMessageId = cxfMessageId == null ? null : cxfMessageId.replace(DELEMITER, "");
        this.elnoCaseId = elnoCaseId;
        this.elnoMessageId = elnoMessageId;
        this.elnoIdentifier = elnoIdentifier;

        this.id = StringUtils.joinWith(DELEMITER, this.cxfMessageId, this.elnoCaseId, this.elnoMessageId, this.elnoIdentifier );

    }

    public CommsBrokerId(String id) {
        this.id = id;
        if (id != null) {
            String[] parts = id.split(DELEMITER);
            this.cxfMessageId = parts.length > 0 && StringUtils.isNotEmpty(parts[0]) ? parts[0] : null;
            this.elnoCaseId = parts.length > 1 && StringUtils.isNotEmpty(parts[1]) ? parts[1] : null;
            this.elnoMessageId = parts.length > 2 && StringUtils.isNotEmpty(parts[2]) ? parts[2] : null;
            this.elnoIdentifier = parts.length > 3 && StringUtils.isNotEmpty(parts[3]) ? parts[3] : null;
        }
    }

    public String getCxfMessageId() {
        return cxfMessageId;
    }

    public String getElnoCaseId() {
        return elnoCaseId;
    }

    public String getElnoMessageId() {
        return elnoMessageId;
    }

    public String getElnoIdentifier() {
        return elnoIdentifier;
    }

    public String getId() {
        return id;
    }
}
