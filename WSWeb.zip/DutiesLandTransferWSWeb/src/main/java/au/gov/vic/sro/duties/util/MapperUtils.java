package au.gov.vic.sro.duties.util;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.springframework.stereotype.Component;

@Component
public class MapperUtils implements Serializable {
	private static final long serialVersionUID = -9164525607835209391L;

	public XMLGregorianCalendar toXMLGregorianCalendar(Date d) {
		return toXMLGregorianCalendar(d, false);
	}

	public XMLGregorianCalendar toXMLGregorianCalendar(Date d, boolean truncateTime) {
		if (d == null) {
			return null;
		}
		if (truncateTime) {
			return getDatatypeFactory().newXMLGregorianCalendar(new SimpleDateFormat("yyyy-MM-dd").format(d));
		}
		GregorianCalendar cal = new GregorianCalendar();
		cal.setTime(d);
		return getDatatypeFactory().newXMLGregorianCalendar(cal);
	}

	public XMLGregorianCalendar getTimestamp() {
		return getDatatypeFactory().newXMLGregorianCalendar(new GregorianCalendar());
	}

	public XMLGregorianCalendar toXMLGregorianCalendar(Calendar cal) {
		if (cal == null) {
			return null;
		}
		return toXMLGregorianCalendar(cal.getTime());
	}

	public Calendar toCalendar(XMLGregorianCalendar xcal) {
		if (xcal == null) {
			return null;
		}
		return xcal.toGregorianCalendar();
	}

	public Date toDate(XMLGregorianCalendar xcal) {
		if (xcal == null) {
			return null;
		}
		return xcal.toGregorianCalendar().getTime();
	}

	public XMLGregorianCalendar toXMLGregorianCalendar(String yyyymmddFormatString) {
		if (yyyymmddFormatString == null) {
			return null;
		}
		return getDatatypeFactory().newXMLGregorianCalendar(yyyymmddFormatString);
	}

	public String formatStringList(String... stringList) {
		final StringBuffer sb = new StringBuffer();
		boolean isFirst = true;

		for (int i = 0; i < stringList.length; i++) {
			if (stringList[i] != null) {
				if (!isFirst) {
					sb.append(' ');
				}
				sb.append(stringList[i]);
				isFirst = false;
			}
		}

		return sb.toString();
	}

	public BigDecimal toBigDecimal(Integer num) {
		if (num == null) {
			return null;
		}

		return new BigDecimal(num);
	}

	public BigInteger toBigInteger(Integer num) {
		if (num == null) {
			return null;
		}

		return BigInteger.valueOf(num.longValue());
	}

	public BigInteger toBigInteger(String num) {
		if (num == null) {
			return null;
		}

		return BigInteger.valueOf(Long.parseLong(num));
	}

	private DatatypeFactory getDatatypeFactory() {
		try {
			return DatatypeFactory.newInstance();
		} catch (DatatypeConfigurationException e) {
			throw new RuntimeException(e);
		}
	}

}
