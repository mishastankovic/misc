package au.gov.vic.sro.duties.interceptors.commsbroker;

import au.gov.messages.osr.schema._2.StampDutyVerificationRequestType;
import au.gov.vic.sro.duties.transfer.dao.configuration.PersistenceConfiguration;
import org.apache.cxf.ext.logging.AbstractLoggingInterceptor;
import org.apache.cxf.ext.logging.LoggingInInterceptor;
import org.apache.cxf.ext.logging.event.LogEventSender;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.message.Exchange;
import org.apache.cxf.message.Message;
import org.apache.cxf.message.MessageContentsList;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class CommBrokerInfoInterceptor extends AbstractLoggingInterceptor {

    private static final Logger log = LoggerFactory.getLogger(CommBrokerInfoInterceptor.class);

    public static final String EXCHANGE_ID = "exchangeId";

    public CommBrokerInfoInterceptor(LogEventSender sender) {
        super("pre-invoke", sender);
        this.getBefore().add(LoggingInInterceptor.class.getName());
    }

    public void handleMessage(Message message) throws Fault {

        try {
            MessageContentsList messageContentsList = MessageContentsList.getContentsList(message);
            StampDutyVerificationRequestType stampDutyVerificationRequestType = (StampDutyVerificationRequestType) messageContentsList.get(0);

            if (stampDutyVerificationRequestType != null) {

                createExchangeId(message);
                Exchange exchange = message.getExchange();
                String exchangeId = (String)exchange.get(EXCHANGE_ID);

                String elnoMessageId = stampDutyVerificationRequestType.getMessageHeader().getMessageId();
                String elnoLodgementCaseId = stampDutyVerificationRequestType.getElnLodgementCaseId();

                CommsBrokerId commsBrokerId = new CommsBrokerId(exchangeId, elnoMessageId, elnoLodgementCaseId, null);
                exchange.put(EXCHANGE_ID, commsBrokerId.getId() );
            }
        } catch (Exception e) {
            log.error("generation of commbroker message Id faied.", e);
        }
    }
}
