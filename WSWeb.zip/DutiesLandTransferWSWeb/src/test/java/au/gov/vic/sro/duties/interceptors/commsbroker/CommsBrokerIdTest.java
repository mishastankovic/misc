package au.gov.vic.sro.duties.interceptors.commsbroker;

import org.junit.Assert;
import org.junit.Test;

public class CommsBrokerIdTest {

    @Test
    public void toId() {
        CommsBrokerId commsBrokerId = new CommsBrokerId("cxfMessageId",  "elnoMessageId","elnoCaseId", "elnoIdentifier");
        Assert.assertEquals("cxfMessageId:elnoCaseId:elnoMessageId:elnoIdentifier", commsBrokerId.getId() );
    }


    @Test
    public void toIdWitnCxfMessageIdNull() {
        CommsBrokerId commsBrokerId = new CommsBrokerId(null,  "elnoMessageId","elnoCaseId", "elnoIdentifier");
        Assert.assertEquals(":elnoCaseId:elnoMessageId:elnoIdentifier", commsBrokerId.getId() );
    }

    @Test
    public void toIdWitnelnoCaseIdNull() {
        CommsBrokerId commsBrokerId = new CommsBrokerId("cxfMessageId", "elnoMessageId",  null,"elnoIdentifier");
        Assert.assertEquals("cxfMessageId::elnoMessageId:elnoIdentifier", commsBrokerId.getId() );
    }

    @Test
    public void toIdWitnelnoElnoIdentifierNull() {
        CommsBrokerId commsBrokerId = new CommsBrokerId("cxfMessageId", "elnoMessageId",  "elnoCaseId",null);
        Assert.assertEquals("cxfMessageId:elnoCaseId:elnoMessageId:", commsBrokerId.getId() );
    }

    @Test
    public void fromId() {
        String id = "cxfMessageId:elnoCaseId:elnoMessageId:elnoIdentifier";
        CommsBrokerId commsBrokerId = new CommsBrokerId(id);

        Assert.assertEquals("cxfMessageId", commsBrokerId.getCxfMessageId());
        Assert.assertEquals("elnoCaseId", commsBrokerId.getElnoCaseId());
        Assert.assertEquals("elnoMessageId", commsBrokerId.getElnoMessageId());
        Assert.assertEquals("elnoIdentifier", commsBrokerId.getElnoIdentifier());
    }

    @Test
    public void fromIdWithNull() {
        String id = "cxfMessageId::elnoMessageId:elnoIdentifier";
        CommsBrokerId commsBrokerId = new CommsBrokerId(id);

        Assert.assertEquals("cxfMessageId", commsBrokerId.getCxfMessageId());
        Assert.assertEquals(null, commsBrokerId.getElnoCaseId());
        Assert.assertEquals("elnoMessageId", commsBrokerId.getElnoMessageId());
        Assert.assertEquals("elnoIdentifier", commsBrokerId.getElnoIdentifier());
    }

}
