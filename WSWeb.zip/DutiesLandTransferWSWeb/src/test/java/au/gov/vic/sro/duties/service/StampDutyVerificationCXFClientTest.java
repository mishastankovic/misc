package au.gov.vic.sro.duties.service;

import au.gov.messages.osr.schema._2.StampDutyVerificationRequestType;
import au.gov.messages.osr.service._2.ObjectFactory;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.InputStream;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.DEFINED_PORT)
@ActiveProfiles({ "local" })
@Ignore
public class StampDutyVerificationCXFClientTest {

	@Autowired
	private StampDutyVerificationCXFClient stampdutyVerificationClient;
	private StampDutyVerificationRequestType requestType;

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testStampdutyVerificationSuccess() {
		requestType = unmarshallStampDutyRequest("stampdutyWebserviceSamples/StampdutyVerificationSample.xml");
		requestType.setElnLodgementCaseId(getUniqueIdentifier());
		requestType.setTransactionId(null);
		assertThat(stampdutyVerificationClient.stampdutyVerification(requestType).getTransactionId()).isNotBlank();

	}

	@Test
	public void testStampdutyVerificationValidationErrors() {
		requestType = unmarshallStampDutyRequest(
				"stampdutyWebserviceSamples/StampdutyVerification_MultiParty_Missing_Data.xml");
		requestType.setElnLodgementCaseId(getUniqueIdentifier());
		requestType.setTransactionId(null);
		assertThat(stampdutyVerificationClient.stampdutyVerification(requestType).getMessageHeader().getMessageStatus())
				.isNotEmpty();

	}

	@SuppressWarnings("unchecked")
	private StampDutyVerificationRequestType unmarshallStampDutyRequest(String resourcePath) {
		InputStream requestStream =
				StampDutyVerificationCXFClientTest.class.getClassLoader().getResourceAsStream(resourcePath);

		// InputStream requestStream = getClass().getResourceAsStream(resourcePath);

		JAXBContext jaxbContext;
		try {
			jaxbContext = JAXBContext.newInstance(ObjectFactory.class);

			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();

			Object object = jaxbUnmarshaller.unmarshal(requestStream);
			JAXBElement<StampDutyVerificationRequestType> jAXBElement =
					(JAXBElement<StampDutyVerificationRequestType>) object;

			return jAXBElement.getValue();
		} catch (JAXBException e) {
			e.printStackTrace();
		}
		return null;
	}

	private String getUniqueIdentifier() {
		return UUID.randomUUID().toString();
	}
}