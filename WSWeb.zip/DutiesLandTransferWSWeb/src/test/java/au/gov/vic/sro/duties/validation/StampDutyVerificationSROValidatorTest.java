package au.gov.vic.sro.duties.validation;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.InputStream;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;

import au.gov.messages.osr.schema._2.StampDutyVerificationRequestType;
import au.gov.messages.osr.service._2.ObjectFactory;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = { StampDutyVerificationSROValidator.class },
		loader = AnnotationConfigContextLoader.class)
@Ignore
public class StampDutyVerificationSROValidatorTest {

	private StampDutyVerificationRequestType requestType;

	@Autowired
	private StampDutyVerificationSROValidator sroValidator;

	@Before
	public void setUp() throws Exception {
		requestType = unmarshalStampDutyRequest();
	}

	@Test
	public void testStampdutyVerificationValidations() throws Exception {
		ValidationResult result = sroValidator.validateStampDutyVerificationRequest(requestType);
		assertThat(result.isValid()).isFalse();
		assertThat(result.getErrors()).isNotEmpty();
	}

	@SuppressWarnings("unchecked")
	private StampDutyVerificationRequestType unmarshalStampDutyRequest() {
		InputStream requestStream = StampDutyVerificationSROValidatorTest.class.getClassLoader()
				.getResourceAsStream("stampdutyWebserviceSamples\\StampdutyVerification_MultiParty_Missing_Data.xml");

		JAXBContext jaxbContext;
		try {
			jaxbContext = JAXBContext.newInstance(ObjectFactory.class);

			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();

			Object object = jaxbUnmarshaller.unmarshal(requestStream);
			JAXBElement<StampDutyVerificationRequestType> jAXBElement =
					(JAXBElement<StampDutyVerificationRequestType>) object;

			return jAXBElement.getValue();
		} catch (JAXBException e) {
			e.printStackTrace();
		}
		return null;
	}
}