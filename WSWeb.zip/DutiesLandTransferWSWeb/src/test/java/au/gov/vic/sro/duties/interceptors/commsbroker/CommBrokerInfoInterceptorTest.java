package au.gov.vic.sro.duties.interceptors.commsbroker;

import au.gov.messages.osr.schema._2.MessageHeaderType;
import au.gov.messages.osr.schema._2.StampDutyVerificationRequestType;
import org.apache.cxf.ext.logging.event.LogEventSender;
import org.apache.cxf.message.Exchange;
import org.apache.cxf.message.ExchangeImpl;
import org.apache.cxf.message.Message;
import org.apache.cxf.message.MessageContentsList;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

public class CommBrokerInfoInterceptorTest {

    @Mock
    private LogEventSender logEventSender;


    private Exchange excchange;

    @Mock
    private Message message;

    @Mock
    private MessageContentsList messageContentsList;

    private CommBrokerInfoInterceptor commBrokerInfoInterceptor;


    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        this.excchange = new ExchangeImpl();
        Mockito.when(this.message.getExchange()).thenReturn(this.excchange);
        commBrokerInfoInterceptor = new CommBrokerInfoInterceptor( this.logEventSender);

    }


    @Test
    public void failuresDoesNotThrowError() {
        commBrokerInfoInterceptor.handleMessage(message);
        //no errors thould be thrown.
    }


        @Test
    public void testSuccessfulMessageIdCreation() {
        StampDutyVerificationRequestType stampDutyVerificationRequestType = Mockito.mock(StampDutyVerificationRequestType.class);
        MessageHeaderType messageHeaderType = Mockito.mock(MessageHeaderType.class);

        String elnoCaseId = "elnoCaseId";
        String elnoMessageId = "elnoMessageId";

        Mockito.when(stampDutyVerificationRequestType.getMessageHeader()).thenReturn(messageHeaderType);
        Mockito.when(messageHeaderType.getMessageId()).thenReturn(elnoMessageId);
        Mockito.when(stampDutyVerificationRequestType.getElnLodgementCaseId()).thenReturn(elnoCaseId);


        Mockito.when(MessageContentsList.getContentsList(message)).thenReturn(messageContentsList);
        Mockito.when(messageContentsList.get(0)).thenReturn(stampDutyVerificationRequestType);


        commBrokerInfoInterceptor.handleMessage(message);

        String exchahngeId = (String) this.excchange.get(CommBrokerInfoInterceptor.EXCHANGE_ID);
        String[] parts = exchahngeId.split(":");
        Assert.assertEquals("elnoCaseId", parts[1]);
        Assert.assertEquals("elnoMessageId", parts[2]);
    }

}
