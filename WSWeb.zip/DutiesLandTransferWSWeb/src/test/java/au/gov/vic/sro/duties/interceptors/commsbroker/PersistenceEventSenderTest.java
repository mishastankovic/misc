package au.gov.vic.sro.duties.interceptors.commsbroker;

import au.gov.vic.sro.communication.model.Communication;
import au.gov.vic.sro.communication.service.CommunicationService;
import au.gov.vic.sro.communication.service.CommunicationServiceImpl;
import org.apache.commons.lang3.builder.ToStringExclude;
import org.apache.cxf.ext.logging.event.LogEvent;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.util.ReflectionTestUtils;
import sun.reflect.Reflection;

public class PersistenceEventSenderTest {



    @Mock
    CommunicationService communicationService;

    @InjectMocks
    private PersistenceEventSender persistenceEventSender;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(persistenceEventSender, "commsBrokerEventMapper",new CommsBrokerEventMapper() );
    }

    @Test
    public void shouldMapAndSaveEvent() {
        ArgumentCaptor<Communication> argument = ArgumentCaptor.forClass(Communication.class);
        LogEvent logEvent = new LogEvent();
        logEvent.setPayload("payload");

        persistenceEventSender.send(logEvent);
        Mockito.verify(communicationService, Mockito.times(1)).logCommunication(argument.capture());

        Communication communication = argument.getValue();
        //full verification of mapping is tested in CommsBrokerEventMapperTest class.
        Assert.assertEquals(logEvent.getPayload(), communication.getCommunicationContents().get(0).getCommunicationClobContent());
    }


    @Test
    public void shouldNotThrowExceptionWhenSavingThrowsException() {
        ArgumentCaptor<Communication> argument = ArgumentCaptor.forClass(Communication.class);
        Mockito.doThrow(new RuntimeException()).when(communicationService).logCommunication(argument.capture());
        persistenceEventSender.send(new LogEvent());
    }



}
