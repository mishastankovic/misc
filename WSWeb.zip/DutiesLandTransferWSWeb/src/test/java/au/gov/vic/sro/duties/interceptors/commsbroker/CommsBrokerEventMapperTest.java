package au.gov.vic.sro.duties.interceptors.commsbroker;

import au.gov.vic.sro.communication.model.Communication;
import au.gov.vic.sro.communication.model.CommunicationContent;
import org.apache.cxf.ext.logging.event.EventType;
import org.apache.cxf.ext.logging.event.LogEvent;
import org.junit.Assert;
import org.junit.Test;

public class CommsBrokerEventMapperTest {

    @Test
    public void mapRequestEvent() {

        CommsBrokerEventMapper commsBrokerEventMapper = new CommsBrokerEventMapper();
        LogEvent event = createLogEvent();
        Communication communication = commsBrokerEventMapper.createCommunication(event);

        Assert.assertEquals("bb",  communication.getPrimaryCommunicationIdentifier());
        Assert.assertEquals("aa",  communication.getSecondaryCommunicationIdentifier());
        Assert.assertEquals("elno",  communication.getSource());
        Assert.assertEquals("e-Business",  communication.getDestination());
        Assert.assertEquals("ELNO_VERFICATION_REQUEST",  communication.getCommunicationType());

        CommunicationContent content = communication.getCommunicationContents().get(0);
        Assert.assertEquals("payload", content.getCommunicationClobContent());
        Assert.assertEquals("ELNO_VERFICATION_REQUEST",  content.getCommunicationContentType());
    }

    @Test
    public void mapResponseEvent() {

        CommsBrokerEventMapper commsBrokerEventMapper = new CommsBrokerEventMapper();
        LogEvent event = createLogEvent();
        event.setType(EventType.RESP_OUT);
        Communication communication = commsBrokerEventMapper.createCommunication(event);

        Assert.assertEquals("ELNO_VERFICATION_RESPONSE",  communication.getCommunicationType());
        CommunicationContent content = communication.getCommunicationContents().get(0);
        Assert.assertEquals("ELNO_VERFICATION_RESPONSE",  content.getCommunicationContentType());
    }


    private LogEvent createLogEvent() {
        LogEvent logEvent = new LogEvent();
        logEvent.setExchangeId("aa:bb:cc:dd");
        logEvent.setType(EventType.REQ_IN);
        logEvent.setPayload("payload");
        return logEvent;
    }

}
