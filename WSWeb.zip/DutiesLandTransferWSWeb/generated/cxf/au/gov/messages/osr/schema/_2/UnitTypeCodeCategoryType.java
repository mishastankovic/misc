
package au.gov.messages.osr.schema._2;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for unitTypeCodeCategoryType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="unitTypeCodeCategoryType"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;maxLength value="7"/&gt;
 *     &lt;enumeration value="ANT"/&gt;
 *     &lt;enumeration value="APT"/&gt;
 *     &lt;enumeration value="AT"/&gt;
 *     &lt;enumeration value="ATM"/&gt;
 *     &lt;enumeration value="BBQ"/&gt;
 *     &lt;enumeration value="BTSD"/&gt;
 *     &lt;enumeration value="BLDG"/&gt;
 *     &lt;enumeration value="BNGW"/&gt;
 *     &lt;enumeration value="CAGE"/&gt;
 *     &lt;enumeration value="CARP"/&gt;
 *     &lt;enumeration value="CARS"/&gt;
 *     &lt;enumeration value="CLUB"/&gt;
 *     &lt;enumeration value="CO"/&gt;
 *     &lt;enumeration value="COOL"/&gt;
 *     &lt;enumeration value="CTGE"/&gt;
 *     &lt;enumeration value="DUPL"/&gt;
 *     &lt;enumeration value="FCTY"/&gt;
 *     &lt;enumeration value="FLAT"/&gt;
 *     &lt;enumeration value="GRGE"/&gt;
 *     &lt;enumeration value="HALL"/&gt;
 *     &lt;enumeration value="HSE"/&gt;
 *     &lt;enumeration value="KSK"/&gt;
 *     &lt;enumeration value="LSE"/&gt;
 *     &lt;enumeration value="LBBY"/&gt;
 *     &lt;enumeration value="LOFT"/&gt;
 *     &lt;enumeration value="LOT"/&gt;
 *     &lt;enumeration value="MSNT"/&gt;
 *     &lt;enumeration value="MBTH"/&gt;
 *     &lt;enumeration value="OFFC"/&gt;
 *     &lt;enumeration value="PTHS"/&gt;
 *     &lt;enumeration value="RESV"/&gt;
 *     &lt;enumeration value="ROOM"/&gt;
 *     &lt;enumeration value="SHED"/&gt;
 *     &lt;enumeration value="SHOP"/&gt;
 *     &lt;enumeration value="SHRM"/&gt;
 *     &lt;enumeration value="SIGN"/&gt;
 *     &lt;enumeration value="SITE"/&gt;
 *     &lt;enumeration value="STLL"/&gt;
 *     &lt;enumeration value="STOR"/&gt;
 *     &lt;enumeration value="STR"/&gt;
 *     &lt;enumeration value="STU"/&gt;
 *     &lt;enumeration value="SUBS"/&gt;
 *     &lt;enumeration value="SE"/&gt;
 *     &lt;enumeration value="TNCY"/&gt;
 *     &lt;enumeration value="TWR"/&gt;
 *     &lt;enumeration value="TNHS"/&gt;
 *     &lt;enumeration value="UNIT"/&gt;
 *     &lt;enumeration value="VLT"/&gt;
 *     &lt;enumeration value="VLLA"/&gt;
 *     &lt;enumeration value="WARD"/&gt;
 *     &lt;enumeration value="WHSE"/&gt;
 *     &lt;enumeration value="WKSH"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "unitTypeCodeCategoryType")
@XmlEnum
public enum UnitTypeCodeCategoryType {


    /**
     * Antenna [AS4590-2006]
     * 
     */
    ANT,

    /**
     * Apartment [AS4590-2006]
     * 
     */
    APT,

    /**
     * Automatic Teller [Vic Augmentation]
     * 
     */
    AT,

    /**
     * Automated Teller Machine [AS4590-2006]
     * 
     */
    ATM,

    /**
     * Barbecue [AS4590-2006]
     * 
     */
    BBQ,

    /**
     * Boatshed [AS4590-2006]
     * 
     */
    BTSD,

    /**
     * Building [AS4590-2006]
     * 
     */
    BLDG,

    /**
     * Bungalow [AS4590-2006]
     * 
     */
    BNGW,

    /**
     * Cage [AS4590-2006]
     * 
     */
    CAGE,

    /**
     * Carpark [AS4590-2006]
     * 
     */
    CARP,

    /**
     * Carspace [AS4590-2006]
     * 
     */
    CARS,

    /**
     * Club [AS4590-2006]
     * 
     */
    CLUB,

    /**
     * Condominium [Vic Augmentation]
     * 
     */
    CO,

    /**
     * Coolroom [AS4590-2006]
     * 
     */
    COOL,

    /**
     * Cottage [AS4590-2006]
     * 
     */
    CTGE,

    /**
     * Duplex [AS4590-2006]
     * 
     */
    DUPL,

    /**
     * Factory [AS4590-2006]
     * 
     */
    FCTY,

    /**
     * Flat [AS4590-2006]
     * 
     */
    FLAT,

    /**
     * Garage [AS4590-2006]
     * 
     */
    GRGE,

    /**
     * Hall [AS4590-2006]
     * 
     */
    HALL,

    /**
     * House [AS4590-2006]
     * 
     */
    HSE,

    /**
     * Kiosk [AS4590-2006]
     * 
     */
    KSK,

    /**
     * Lease [AS4590-2006]
     * 
     */
    LSE,

    /**
     * Lobby [AS4590-2006]
     * 
     */
    LBBY,

    /**
     * Loft [AS4590-2006]
     * 
     */
    LOFT,

    /**
     * Lot [AS4590-2006]
     * 
     */
    LOT,

    /**
     * Maisonette [AS4590-2006]
     * 
     */
    MSNT,

    /**
     * Marine Berth [AS4590-2006]
     * 
     */
    MBTH,

    /**
     * Office [AS4590-2006]
     * 
     */
    OFFC,

    /**
     * Penthouse [Vic Augmentation]
     * 
     */
    PTHS,

    /**
     * Reserve [AS4590-2006]
     * 
     */
    RESV,

    /**
     * Room [AS4590-2006]
     * 
     */
    ROOM,

    /**
     * Shed [AS4590-2006]
     * 
     */
    SHED,

    /**
     * Shop [AS4590-2006]
     * 
     */
    SHOP,

    /**
     * Showroom [AS4590-2006]
     * 
     */
    SHRM,

    /**
     * Sign [AS4590-2006]
     * 
     */
    SIGN,

    /**
     * Site [AS4590-2006]
     * 
     */
    SITE,

    /**
     * Stall [AS4590-2006]
     * 
     */
    STLL,

    /**
     * Store [AS4590-2006]
     * 
     */
    STOR,

    /**
     * Strata unit [AS4590-2006]
     * 
     */
    STR,

    /**
     * Studio / Studio Apartment [AS4590-2006]
     * 
     */
    STU,

    /**
     * Substation [AS4590-2006]
     * 
     */
    SUBS,

    /**
     * Suite [AS4590-2006]
     * 
     */
    SE,

    /**
     * Tenancy [AS4590-2006]
     * 
     */
    TNCY,

    /**
     * Tower [AS4590-2006]
     * 
     */
    TWR,

    /**
     * Townhouse [AS4590-2006]
     * 
     */
    TNHS,

    /**
     * Unit [AS4590-2006]
     * 
     */
    UNIT,

    /**
     * Vault [AS4590-2006]
     * 
     */
    VLT,

    /**
     * Villa [AS4590-2006]
     * 
     */
    VLLA,

    /**
     * Ward [AS4590-2006]
     * 
     */
    WARD,

    /**
     * Warehouse [AS4590-2006]
     * 
     */
    WHSE,

    /**
     * Workshop [AS4590-2006]
     * 
     */
    WKSH;

    public String value() {
        return name();
    }

    public static UnitTypeCodeCategoryType fromValue(String v) {
        return valueOf(v);
    }

}
