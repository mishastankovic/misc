
package au.gov.messages.osr.schema._2;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for documentDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="documentDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="DocumentId" type="{http://osr.messages.gov.au/schema/2.4/}identifierType"/&gt;
 *         &lt;element name="DocumentUnsigned" type="{http://osr.messages.gov.au/schema/2.4/}yesNoType" minOccurs="0"/&gt;
 *         &lt;element name="SubjectLandTitle" maxOccurs="unbounded"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="LandTitleReference" type="{http://osr.messages.gov.au/schema/2.4/}landTitleReferenceType"/&gt;
 *                   &lt;element name="StreetAddress" type="{http://osr.messages.gov.au/schema/2.4/}streetAddressType" minOccurs="0"/&gt;
 *                   &lt;element name="LandDescription" type="{http://osr.messages.gov.au/schema/2.4/}landDescriptionType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *                   &lt;element name="EstateType" type="{http://osr.messages.gov.au/schema/2.4/}estateTypeCategoryType"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Consideration" type="{http://osr.messages.gov.au/schema/2.4/}considerationType" maxOccurs="2" minOccurs="0"/&gt;
 *         &lt;element name="PartyReceivingDetail" maxOccurs="unbounded"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="Tenancy" type="{http://osr.messages.gov.au/schema/2.4/}tenancyDetailType"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="PartyRelinquishingDetail" maxOccurs="unbounded"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="Tenancy" type="{http://osr.messages.gov.au/schema/2.4/}tenancyDetailType"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TransactionInformation" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="Agreement" type="{http://osr.messages.gov.au/schema/2.4/}yesNoType"/&gt;
 *                   &lt;element name="PartiesRelated" type="{http://osr.messages.gov.au/schema/2.4/}yesNoType"/&gt;
 *                   &lt;element name="ConsiderationLess" type="{http://osr.messages.gov.au/schema/2.4/}yesNoType"/&gt;
 *                   &lt;element name="OtherDutiable" type="{http://osr.messages.gov.au/schema/2.4/}yesNoType"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "documentDataType", propOrder = {
    "documentId",
    "documentUnsigned",
    "subjectLandTitle",
    "consideration",
    "partyReceivingDetail",
    "partyRelinquishingDetail",
    "transactionInformation"
})
public class DocumentDataType {

    @XmlElement(name = "DocumentId", required = true)
    protected String documentId;
    @XmlElement(name = "DocumentUnsigned")
    protected String documentUnsigned;
    @XmlElement(name = "SubjectLandTitle", required = true)
    protected List<DocumentDataType.SubjectLandTitle> subjectLandTitle;
    @XmlElement(name = "Consideration")
    protected List<ConsiderationType> consideration;
    @XmlElement(name = "PartyReceivingDetail", required = true)
    protected List<DocumentDataType.PartyReceivingDetail> partyReceivingDetail;
    @XmlElement(name = "PartyRelinquishingDetail", required = true)
    protected List<DocumentDataType.PartyRelinquishingDetail> partyRelinquishingDetail;
    @XmlElement(name = "TransactionInformation")
    protected DocumentDataType.TransactionInformation transactionInformation;

    /**
     * Gets the value of the documentId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDocumentId() {
        return documentId;
    }

    /**
     * Sets the value of the documentId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDocumentId(String value) {
        this.documentId = value;
    }

    /**
     * Gets the value of the documentUnsigned property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDocumentUnsigned() {
        return documentUnsigned;
    }

    /**
     * Sets the value of the documentUnsigned property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDocumentUnsigned(String value) {
        this.documentUnsigned = value;
    }

    /**
     * Gets the value of the subjectLandTitle property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the subjectLandTitle property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSubjectLandTitle().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DocumentDataType.SubjectLandTitle }
     * 
     * 
     */
    public List<DocumentDataType.SubjectLandTitle> getSubjectLandTitle() {
        if (subjectLandTitle == null) {
            subjectLandTitle = new ArrayList<DocumentDataType.SubjectLandTitle>();
        }
        return this.subjectLandTitle;
    }

    /**
     * Gets the value of the consideration property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the consideration property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getConsideration().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ConsiderationType }
     * 
     * 
     */
    public List<ConsiderationType> getConsideration() {
        if (consideration == null) {
            consideration = new ArrayList<ConsiderationType>();
        }
        return this.consideration;
    }

    /**
     * Gets the value of the partyReceivingDetail property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the partyReceivingDetail property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPartyReceivingDetail().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DocumentDataType.PartyReceivingDetail }
     * 
     * 
     */
    public List<DocumentDataType.PartyReceivingDetail> getPartyReceivingDetail() {
        if (partyReceivingDetail == null) {
            partyReceivingDetail = new ArrayList<DocumentDataType.PartyReceivingDetail>();
        }
        return this.partyReceivingDetail;
    }

    /**
     * Gets the value of the partyRelinquishingDetail property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the partyRelinquishingDetail property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPartyRelinquishingDetail().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DocumentDataType.PartyRelinquishingDetail }
     * 
     * 
     */
    public List<DocumentDataType.PartyRelinquishingDetail> getPartyRelinquishingDetail() {
        if (partyRelinquishingDetail == null) {
            partyRelinquishingDetail = new ArrayList<DocumentDataType.PartyRelinquishingDetail>();
        }
        return this.partyRelinquishingDetail;
    }

    /**
     * Gets the value of the transactionInformation property.
     * 
     * @return
     *     possible object is
     *     {@link DocumentDataType.TransactionInformation }
     *     
     */
    public DocumentDataType.TransactionInformation getTransactionInformation() {
        return transactionInformation;
    }

    /**
     * Sets the value of the transactionInformation property.
     * 
     * @param value
     *     allowed object is
     *     {@link DocumentDataType.TransactionInformation }
     *     
     */
    public void setTransactionInformation(DocumentDataType.TransactionInformation value) {
        this.transactionInformation = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="Tenancy" type="{http://osr.messages.gov.au/schema/2.4/}tenancyDetailType"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "tenancy"
    })
    public static class PartyReceivingDetail {

        @XmlElement(name = "Tenancy", required = true)
        protected TenancyDetailType tenancy;

        /**
         * Gets the value of the tenancy property.
         * 
         * @return
         *     possible object is
         *     {@link TenancyDetailType }
         *     
         */
        public TenancyDetailType getTenancy() {
            return tenancy;
        }

        /**
         * Sets the value of the tenancy property.
         * 
         * @param value
         *     allowed object is
         *     {@link TenancyDetailType }
         *     
         */
        public void setTenancy(TenancyDetailType value) {
            this.tenancy = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="Tenancy" type="{http://osr.messages.gov.au/schema/2.4/}tenancyDetailType"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "tenancy"
    })
    public static class PartyRelinquishingDetail {

        @XmlElement(name = "Tenancy", required = true)
        protected TenancyDetailType tenancy;

        /**
         * Gets the value of the tenancy property.
         * 
         * @return
         *     possible object is
         *     {@link TenancyDetailType }
         *     
         */
        public TenancyDetailType getTenancy() {
            return tenancy;
        }

        /**
         * Sets the value of the tenancy property.
         * 
         * @param value
         *     allowed object is
         *     {@link TenancyDetailType }
         *     
         */
        public void setTenancy(TenancyDetailType value) {
            this.tenancy = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="LandTitleReference" type="{http://osr.messages.gov.au/schema/2.4/}landTitleReferenceType"/&gt;
     *         &lt;element name="StreetAddress" type="{http://osr.messages.gov.au/schema/2.4/}streetAddressType" minOccurs="0"/&gt;
     *         &lt;element name="LandDescription" type="{http://osr.messages.gov.au/schema/2.4/}landDescriptionType" maxOccurs="unbounded" minOccurs="0"/&gt;
     *         &lt;element name="EstateType" type="{http://osr.messages.gov.au/schema/2.4/}estateTypeCategoryType"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "landTitleReference",
        "streetAddress",
        "landDescription",
        "estateType"
    })
    public static class SubjectLandTitle {

        @XmlElement(name = "LandTitleReference", required = true)
        protected LandTitleReferenceType landTitleReference;
        @XmlElement(name = "StreetAddress")
        protected StreetAddressType streetAddress;
        @XmlElement(name = "LandDescription")
        protected List<LandDescriptionType> landDescription;
        @XmlElement(name = "EstateType", required = true)
        protected String estateType;

        /**
         * Gets the value of the landTitleReference property.
         * 
         * @return
         *     possible object is
         *     {@link LandTitleReferenceType }
         *     
         */
        public LandTitleReferenceType getLandTitleReference() {
            return landTitleReference;
        }

        /**
         * Sets the value of the landTitleReference property.
         * 
         * @param value
         *     allowed object is
         *     {@link LandTitleReferenceType }
         *     
         */
        public void setLandTitleReference(LandTitleReferenceType value) {
            this.landTitleReference = value;
        }

        /**
         * Gets the value of the streetAddress property.
         * 
         * @return
         *     possible object is
         *     {@link StreetAddressType }
         *     
         */
        public StreetAddressType getStreetAddress() {
            return streetAddress;
        }

        /**
         * Sets the value of the streetAddress property.
         * 
         * @param value
         *     allowed object is
         *     {@link StreetAddressType }
         *     
         */
        public void setStreetAddress(StreetAddressType value) {
            this.streetAddress = value;
        }

        /**
         * Gets the value of the landDescription property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the landDescription property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getLandDescription().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link LandDescriptionType }
         * 
         * 
         */
        public List<LandDescriptionType> getLandDescription() {
            if (landDescription == null) {
                landDescription = new ArrayList<LandDescriptionType>();
            }
            return this.landDescription;
        }

        /**
         * Gets the value of the estateType property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getEstateType() {
            return estateType;
        }

        /**
         * Sets the value of the estateType property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setEstateType(String value) {
            this.estateType = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="Agreement" type="{http://osr.messages.gov.au/schema/2.4/}yesNoType"/&gt;
     *         &lt;element name="PartiesRelated" type="{http://osr.messages.gov.au/schema/2.4/}yesNoType"/&gt;
     *         &lt;element name="ConsiderationLess" type="{http://osr.messages.gov.au/schema/2.4/}yesNoType"/&gt;
     *         &lt;element name="OtherDutiable" type="{http://osr.messages.gov.au/schema/2.4/}yesNoType"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "agreement",
        "partiesRelated",
        "considerationLess",
        "otherDutiable"
    })
    public static class TransactionInformation {

        @XmlElement(name = "Agreement", required = true)
        protected String agreement;
        @XmlElement(name = "PartiesRelated", required = true)
        protected String partiesRelated;
        @XmlElement(name = "ConsiderationLess", required = true)
        protected String considerationLess;
        @XmlElement(name = "OtherDutiable", required = true)
        protected String otherDutiable;

        /**
         * Gets the value of the agreement property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getAgreement() {
            return agreement;
        }

        /**
         * Sets the value of the agreement property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setAgreement(String value) {
            this.agreement = value;
        }

        /**
         * Gets the value of the partiesRelated property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getPartiesRelated() {
            return partiesRelated;
        }

        /**
         * Sets the value of the partiesRelated property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setPartiesRelated(String value) {
            this.partiesRelated = value;
        }

        /**
         * Gets the value of the considerationLess property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getConsiderationLess() {
            return considerationLess;
        }

        /**
         * Sets the value of the considerationLess property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setConsiderationLess(String value) {
            this.considerationLess = value;
        }

        /**
         * Gets the value of the otherDutiable property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getOtherDutiable() {
            return otherDutiable;
        }

        /**
         * Sets the value of the otherDutiable property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setOtherDutiable(String value) {
            this.otherDutiable = value;
        }

    }

}
