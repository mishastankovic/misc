
package au.gov.messages.osr.schema._2;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for subscriberDetailsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="subscriberDetailsType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="SubscriberId" type="{http://osr.messages.gov.au/schema/2.4/}identifierType"/&gt;
 *         &lt;element name="Subscriber" type="{http://osr.messages.gov.au/schema/2.4/}partyFullNameType"/&gt;
 *         &lt;element name="RevenueOfficeClientId" type="{http://osr.messages.gov.au/schema/2.4/}identifierType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "subscriberDetailsType", propOrder = {
    "subscriberId",
    "subscriber",
    "revenueOfficeClientId"
})
public class SubscriberDetailsType {

    @XmlElement(name = "SubscriberId", required = true)
    protected String subscriberId;
    @XmlElement(name = "Subscriber", required = true)
    protected PartyFullNameType subscriber;
    @XmlElement(name = "RevenueOfficeClientId")
    protected String revenueOfficeClientId;

    /**
     * Gets the value of the subscriberId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubscriberId() {
        return subscriberId;
    }

    /**
     * Sets the value of the subscriberId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubscriberId(String value) {
        this.subscriberId = value;
    }

    /**
     * Gets the value of the subscriber property.
     * 
     * @return
     *     possible object is
     *     {@link PartyFullNameType }
     *     
     */
    public PartyFullNameType getSubscriber() {
        return subscriber;
    }

    /**
     * Sets the value of the subscriber property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyFullNameType }
     *     
     */
    public void setSubscriber(PartyFullNameType value) {
        this.subscriber = value;
    }

    /**
     * Gets the value of the revenueOfficeClientId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRevenueOfficeClientId() {
        return revenueOfficeClientId;
    }

    /**
     * Sets the value of the revenueOfficeClientId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRevenueOfficeClientId(String value) {
        this.revenueOfficeClientId = value;
    }

}
