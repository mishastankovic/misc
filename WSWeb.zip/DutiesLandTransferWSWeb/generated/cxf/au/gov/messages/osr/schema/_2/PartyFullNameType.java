
package au.gov.messages.osr.schema._2;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;


/**
 * <p>Java class for partyFullNameType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="partyFullNameType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PartyType" type="{http://osr.messages.gov.au/schema/2.4/}partyTypeCategoryType" minOccurs="0"/&gt;
 *         &lt;element name="LegalEntityName" type="{http://osr.messages.gov.au/schema/2.4/}textType"/&gt;
 *         &lt;element name="PersonFullName" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="NameTitle" type="{http://osr.messages.gov.au/schema/2.4/}nameTitleCategoryType" minOccurs="0"/&gt;
 *                   &lt;element name="GivenName" maxOccurs="unbounded"&gt;
 *                     &lt;complexType&gt;
 *                       &lt;simpleContent&gt;
 *                         &lt;extension base="&lt;http://osr.messages.gov.au/schema/2.4/&gt;textType"&gt;
 *                           &lt;attribute name="order" type="{http://osr.messages.gov.au/schema/2.4/}ordinalType" /&gt;
 *                         &lt;/extension&gt;
 *                       &lt;/simpleContent&gt;
 *                     &lt;/complexType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="FamilyName" type="{http://osr.messages.gov.au/schema/2.4/}textType" minOccurs="0"/&gt;
 *                   &lt;element name="FamilyNameOrder" type="{http://osr.messages.gov.au/schema/2.4/}familyNameOrderCategoryType" minOccurs="0"/&gt;
 *                   &lt;element name="NameSuffix" type="{http://osr.messages.gov.au/schema/2.4/}textType" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="BusinessName" type="{http://osr.messages.gov.au/schema/2.4/}textType" minOccurs="0"/&gt;
 *         &lt;element name="BusinessUnit" type="{http://osr.messages.gov.au/schema/2.4/}textType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "partyFullNameType", propOrder = {
    "partyType",
    "legalEntityName",
    "personFullName",
    "businessName",
    "businessUnit"
})
public class PartyFullNameType {

    @XmlElement(name = "PartyType")
    @XmlSchemaType(name = "string")
    protected PartyTypeCategoryType partyType;
    @XmlElement(name = "LegalEntityName", required = true)
    protected String legalEntityName;
    @XmlElement(name = "PersonFullName")
    protected PartyFullNameType.PersonFullName personFullName;
    @XmlElement(name = "BusinessName")
    protected String businessName;
    @XmlElement(name = "BusinessUnit")
    protected String businessUnit;

    /**
     * Gets the value of the partyType property.
     * 
     * @return
     *     possible object is
     *     {@link PartyTypeCategoryType }
     *     
     */
    public PartyTypeCategoryType getPartyType() {
        return partyType;
    }

    /**
     * Sets the value of the partyType property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyTypeCategoryType }
     *     
     */
    public void setPartyType(PartyTypeCategoryType value) {
        this.partyType = value;
    }

    /**
     * Gets the value of the legalEntityName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLegalEntityName() {
        return legalEntityName;
    }

    /**
     * Sets the value of the legalEntityName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLegalEntityName(String value) {
        this.legalEntityName = value;
    }

    /**
     * Gets the value of the personFullName property.
     * 
     * @return
     *     possible object is
     *     {@link PartyFullNameType.PersonFullName }
     *     
     */
    public PartyFullNameType.PersonFullName getPersonFullName() {
        return personFullName;
    }

    /**
     * Sets the value of the personFullName property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyFullNameType.PersonFullName }
     *     
     */
    public void setPersonFullName(PartyFullNameType.PersonFullName value) {
        this.personFullName = value;
    }

    /**
     * Gets the value of the businessName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBusinessName() {
        return businessName;
    }

    /**
     * Sets the value of the businessName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBusinessName(String value) {
        this.businessName = value;
    }

    /**
     * Gets the value of the businessUnit property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBusinessUnit() {
        return businessUnit;
    }

    /**
     * Sets the value of the businessUnit property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBusinessUnit(String value) {
        this.businessUnit = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="NameTitle" type="{http://osr.messages.gov.au/schema/2.4/}nameTitleCategoryType" minOccurs="0"/&gt;
     *         &lt;element name="GivenName" maxOccurs="unbounded"&gt;
     *           &lt;complexType&gt;
     *             &lt;simpleContent&gt;
     *               &lt;extension base="&lt;http://osr.messages.gov.au/schema/2.4/&gt;textType"&gt;
     *                 &lt;attribute name="order" type="{http://osr.messages.gov.au/schema/2.4/}ordinalType" /&gt;
     *               &lt;/extension&gt;
     *             &lt;/simpleContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="FamilyName" type="{http://osr.messages.gov.au/schema/2.4/}textType" minOccurs="0"/&gt;
     *         &lt;element name="FamilyNameOrder" type="{http://osr.messages.gov.au/schema/2.4/}familyNameOrderCategoryType" minOccurs="0"/&gt;
     *         &lt;element name="NameSuffix" type="{http://osr.messages.gov.au/schema/2.4/}textType" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "nameTitle",
        "givenName",
        "familyName",
        "familyNameOrder",
        "nameSuffix"
    })
    public static class PersonFullName {

        @XmlElement(name = "NameTitle")
        protected String nameTitle;
        @XmlElement(name = "GivenName", required = true)
        protected List<PartyFullNameType.PersonFullName.GivenName> givenName;
        @XmlElement(name = "FamilyName")
        protected String familyName;
        @XmlElement(name = "FamilyNameOrder")
        @XmlSchemaType(name = "string")
        protected FamilyNameOrderCategoryType familyNameOrder;
        @XmlElement(name = "NameSuffix")
        protected String nameSuffix;

        /**
         * Gets the value of the nameTitle property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getNameTitle() {
            return nameTitle;
        }

        /**
         * Sets the value of the nameTitle property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setNameTitle(String value) {
            this.nameTitle = value;
        }

        /**
         * Gets the value of the givenName property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the givenName property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getGivenName().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link PartyFullNameType.PersonFullName.GivenName }
         * 
         * 
         */
        public List<PartyFullNameType.PersonFullName.GivenName> getGivenName() {
            if (givenName == null) {
                givenName = new ArrayList<PartyFullNameType.PersonFullName.GivenName>();
            }
            return this.givenName;
        }

        /**
         * Gets the value of the familyName property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getFamilyName() {
            return familyName;
        }

        /**
         * Sets the value of the familyName property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setFamilyName(String value) {
            this.familyName = value;
        }

        /**
         * Gets the value of the familyNameOrder property.
         * 
         * @return
         *     possible object is
         *     {@link FamilyNameOrderCategoryType }
         *     
         */
        public FamilyNameOrderCategoryType getFamilyNameOrder() {
            return familyNameOrder;
        }

        /**
         * Sets the value of the familyNameOrder property.
         * 
         * @param value
         *     allowed object is
         *     {@link FamilyNameOrderCategoryType }
         *     
         */
        public void setFamilyNameOrder(FamilyNameOrderCategoryType value) {
            this.familyNameOrder = value;
        }

        /**
         * Gets the value of the nameSuffix property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getNameSuffix() {
            return nameSuffix;
        }

        /**
         * Sets the value of the nameSuffix property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setNameSuffix(String value) {
            this.nameSuffix = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;simpleContent&gt;
         *     &lt;extension base="&lt;http://osr.messages.gov.au/schema/2.4/&gt;textType"&gt;
         *       &lt;attribute name="order" type="{http://osr.messages.gov.au/schema/2.4/}ordinalType" /&gt;
         *     &lt;/extension&gt;
         *   &lt;/simpleContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "value"
        })
        public static class GivenName {

            @XmlValue
            protected String value;
            @XmlAttribute(name = "order")
            protected BigInteger order;

            /**
             * Gets the value of the value property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getValue() {
                return value;
            }

            /**
             * Sets the value of the value property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setValue(String value) {
                this.value = value;
            }

            /**
             * Gets the value of the order property.
             * 
             * @return
             *     possible object is
             *     {@link BigInteger }
             *     
             */
            public BigInteger getOrder() {
                return order;
            }

            /**
             * Sets the value of the order property.
             * 
             * @param value
             *     allowed object is
             *     {@link BigInteger }
             *     
             */
            public void setOrder(BigInteger value) {
                this.order = value;
            }

        }

    }

}
