
package au.gov.messages.osr.schema._2;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the au.gov.messages.osr.schema._2 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: au.gov.messages.osr.schema._2
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link PartyFullNameType }
     * 
     */
    public PartyFullNameType createPartyFullNameType() {
        return new PartyFullNameType();
    }

    /**
     * Create an instance of {@link PartyFullNameType.PersonFullName }
     * 
     */
    public PartyFullNameType.PersonFullName createPartyFullNameTypePersonFullName() {
        return new PartyFullNameType.PersonFullName();
    }

    /**
     * Create an instance of {@link TenancyDetailType }
     * 
     */
    public TenancyDetailType createTenancyDetailType() {
        return new TenancyDetailType();
    }

    /**
     * Create an instance of {@link TenancyDetailType.TenancyGroup }
     * 
     */
    public TenancyDetailType.TenancyGroup createTenancyDetailTypeTenancyGroup() {
        return new TenancyDetailType.TenancyGroup();
    }

    /**
     * Create an instance of {@link MessageHeaderType }
     * 
     */
    public MessageHeaderType createMessageHeaderType() {
        return new MessageHeaderType();
    }

    /**
     * Create an instance of {@link LandTitleReferenceType }
     * 
     */
    public LandTitleReferenceType createLandTitleReferenceType() {
        return new LandTitleReferenceType();
    }

    /**
     * Create an instance of {@link OverseasAddressType }
     * 
     */
    public OverseasAddressType createOverseasAddressType() {
        return new OverseasAddressType();
    }

    /**
     * Create an instance of {@link PostalDeliveryServiceAddressType }
     * 
     */
    public PostalDeliveryServiceAddressType createPostalDeliveryServiceAddressType() {
        return new PostalDeliveryServiceAddressType();
    }

    /**
     * Create an instance of {@link PostalDeliveryServiceAddressType.StructuredAddress }
     * 
     */
    public PostalDeliveryServiceAddressType.StructuredAddress createPostalDeliveryServiceAddressTypeStructuredAddress() {
        return new PostalDeliveryServiceAddressType.StructuredAddress();
    }

    /**
     * Create an instance of {@link PostalDeliveryServiceAddressType.StructuredAddress.Road }
     * 
     */
    public PostalDeliveryServiceAddressType.StructuredAddress.Road createPostalDeliveryServiceAddressTypeStructuredAddressRoad() {
        return new PostalDeliveryServiceAddressType.StructuredAddress.Road();
    }

    /**
     * Create an instance of {@link PostalDeliveryServiceAddressType.StructuredAddress.ComplexRoad }
     * 
     */
    public PostalDeliveryServiceAddressType.StructuredAddress.ComplexRoad createPostalDeliveryServiceAddressTypeStructuredAddressComplexRoad() {
        return new PostalDeliveryServiceAddressType.StructuredAddress.ComplexRoad();
    }

    /**
     * Create an instance of {@link PostalDeliveryServiceAddressType.UnstructuredAddress }
     * 
     */
    public PostalDeliveryServiceAddressType.UnstructuredAddress createPostalDeliveryServiceAddressTypeUnstructuredAddress() {
        return new PostalDeliveryServiceAddressType.UnstructuredAddress();
    }

    /**
     * Create an instance of {@link StreetAddressType }
     * 
     */
    public StreetAddressType createStreetAddressType() {
        return new StreetAddressType();
    }

    /**
     * Create an instance of {@link StreetAddressType.StructuredAddress }
     * 
     */
    public StreetAddressType.StructuredAddress createStreetAddressTypeStructuredAddress() {
        return new StreetAddressType.StructuredAddress();
    }

    /**
     * Create an instance of {@link StreetAddressType.StructuredAddress.Road }
     * 
     */
    public StreetAddressType.StructuredAddress.Road createStreetAddressTypeStructuredAddressRoad() {
        return new StreetAddressType.StructuredAddress.Road();
    }

    /**
     * Create an instance of {@link StreetAddressType.StructuredAddress.ComplexRoad }
     * 
     */
    public StreetAddressType.StructuredAddress.ComplexRoad createStreetAddressTypeStructuredAddressComplexRoad() {
        return new StreetAddressType.StructuredAddress.ComplexRoad();
    }

    /**
     * Create an instance of {@link StreetAddressType.UnstructuredAddress }
     * 
     */
    public StreetAddressType.UnstructuredAddress createStreetAddressTypeUnstructuredAddress() {
        return new StreetAddressType.UnstructuredAddress();
    }

    /**
     * Create an instance of {@link DocumentDataType }
     * 
     */
    public DocumentDataType createDocumentDataType() {
        return new DocumentDataType();
    }

    /**
     * Create an instance of {@link PartyDetailType }
     * 
     */
    public PartyDetailType createPartyDetailType() {
        return new PartyDetailType();
    }

    /**
     * Create an instance of {@link PartyDetailType.PersonFullName }
     * 
     */
    public PartyDetailType.PersonFullName createPartyDetailTypePersonFullName() {
        return new PartyDetailType.PersonFullName();
    }

    /**
     * Create an instance of {@link LandDescriptionType }
     * 
     */
    public LandDescriptionType createLandDescriptionType() {
        return new LandDescriptionType();
    }

    /**
     * Create an instance of {@link StampDutyVerificationResponseType }
     * 
     */
    public StampDutyVerificationResponseType createStampDutyVerificationResponseType() {
        return new StampDutyVerificationResponseType();
    }

    /**
     * Create an instance of {@link FractionType }
     * 
     */
    public FractionType createFractionType() {
        return new FractionType();
    }

    /**
     * Create an instance of {@link StampDutyVerificationRequestType }
     * 
     */
    public StampDutyVerificationRequestType createStampDutyVerificationRequestType() {
        return new StampDutyVerificationRequestType();
    }

    /**
     * Create an instance of {@link CounterpartDetailType }
     * 
     */
    public CounterpartDetailType createCounterpartDetailType() {
        return new CounterpartDetailType();
    }

    /**
     * Create an instance of {@link SubscriberDetailsType }
     * 
     */
    public SubscriberDetailsType createSubscriberDetailsType() {
        return new SubscriberDetailsType();
    }

    /**
     * Create an instance of {@link ConsiderationType }
     * 
     */
    public ConsiderationType createConsiderationType() {
        return new ConsiderationType();
    }

    /**
     * Create an instance of {@link DeliveryAddressType }
     * 
     */
    public DeliveryAddressType createDeliveryAddressType() {
        return new DeliveryAddressType();
    }

    /**
     * Create an instance of {@link DxAddressType }
     * 
     */
    public DxAddressType createDxAddressType() {
        return new DxAddressType();
    }

    /**
     * Create an instance of {@link DutyVerificationReportType }
     * 
     */
    public DutyVerificationReportType createDutyVerificationReportType() {
        return new DutyVerificationReportType();
    }

    /**
     * Create an instance of {@link DutyComplianceType }
     * 
     */
    public DutyComplianceType createDutyComplianceType() {
        return new DutyComplianceType();
    }

    /**
     * Create an instance of {@link DisbursementAccountType }
     * 
     */
    public DisbursementAccountType createDisbursementAccountType() {
        return new DisbursementAccountType();
    }

    /**
     * Create an instance of {@link PartyCapacityType }
     * 
     */
    public PartyCapacityType createPartyCapacityType() {
        return new PartyCapacityType();
    }

    /**
     * Create an instance of {@link PartyFullNameType.PersonFullName.GivenName }
     * 
     */
    public PartyFullNameType.PersonFullName.GivenName createPartyFullNameTypePersonFullNameGivenName() {
        return new PartyFullNameType.PersonFullName.GivenName();
    }

    /**
     * Create an instance of {@link TenancyDetailType.TenancyGroup.TenantHolding }
     * 
     */
    public TenancyDetailType.TenancyGroup.TenantHolding createTenancyDetailTypeTenancyGroupTenantHolding() {
        return new TenancyDetailType.TenancyGroup.TenantHolding();
    }

    /**
     * Create an instance of {@link MessageHeaderType.MessageStatus }
     * 
     */
    public MessageHeaderType.MessageStatus createMessageHeaderTypeMessageStatus() {
        return new MessageHeaderType.MessageStatus();
    }

    /**
     * Create an instance of {@link LandTitleReferenceType.Component }
     * 
     */
    public LandTitleReferenceType.Component createLandTitleReferenceTypeComponent() {
        return new LandTitleReferenceType.Component();
    }

    /**
     * Create an instance of {@link OverseasAddressType.AddressLine }
     * 
     */
    public OverseasAddressType.AddressLine createOverseasAddressTypeAddressLine() {
        return new OverseasAddressType.AddressLine();
    }

    /**
     * Create an instance of {@link PostalDeliveryServiceAddressType.StructuredAddress.SubDwellingUnitType }
     * 
     */
    public PostalDeliveryServiceAddressType.StructuredAddress.SubDwellingUnitType createPostalDeliveryServiceAddressTypeStructuredAddressSubDwellingUnitType() {
        return new PostalDeliveryServiceAddressType.StructuredAddress.SubDwellingUnitType();
    }

    /**
     * Create an instance of {@link PostalDeliveryServiceAddressType.StructuredAddress.Level }
     * 
     */
    public PostalDeliveryServiceAddressType.StructuredAddress.Level createPostalDeliveryServiceAddressTypeStructuredAddressLevel() {
        return new PostalDeliveryServiceAddressType.StructuredAddress.Level();
    }

    /**
     * Create an instance of {@link PostalDeliveryServiceAddressType.StructuredAddress.PostalDelivery }
     * 
     */
    public PostalDeliveryServiceAddressType.StructuredAddress.PostalDelivery createPostalDeliveryServiceAddressTypeStructuredAddressPostalDelivery() {
        return new PostalDeliveryServiceAddressType.StructuredAddress.PostalDelivery();
    }

    /**
     * Create an instance of {@link PostalDeliveryServiceAddressType.StructuredAddress.Road.RoadNumber }
     * 
     */
    public PostalDeliveryServiceAddressType.StructuredAddress.Road.RoadNumber createPostalDeliveryServiceAddressTypeStructuredAddressRoadRoadNumber() {
        return new PostalDeliveryServiceAddressType.StructuredAddress.Road.RoadNumber();
    }

    /**
     * Create an instance of {@link PostalDeliveryServiceAddressType.StructuredAddress.ComplexRoad.RoadNumber }
     * 
     */
    public PostalDeliveryServiceAddressType.StructuredAddress.ComplexRoad.RoadNumber createPostalDeliveryServiceAddressTypeStructuredAddressComplexRoadRoadNumber() {
        return new PostalDeliveryServiceAddressType.StructuredAddress.ComplexRoad.RoadNumber();
    }

    /**
     * Create an instance of {@link PostalDeliveryServiceAddressType.UnstructuredAddress.AddressLine }
     * 
     */
    public PostalDeliveryServiceAddressType.UnstructuredAddress.AddressLine createPostalDeliveryServiceAddressTypeUnstructuredAddressAddressLine() {
        return new PostalDeliveryServiceAddressType.UnstructuredAddress.AddressLine();
    }

    /**
     * Create an instance of {@link StreetAddressType.StructuredAddress.SubDwellingUnitType }
     * 
     */
    public StreetAddressType.StructuredAddress.SubDwellingUnitType createStreetAddressTypeStructuredAddressSubDwellingUnitType() {
        return new StreetAddressType.StructuredAddress.SubDwellingUnitType();
    }

    /**
     * Create an instance of {@link StreetAddressType.StructuredAddress.Level }
     * 
     */
    public StreetAddressType.StructuredAddress.Level createStreetAddressTypeStructuredAddressLevel() {
        return new StreetAddressType.StructuredAddress.Level();
    }

    /**
     * Create an instance of {@link StreetAddressType.StructuredAddress.Road.RoadNumber }
     * 
     */
    public StreetAddressType.StructuredAddress.Road.RoadNumber createStreetAddressTypeStructuredAddressRoadRoadNumber() {
        return new StreetAddressType.StructuredAddress.Road.RoadNumber();
    }

    /**
     * Create an instance of {@link StreetAddressType.StructuredAddress.ComplexRoad.RoadNumber }
     * 
     */
    public StreetAddressType.StructuredAddress.ComplexRoad.RoadNumber createStreetAddressTypeStructuredAddressComplexRoadRoadNumber() {
        return new StreetAddressType.StructuredAddress.ComplexRoad.RoadNumber();
    }

    /**
     * Create an instance of {@link StreetAddressType.UnstructuredAddress.AddressLine }
     * 
     */
    public StreetAddressType.UnstructuredAddress.AddressLine createStreetAddressTypeUnstructuredAddressAddressLine() {
        return new StreetAddressType.UnstructuredAddress.AddressLine();
    }

    /**
     * Create an instance of {@link DocumentDataType.SubjectLandTitle }
     * 
     */
    public DocumentDataType.SubjectLandTitle createDocumentDataTypeSubjectLandTitle() {
        return new DocumentDataType.SubjectLandTitle();
    }

    /**
     * Create an instance of {@link DocumentDataType.PartyReceivingDetail }
     * 
     */
    public DocumentDataType.PartyReceivingDetail createDocumentDataTypePartyReceivingDetail() {
        return new DocumentDataType.PartyReceivingDetail();
    }

    /**
     * Create an instance of {@link DocumentDataType.PartyRelinquishingDetail }
     * 
     */
    public DocumentDataType.PartyRelinquishingDetail createDocumentDataTypePartyRelinquishingDetail() {
        return new DocumentDataType.PartyRelinquishingDetail();
    }

    /**
     * Create an instance of {@link DocumentDataType.TransactionInformation }
     * 
     */
    public DocumentDataType.TransactionInformation createDocumentDataTypeTransactionInformation() {
        return new DocumentDataType.TransactionInformation();
    }

    /**
     * Create an instance of {@link PartyDetailType.PartyIdentification }
     * 
     */
    public PartyDetailType.PartyIdentification createPartyDetailTypePartyIdentification() {
        return new PartyDetailType.PartyIdentification();
    }

    /**
     * Create an instance of {@link PartyDetailType.TrustDetail }
     * 
     */
    public PartyDetailType.TrustDetail createPartyDetailTypeTrustDetail() {
        return new PartyDetailType.TrustDetail();
    }

    /**
     * Create an instance of {@link PartyDetailType.PersonFullName.GivenName }
     * 
     */
    public PartyDetailType.PersonFullName.GivenName createPartyDetailTypePersonFullNameGivenName() {
        return new PartyDetailType.PersonFullName.GivenName();
    }

    /**
     * Create an instance of {@link LandDescriptionType.Component }
     * 
     */
    public LandDescriptionType.Component createLandDescriptionTypeComponent() {
        return new LandDescriptionType.Component();
    }

    /**
     * Create an instance of {@link StampDutyVerificationResponseType.DocumentAssessmentDetail }
     * 
     */
    public StampDutyVerificationResponseType.DocumentAssessmentDetail createStampDutyVerificationResponseTypeDocumentAssessmentDetail() {
        return new StampDutyVerificationResponseType.DocumentAssessmentDetail();
    }

}
