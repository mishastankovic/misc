
package au.gov.messages.osr.schema._2;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for roadTypeCodeCategoryType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="roadTypeCodeCategoryType"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="ACCS"/&gt;
 *     &lt;enumeration value="ALLY"/&gt;
 *     &lt;enumeration value="ALWY"/&gt;
 *     &lt;enumeration value="AMBL"/&gt;
 *     &lt;enumeration value="ANCG"/&gt;
 *     &lt;enumeration value="APP"/&gt;
 *     &lt;enumeration value="ARC"/&gt;
 *     &lt;enumeration value="ARTL"/&gt;
 *     &lt;enumeration value="ARTY"/&gt;
 *     &lt;enumeration value="AV"/&gt;
 *     &lt;enumeration value="BA"/&gt;
 *     &lt;enumeration value="BANK"/&gt;
 *     &lt;enumeration value="BASN"/&gt;
 *     &lt;enumeration value="BAY"/&gt;
 *     &lt;enumeration value="BCH"/&gt;
 *     &lt;enumeration value="BDGE"/&gt;
 *     &lt;enumeration value="BDWY"/&gt;
 *     &lt;enumeration value="BEND"/&gt;
 *     &lt;enumeration value="BLK"/&gt;
 *     &lt;enumeration value="BOWL"/&gt;
 *     &lt;enumeration value="BR"/&gt;
 *     &lt;enumeration value="BRAE"/&gt;
 *     &lt;enumeration value="BRK"/&gt;
 *     &lt;enumeration value="BROW"/&gt;
 *     &lt;enumeration value="BVD"/&gt;
 *     &lt;enumeration value="BVDE"/&gt;
 *     &lt;enumeration value="BWLK"/&gt;
 *     &lt;enumeration value="BYPA"/&gt;
 *     &lt;enumeration value="BYWY"/&gt;
 *     &lt;enumeration value="CCT"/&gt;
 *     &lt;enumeration value="CH"/&gt;
 *     &lt;enumeration value="CIR"/&gt;
 *     &lt;enumeration value="CL"/&gt;
 *     &lt;enumeration value="CLDE"/&gt;
 *     &lt;enumeration value="CLST"/&gt;
 *     &lt;enumeration value="CLT"/&gt;
 *     &lt;enumeration value="CMMN"/&gt;
 *     &lt;enumeration value="CNR"/&gt;
 *     &lt;enumeration value="CNWY"/&gt;
 *     &lt;enumeration value="CON"/&gt;
 *     &lt;enumeration value="COVE"/&gt;
 *     &lt;enumeration value="COWY"/&gt;
 *     &lt;enumeration value="CPS"/&gt;
 *     &lt;enumeration value="CR"/&gt;
 *     &lt;enumeration value="CRCS"/&gt;
 *     &lt;enumeration value="CRD"/&gt;
 *     &lt;enumeration value="CRSE"/&gt;
 *     &lt;enumeration value="CRSG"/&gt;
 *     &lt;enumeration value="CRSS"/&gt;
 *     &lt;enumeration value="CRST"/&gt;
 *     &lt;enumeration value="CSAC"/&gt;
 *     &lt;enumeration value="CSO"/&gt;
 *     &lt;enumeration value="CSWY"/&gt;
 *     &lt;enumeration value="CT"/&gt;
 *     &lt;enumeration value="CTR"/&gt;
 *     &lt;enumeration value="CTT"/&gt;
 *     &lt;enumeration value="CTYD"/&gt;
 *     &lt;enumeration value="CUWY"/&gt;
 *     &lt;enumeration value="CX"/&gt;
 *     &lt;enumeration value="DALE"/&gt;
 *     &lt;enumeration value="DELL"/&gt;
 *     &lt;enumeration value="DENE"/&gt;
 *     &lt;enumeration value="DEVN"/&gt;
 *     &lt;enumeration value="DIP"/&gt;
 *     &lt;enumeration value="DIV"/&gt;
 *     &lt;enumeration value="DMN"/&gt;
 *     &lt;enumeration value="DOCK"/&gt;
 *     &lt;enumeration value="DR"/&gt;
 *     &lt;enumeration value="DSTR"/&gt;
 *     &lt;enumeration value="DVWY"/&gt;
 *     &lt;enumeration value="EDGE"/&gt;
 *     &lt;enumeration value="ELB"/&gt;
 *     &lt;enumeration value="END"/&gt;
 *     &lt;enumeration value="ENT"/&gt;
 *     &lt;enumeration value="ESP"/&gt;
 *     &lt;enumeration value="EST"/&gt;
 *     &lt;enumeration value="EXP"/&gt;
 *     &lt;enumeration value="EXTN"/&gt;
 *     &lt;enumeration value="FAWY"/&gt;
 *     &lt;enumeration value="FB"/&gt;
 *     &lt;enumeration value="FE"/&gt;
 *     &lt;enumeration value="FITR"/&gt;
 *     &lt;enumeration value="FLAT"/&gt;
 *     &lt;enumeration value="FLTS"/&gt;
 *     &lt;enumeration value="FOLW"/&gt;
 *     &lt;enumeration value="FORD"/&gt;
 *     &lt;enumeration value="FORM"/&gt;
 *     &lt;enumeration value="FRNT"/&gt;
 *     &lt;enumeration value="FRTG"/&gt;
 *     &lt;enumeration value="FSHR"/&gt;
 *     &lt;enumeration value="FTRK"/&gt;
 *     &lt;enumeration value="FTWY"/&gt;
 *     &lt;enumeration value="FWY"/&gt;
 *     &lt;enumeration value="GAP"/&gt;
 *     &lt;enumeration value="GDN"/&gt;
 *     &lt;enumeration value="GDNS"/&gt;
 *     &lt;enumeration value="GLDE"/&gt;
 *     &lt;enumeration value="GLEN"/&gt;
 *     &lt;enumeration value="GLY"/&gt;
 *     &lt;enumeration value="GR"/&gt;
 *     &lt;enumeration value="GRA"/&gt;
 *     &lt;enumeration value="GRN"/&gt;
 *     &lt;enumeration value="GRND"/&gt;
 *     &lt;enumeration value="GTE"/&gt;
 *     &lt;enumeration value="GTWY"/&gt;
 *     &lt;enumeration value="HILL"/&gt;
 *     &lt;enumeration value="HOLW"/&gt;
 *     &lt;enumeration value="HRBR"/&gt;
 *     &lt;enumeration value="HTH"/&gt;
 *     &lt;enumeration value="HTRD"/&gt;
 *     &lt;enumeration value="HTS"/&gt;
 *     &lt;enumeration value="HUB"/&gt;
 *     &lt;enumeration value="HWY"/&gt;
 *     &lt;enumeration value="INTG"/&gt;
 *     &lt;enumeration value="INTN"/&gt;
 *     &lt;enumeration value="ISLD"/&gt;
 *     &lt;enumeration value="JNC"/&gt;
 *     &lt;enumeration value="KEY"/&gt;
 *     &lt;enumeration value="KEYS"/&gt;
 *     &lt;enumeration value="LANE"/&gt;
 *     &lt;enumeration value="LDG"/&gt;
 *     &lt;enumeration value="LEES"/&gt;
 *     &lt;enumeration value="LINE"/&gt;
 *     &lt;enumeration value="LINK"/&gt;
 *     &lt;enumeration value="LKT"/&gt;
 *     &lt;enumeration value="LNWY"/&gt;
 *     &lt;enumeration value="LOOP"/&gt;
 *     &lt;enumeration value="LT"/&gt;
 *     &lt;enumeration value="LWR"/&gt;
 *     &lt;enumeration value="MALL"/&gt;
 *     &lt;enumeration value="MEW"/&gt;
 *     &lt;enumeration value="MEWS"/&gt;
 *     &lt;enumeration value="MNDR"/&gt;
 *     &lt;enumeration value="MNR"/&gt;
 *     &lt;enumeration value="MT"/&gt;
 *     &lt;enumeration value="MTWY"/&gt;
 *     &lt;enumeration value="NOOK"/&gt;
 *     &lt;enumeration value="OTLK"/&gt;
 *     &lt;enumeration value="OTLT"/&gt;
 *     &lt;enumeration value="PARK"/&gt;
 *     &lt;enumeration value="PART"/&gt;
 *     &lt;enumeration value="PASS"/&gt;
 *     &lt;enumeration value="PATH"/&gt;
 *     &lt;enumeration value="PDE"/&gt;
 *     &lt;enumeration value="PIAZ"/&gt;
 *     &lt;enumeration value="PKLD"/&gt;
 *     &lt;enumeration value="PKT"/&gt;
 *     &lt;enumeration value="PL"/&gt;
 *     &lt;enumeration value="PLAT"/&gt;
 *     &lt;enumeration value="PLZA"/&gt;
 *     &lt;enumeration value="PNT"/&gt;
 *     &lt;enumeration value="PORT"/&gt;
 *     &lt;enumeration value="PROM"/&gt;
 *     &lt;enumeration value="PRST"/&gt;
 *     &lt;enumeration value="PSGE"/&gt;
 *     &lt;enumeration value="PWAY"/&gt;
 *     &lt;enumeration value="PWY"/&gt;
 *     &lt;enumeration value="QDGL"/&gt;
 *     &lt;enumeration value="QDRT"/&gt;
 *     &lt;enumeration value="QUAD"/&gt;
 *     &lt;enumeration value="QY"/&gt;
 *     &lt;enumeration value="QYS"/&gt;
 *     &lt;enumeration value="RAMP"/&gt;
 *     &lt;enumeration value="RCH"/&gt;
 *     &lt;enumeration value="RD"/&gt;
 *     &lt;enumeration value="RDGE"/&gt;
 *     &lt;enumeration value="RDS"/&gt;
 *     &lt;enumeration value="RDSD"/&gt;
 *     &lt;enumeration value="RDWY"/&gt;
 *     &lt;enumeration value="RES"/&gt;
 *     &lt;enumeration value="REST"/&gt;
 *     &lt;enumeration value="RGWY"/&gt;
 *     &lt;enumeration value="RIDE"/&gt;
 *     &lt;enumeration value="RING"/&gt;
 *     &lt;enumeration value="RISE"/&gt;
 *     &lt;enumeration value="RMBL"/&gt;
 *     &lt;enumeration value="RND"/&gt;
 *     &lt;enumeration value="RNDE"/&gt;
 *     &lt;enumeration value="RNGE"/&gt;
 *     &lt;enumeration value="ROW"/&gt;
 *     &lt;enumeration value="ROWY"/&gt;
 *     &lt;enumeration value="RSBL"/&gt;
 *     &lt;enumeration value="RSNG"/&gt;
 *     &lt;enumeration value="RTE"/&gt;
 *     &lt;enumeration value="RTRN"/&gt;
 *     &lt;enumeration value="RTT"/&gt;
 *     &lt;enumeration value="RTY"/&gt;
 *     &lt;enumeration value="RUE"/&gt;
 *     &lt;enumeration value="RUN"/&gt;
 *     &lt;enumeration value="RVR"/&gt;
 *     &lt;enumeration value="RVRA"/&gt;
 *     &lt;enumeration value="RVWY"/&gt;
 *     &lt;enumeration value="SBWY"/&gt;
 *     &lt;enumeration value="SDNG"/&gt;
 *     &lt;enumeration value="SHUN"/&gt;
 *     &lt;enumeration value="SHWY"/&gt;
 *     &lt;enumeration value="SLPE"/&gt;
 *     &lt;enumeration value="SND"/&gt;
 *     &lt;enumeration value="SPUR"/&gt;
 *     &lt;enumeration value="SQ"/&gt;
 *     &lt;enumeration value="ST"/&gt;
 *     &lt;enumeration value="STPS"/&gt;
 *     &lt;enumeration value="STRA"/&gt;
 *     &lt;enumeration value="STRP"/&gt;
 *     &lt;enumeration value="STRS"/&gt;
 *     &lt;enumeration value="SVWY"/&gt;
 *     &lt;enumeration value="TARN"/&gt;
 *     &lt;enumeration value="TCE"/&gt;
 *     &lt;enumeration value="THFR"/&gt;
 *     &lt;enumeration value="TKWY"/&gt;
 *     &lt;enumeration value="TLWY"/&gt;
 *     &lt;enumeration value="TOP"/&gt;
 *     &lt;enumeration value="TOR"/&gt;
 *     &lt;enumeration value="TRI"/&gt;
 *     &lt;enumeration value="TRK"/&gt;
 *     &lt;enumeration value="TRL"/&gt;
 *     &lt;enumeration value="TRLR"/&gt;
 *     &lt;enumeration value="TRWY"/&gt;
 *     &lt;enumeration value="TURN"/&gt;
 *     &lt;enumeration value="TWIST"/&gt;
 *     &lt;enumeration value="TWRS"/&gt;
 *     &lt;enumeration value="UPAS"/&gt;
 *     &lt;enumeration value="UPR"/&gt;
 *     &lt;enumeration value="VALE"/&gt;
 *     &lt;enumeration value="VIAD"/&gt;
 *     &lt;enumeration value="VIEW"/&gt;
 *     &lt;enumeration value="VLLS"/&gt;
 *     &lt;enumeration value="VLLY"/&gt;
 *     &lt;enumeration value="VSTA"/&gt;
 *     &lt;enumeration value="VWS"/&gt;
 *     &lt;enumeration value="WADE"/&gt;
 *     &lt;enumeration value="WALK"/&gt;
 *     &lt;enumeration value="WAY"/&gt;
 *     &lt;enumeration value="WDS"/&gt;
 *     &lt;enumeration value="WHRF"/&gt;
 *     &lt;enumeration value="WKWY"/&gt;
 *     &lt;enumeration value="WTRS"/&gt;
 *     &lt;enumeration value="WTWY"/&gt;
 *     &lt;enumeration value="WYND"/&gt;
 *     &lt;enumeration value="YARD"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "roadTypeCodeCategoryType")
@XmlEnum
public enum RoadTypeCodeCategoryType {


    /**
     * Access [AS4590-2006]
     * 
     */
    ACCS,

    /**
     * Alley [AS4590-2006]
     * 
     */
    ALLY,

    /**
     * Alleyway [AS4590-2006]
     * 
     */
    ALWY,

    /**
     * Amble [AS4590-2006]
     * 
     */
    AMBL,

    /**
     * Anchorage [Vic Augmentation]
     * 
     */
    ANCG,

    /**
     * Approach [AS4590-2006]
     * 
     */
    APP,

    /**
     * Arcade [AS4590-2006]
     * 
     */
    ARC,

    /**
     * Arterial [AS4590-2006]
     * 
     */
    ARTL,

    /**
     * Artery [AS4590-2006]
     * 
     */
    ARTY,

    /**
     * Avenue [AS4590-2006]
     * 
     */
    AV,

    /**
     * Banan [AS4590-2006]
     * 
     */
    BA,

    /**
     * Bank [Vic Augmentation]
     * 
     */
    BANK,

    /**
     * Basin [Vic Augmentation]
     * 
     */
    BASN,

    /**
     * Bay [Vic Augmentation]
     * 
     */
    BAY,

    /**
     * Beach [Vic Augmentation]
     * 
     */
    BCH,

    /**
     * Bridge [Vic Augmentation]
     * 
     */
    BDGE,

    /**
     * Broadway [Vic Augmentation]
     * 
     */
    BDWY,

    /**
     * Bend [AS4590-2006]
     * 
     */
    BEND,

    /**
     * Block [Vic Augmentation]
     * 
     */
    BLK,

    /**
     * Bowl [Vic Augmentation]
     * 
     */
    BOWL,

    /**
     * Brace [AS4590-2006]
     * 
     */
    BR,

    /**
     * Brae [AS4590-2006]
     * 
     */
    BRAE,

    /**
     * Break [AS4590-2006]
     * 
     */
    BRK,

    /**
     * Brow [AS4590-2006]
     * 
     */
    BROW,

    /**
     * Boulevard [AS4590-2006]
     * 
     */
    BVD,

    /**
     * Boulevarde [Vic Augmentation]
     * 
     */
    BVDE,

    /**
     * Boardwalk [AS4590-2006]
     * 
     */
    BWLK,

    /**
     * Bypass [AS4590-2006]
     * 
     */
    BYPA,

    /**
     * Byway [AS4590-2006]
     * 
     */
    BYWY,

    /**
     * Circuit [AS4590-2006]
     * 
     */
    CCT,

    /**
     * Chase [AS4590-2006]
     * 
     */
    CH,

    /**
     * Circle [AS4590-2006]
     * 
     */
    CIR,

    /**
     * Close [AS4590-2006]
     * 
     */
    CL,

    /**
     * Colonnade [Vic Augmentation]
     * 
     */
    CLDE,

    /**
     * Cluster [Vic Augmentation]
     * 
     */
    CLST,

    /**
     * Circlet [Vic Augmentation]
     * 
     */
    CLT,

    /**
     * Common [Vic Augmentation]
     * 
     */
    CMMN,

    /**
     * Corner [AS4590-2006]
     * 
     */
    CNR,

    /**
     * Centreway [Vic Augmentation]
     * 
     */
    CNWY,

    /**
     * Concourse [AS4590-2006]
     * 
     */
    CON,

    /**
     * Cove [AS4590-2006]
     * 
     */
    COVE,

    /**
     * Crossway [Vic Augmentation]
     * 
     */
    COWY,

    /**
     * Copse [AS4590-2006]
     * 
     */
    CPS,

    /**
     * Crescent [AS4590-2006]
     * 
     */
    CR,

    /**
     * Circus [AS4590-2006]
     * 
     */
    CRCS,

    /**
     * Crossroad [Vic Augmentation]
     * 
     */
    CRD,

    /**
     * Course [Vic Augmentation]
     * 
     */
    CRSE,

    /**
     * Crossing [Vic Augmentation]
     * 
     */
    CRSG,

    /**
     * Cross [AS4590-2006]
     * 
     */
    CRSS,

    /**
     * Crest [AS4590-2006]
     * 
     */
    CRST,

    /**
     * Cul-de-sac [AS4590-2006]
     * 
     */
    CSAC,

    /**
     * Corso [Vic Augmentation]
     * 
     */
    CSO,

    /**
     * Causeway [AS4590-2006]
     * 
     */
    CSWY,

    /**
     * Court [AS4590-2006]
     * 
     */
    CT,

    /**
     * Centre [AS4590-2006]
     * 
     */
    CTR,

    /**
     * Cutting [AS4590-2006]
     * 
     */
    CTT,

    /**
     * Courtyard [AS4590-2006]
     * 
     */
    CTYD,

    /**
     * Cruiseway [Vic Augmentation]
     * 
     */
    CUWY,

    /**
     * Connection [Vic Augmentation]
     * 
     */
    CX,

    /**
     * Dale [AS4590-2006]
     * 
     */
    DALE,

    /**
     * Dell [Vic Augmentation]
     * 
     */
    DELL,

    /**
     * Dene [Vic Augmentation]
     * 
     */
    DENE,

    /**
     * Deviation [Vic Augmentation]
     * 
     */
    DEVN,

    /**
     * Dip [AS4590-2006]
     * 
     */
    DIP,

    /**
     * Divide [Vic Augmentation]
     * 
     */
    DIV,

    /**
     * Domain [Vic Augmentation]
     * 
     */
    DMN,

    /**
     * Dock [Vic Augmentation]
     * 
     */
    DOCK,

    /**
     * Drive [AS4590-2006]
     * 
     */
    DR,

    /**
     * Distributor [Vic Augmentation]
     * 
     */
    DSTR,

    /**
     * Driveway [AS4590-2006]
     * 
     */
    DVWY,

    /**
     * Edge [AS4590-2006]
     * 
     */
    EDGE,

    /**
     * Elbow [AS4590-2006]
     * 
     */
    ELB,

    /**
     * End [AS4590-2006]
     * 
     */
    END,

    /**
     * Entrance [AS4590-2006]
     * 
     */
    ENT,

    /**
     * Esplanade [AS4590-2006]
     * 
     */
    ESP,

    /**
     * Estate [Vic Augmentation]
     * 
     */
    EST,

    /**
     * Expressway [AS4590-2006]
     * 
     */
    EXP,

    /**
     * Extension [Vic Augmentation]
     * 
     */
    EXTN,

    /**
     * Fairway [AS4590-2006]
     * 
     */
    FAWY,

    /**
     * Firebreak [Vic Augmentation]
     * 
     */
    FB,

    /**
     * Fireline [Vic Augmentation]
     * 
     */
    FE,

    /**
     * Firetrail [AS/NZS4819-2011]
     * 
     */
    FITR,

    /**
     * Flat [Vic Augmentation]
     * 
     */
    FLAT,

    /**
     * Flats [Vic Augmentation]
     * 
     */
    FLTS,

    /**
     * Follow [AS4590-2006]
     * 
     */
    FOLW,

    /**
     * Ford [Vic Augmentation]
     * 
     */
    FORD,

    /**
     * Formation [AS4590-2006]
     * 
     */
    FORM,

    /**
     * Front [Vic Augmentation]
     * 
     */
    FRNT,

    /**
     * Frontage [AS4590-2006]
     * 
     */
    FRTG,

    /**
     * Foreshore [Vic Augmentation]
     * 
     */
    FSHR,

    /**
     * Firetrack [Vic Augmentation]
     * 
     */
    FTRK,

    /**
     * Footway [AS4590-2006]
     * 
     */
    FTWY,

    /**
     * Freeway [AS4590-2006]
     * 
     */
    FWY,

    /**
     * Gap [AS4590-2006]
     * 
     */
    GAP,

    /**
     * Garden [Vic Augmentation]
     * 
     */
    GDN,

    /**
     * Gardens [AS4590-2006]
     * 
     */
    GDNS,

    /**
     * Glade [AS4590-2006]
     * 
     */
    GLDE,

    /**
     * Glen [AS4590-2006]
     * 
     */
    GLEN,

    /**
     * Gully [Vic Augmentation]
     * 
     */
    GLY,

    /**
     * Grove [AS4590-2006]
     * 
     */
    GR,

    /**
     * Grange [AS4590-2006]
     * 
     */
    GRA,

    /**
     * Green [AS4590-2006]
     * 
     */
    GRN,

    /**
     * Ground [Vic Augmentation]
     * 
     */
    GRND,

    /**
     * Gate [AS4590-2006]
     * 
     */
    GTE,

    /**
     * Gateway [Vic Augmentation]
     * 
     */
    GTWY,

    /**
     * Hill [AS4590-2006]
     * 
     */
    HILL,

    /**
     * Hollow [Vic Augmentation]
     * 
     */
    HOLW,

    /**
     * Harbour [Vic Augmentation]
     * 
     */
    HRBR,

    /**
     * Heath [Vic Augmentation]
     * 
     */
    HTH,

    /**
     * Highroad [AS4590-2006]
     * 
     */
    HTRD,

    /**
     * Heights [AS4590-2006]
     * 
     */
    HTS,

    /**
     * Hub [Vic Augmentation]
     * 
     */
    HUB,

    /**
     * Highway [AS4590-2006]
     * 
     */
    HWY,

    /**
     * Interchange [AS4590-2006]
     * 
     */
    INTG,

    /**
     * Intersection [Vic Augmentation]
     * 
     */
    INTN,

    /**
     * Island [Vic Augmentation]
     * 
     */
    ISLD,

    /**
     * Junction [AS4590-2006]
     * 
     */
    JNC,

    /**
     * Key [AS4590-2006]
     * 
     */
    KEY,

    /**
     * Keys [Vic Augmentation]
     * 
     */
    KEYS,

    /**
     * Lane [AS4590-2006]
     * 
     */
    LANE,

    /**
     * Landing [Vic Augmentation]
     * 
     */
    LDG,

    /**
     * Lees [Vic Augmentation]
     * 
     */
    LEES,

    /**
     * Line [AS4590-2006]
     * 
     */
    LINE,

    /**
     * Link [AS4590-2006]
     * 
     */
    LINK,

    /**
     * Lookout [AS4590-2006]
     * 
     */
    LKT,

    /**
     * Laneway [AS4590-2006]
     * 
     */
    LNWY,

    /**
     * Loop [AS4590-2006]
     * 
     */
    LOOP,

    /**
     * Little [Vic Augmentation]
     * 
     */
    LT,

    /**
     * Lower [Vic Augmentation]
     * 
     */
    LWR,

    /**
     * Mall [AS4590-2006]
     * 
     */
    MALL,

    /**
     * Mew [Vic Augmentation]
     * 
     */
    MEW,

    /**
     * Mews [AS4590-2006]
     * 
     */
    MEWS,

    /**
     * Meander [AS4590-2006]
     * 
     */
    MNDR,

    /**
     * Manor [Vic Augmentation]
     * 
     */
    MNR,

    /**
     * Mount [Vic Augmentation]
     * 
     */
    MT,

    /**
     * Motorway [AS4590-2006]
     * 
     */
    MTWY,

    /**
     * Nook [AS4590-2006]
     * 
     */
    NOOK,

    /**
     * Outlook [AS4590-2006]
     * 
     */
    OTLK,

    /**
     * Outlet [Vic Augmentation]
     * 
     */
    OTLT,

    /**
     * Park [Vic Augmentation]
     * 
     */
    PARK,

    /**
     * Part [Vic Augmentation]
     * 
     */
    PART,

    /**
     * Pass [AS4590-2006]
     * 
     */
    PASS,

    /**
     * Path [AS4590-2006]
     * 
     */
    PATH,

    /**
     * Parade [AS4590-2006]
     * 
     */
    PDE,

    /**
     * Piazza [AS4590-2006]
     * 
     */
    PIAZ,

    /**
     * Parklands [Vic Augmentation]
     * 
     */
    PKLD,

    /**
     * Pocket [AS4590-2006]
     * 
     */
    PKT,

    /**
     * Place [AS4590-2006]
     * 
     */
    PL,

    /**
     * Plateau [Vic Augmentation]
     * 
     */
    PLAT,

    /**
     * Plaza [AS4590-2006]
     * 
     */
    PLZA,

    /**
     * Point [AS4590-2006]
     * 
     */
    PNT,

    /**
     * Port [AS4590-2006]
     * 
     */
    PORT,

    /**
     * Promenade [AS4590-2006]
     * 
     */
    PROM,

    /**
     * Pursuit [Vic Augmentation]
     * 
     */
    PRST,

    /**
     * Passage [AS4590]
     * 
     */
    PSGE,

    /**
     * Pathway [AS4590-2006]
     * 
     */
    PWAY,

    /**
     * Parkway [AS4590-2006]
     * 
     */
    PWY,

    /**
     * Quadrangle [Vic Augmentation]
     * 
     */
    QDGL,

    /**
     * Quadrant [AS4590-2006]
     * 
     */
    QDRT,

    /**
     * Quad [Vic Augmentation]
     * 
     */
    QUAD,

    /**
     * Quay [Vic Augmentation]
     * 
     */
    QY,

    /**
     * Quays [AS4590]
     * 
     */
    QYS,

    /**
     * Ramp [AS/NZS4819-2011]
     * 
     */
    RAMP,

    /**
     * Reach [Vic Augmentation]
     * 
     */
    RCH,

    /**
     * Road [AS4590-2006]
     * 
     */
    RD,

    /**
     * Ridge [AS4590-2006]
     * 
     */
    RDGE,

    /**
     * Roads [Vic Augmentation]
     * 
     */
    RDS,

    /**
     * Roadside [Vic Augmentation]
     * 
     */
    RDSD,

    /**
     * Roadway [Vic Augmentation]
     * 
     */
    RDWY,

    /**
     * Reserve [Vic Augmentation]
     * 
     */
    RES,

    /**
     * Rest [AS4590-2006]
     * 
     */
    REST,

    /**
     * Ridgeway [Vic Augmentation]
     * 
     */
    RGWY,

    /**
     * Ride [Vic Augmentation]
     * 
     */
    RIDE,

    /**
     * Ring [Vic Augmentation]
     * 
     */
    RING,

    /**
     * Rise [AS4590-2006]
     * 
     */
    RISE,

    /**
     * Ramble [AS4590-2006]
     * 
     */
    RMBL,

    /**
     * Round [Vic Augmentation]
     * 
     */
    RND,

    /**
     * Ronde [Vic Augmentation]
     * 
     */
    RNDE,

    /**
     * Range [Vic Augmentation]
     * 
     */
    RNGE,

    /**
     * Row [AS4590-2006]
     * 
     */
    ROW,

    /**
     * Right of Way [Vic Augmentation]
     * 
     */
    ROWY,

    /**
     * Rosebowl [Vic Augmentation]
     * 
     */
    RSBL,

    /**
     * Rising [Vic Augmentation]
     * 
     */
    RSNG,

    /**
     * Route [AS4590-2006]
     * 
     */
    RTE,

    /**
     * Return [Vic Augmentation]
     * 
     */
    RTRN,

    /**
     * Retreat [AS4590-2006]
     * 
     */
    RTT,

    /**
     * Rotary [AS4590-2006]
     * 
     */
    RTY,

    /**
     * Rue [AS4590-2006]
     * 
     */
    RUE,

    /**
     * Run [Vic Augmentation]
     * 
     */
    RUN,

    /**
     * River [Vic Augmentation]
     * 
     */
    RVR,

    /**
     * Riviera [Vic Augmentation]
     * 
     */
    RVRA,

    /**
     * Riverway [Vic Augmentation]
     * 
     */
    RVWY,

    /**
     * Subway [AS4590-2006]
     * 
     */
    SBWY,

    /**
     * Siding [Vic Augmentation]
     * 
     */
    SDNG,

    /**
     * Shunt [AS4590-2006]
     * 
     */
    SHUN,

    /**
     * State Highway [Vic Augmentation]
     * 
     */
    SHWY,

    /**
     * Slope [Vic Augmentation]
     * 
     */
    SLPE,

    /**
     * Sound [Vic Augmentation]
     * 
     */
    SND,

    /**
     * Spur [AS4590-2006]
     * 
     */
    SPUR,

    /**
     * Square [AS4590-2006]
     * 
     */
    SQ,

    /**
     * Street [AS4590-2006]
     * 
     */
    ST,

    /**
     * Steps [AS/NZS4819-2011]
     * 
     */
    STPS,

    /**
     * Strand [Vic Augmentation]
     * 
     */
    STRA,

    /**
     * Strip [Vic Augmentation]
     * 
     */
    STRP,

    /**
     * Stairs [Vic Augmentation]
     * 
     */
    STRS,

    /**
     * Service Way [AS4590-2006]
     * 
     */
    SVWY,

    /**
     * Tarn [AS4590-2006]
     * 
     */
    TARN,

    /**
     * Terrace [AS4590-2006]
     * 
     */
    TCE,

    /**
     * Thoroughfare [AS4590-2006]
     * 
     */
    THFR,

    /**
     * Trunkway [Vic Augmentation]
     * 
     */
    TKWY,

    /**
     * Tollway [AS4590-2006]
     * 
     */
    TLWY,

    /**
     * Top [AS4590-2006]
     * 
     */
    TOP,

    /**
     * Tor [AS4590-2006]
     * 
     */
    TOR,

    /**
     * Triangle [Vic Augmentation]
     * 
     */
    TRI,

    /**
     * Track [AS4590-2006]
     * 
     */
    TRK,

    /**
     * Trail [AS4590-2006]
     * 
     */
    TRL,

    /**
     * Trailer [Vic Augmentation]
     * 
     */
    TRLR,

    /**
     * Throughway [Vic Augmentation]
     * 
     */
    TRWY,

    /**
     * Turn [AS4590-2006]
     * 
     */
    TURN,

    /**
     * Twist [Vic Augmentation]
     * 
     */
    TWIST,

    /**
     * Towers [Vic Augmentation]
     * 
     */
    TWRS,

    /**
     * Underpass [AS4590-2006]
     * 
     */
    UPAS,

    /**
     * Upper [Vic Augmentation]
     * 
     */
    UPR,

    /**
     * Vale [AS4590-2006]
     * 
     */
    VALE,

    /**
     * Viaduct [AS4590-2006]
     * 
     */
    VIAD,

    /**
     * View [AS4590-2006]
     * 
     */
    VIEW,

    /**
     * Villas [Vic Augmentation]
     * 
     */
    VLLS,

    /**
     * Valley [Vic Augmentation]
     * 
     */
    VLLY,

    /**
     * Vista [AS4590-2006]
     * 
     */
    VSTA,

    /**
     * Views [Vic Augmentation]
     * 
     */
    VWS,

    /**
     * Wade [Vic Augmentation]
     * 
     */
    WADE,

    /**
     * Walk [AS4590-2006]
     * 
     */
    WALK,

    /**
     * Way [AS4590-2006]
     * 
     */
    WAY,

    /**
     * Woods [Vic Augmentation]
     * 
     */
    WDS,

    /**
     * Wharf [AS4590-2006]
     * 
     */
    WHRF,

    /**
     * Walkway [AS4590-2006]
     * 
     */
    WKWY,

    /**
     * Waters [Vic Augmentation]
     * 
     */
    WTRS,

    /**
     * Waterway [Vic Augmentation]
     * 
     */
    WTWY,

    /**
     * Wynd [AS4590-2006]
     * 
     */
    WYND,

    /**
     * Yard [Vic Augmentation]
     * 
     */
    YARD;

    public String value() {
        return name();
    }

    public static RoadTypeCodeCategoryType fromValue(String v) {
        return valueOf(v);
    }

}
