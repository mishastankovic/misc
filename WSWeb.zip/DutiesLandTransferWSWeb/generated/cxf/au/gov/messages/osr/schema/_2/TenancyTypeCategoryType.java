
package au.gov.messages.osr.schema._2;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for tenancyTypeCategoryType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="tenancyTypeCategoryType"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="Joint Tenants"/&gt;
 *     &lt;enumeration value="Mortgagee"/&gt;
 *     &lt;enumeration value="Multi"/&gt;
 *     &lt;enumeration value="Sole Proprietor"/&gt;
 *     &lt;enumeration value="Survivorship"/&gt;
 *     &lt;enumeration value="Tenants in Common"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "tenancyTypeCategoryType")
@XmlEnum
public enum TenancyTypeCategoryType {

    @XmlEnumValue("Joint Tenants")
    JOINT_TENANTS("Joint Tenants"),
    @XmlEnumValue("Mortgagee")
    MORTGAGEE("Mortgagee"),
    @XmlEnumValue("Multi")
    MULTI("Multi"),
    @XmlEnumValue("Sole Proprietor")
    SOLE_PROPRIETOR("Sole Proprietor"),
    @XmlEnumValue("Survivorship")
    SURVIVORSHIP("Survivorship"),
    @XmlEnumValue("Tenants in Common")
    TENANTS_IN_COMMON("Tenants in Common");
    private final String value;

    TenancyTypeCategoryType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static TenancyTypeCategoryType fromValue(String v) {
        for (TenancyTypeCategoryType c: TenancyTypeCategoryType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
