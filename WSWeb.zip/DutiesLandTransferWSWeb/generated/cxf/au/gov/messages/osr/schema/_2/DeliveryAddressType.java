
package au.gov.messages.osr.schema._2;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for deliveryAddressType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="deliveryAddressType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="StreetAddress" type="{http://osr.messages.gov.au/schema/2.4/}streetAddressType"/&gt;
 *         &lt;element name="PostalDeliveryServiceAddress" type="{http://osr.messages.gov.au/schema/2.4/}postalDeliveryServiceAddressType"/&gt;
 *         &lt;element name="DxAddress" type="{http://osr.messages.gov.au/schema/2.4/}dxAddressType"/&gt;
 *         &lt;element name="OverseasAddress" type="{http://osr.messages.gov.au/schema/2.4/}overseasAddressType"/&gt;
 *       &lt;/choice&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "deliveryAddressType", propOrder = {
    "streetAddress",
    "postalDeliveryServiceAddress",
    "dxAddress",
    "overseasAddress"
})
public class DeliveryAddressType {

    @XmlElement(name = "StreetAddress")
    protected StreetAddressType streetAddress;
    @XmlElement(name = "PostalDeliveryServiceAddress")
    protected PostalDeliveryServiceAddressType postalDeliveryServiceAddress;
    @XmlElement(name = "DxAddress")
    protected DxAddressType dxAddress;
    @XmlElement(name = "OverseasAddress")
    protected OverseasAddressType overseasAddress;

    /**
     * Gets the value of the streetAddress property.
     * 
     * @return
     *     possible object is
     *     {@link StreetAddressType }
     *     
     */
    public StreetAddressType getStreetAddress() {
        return streetAddress;
    }

    /**
     * Sets the value of the streetAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link StreetAddressType }
     *     
     */
    public void setStreetAddress(StreetAddressType value) {
        this.streetAddress = value;
    }

    /**
     * Gets the value of the postalDeliveryServiceAddress property.
     * 
     * @return
     *     possible object is
     *     {@link PostalDeliveryServiceAddressType }
     *     
     */
    public PostalDeliveryServiceAddressType getPostalDeliveryServiceAddress() {
        return postalDeliveryServiceAddress;
    }

    /**
     * Sets the value of the postalDeliveryServiceAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link PostalDeliveryServiceAddressType }
     *     
     */
    public void setPostalDeliveryServiceAddress(PostalDeliveryServiceAddressType value) {
        this.postalDeliveryServiceAddress = value;
    }

    /**
     * Gets the value of the dxAddress property.
     * 
     * @return
     *     possible object is
     *     {@link DxAddressType }
     *     
     */
    public DxAddressType getDxAddress() {
        return dxAddress;
    }

    /**
     * Sets the value of the dxAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link DxAddressType }
     *     
     */
    public void setDxAddress(DxAddressType value) {
        this.dxAddress = value;
    }

    /**
     * Gets the value of the overseasAddress property.
     * 
     * @return
     *     possible object is
     *     {@link OverseasAddressType }
     *     
     */
    public OverseasAddressType getOverseasAddress() {
        return overseasAddress;
    }

    /**
     * Sets the value of the overseasAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link OverseasAddressType }
     *     
     */
    public void setOverseasAddress(OverseasAddressType value) {
        this.overseasAddress = value;
    }

}
