
package au.gov.messages.osr.schema._2;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for paymentStatusType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="paymentStatusType"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="Paid"/&gt;
 *     &lt;enumeration value="Unpaid"/&gt;
 *     &lt;enumeration value="Nil Assessed"/&gt;
 *     &lt;enumeration value="Exempt"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "paymentStatusType")
@XmlEnum
public enum PaymentStatusType {

    @XmlEnumValue("Paid")
    PAID("Paid"),
    @XmlEnumValue("Unpaid")
    UNPAID("Unpaid"),
    @XmlEnumValue("Nil Assessed")
    NIL_ASSESSED("Nil Assessed"),
    @XmlEnumValue("Exempt")
    EXEMPT("Exempt");
    private final String value;

    PaymentStatusType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static PaymentStatusType fromValue(String v) {
        for (PaymentStatusType c: PaymentStatusType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
