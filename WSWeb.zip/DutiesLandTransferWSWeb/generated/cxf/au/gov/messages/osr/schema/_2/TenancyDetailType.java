
package au.gov.messages.osr.schema._2;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for tenancyDetailType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="tenancyDetailType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="TenancyType" type="{http://osr.messages.gov.au/schema/2.4/}tenancyTypeCategoryType"/&gt;
 *         &lt;element name="TenancyGroup" maxOccurs="unbounded"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="TenancyGroupType" type="{http://osr.messages.gov.au/schema/2.4/}proprietorGroupTypeCategoryType" minOccurs="0"/&gt;
 *                   &lt;element name="ShareFraction" type="{http://osr.messages.gov.au/schema/2.4/}fractionType" minOccurs="0"/&gt;
 *                   &lt;element name="TenantHolding" maxOccurs="unbounded"&gt;
 *                     &lt;complexType&gt;
 *                       &lt;complexContent&gt;
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                           &lt;sequence&gt;
 *                             &lt;element name="PartyId" type="{http://osr.messages.gov.au/schema/2.4/}partyReferenceType"/&gt;
 *                             &lt;element name="Capacity" type="{http://osr.messages.gov.au/schema/2.4/}partyCapacityType" minOccurs="0"/&gt;
 *                           &lt;/sequence&gt;
 *                           &lt;attribute name="order" type="{http://osr.messages.gov.au/schema/2.4/}ordinalType" /&gt;
 *                         &lt;/restriction&gt;
 *                       &lt;/complexContent&gt;
 *                     &lt;/complexType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="EffectiveDate" type="{http://osr.messages.gov.au/schema/2.4/}dateType" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *                 &lt;attribute name="order" type="{http://osr.messages.gov.au/schema/2.4/}ordinalType" /&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tenancyDetailType", propOrder = {
    "tenancyType",
    "tenancyGroup"
})
public class TenancyDetailType {

    @XmlElement(name = "TenancyType", required = true)
    @XmlSchemaType(name = "string")
    protected TenancyTypeCategoryType tenancyType;
    @XmlElement(name = "TenancyGroup", required = true)
    protected List<TenancyDetailType.TenancyGroup> tenancyGroup;

    /**
     * Gets the value of the tenancyType property.
     * 
     * @return
     *     possible object is
     *     {@link TenancyTypeCategoryType }
     *     
     */
    public TenancyTypeCategoryType getTenancyType() {
        return tenancyType;
    }

    /**
     * Sets the value of the tenancyType property.
     * 
     * @param value
     *     allowed object is
     *     {@link TenancyTypeCategoryType }
     *     
     */
    public void setTenancyType(TenancyTypeCategoryType value) {
        this.tenancyType = value;
    }

    /**
     * Gets the value of the tenancyGroup property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the tenancyGroup property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTenancyGroup().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TenancyDetailType.TenancyGroup }
     * 
     * 
     */
    public List<TenancyDetailType.TenancyGroup> getTenancyGroup() {
        if (tenancyGroup == null) {
            tenancyGroup = new ArrayList<TenancyDetailType.TenancyGroup>();
        }
        return this.tenancyGroup;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="TenancyGroupType" type="{http://osr.messages.gov.au/schema/2.4/}proprietorGroupTypeCategoryType" minOccurs="0"/&gt;
     *         &lt;element name="ShareFraction" type="{http://osr.messages.gov.au/schema/2.4/}fractionType" minOccurs="0"/&gt;
     *         &lt;element name="TenantHolding" maxOccurs="unbounded"&gt;
     *           &lt;complexType&gt;
     *             &lt;complexContent&gt;
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                 &lt;sequence&gt;
     *                   &lt;element name="PartyId" type="{http://osr.messages.gov.au/schema/2.4/}partyReferenceType"/&gt;
     *                   &lt;element name="Capacity" type="{http://osr.messages.gov.au/schema/2.4/}partyCapacityType" minOccurs="0"/&gt;
     *                 &lt;/sequence&gt;
     *                 &lt;attribute name="order" type="{http://osr.messages.gov.au/schema/2.4/}ordinalType" /&gt;
     *               &lt;/restriction&gt;
     *             &lt;/complexContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="EffectiveDate" type="{http://osr.messages.gov.au/schema/2.4/}dateType" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *       &lt;attribute name="order" type="{http://osr.messages.gov.au/schema/2.4/}ordinalType" /&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "tenancyGroupType",
        "shareFraction",
        "tenantHolding",
        "effectiveDate"
    })
    public static class TenancyGroup {

        @XmlElement(name = "TenancyGroupType")
        @XmlSchemaType(name = "string")
        protected ProprietorGroupTypeCategoryType tenancyGroupType;
        @XmlElement(name = "ShareFraction")
        protected FractionType shareFraction;
        @XmlElement(name = "TenantHolding", required = true)
        protected List<TenancyDetailType.TenancyGroup.TenantHolding> tenantHolding;
        @XmlElement(name = "EffectiveDate")
        @XmlSchemaType(name = "dateTime")
        protected XMLGregorianCalendar effectiveDate;
        @XmlAttribute(name = "order")
        protected BigInteger order;

        /**
         * Gets the value of the tenancyGroupType property.
         * 
         * @return
         *     possible object is
         *     {@link ProprietorGroupTypeCategoryType }
         *     
         */
        public ProprietorGroupTypeCategoryType getTenancyGroupType() {
            return tenancyGroupType;
        }

        /**
         * Sets the value of the tenancyGroupType property.
         * 
         * @param value
         *     allowed object is
         *     {@link ProprietorGroupTypeCategoryType }
         *     
         */
        public void setTenancyGroupType(ProprietorGroupTypeCategoryType value) {
            this.tenancyGroupType = value;
        }

        /**
         * Gets the value of the shareFraction property.
         * 
         * @return
         *     possible object is
         *     {@link FractionType }
         *     
         */
        public FractionType getShareFraction() {
            return shareFraction;
        }

        /**
         * Sets the value of the shareFraction property.
         * 
         * @param value
         *     allowed object is
         *     {@link FractionType }
         *     
         */
        public void setShareFraction(FractionType value) {
            this.shareFraction = value;
        }

        /**
         * Gets the value of the tenantHolding property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the tenantHolding property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getTenantHolding().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link TenancyDetailType.TenancyGroup.TenantHolding }
         * 
         * 
         */
        public List<TenancyDetailType.TenancyGroup.TenantHolding> getTenantHolding() {
            if (tenantHolding == null) {
                tenantHolding = new ArrayList<TenancyDetailType.TenancyGroup.TenantHolding>();
            }
            return this.tenantHolding;
        }

        /**
         * Gets the value of the effectiveDate property.
         * 
         * @return
         *     possible object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public XMLGregorianCalendar getEffectiveDate() {
            return effectiveDate;
        }

        /**
         * Sets the value of the effectiveDate property.
         * 
         * @param value
         *     allowed object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public void setEffectiveDate(XMLGregorianCalendar value) {
            this.effectiveDate = value;
        }

        /**
         * Gets the value of the order property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getOrder() {
            return order;
        }

        /**
         * Sets the value of the order property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setOrder(BigInteger value) {
            this.order = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;complexContent&gt;
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *       &lt;sequence&gt;
         *         &lt;element name="PartyId" type="{http://osr.messages.gov.au/schema/2.4/}partyReferenceType"/&gt;
         *         &lt;element name="Capacity" type="{http://osr.messages.gov.au/schema/2.4/}partyCapacityType" minOccurs="0"/&gt;
         *       &lt;/sequence&gt;
         *       &lt;attribute name="order" type="{http://osr.messages.gov.au/schema/2.4/}ordinalType" /&gt;
         *     &lt;/restriction&gt;
         *   &lt;/complexContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "partyId",
            "capacity"
        })
        public static class TenantHolding {

            @XmlElement(name = "PartyId", required = true)
            protected String partyId;
            @XmlElement(name = "Capacity")
            protected PartyCapacityType capacity;
            @XmlAttribute(name = "order")
            protected BigInteger order;

            /**
             * Gets the value of the partyId property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getPartyId() {
                return partyId;
            }

            /**
             * Sets the value of the partyId property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setPartyId(String value) {
                this.partyId = value;
            }

            /**
             * Gets the value of the capacity property.
             * 
             * @return
             *     possible object is
             *     {@link PartyCapacityType }
             *     
             */
            public PartyCapacityType getCapacity() {
                return capacity;
            }

            /**
             * Sets the value of the capacity property.
             * 
             * @param value
             *     allowed object is
             *     {@link PartyCapacityType }
             *     
             */
            public void setCapacity(PartyCapacityType value) {
                this.capacity = value;
            }

            /**
             * Gets the value of the order property.
             * 
             * @return
             *     possible object is
             *     {@link BigInteger }
             *     
             */
            public BigInteger getOrder() {
                return order;
            }

            /**
             * Sets the value of the order property.
             * 
             * @param value
             *     allowed object is
             *     {@link BigInteger }
             *     
             */
            public void setOrder(BigInteger value) {
                this.order = value;
            }

        }

    }

}
