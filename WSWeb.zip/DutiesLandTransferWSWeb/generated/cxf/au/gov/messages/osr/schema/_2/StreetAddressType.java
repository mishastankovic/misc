
package au.gov.messages.osr.schema._2;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;


/**
 * <p>Java class for streetAddressType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="streetAddressType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="UnstructuredAddress" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="AddressLine" maxOccurs="4"&gt;
 *                     &lt;complexType&gt;
 *                       &lt;simpleContent&gt;
 *                         &lt;extension base="&lt;http://osr.messages.gov.au/schema/2.4/&gt;textType"&gt;
 *                           &lt;attribute name="order" type="{http://osr.messages.gov.au/schema/2.4/}ordinalType" /&gt;
 *                         &lt;/extension&gt;
 *                       &lt;/simpleContent&gt;
 *                     &lt;/complexType&gt;
 *                   &lt;/element&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="StructuredAddress" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="SubDwellingUnitType" minOccurs="0"&gt;
 *                     &lt;complexType&gt;
 *                       &lt;complexContent&gt;
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                           &lt;sequence&gt;
 *                             &lt;element name="UnitTypeCode" type="{http://osr.messages.gov.au/schema/2.4/}unitTypeCodeCategoryType"/&gt;
 *                             &lt;element name="UnitNumber" type="{http://osr.messages.gov.au/schema/2.4/}textType"/&gt;
 *                           &lt;/sequence&gt;
 *                         &lt;/restriction&gt;
 *                       &lt;/complexContent&gt;
 *                     &lt;/complexType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="Level" minOccurs="0"&gt;
 *                     &lt;complexType&gt;
 *                       &lt;complexContent&gt;
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                           &lt;sequence&gt;
 *                             &lt;element name="LevelTypeCode" type="{http://osr.messages.gov.au/schema/2.4/}levelTypeCodeCategoryType"/&gt;
 *                             &lt;element name="LevelNumber" type="{http://osr.messages.gov.au/schema/2.4/}textType" minOccurs="0"/&gt;
 *                           &lt;/sequence&gt;
 *                         &lt;/restriction&gt;
 *                       &lt;/complexContent&gt;
 *                     &lt;/complexType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="ComplexRoad" maxOccurs="2" minOccurs="0"&gt;
 *                     &lt;complexType&gt;
 *                       &lt;complexContent&gt;
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                           &lt;sequence&gt;
 *                             &lt;element name="RoadNumber" maxOccurs="2" minOccurs="0"&gt;
 *                               &lt;complexType&gt;
 *                                 &lt;simpleContent&gt;
 *                                   &lt;extension base="&lt;http://osr.messages.gov.au/schema/2.4/&gt;textType"&gt;
 *                                     &lt;attribute name="order" type="{http://osr.messages.gov.au/schema/2.4/}ordinalType" /&gt;
 *                                   &lt;/extension&gt;
 *                                 &lt;/simpleContent&gt;
 *                               &lt;/complexType&gt;
 *                             &lt;/element&gt;
 *                             &lt;element name="RoadName" type="{http://osr.messages.gov.au/schema/2.4/}textType" minOccurs="0"/&gt;
 *                             &lt;element name="RoadTypeCode" type="{http://osr.messages.gov.au/schema/2.4/}roadTypeCodeCategoryType" minOccurs="0"/&gt;
 *                             &lt;element name="RoadSuffixCode" type="{http://osr.messages.gov.au/schema/2.4/}roadSuffixCodeCategoryType" minOccurs="0"/&gt;
 *                           &lt;/sequence&gt;
 *                           &lt;attribute name="order" type="{http://osr.messages.gov.au/schema/2.4/}ordinalType" /&gt;
 *                         &lt;/restriction&gt;
 *                       &lt;/complexContent&gt;
 *                     &lt;/complexType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="SecondaryComplex" type="{http://osr.messages.gov.au/schema/2.4/}textType" minOccurs="0"/&gt;
 *                   &lt;element name="AddressSiteName" type="{http://osr.messages.gov.au/schema/2.4/}textType" minOccurs="0"/&gt;
 *                   &lt;element name="Road" maxOccurs="2" minOccurs="0"&gt;
 *                     &lt;complexType&gt;
 *                       &lt;complexContent&gt;
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                           &lt;sequence&gt;
 *                             &lt;element name="LotNumber" type="{http://osr.messages.gov.au/schema/2.4/}textType" minOccurs="0"/&gt;
 *                             &lt;element name="RoadNumber" maxOccurs="2" minOccurs="0"&gt;
 *                               &lt;complexType&gt;
 *                                 &lt;simpleContent&gt;
 *                                   &lt;extension base="&lt;http://osr.messages.gov.au/schema/2.4/&gt;textType"&gt;
 *                                     &lt;attribute name="order" type="{http://osr.messages.gov.au/schema/2.4/}ordinalType" /&gt;
 *                                   &lt;/extension&gt;
 *                                 &lt;/simpleContent&gt;
 *                               &lt;/complexType&gt;
 *                             &lt;/element&gt;
 *                             &lt;element name="RoadName" type="{http://osr.messages.gov.au/schema/2.4/}textType" minOccurs="0"/&gt;
 *                             &lt;element name="RoadTypeCode" type="{http://osr.messages.gov.au/schema/2.4/}roadTypeCodeCategoryType" minOccurs="0"/&gt;
 *                             &lt;element name="RoadSuffixCode" type="{http://osr.messages.gov.au/schema/2.4/}roadSuffixCodeCategoryType" minOccurs="0"/&gt;
 *                           &lt;/sequence&gt;
 *                           &lt;attribute name="order" type="{http://osr.messages.gov.au/schema/2.4/}ordinalType" /&gt;
 *                         &lt;/restriction&gt;
 *                       &lt;/complexContent&gt;
 *                     &lt;/complexType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="LocalityName" type="{http://osr.messages.gov.au/schema/2.4/}localityNameType"/&gt;
 *                   &lt;element name="Postcode" type="{http://osr.messages.gov.au/schema/2.4/}textType" minOccurs="0"/&gt;
 *                   &lt;element name="State" type="{http://osr.messages.gov.au/schema/2.4/}stateCategoryType"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "streetAddressType", propOrder = {
    "unstructuredAddress",
    "structuredAddress"
})
public class StreetAddressType {

    @XmlElement(name = "UnstructuredAddress")
    protected StreetAddressType.UnstructuredAddress unstructuredAddress;
    @XmlElement(name = "StructuredAddress")
    protected StreetAddressType.StructuredAddress structuredAddress;

    /**
     * Gets the value of the unstructuredAddress property.
     * 
     * @return
     *     possible object is
     *     {@link StreetAddressType.UnstructuredAddress }
     *     
     */
    public StreetAddressType.UnstructuredAddress getUnstructuredAddress() {
        return unstructuredAddress;
    }

    /**
     * Sets the value of the unstructuredAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link StreetAddressType.UnstructuredAddress }
     *     
     */
    public void setUnstructuredAddress(StreetAddressType.UnstructuredAddress value) {
        this.unstructuredAddress = value;
    }

    /**
     * Gets the value of the structuredAddress property.
     * 
     * @return
     *     possible object is
     *     {@link StreetAddressType.StructuredAddress }
     *     
     */
    public StreetAddressType.StructuredAddress getStructuredAddress() {
        return structuredAddress;
    }

    /**
     * Sets the value of the structuredAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link StreetAddressType.StructuredAddress }
     *     
     */
    public void setStructuredAddress(StreetAddressType.StructuredAddress value) {
        this.structuredAddress = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="SubDwellingUnitType" minOccurs="0"&gt;
     *           &lt;complexType&gt;
     *             &lt;complexContent&gt;
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                 &lt;sequence&gt;
     *                   &lt;element name="UnitTypeCode" type="{http://osr.messages.gov.au/schema/2.4/}unitTypeCodeCategoryType"/&gt;
     *                   &lt;element name="UnitNumber" type="{http://osr.messages.gov.au/schema/2.4/}textType"/&gt;
     *                 &lt;/sequence&gt;
     *               &lt;/restriction&gt;
     *             &lt;/complexContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="Level" minOccurs="0"&gt;
     *           &lt;complexType&gt;
     *             &lt;complexContent&gt;
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                 &lt;sequence&gt;
     *                   &lt;element name="LevelTypeCode" type="{http://osr.messages.gov.au/schema/2.4/}levelTypeCodeCategoryType"/&gt;
     *                   &lt;element name="LevelNumber" type="{http://osr.messages.gov.au/schema/2.4/}textType" minOccurs="0"/&gt;
     *                 &lt;/sequence&gt;
     *               &lt;/restriction&gt;
     *             &lt;/complexContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="ComplexRoad" maxOccurs="2" minOccurs="0"&gt;
     *           &lt;complexType&gt;
     *             &lt;complexContent&gt;
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                 &lt;sequence&gt;
     *                   &lt;element name="RoadNumber" maxOccurs="2" minOccurs="0"&gt;
     *                     &lt;complexType&gt;
     *                       &lt;simpleContent&gt;
     *                         &lt;extension base="&lt;http://osr.messages.gov.au/schema/2.4/&gt;textType"&gt;
     *                           &lt;attribute name="order" type="{http://osr.messages.gov.au/schema/2.4/}ordinalType" /&gt;
     *                         &lt;/extension&gt;
     *                       &lt;/simpleContent&gt;
     *                     &lt;/complexType&gt;
     *                   &lt;/element&gt;
     *                   &lt;element name="RoadName" type="{http://osr.messages.gov.au/schema/2.4/}textType" minOccurs="0"/&gt;
     *                   &lt;element name="RoadTypeCode" type="{http://osr.messages.gov.au/schema/2.4/}roadTypeCodeCategoryType" minOccurs="0"/&gt;
     *                   &lt;element name="RoadSuffixCode" type="{http://osr.messages.gov.au/schema/2.4/}roadSuffixCodeCategoryType" minOccurs="0"/&gt;
     *                 &lt;/sequence&gt;
     *                 &lt;attribute name="order" type="{http://osr.messages.gov.au/schema/2.4/}ordinalType" /&gt;
     *               &lt;/restriction&gt;
     *             &lt;/complexContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="SecondaryComplex" type="{http://osr.messages.gov.au/schema/2.4/}textType" minOccurs="0"/&gt;
     *         &lt;element name="AddressSiteName" type="{http://osr.messages.gov.au/schema/2.4/}textType" minOccurs="0"/&gt;
     *         &lt;element name="Road" maxOccurs="2" minOccurs="0"&gt;
     *           &lt;complexType&gt;
     *             &lt;complexContent&gt;
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                 &lt;sequence&gt;
     *                   &lt;element name="LotNumber" type="{http://osr.messages.gov.au/schema/2.4/}textType" minOccurs="0"/&gt;
     *                   &lt;element name="RoadNumber" maxOccurs="2" minOccurs="0"&gt;
     *                     &lt;complexType&gt;
     *                       &lt;simpleContent&gt;
     *                         &lt;extension base="&lt;http://osr.messages.gov.au/schema/2.4/&gt;textType"&gt;
     *                           &lt;attribute name="order" type="{http://osr.messages.gov.au/schema/2.4/}ordinalType" /&gt;
     *                         &lt;/extension&gt;
     *                       &lt;/simpleContent&gt;
     *                     &lt;/complexType&gt;
     *                   &lt;/element&gt;
     *                   &lt;element name="RoadName" type="{http://osr.messages.gov.au/schema/2.4/}textType" minOccurs="0"/&gt;
     *                   &lt;element name="RoadTypeCode" type="{http://osr.messages.gov.au/schema/2.4/}roadTypeCodeCategoryType" minOccurs="0"/&gt;
     *                   &lt;element name="RoadSuffixCode" type="{http://osr.messages.gov.au/schema/2.4/}roadSuffixCodeCategoryType" minOccurs="0"/&gt;
     *                 &lt;/sequence&gt;
     *                 &lt;attribute name="order" type="{http://osr.messages.gov.au/schema/2.4/}ordinalType" /&gt;
     *               &lt;/restriction&gt;
     *             &lt;/complexContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="LocalityName" type="{http://osr.messages.gov.au/schema/2.4/}localityNameType"/&gt;
     *         &lt;element name="Postcode" type="{http://osr.messages.gov.au/schema/2.4/}textType" minOccurs="0"/&gt;
     *         &lt;element name="State" type="{http://osr.messages.gov.au/schema/2.4/}stateCategoryType"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "subDwellingUnitType",
        "level",
        "complexRoad",
        "secondaryComplex",
        "addressSiteName",
        "road",
        "localityName",
        "postcode",
        "state"
    })
    public static class StructuredAddress {

        @XmlElement(name = "SubDwellingUnitType")
        protected StreetAddressType.StructuredAddress.SubDwellingUnitType subDwellingUnitType;
        @XmlElement(name = "Level")
        protected StreetAddressType.StructuredAddress.Level level;
        @XmlElement(name = "ComplexRoad")
        protected List<StreetAddressType.StructuredAddress.ComplexRoad> complexRoad;
        @XmlElement(name = "SecondaryComplex")
        protected String secondaryComplex;
        @XmlElement(name = "AddressSiteName")
        protected String addressSiteName;
        @XmlElement(name = "Road")
        protected List<StreetAddressType.StructuredAddress.Road> road;
        @XmlElement(name = "LocalityName", required = true)
        protected String localityName;
        @XmlElement(name = "Postcode")
        protected String postcode;
        @XmlElement(name = "State", required = true)
        @XmlSchemaType(name = "string")
        protected StateCategoryType state;

        /**
         * Gets the value of the subDwellingUnitType property.
         * 
         * @return
         *     possible object is
         *     {@link StreetAddressType.StructuredAddress.SubDwellingUnitType }
         *     
         */
        public StreetAddressType.StructuredAddress.SubDwellingUnitType getSubDwellingUnitType() {
            return subDwellingUnitType;
        }

        /**
         * Sets the value of the subDwellingUnitType property.
         * 
         * @param value
         *     allowed object is
         *     {@link StreetAddressType.StructuredAddress.SubDwellingUnitType }
         *     
         */
        public void setSubDwellingUnitType(StreetAddressType.StructuredAddress.SubDwellingUnitType value) {
            this.subDwellingUnitType = value;
        }

        /**
         * Gets the value of the level property.
         * 
         * @return
         *     possible object is
         *     {@link StreetAddressType.StructuredAddress.Level }
         *     
         */
        public StreetAddressType.StructuredAddress.Level getLevel() {
            return level;
        }

        /**
         * Sets the value of the level property.
         * 
         * @param value
         *     allowed object is
         *     {@link StreetAddressType.StructuredAddress.Level }
         *     
         */
        public void setLevel(StreetAddressType.StructuredAddress.Level value) {
            this.level = value;
        }

        /**
         * Gets the value of the complexRoad property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the complexRoad property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getComplexRoad().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link StreetAddressType.StructuredAddress.ComplexRoad }
         * 
         * 
         */
        public List<StreetAddressType.StructuredAddress.ComplexRoad> getComplexRoad() {
            if (complexRoad == null) {
                complexRoad = new ArrayList<StreetAddressType.StructuredAddress.ComplexRoad>();
            }
            return this.complexRoad;
        }

        /**
         * Gets the value of the secondaryComplex property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getSecondaryComplex() {
            return secondaryComplex;
        }

        /**
         * Sets the value of the secondaryComplex property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setSecondaryComplex(String value) {
            this.secondaryComplex = value;
        }

        /**
         * Gets the value of the addressSiteName property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getAddressSiteName() {
            return addressSiteName;
        }

        /**
         * Sets the value of the addressSiteName property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setAddressSiteName(String value) {
            this.addressSiteName = value;
        }

        /**
         * Gets the value of the road property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the road property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getRoad().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link StreetAddressType.StructuredAddress.Road }
         * 
         * 
         */
        public List<StreetAddressType.StructuredAddress.Road> getRoad() {
            if (road == null) {
                road = new ArrayList<StreetAddressType.StructuredAddress.Road>();
            }
            return this.road;
        }

        /**
         * Gets the value of the localityName property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getLocalityName() {
            return localityName;
        }

        /**
         * Sets the value of the localityName property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setLocalityName(String value) {
            this.localityName = value;
        }

        /**
         * Gets the value of the postcode property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getPostcode() {
            return postcode;
        }

        /**
         * Sets the value of the postcode property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setPostcode(String value) {
            this.postcode = value;
        }

        /**
         * Gets the value of the state property.
         * 
         * @return
         *     possible object is
         *     {@link StateCategoryType }
         *     
         */
        public StateCategoryType getState() {
            return state;
        }

        /**
         * Sets the value of the state property.
         * 
         * @param value
         *     allowed object is
         *     {@link StateCategoryType }
         *     
         */
        public void setState(StateCategoryType value) {
            this.state = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;complexContent&gt;
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *       &lt;sequence&gt;
         *         &lt;element name="RoadNumber" maxOccurs="2" minOccurs="0"&gt;
         *           &lt;complexType&gt;
         *             &lt;simpleContent&gt;
         *               &lt;extension base="&lt;http://osr.messages.gov.au/schema/2.4/&gt;textType"&gt;
         *                 &lt;attribute name="order" type="{http://osr.messages.gov.au/schema/2.4/}ordinalType" /&gt;
         *               &lt;/extension&gt;
         *             &lt;/simpleContent&gt;
         *           &lt;/complexType&gt;
         *         &lt;/element&gt;
         *         &lt;element name="RoadName" type="{http://osr.messages.gov.au/schema/2.4/}textType" minOccurs="0"/&gt;
         *         &lt;element name="RoadTypeCode" type="{http://osr.messages.gov.au/schema/2.4/}roadTypeCodeCategoryType" minOccurs="0"/&gt;
         *         &lt;element name="RoadSuffixCode" type="{http://osr.messages.gov.au/schema/2.4/}roadSuffixCodeCategoryType" minOccurs="0"/&gt;
         *       &lt;/sequence&gt;
         *       &lt;attribute name="order" type="{http://osr.messages.gov.au/schema/2.4/}ordinalType" /&gt;
         *     &lt;/restriction&gt;
         *   &lt;/complexContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "roadNumber",
            "roadName",
            "roadTypeCode",
            "roadSuffixCode"
        })
        public static class ComplexRoad {

            @XmlElement(name = "RoadNumber")
            protected List<StreetAddressType.StructuredAddress.ComplexRoad.RoadNumber> roadNumber;
            @XmlElement(name = "RoadName")
            protected String roadName;
            @XmlElement(name = "RoadTypeCode")
            @XmlSchemaType(name = "string")
            protected RoadTypeCodeCategoryType roadTypeCode;
            @XmlElement(name = "RoadSuffixCode")
            @XmlSchemaType(name = "string")
            protected RoadSuffixCodeCategoryType roadSuffixCode;
            @XmlAttribute(name = "order")
            protected BigInteger order;

            /**
             * Gets the value of the roadNumber property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the roadNumber property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getRoadNumber().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link StreetAddressType.StructuredAddress.ComplexRoad.RoadNumber }
             * 
             * 
             */
            public List<StreetAddressType.StructuredAddress.ComplexRoad.RoadNumber> getRoadNumber() {
                if (roadNumber == null) {
                    roadNumber = new ArrayList<StreetAddressType.StructuredAddress.ComplexRoad.RoadNumber>();
                }
                return this.roadNumber;
            }

            /**
             * Gets the value of the roadName property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getRoadName() {
                return roadName;
            }

            /**
             * Sets the value of the roadName property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setRoadName(String value) {
                this.roadName = value;
            }

            /**
             * Gets the value of the roadTypeCode property.
             * 
             * @return
             *     possible object is
             *     {@link RoadTypeCodeCategoryType }
             *     
             */
            public RoadTypeCodeCategoryType getRoadTypeCode() {
                return roadTypeCode;
            }

            /**
             * Sets the value of the roadTypeCode property.
             * 
             * @param value
             *     allowed object is
             *     {@link RoadTypeCodeCategoryType }
             *     
             */
            public void setRoadTypeCode(RoadTypeCodeCategoryType value) {
                this.roadTypeCode = value;
            }

            /**
             * Gets the value of the roadSuffixCode property.
             * 
             * @return
             *     possible object is
             *     {@link RoadSuffixCodeCategoryType }
             *     
             */
            public RoadSuffixCodeCategoryType getRoadSuffixCode() {
                return roadSuffixCode;
            }

            /**
             * Sets the value of the roadSuffixCode property.
             * 
             * @param value
             *     allowed object is
             *     {@link RoadSuffixCodeCategoryType }
             *     
             */
            public void setRoadSuffixCode(RoadSuffixCodeCategoryType value) {
                this.roadSuffixCode = value;
            }

            /**
             * Gets the value of the order property.
             * 
             * @return
             *     possible object is
             *     {@link BigInteger }
             *     
             */
            public BigInteger getOrder() {
                return order;
            }

            /**
             * Sets the value of the order property.
             * 
             * @param value
             *     allowed object is
             *     {@link BigInteger }
             *     
             */
            public void setOrder(BigInteger value) {
                this.order = value;
            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType&gt;
             *   &lt;simpleContent&gt;
             *     &lt;extension base="&lt;http://osr.messages.gov.au/schema/2.4/&gt;textType"&gt;
             *       &lt;attribute name="order" type="{http://osr.messages.gov.au/schema/2.4/}ordinalType" /&gt;
             *     &lt;/extension&gt;
             *   &lt;/simpleContent&gt;
             * &lt;/complexType&gt;
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "value"
            })
            public static class RoadNumber {

                @XmlValue
                protected String value;
                @XmlAttribute(name = "order")
                protected BigInteger order;

                /**
                 * Gets the value of the value property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getValue() {
                    return value;
                }

                /**
                 * Sets the value of the value property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setValue(String value) {
                    this.value = value;
                }

                /**
                 * Gets the value of the order property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link BigInteger }
                 *     
                 */
                public BigInteger getOrder() {
                    return order;
                }

                /**
                 * Sets the value of the order property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link BigInteger }
                 *     
                 */
                public void setOrder(BigInteger value) {
                    this.order = value;
                }

            }

        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;complexContent&gt;
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *       &lt;sequence&gt;
         *         &lt;element name="LevelTypeCode" type="{http://osr.messages.gov.au/schema/2.4/}levelTypeCodeCategoryType"/&gt;
         *         &lt;element name="LevelNumber" type="{http://osr.messages.gov.au/schema/2.4/}textType" minOccurs="0"/&gt;
         *       &lt;/sequence&gt;
         *     &lt;/restriction&gt;
         *   &lt;/complexContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "levelTypeCode",
            "levelNumber"
        })
        public static class Level {

            @XmlElement(name = "LevelTypeCode", required = true)
            @XmlSchemaType(name = "string")
            protected LevelTypeCodeCategoryType levelTypeCode;
            @XmlElement(name = "LevelNumber")
            protected String levelNumber;

            /**
             * Gets the value of the levelTypeCode property.
             * 
             * @return
             *     possible object is
             *     {@link LevelTypeCodeCategoryType }
             *     
             */
            public LevelTypeCodeCategoryType getLevelTypeCode() {
                return levelTypeCode;
            }

            /**
             * Sets the value of the levelTypeCode property.
             * 
             * @param value
             *     allowed object is
             *     {@link LevelTypeCodeCategoryType }
             *     
             */
            public void setLevelTypeCode(LevelTypeCodeCategoryType value) {
                this.levelTypeCode = value;
            }

            /**
             * Gets the value of the levelNumber property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getLevelNumber() {
                return levelNumber;
            }

            /**
             * Sets the value of the levelNumber property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setLevelNumber(String value) {
                this.levelNumber = value;
            }

        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;complexContent&gt;
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *       &lt;sequence&gt;
         *         &lt;element name="LotNumber" type="{http://osr.messages.gov.au/schema/2.4/}textType" minOccurs="0"/&gt;
         *         &lt;element name="RoadNumber" maxOccurs="2" minOccurs="0"&gt;
         *           &lt;complexType&gt;
         *             &lt;simpleContent&gt;
         *               &lt;extension base="&lt;http://osr.messages.gov.au/schema/2.4/&gt;textType"&gt;
         *                 &lt;attribute name="order" type="{http://osr.messages.gov.au/schema/2.4/}ordinalType" /&gt;
         *               &lt;/extension&gt;
         *             &lt;/simpleContent&gt;
         *           &lt;/complexType&gt;
         *         &lt;/element&gt;
         *         &lt;element name="RoadName" type="{http://osr.messages.gov.au/schema/2.4/}textType" minOccurs="0"/&gt;
         *         &lt;element name="RoadTypeCode" type="{http://osr.messages.gov.au/schema/2.4/}roadTypeCodeCategoryType" minOccurs="0"/&gt;
         *         &lt;element name="RoadSuffixCode" type="{http://osr.messages.gov.au/schema/2.4/}roadSuffixCodeCategoryType" minOccurs="0"/&gt;
         *       &lt;/sequence&gt;
         *       &lt;attribute name="order" type="{http://osr.messages.gov.au/schema/2.4/}ordinalType" /&gt;
         *     &lt;/restriction&gt;
         *   &lt;/complexContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "lotNumber",
            "roadNumber",
            "roadName",
            "roadTypeCode",
            "roadSuffixCode"
        })
        public static class Road {

            @XmlElement(name = "LotNumber")
            protected String lotNumber;
            @XmlElement(name = "RoadNumber")
            protected List<StreetAddressType.StructuredAddress.Road.RoadNumber> roadNumber;
            @XmlElement(name = "RoadName")
            protected String roadName;
            @XmlElement(name = "RoadTypeCode")
            @XmlSchemaType(name = "string")
            protected RoadTypeCodeCategoryType roadTypeCode;
            @XmlElement(name = "RoadSuffixCode")
            @XmlSchemaType(name = "string")
            protected RoadSuffixCodeCategoryType roadSuffixCode;
            @XmlAttribute(name = "order")
            protected BigInteger order;

            /**
             * Gets the value of the lotNumber property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getLotNumber() {
                return lotNumber;
            }

            /**
             * Sets the value of the lotNumber property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setLotNumber(String value) {
                this.lotNumber = value;
            }

            /**
             * Gets the value of the roadNumber property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the roadNumber property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getRoadNumber().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link StreetAddressType.StructuredAddress.Road.RoadNumber }
             * 
             * 
             */
            public List<StreetAddressType.StructuredAddress.Road.RoadNumber> getRoadNumber() {
                if (roadNumber == null) {
                    roadNumber = new ArrayList<StreetAddressType.StructuredAddress.Road.RoadNumber>();
                }
                return this.roadNumber;
            }

            /**
             * Gets the value of the roadName property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getRoadName() {
                return roadName;
            }

            /**
             * Sets the value of the roadName property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setRoadName(String value) {
                this.roadName = value;
            }

            /**
             * Gets the value of the roadTypeCode property.
             * 
             * @return
             *     possible object is
             *     {@link RoadTypeCodeCategoryType }
             *     
             */
            public RoadTypeCodeCategoryType getRoadTypeCode() {
                return roadTypeCode;
            }

            /**
             * Sets the value of the roadTypeCode property.
             * 
             * @param value
             *     allowed object is
             *     {@link RoadTypeCodeCategoryType }
             *     
             */
            public void setRoadTypeCode(RoadTypeCodeCategoryType value) {
                this.roadTypeCode = value;
            }

            /**
             * Gets the value of the roadSuffixCode property.
             * 
             * @return
             *     possible object is
             *     {@link RoadSuffixCodeCategoryType }
             *     
             */
            public RoadSuffixCodeCategoryType getRoadSuffixCode() {
                return roadSuffixCode;
            }

            /**
             * Sets the value of the roadSuffixCode property.
             * 
             * @param value
             *     allowed object is
             *     {@link RoadSuffixCodeCategoryType }
             *     
             */
            public void setRoadSuffixCode(RoadSuffixCodeCategoryType value) {
                this.roadSuffixCode = value;
            }

            /**
             * Gets the value of the order property.
             * 
             * @return
             *     possible object is
             *     {@link BigInteger }
             *     
             */
            public BigInteger getOrder() {
                return order;
            }

            /**
             * Sets the value of the order property.
             * 
             * @param value
             *     allowed object is
             *     {@link BigInteger }
             *     
             */
            public void setOrder(BigInteger value) {
                this.order = value;
            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType&gt;
             *   &lt;simpleContent&gt;
             *     &lt;extension base="&lt;http://osr.messages.gov.au/schema/2.4/&gt;textType"&gt;
             *       &lt;attribute name="order" type="{http://osr.messages.gov.au/schema/2.4/}ordinalType" /&gt;
             *     &lt;/extension&gt;
             *   &lt;/simpleContent&gt;
             * &lt;/complexType&gt;
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "value"
            })
            public static class RoadNumber {

                @XmlValue
                protected String value;
                @XmlAttribute(name = "order")
                protected BigInteger order;

                /**
                 * Gets the value of the value property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getValue() {
                    return value;
                }

                /**
                 * Sets the value of the value property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setValue(String value) {
                    this.value = value;
                }

                /**
                 * Gets the value of the order property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link BigInteger }
                 *     
                 */
                public BigInteger getOrder() {
                    return order;
                }

                /**
                 * Sets the value of the order property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link BigInteger }
                 *     
                 */
                public void setOrder(BigInteger value) {
                    this.order = value;
                }

            }

        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;complexContent&gt;
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *       &lt;sequence&gt;
         *         &lt;element name="UnitTypeCode" type="{http://osr.messages.gov.au/schema/2.4/}unitTypeCodeCategoryType"/&gt;
         *         &lt;element name="UnitNumber" type="{http://osr.messages.gov.au/schema/2.4/}textType"/&gt;
         *       &lt;/sequence&gt;
         *     &lt;/restriction&gt;
         *   &lt;/complexContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "unitTypeCode",
            "unitNumber"
        })
        public static class SubDwellingUnitType {

            @XmlElement(name = "UnitTypeCode", required = true)
            @XmlSchemaType(name = "string")
            protected UnitTypeCodeCategoryType unitTypeCode;
            @XmlElement(name = "UnitNumber", required = true)
            protected String unitNumber;

            /**
             * Gets the value of the unitTypeCode property.
             * 
             * @return
             *     possible object is
             *     {@link UnitTypeCodeCategoryType }
             *     
             */
            public UnitTypeCodeCategoryType getUnitTypeCode() {
                return unitTypeCode;
            }

            /**
             * Sets the value of the unitTypeCode property.
             * 
             * @param value
             *     allowed object is
             *     {@link UnitTypeCodeCategoryType }
             *     
             */
            public void setUnitTypeCode(UnitTypeCodeCategoryType value) {
                this.unitTypeCode = value;
            }

            /**
             * Gets the value of the unitNumber property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getUnitNumber() {
                return unitNumber;
            }

            /**
             * Sets the value of the unitNumber property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setUnitNumber(String value) {
                this.unitNumber = value;
            }

        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="AddressLine" maxOccurs="4"&gt;
     *           &lt;complexType&gt;
     *             &lt;simpleContent&gt;
     *               &lt;extension base="&lt;http://osr.messages.gov.au/schema/2.4/&gt;textType"&gt;
     *                 &lt;attribute name="order" type="{http://osr.messages.gov.au/schema/2.4/}ordinalType" /&gt;
     *               &lt;/extension&gt;
     *             &lt;/simpleContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "addressLine"
    })
    public static class UnstructuredAddress {

        @XmlElement(name = "AddressLine", required = true)
        protected List<StreetAddressType.UnstructuredAddress.AddressLine> addressLine;

        /**
         * Gets the value of the addressLine property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the addressLine property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getAddressLine().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link StreetAddressType.UnstructuredAddress.AddressLine }
         * 
         * 
         */
        public List<StreetAddressType.UnstructuredAddress.AddressLine> getAddressLine() {
            if (addressLine == null) {
                addressLine = new ArrayList<StreetAddressType.UnstructuredAddress.AddressLine>();
            }
            return this.addressLine;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;simpleContent&gt;
         *     &lt;extension base="&lt;http://osr.messages.gov.au/schema/2.4/&gt;textType"&gt;
         *       &lt;attribute name="order" type="{http://osr.messages.gov.au/schema/2.4/}ordinalType" /&gt;
         *     &lt;/extension&gt;
         *   &lt;/simpleContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "value"
        })
        public static class AddressLine {

            @XmlValue
            protected String value;
            @XmlAttribute(name = "order")
            protected BigInteger order;

            /**
             * Gets the value of the value property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getValue() {
                return value;
            }

            /**
             * Sets the value of the value property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setValue(String value) {
                this.value = value;
            }

            /**
             * Gets the value of the order property.
             * 
             * @return
             *     possible object is
             *     {@link BigInteger }
             *     
             */
            public BigInteger getOrder() {
                return order;
            }

            /**
             * Sets the value of the order property.
             * 
             * @param value
             *     allowed object is
             *     {@link BigInteger }
             *     
             */
            public void setOrder(BigInteger value) {
                this.order = value;
            }

        }

    }

}
