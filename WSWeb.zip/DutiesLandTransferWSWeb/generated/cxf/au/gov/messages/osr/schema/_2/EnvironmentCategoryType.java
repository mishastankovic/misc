
package au.gov.messages.osr.schema._2;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for environmentCategoryType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="environmentCategoryType"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="Development"/&gt;
 *     &lt;enumeration value="Production"/&gt;
 *     &lt;enumeration value="Test"/&gt;
 *     &lt;enumeration value="Training"/&gt;
 *     &lt;enumeration value="UAT"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "environmentCategoryType")
@XmlEnum
public enum EnvironmentCategoryType {

    @XmlEnumValue("Development")
    DEVELOPMENT("Development"),
    @XmlEnumValue("Production")
    PRODUCTION("Production"),
    @XmlEnumValue("Test")
    TEST("Test"),
    @XmlEnumValue("Training")
    TRAINING("Training"),
    UAT("UAT");
    private final String value;

    EnvironmentCategoryType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static EnvironmentCategoryType fromValue(String v) {
        for (EnvironmentCategoryType c: EnvironmentCategoryType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
