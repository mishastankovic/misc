
package au.gov.messages.osr.schema._2;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for partyDetailType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="partyDetailType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PartyId" type="{http://osr.messages.gov.au/schema/2.4/}partyReferenceType"/&gt;
 *         &lt;element name="PartyType" type="{http://osr.messages.gov.au/schema/2.4/}partyTypeCategoryType"/&gt;
 *         &lt;element name="LegalEntityName" type="{http://osr.messages.gov.au/schema/2.4/}textType"/&gt;
 *         &lt;element name="PersonFullName" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="NameTitle" type="{http://osr.messages.gov.au/schema/2.4/}nameTitleCategoryType" minOccurs="0"/&gt;
 *                   &lt;element name="GivenName" maxOccurs="unbounded"&gt;
 *                     &lt;complexType&gt;
 *                       &lt;simpleContent&gt;
 *                         &lt;extension base="&lt;http://osr.messages.gov.au/schema/2.4/&gt;textType"&gt;
 *                           &lt;attribute name="order" type="{http://osr.messages.gov.au/schema/2.4/}ordinalType" /&gt;
 *                         &lt;/extension&gt;
 *                       &lt;/simpleContent&gt;
 *                     &lt;/complexType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="FamilyName" type="{http://osr.messages.gov.au/schema/2.4/}textType" minOccurs="0"/&gt;
 *                   &lt;element name="FamilyNameOrder" type="{http://osr.messages.gov.au/schema/2.4/}familyNameOrderCategoryType" minOccurs="0"/&gt;
 *                   &lt;element name="NameSuffix" type="{http://osr.messages.gov.au/schema/2.4/}textType" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="BusinessName" type="{http://osr.messages.gov.au/schema/2.4/}textType" minOccurs="0"/&gt;
 *         &lt;element name="BusinessUnit" type="{http://osr.messages.gov.au/schema/2.4/}textType" minOccurs="0"/&gt;
 *         &lt;element name="PartyCorrespondenceAddress" type="{http://osr.messages.gov.au/schema/2.4/}deliveryAddressType" minOccurs="0"/&gt;
 *         &lt;element name="BirthDate" type="{http://osr.messages.gov.au/schema/2.4/}dateType" minOccurs="0"/&gt;
 *         &lt;element name="PartyIdentification" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="PartyIdentificationDesignation" type="{http://osr.messages.gov.au/schema/2.4/}identifierType"/&gt;
 *                   &lt;element name="PartyIdentificationName" type="{http://osr.messages.gov.au/schema/2.4/}partyIdentificationNameCategoryType"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TrustDetail" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="TrustIndicator" type="{http://osr.messages.gov.au/schema/2.4/}yesNoType"/&gt;
 *                   &lt;element name="TrustName" type="{http://osr.messages.gov.au/schema/2.4/}textType" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "partyDetailType", propOrder = {
    "partyId",
    "partyType",
    "legalEntityName",
    "personFullName",
    "businessName",
    "businessUnit",
    "partyCorrespondenceAddress",
    "birthDate",
    "partyIdentification",
    "trustDetail"
})
public class PartyDetailType {

    @XmlElement(name = "PartyId", required = true)
    protected String partyId;
    @XmlElement(name = "PartyType", required = true)
    @XmlSchemaType(name = "string")
    protected PartyTypeCategoryType partyType;
    @XmlElement(name = "LegalEntityName", required = true)
    protected String legalEntityName;
    @XmlElement(name = "PersonFullName")
    protected PartyDetailType.PersonFullName personFullName;
    @XmlElement(name = "BusinessName")
    protected String businessName;
    @XmlElement(name = "BusinessUnit")
    protected String businessUnit;
    @XmlElement(name = "PartyCorrespondenceAddress")
    protected DeliveryAddressType partyCorrespondenceAddress;
    @XmlElement(name = "BirthDate")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar birthDate;
    @XmlElement(name = "PartyIdentification")
    protected List<PartyDetailType.PartyIdentification> partyIdentification;
    @XmlElement(name = "TrustDetail")
    protected PartyDetailType.TrustDetail trustDetail;

    /**
     * Gets the value of the partyId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartyId() {
        return partyId;
    }

    /**
     * Sets the value of the partyId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartyId(String value) {
        this.partyId = value;
    }

    /**
     * Gets the value of the partyType property.
     * 
     * @return
     *     possible object is
     *     {@link PartyTypeCategoryType }
     *     
     */
    public PartyTypeCategoryType getPartyType() {
        return partyType;
    }

    /**
     * Sets the value of the partyType property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyTypeCategoryType }
     *     
     */
    public void setPartyType(PartyTypeCategoryType value) {
        this.partyType = value;
    }

    /**
     * Gets the value of the legalEntityName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLegalEntityName() {
        return legalEntityName;
    }

    /**
     * Sets the value of the legalEntityName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLegalEntityName(String value) {
        this.legalEntityName = value;
    }

    /**
     * Gets the value of the personFullName property.
     * 
     * @return
     *     possible object is
     *     {@link PartyDetailType.PersonFullName }
     *     
     */
    public PartyDetailType.PersonFullName getPersonFullName() {
        return personFullName;
    }

    /**
     * Sets the value of the personFullName property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyDetailType.PersonFullName }
     *     
     */
    public void setPersonFullName(PartyDetailType.PersonFullName value) {
        this.personFullName = value;
    }

    /**
     * Gets the value of the businessName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBusinessName() {
        return businessName;
    }

    /**
     * Sets the value of the businessName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBusinessName(String value) {
        this.businessName = value;
    }

    /**
     * Gets the value of the businessUnit property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBusinessUnit() {
        return businessUnit;
    }

    /**
     * Sets the value of the businessUnit property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBusinessUnit(String value) {
        this.businessUnit = value;
    }

    /**
     * Gets the value of the partyCorrespondenceAddress property.
     * 
     * @return
     *     possible object is
     *     {@link DeliveryAddressType }
     *     
     */
    public DeliveryAddressType getPartyCorrespondenceAddress() {
        return partyCorrespondenceAddress;
    }

    /**
     * Sets the value of the partyCorrespondenceAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeliveryAddressType }
     *     
     */
    public void setPartyCorrespondenceAddress(DeliveryAddressType value) {
        this.partyCorrespondenceAddress = value;
    }

    /**
     * Gets the value of the birthDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getBirthDate() {
        return birthDate;
    }

    /**
     * Sets the value of the birthDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setBirthDate(XMLGregorianCalendar value) {
        this.birthDate = value;
    }

    /**
     * Gets the value of the partyIdentification property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the partyIdentification property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPartyIdentification().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PartyDetailType.PartyIdentification }
     * 
     * 
     */
    public List<PartyDetailType.PartyIdentification> getPartyIdentification() {
        if (partyIdentification == null) {
            partyIdentification = new ArrayList<PartyDetailType.PartyIdentification>();
        }
        return this.partyIdentification;
    }

    /**
     * Gets the value of the trustDetail property.
     * 
     * @return
     *     possible object is
     *     {@link PartyDetailType.TrustDetail }
     *     
     */
    public PartyDetailType.TrustDetail getTrustDetail() {
        return trustDetail;
    }

    /**
     * Sets the value of the trustDetail property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyDetailType.TrustDetail }
     *     
     */
    public void setTrustDetail(PartyDetailType.TrustDetail value) {
        this.trustDetail = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="PartyIdentificationDesignation" type="{http://osr.messages.gov.au/schema/2.4/}identifierType"/&gt;
     *         &lt;element name="PartyIdentificationName" type="{http://osr.messages.gov.au/schema/2.4/}partyIdentificationNameCategoryType"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "partyIdentificationDesignation",
        "partyIdentificationName"
    })
    public static class PartyIdentification {

        @XmlElement(name = "PartyIdentificationDesignation", required = true)
        protected String partyIdentificationDesignation;
        @XmlElement(name = "PartyIdentificationName", required = true)
        @XmlSchemaType(name = "string")
        protected PartyIdentificationNameCategoryType partyIdentificationName;

        /**
         * Gets the value of the partyIdentificationDesignation property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getPartyIdentificationDesignation() {
            return partyIdentificationDesignation;
        }

        /**
         * Sets the value of the partyIdentificationDesignation property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setPartyIdentificationDesignation(String value) {
            this.partyIdentificationDesignation = value;
        }

        /**
         * Gets the value of the partyIdentificationName property.
         * 
         * @return
         *     possible object is
         *     {@link PartyIdentificationNameCategoryType }
         *     
         */
        public PartyIdentificationNameCategoryType getPartyIdentificationName() {
            return partyIdentificationName;
        }

        /**
         * Sets the value of the partyIdentificationName property.
         * 
         * @param value
         *     allowed object is
         *     {@link PartyIdentificationNameCategoryType }
         *     
         */
        public void setPartyIdentificationName(PartyIdentificationNameCategoryType value) {
            this.partyIdentificationName = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="NameTitle" type="{http://osr.messages.gov.au/schema/2.4/}nameTitleCategoryType" minOccurs="0"/&gt;
     *         &lt;element name="GivenName" maxOccurs="unbounded"&gt;
     *           &lt;complexType&gt;
     *             &lt;simpleContent&gt;
     *               &lt;extension base="&lt;http://osr.messages.gov.au/schema/2.4/&gt;textType"&gt;
     *                 &lt;attribute name="order" type="{http://osr.messages.gov.au/schema/2.4/}ordinalType" /&gt;
     *               &lt;/extension&gt;
     *             &lt;/simpleContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="FamilyName" type="{http://osr.messages.gov.au/schema/2.4/}textType" minOccurs="0"/&gt;
     *         &lt;element name="FamilyNameOrder" type="{http://osr.messages.gov.au/schema/2.4/}familyNameOrderCategoryType" minOccurs="0"/&gt;
     *         &lt;element name="NameSuffix" type="{http://osr.messages.gov.au/schema/2.4/}textType" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "nameTitle",
        "givenName",
        "familyName",
        "familyNameOrder",
        "nameSuffix"
    })
    public static class PersonFullName {

        @XmlElement(name = "NameTitle")
        protected String nameTitle;
        @XmlElement(name = "GivenName", required = true)
        protected List<PartyDetailType.PersonFullName.GivenName> givenName;
        @XmlElement(name = "FamilyName")
        protected String familyName;
        @XmlElement(name = "FamilyNameOrder")
        @XmlSchemaType(name = "string")
        protected FamilyNameOrderCategoryType familyNameOrder;
        @XmlElement(name = "NameSuffix")
        protected String nameSuffix;

        /**
         * Gets the value of the nameTitle property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getNameTitle() {
            return nameTitle;
        }

        /**
         * Sets the value of the nameTitle property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setNameTitle(String value) {
            this.nameTitle = value;
        }

        /**
         * Gets the value of the givenName property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the givenName property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getGivenName().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link PartyDetailType.PersonFullName.GivenName }
         * 
         * 
         */
        public List<PartyDetailType.PersonFullName.GivenName> getGivenName() {
            if (givenName == null) {
                givenName = new ArrayList<PartyDetailType.PersonFullName.GivenName>();
            }
            return this.givenName;
        }

        /**
         * Gets the value of the familyName property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getFamilyName() {
            return familyName;
        }

        /**
         * Sets the value of the familyName property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setFamilyName(String value) {
            this.familyName = value;
        }

        /**
         * Gets the value of the familyNameOrder property.
         * 
         * @return
         *     possible object is
         *     {@link FamilyNameOrderCategoryType }
         *     
         */
        public FamilyNameOrderCategoryType getFamilyNameOrder() {
            return familyNameOrder;
        }

        /**
         * Sets the value of the familyNameOrder property.
         * 
         * @param value
         *     allowed object is
         *     {@link FamilyNameOrderCategoryType }
         *     
         */
        public void setFamilyNameOrder(FamilyNameOrderCategoryType value) {
            this.familyNameOrder = value;
        }

        /**
         * Gets the value of the nameSuffix property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getNameSuffix() {
            return nameSuffix;
        }

        /**
         * Sets the value of the nameSuffix property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setNameSuffix(String value) {
            this.nameSuffix = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;simpleContent&gt;
         *     &lt;extension base="&lt;http://osr.messages.gov.au/schema/2.4/&gt;textType"&gt;
         *       &lt;attribute name="order" type="{http://osr.messages.gov.au/schema/2.4/}ordinalType" /&gt;
         *     &lt;/extension&gt;
         *   &lt;/simpleContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "value"
        })
        public static class GivenName {

            @XmlValue
            protected String value;
            @XmlAttribute(name = "order")
            protected BigInteger order;

            /**
             * Gets the value of the value property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getValue() {
                return value;
            }

            /**
             * Sets the value of the value property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setValue(String value) {
                this.value = value;
            }

            /**
             * Gets the value of the order property.
             * 
             * @return
             *     possible object is
             *     {@link BigInteger }
             *     
             */
            public BigInteger getOrder() {
                return order;
            }

            /**
             * Sets the value of the order property.
             * 
             * @param value
             *     allowed object is
             *     {@link BigInteger }
             *     
             */
            public void setOrder(BigInteger value) {
                this.order = value;
            }

        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="TrustIndicator" type="{http://osr.messages.gov.au/schema/2.4/}yesNoType"/&gt;
     *         &lt;element name="TrustName" type="{http://osr.messages.gov.au/schema/2.4/}textType" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "trustIndicator",
        "trustName"
    })
    public static class TrustDetail {

        @XmlElement(name = "TrustIndicator", required = true)
        protected String trustIndicator;
        @XmlElement(name = "TrustName")
        protected String trustName;

        /**
         * Gets the value of the trustIndicator property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getTrustIndicator() {
            return trustIndicator;
        }

        /**
         * Sets the value of the trustIndicator property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setTrustIndicator(String value) {
            this.trustIndicator = value;
        }

        /**
         * Gets the value of the trustName property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getTrustName() {
            return trustName;
        }

        /**
         * Sets the value of the trustName property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setTrustName(String value) {
            this.trustName = value;
        }

    }

}
