
package au.gov.messages.osr.schema._2;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for jurisdictionCategoryType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="jurisdictionCategoryType"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="ACT"/&gt;
 *     &lt;enumeration value="NSW"/&gt;
 *     &lt;enumeration value="NT"/&gt;
 *     &lt;enumeration value="QLD"/&gt;
 *     &lt;enumeration value="SA"/&gt;
 *     &lt;enumeration value="TAS"/&gt;
 *     &lt;enumeration value="VIC"/&gt;
 *     &lt;enumeration value="WA"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "jurisdictionCategoryType")
@XmlEnum
public enum JurisdictionCategoryType {

    ACT,
    NSW,
    NT,
    QLD,
    SA,
    TAS,
    VIC,
    WA;

    public String value() {
        return name();
    }

    public static JurisdictionCategoryType fromValue(String v) {
        return valueOf(v);
    }

}
