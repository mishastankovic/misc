
package au.gov.messages.osr.schema._2;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for stampDutyVerificationResponseType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="stampDutyVerificationResponseType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="MessageHeader" type="{http://osr.messages.gov.au/schema/2.4/}messageHeaderType"/&gt;
 *         &lt;element name="Jurisdiction" type="{http://osr.messages.gov.au/schema/2.4/}jurisdictionCategoryType"/&gt;
 *         &lt;element name="TransactionId" type="{http://osr.messages.gov.au/schema/2.4/}identifierType"/&gt;
 *         &lt;element name="ElnLodgementCaseId" type="{http://osr.messages.gov.au/schema/2.4/}identifierType" minOccurs="0"/&gt;
 *         &lt;element name="OsrCaseStatus" type="{http://osr.messages.gov.au/schema/2.4/}osrCaseStatusCategoryType" minOccurs="0"/&gt;
 *         &lt;element name="LodgementComplianceIndicator" type="{http://osr.messages.gov.au/schema/2.4/}yesNoType" minOccurs="0"/&gt;
 *         &lt;element name="EarliestSettlementDate" type="{http://osr.messages.gov.au/schema/2.4/}date2Type" minOccurs="0"/&gt;
 *         &lt;element name="DutyVerificationReport" type="{http://osr.messages.gov.au/schema/2.4/}dutyVerificationReportType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="DocumentAssessmentDetail" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="DocumentId" type="{http://osr.messages.gov.au/schema/2.4/}identifierType"/&gt;
 *                   &lt;element name="EvidenceDetail" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "stampDutyVerificationResponseType", propOrder = {
    "messageHeader",
    "jurisdiction",
    "transactionId",
    "elnLodgementCaseId",
    "osrCaseStatus",
    "lodgementComplianceIndicator",
    "earliestSettlementDate",
    "dutyVerificationReport",
    "documentAssessmentDetail"
})
public class StampDutyVerificationResponseType {

    @XmlElement(name = "MessageHeader", required = true)
    protected MessageHeaderType messageHeader;
    @XmlElement(name = "Jurisdiction", required = true)
    @XmlSchemaType(name = "string")
    protected JurisdictionCategoryType jurisdiction;
    @XmlElement(name = "TransactionId", required = true)
    protected String transactionId;
    @XmlElement(name = "ElnLodgementCaseId")
    protected String elnLodgementCaseId;
    @XmlElement(name = "OsrCaseStatus")
    protected String osrCaseStatus;
    @XmlElement(name = "LodgementComplianceIndicator")
    protected String lodgementComplianceIndicator;
    @XmlElement(name = "EarliestSettlementDate")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar earliestSettlementDate;
    @XmlElement(name = "DutyVerificationReport")
    protected List<DutyVerificationReportType> dutyVerificationReport;
    @XmlElement(name = "DocumentAssessmentDetail")
    protected StampDutyVerificationResponseType.DocumentAssessmentDetail documentAssessmentDetail;

    /**
     * Gets the value of the messageHeader property.
     * 
     * @return
     *     possible object is
     *     {@link MessageHeaderType }
     *     
     */
    public MessageHeaderType getMessageHeader() {
        return messageHeader;
    }

    /**
     * Sets the value of the messageHeader property.
     * 
     * @param value
     *     allowed object is
     *     {@link MessageHeaderType }
     *     
     */
    public void setMessageHeader(MessageHeaderType value) {
        this.messageHeader = value;
    }

    /**
     * Gets the value of the jurisdiction property.
     * 
     * @return
     *     possible object is
     *     {@link JurisdictionCategoryType }
     *     
     */
    public JurisdictionCategoryType getJurisdiction() {
        return jurisdiction;
    }

    /**
     * Sets the value of the jurisdiction property.
     * 
     * @param value
     *     allowed object is
     *     {@link JurisdictionCategoryType }
     *     
     */
    public void setJurisdiction(JurisdictionCategoryType value) {
        this.jurisdiction = value;
    }

    /**
     * Gets the value of the transactionId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactionId() {
        return transactionId;
    }

    /**
     * Sets the value of the transactionId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactionId(String value) {
        this.transactionId = value;
    }

    /**
     * Gets the value of the elnLodgementCaseId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getElnLodgementCaseId() {
        return elnLodgementCaseId;
    }

    /**
     * Sets the value of the elnLodgementCaseId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setElnLodgementCaseId(String value) {
        this.elnLodgementCaseId = value;
    }

    /**
     * Gets the value of the osrCaseStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOsrCaseStatus() {
        return osrCaseStatus;
    }

    /**
     * Sets the value of the osrCaseStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOsrCaseStatus(String value) {
        this.osrCaseStatus = value;
    }

    /**
     * Gets the value of the lodgementComplianceIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLodgementComplianceIndicator() {
        return lodgementComplianceIndicator;
    }

    /**
     * Sets the value of the lodgementComplianceIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLodgementComplianceIndicator(String value) {
        this.lodgementComplianceIndicator = value;
    }

    /**
     * Gets the value of the earliestSettlementDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getEarliestSettlementDate() {
        return earliestSettlementDate;
    }

    /**
     * Sets the value of the earliestSettlementDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setEarliestSettlementDate(XMLGregorianCalendar value) {
        this.earliestSettlementDate = value;
    }

    /**
     * Gets the value of the dutyVerificationReport property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the dutyVerificationReport property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDutyVerificationReport().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DutyVerificationReportType }
     * 
     * 
     */
    public List<DutyVerificationReportType> getDutyVerificationReport() {
        if (dutyVerificationReport == null) {
            dutyVerificationReport = new ArrayList<DutyVerificationReportType>();
        }
        return this.dutyVerificationReport;
    }

    /**
     * Gets the value of the documentAssessmentDetail property.
     * 
     * @return
     *     possible object is
     *     {@link StampDutyVerificationResponseType.DocumentAssessmentDetail }
     *     
     */
    public StampDutyVerificationResponseType.DocumentAssessmentDetail getDocumentAssessmentDetail() {
        return documentAssessmentDetail;
    }

    /**
     * Sets the value of the documentAssessmentDetail property.
     * 
     * @param value
     *     allowed object is
     *     {@link StampDutyVerificationResponseType.DocumentAssessmentDetail }
     *     
     */
    public void setDocumentAssessmentDetail(StampDutyVerificationResponseType.DocumentAssessmentDetail value) {
        this.documentAssessmentDetail = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="DocumentId" type="{http://osr.messages.gov.au/schema/2.4/}identifierType"/&gt;
     *         &lt;element name="EvidenceDetail" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "documentId",
        "evidenceDetail"
    })
    public static class DocumentAssessmentDetail {

        @XmlElement(name = "DocumentId", required = true)
        protected String documentId;
        @XmlElement(name = "EvidenceDetail")
        protected byte[] evidenceDetail;

        /**
         * Gets the value of the documentId property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getDocumentId() {
            return documentId;
        }

        /**
         * Sets the value of the documentId property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setDocumentId(String value) {
            this.documentId = value;
        }

        /**
         * Gets the value of the evidenceDetail property.
         * 
         * @return
         *     possible object is
         *     byte[]
         */
        public byte[] getEvidenceDetail() {
            return evidenceDetail;
        }

        /**
         * Sets the value of the evidenceDetail property.
         * 
         * @param value
         *     allowed object is
         *     byte[]
         */
        public void setEvidenceDetail(byte[] value) {
            this.evidenceDetail = value;
        }

    }

}
