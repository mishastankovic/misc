@javax.xml.bind.annotation.XmlSchema(namespace = "http://osr.messages.gov.au/schema/2.4/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package au.gov.messages.osr.schema._2;
