
package au.gov.messages.osr.schema._2;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for proprietorGroupTypeCategoryType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="proprietorGroupTypeCategoryType"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="Joint Tenants Inter-se"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "proprietorGroupTypeCategoryType")
@XmlEnum
public enum ProprietorGroupTypeCategoryType {

    @XmlEnumValue("Joint Tenants Inter-se")
    JOINT_TENANTS_INTER_SE("Joint Tenants Inter-se");
    private final String value;

    ProprietorGroupTypeCategoryType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ProprietorGroupTypeCategoryType fromValue(String v) {
        for (ProprietorGroupTypeCategoryType c: ProprietorGroupTypeCategoryType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
