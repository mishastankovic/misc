
package au.gov.messages.osr.schema._2;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for postalDeliveryTypeCodeCategoryType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="postalDeliveryTypeCodeCategoryType"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="CARE PO"/&gt;
 *     &lt;enumeration value="CCARE PO"/&gt;
 *     &lt;enumeration value="CMA"/&gt;
 *     &lt;enumeration value="CMB"/&gt;
 *     &lt;enumeration value="GPO BAG"/&gt;
 *     &lt;enumeration value="GPO BOX"/&gt;
 *     &lt;enumeration value="LOCKED BAG"/&gt;
 *     &lt;enumeration value="MS"/&gt;
 *     &lt;enumeration value="PO BOX"/&gt;
 *     &lt;enumeration value="PRIVATE BAG"/&gt;
 *     &lt;enumeration value="RBN"/&gt;
 *     &lt;enumeration value="RSD"/&gt;
 *     &lt;enumeration value="RMB"/&gt;
 *     &lt;enumeration value="RMS"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "postalDeliveryTypeCodeCategoryType")
@XmlEnum
public enum PostalDeliveryTypeCodeCategoryType {


    /**
     * Poste Restante (also known as Care-of Post Office)
     * 
     */
    @XmlEnumValue("CARE PO")
    CARE_PO("CARE PO"),

    /**
     * Care-of Post Office (also known as Poste Restante)
     * 
     */
    @XmlEnumValue("CCARE PO")
    CCARE_PO("CCARE PO"),

    /**
     * Community Mail Agent
     * 
     */
    CMA("CMA"),

    /**
     * Community Mail Bag
     * 
     */
    CMB("CMB"),

    /**
     * GPO Bag [Vic Augmentation]
     * 
     */
    @XmlEnumValue("GPO BAG")
    GPO_BAG("GPO BAG"),

    /**
     * General Post Office Box
     * 
     */
    @XmlEnumValue("GPO BOX")
    GPO_BOX("GPO BOX"),

    /**
     * Locked Mail Bag Service
     * 
     */
    @XmlEnumValue("LOCKED BAG")
    LOCKED_BAG("LOCKED BAG"),

    /**
     * Mail Service
     * 
     */
    MS("MS"),

    /**
     * Post Office Box
     * 
     */
    @XmlEnumValue("PO BOX")
    PO_BOX("PO BOX"),

    /**
     * Private Mail Bag Service
     * 
     */
    @XmlEnumValue("PRIVATE BAG")
    PRIVATE_BAG("PRIVATE BAG"),

    /**
     * Rural Box Number [Vic Augmentation]
     * 
     */
    RBN("RBN"),

    /**
     * Roadside Delivery
     * 
     */
    RSD("RSD"),

    /**
     * Roadside Mail Box/Bag
     * 
     */
    RMB("RMB"),

    /**
     * Roadside Mail Service
     * 
     */
    RMS("RMS");
    private final String value;

    PostalDeliveryTypeCodeCategoryType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static PostalDeliveryTypeCodeCategoryType fromValue(String v) {
        for (PostalDeliveryTypeCodeCategoryType c: PostalDeliveryTypeCodeCategoryType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
