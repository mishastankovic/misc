
package au.gov.messages.osr.schema._2;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for stampDutyVerificationRequestType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="stampDutyVerificationRequestType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="MessageHeader" type="{http://osr.messages.gov.au/schema/2.4/}messageHeaderType"/&gt;
 *         &lt;element name="Jurisdiction" type="{http://osr.messages.gov.au/schema/2.4/}jurisdictionCategoryType"/&gt;
 *         &lt;element name="TransactionId" type="{http://osr.messages.gov.au/schema/2.4/}identifierType" minOccurs="0"/&gt;
 *         &lt;element name="ElnLodgementCaseId" type="{http://osr.messages.gov.au/schema/2.4/}identifierType" minOccurs="0"/&gt;
 *         &lt;element name="SubscriberDetails" type="{http://osr.messages.gov.au/schema/2.4/}subscriberDetailsType"/&gt;
 *         &lt;element name="DocumentData" type="{http://osr.messages.gov.au/schema/2.4/}documentDataType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="InvolvedParty" type="{http://osr.messages.gov.au/schema/2.4/}partyDetailType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="IntendedSettlementDate" type="{http://osr.messages.gov.au/schema/2.4/}dateType" minOccurs="0"/&gt;
 *         &lt;element name="IntendedLodgementDate" type="{http://osr.messages.gov.au/schema/2.4/}dateType" minOccurs="0"/&gt;
 *         &lt;element name="ContractForSaleDate" type="{http://osr.messages.gov.au/schema/2.4/}dateType" minOccurs="0"/&gt;
 *         &lt;element name="SettlementStatus" type="{http://osr.messages.gov.au/schema/2.4/}settlementStatusCategoryType"/&gt;
 *         &lt;element name="ActionRequested" type="{http://osr.messages.gov.au/schema/2.4/}actionRequestedCategoryType" minOccurs="0"/&gt;
 *         &lt;element name="PaymentMethod" type="{http://osr.messages.gov.au/schema/2.4/}paymentMethodCategoryType" minOccurs="0"/&gt;
 *         &lt;element name="AdditionalPaymentDetail" type="{http://osr.messages.gov.au/schema/2.4/}additionalPaymentDetailCategoryType" minOccurs="0"/&gt;
 *         &lt;element name="CounterpartDetail" type="{http://osr.messages.gov.au/schema/2.4/}counterpartDetailType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "stampDutyVerificationRequestType", propOrder = {
    "messageHeader",
    "jurisdiction",
    "transactionId",
    "elnLodgementCaseId",
    "subscriberDetails",
    "documentData",
    "involvedParty",
    "intendedSettlementDate",
    "intendedLodgementDate",
    "contractForSaleDate",
    "settlementStatus",
    "actionRequested",
    "paymentMethod",
    "additionalPaymentDetail",
    "counterpartDetail"
})
public class StampDutyVerificationRequestType {

    @XmlElement(name = "MessageHeader", required = true)
    protected MessageHeaderType messageHeader;
    @XmlElement(name = "Jurisdiction", required = true)
    @XmlSchemaType(name = "string")
    protected JurisdictionCategoryType jurisdiction;
    @XmlElement(name = "TransactionId")
    protected String transactionId;
    @XmlElement(name = "ElnLodgementCaseId")
    protected String elnLodgementCaseId;
    @XmlElement(name = "SubscriberDetails", required = true)
    protected SubscriberDetailsType subscriberDetails;
    @XmlElement(name = "DocumentData")
    protected List<DocumentDataType> documentData;
    @XmlElement(name = "InvolvedParty")
    protected List<PartyDetailType> involvedParty;
    @XmlElement(name = "IntendedSettlementDate")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar intendedSettlementDate;
    @XmlElement(name = "IntendedLodgementDate")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar intendedLodgementDate;
    @XmlElement(name = "ContractForSaleDate")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar contractForSaleDate;
    @XmlElement(name = "SettlementStatus", required = true)
    @XmlSchemaType(name = "string")
    protected SettlementStatusCategoryType settlementStatus;
    @XmlElement(name = "ActionRequested")
    protected String actionRequested;
    @XmlElement(name = "PaymentMethod")
    @XmlSchemaType(name = "string")
    protected PaymentMethodCategoryType paymentMethod;
    @XmlElement(name = "AdditionalPaymentDetail")
    protected String additionalPaymentDetail;
    @XmlElement(name = "CounterpartDetail")
    protected List<CounterpartDetailType> counterpartDetail;

    /**
     * Gets the value of the messageHeader property.
     * 
     * @return
     *     possible object is
     *     {@link MessageHeaderType }
     *     
     */
    public MessageHeaderType getMessageHeader() {
        return messageHeader;
    }

    /**
     * Sets the value of the messageHeader property.
     * 
     * @param value
     *     allowed object is
     *     {@link MessageHeaderType }
     *     
     */
    public void setMessageHeader(MessageHeaderType value) {
        this.messageHeader = value;
    }

    /**
     * Gets the value of the jurisdiction property.
     * 
     * @return
     *     possible object is
     *     {@link JurisdictionCategoryType }
     *     
     */
    public JurisdictionCategoryType getJurisdiction() {
        return jurisdiction;
    }

    /**
     * Sets the value of the jurisdiction property.
     * 
     * @param value
     *     allowed object is
     *     {@link JurisdictionCategoryType }
     *     
     */
    public void setJurisdiction(JurisdictionCategoryType value) {
        this.jurisdiction = value;
    }

    /**
     * Gets the value of the transactionId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactionId() {
        return transactionId;
    }

    /**
     * Sets the value of the transactionId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactionId(String value) {
        this.transactionId = value;
    }

    /**
     * Gets the value of the elnLodgementCaseId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getElnLodgementCaseId() {
        return elnLodgementCaseId;
    }

    /**
     * Sets the value of the elnLodgementCaseId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setElnLodgementCaseId(String value) {
        this.elnLodgementCaseId = value;
    }

    /**
     * Gets the value of the subscriberDetails property.
     * 
     * @return
     *     possible object is
     *     {@link SubscriberDetailsType }
     *     
     */
    public SubscriberDetailsType getSubscriberDetails() {
        return subscriberDetails;
    }

    /**
     * Sets the value of the subscriberDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link SubscriberDetailsType }
     *     
     */
    public void setSubscriberDetails(SubscriberDetailsType value) {
        this.subscriberDetails = value;
    }

    /**
     * Gets the value of the documentData property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the documentData property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDocumentData().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DocumentDataType }
     * 
     * 
     */
    public List<DocumentDataType> getDocumentData() {
        if (documentData == null) {
            documentData = new ArrayList<DocumentDataType>();
        }
        return this.documentData;
    }

    /**
     * Gets the value of the involvedParty property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the involvedParty property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInvolvedParty().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PartyDetailType }
     * 
     * 
     */
    public List<PartyDetailType> getInvolvedParty() {
        if (involvedParty == null) {
            involvedParty = new ArrayList<PartyDetailType>();
        }
        return this.involvedParty;
    }

    /**
     * Gets the value of the intendedSettlementDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getIntendedSettlementDate() {
        return intendedSettlementDate;
    }

    /**
     * Sets the value of the intendedSettlementDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setIntendedSettlementDate(XMLGregorianCalendar value) {
        this.intendedSettlementDate = value;
    }

    /**
     * Gets the value of the intendedLodgementDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getIntendedLodgementDate() {
        return intendedLodgementDate;
    }

    /**
     * Sets the value of the intendedLodgementDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setIntendedLodgementDate(XMLGregorianCalendar value) {
        this.intendedLodgementDate = value;
    }

    /**
     * Gets the value of the contractForSaleDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getContractForSaleDate() {
        return contractForSaleDate;
    }

    /**
     * Sets the value of the contractForSaleDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setContractForSaleDate(XMLGregorianCalendar value) {
        this.contractForSaleDate = value;
    }

    /**
     * Gets the value of the settlementStatus property.
     * 
     * @return
     *     possible object is
     *     {@link SettlementStatusCategoryType }
     *     
     */
    public SettlementStatusCategoryType getSettlementStatus() {
        return settlementStatus;
    }

    /**
     * Sets the value of the settlementStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link SettlementStatusCategoryType }
     *     
     */
    public void setSettlementStatus(SettlementStatusCategoryType value) {
        this.settlementStatus = value;
    }

    /**
     * Gets the value of the actionRequested property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getActionRequested() {
        return actionRequested;
    }

    /**
     * Sets the value of the actionRequested property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setActionRequested(String value) {
        this.actionRequested = value;
    }

    /**
     * Gets the value of the paymentMethod property.
     * 
     * @return
     *     possible object is
     *     {@link PaymentMethodCategoryType }
     *     
     */
    public PaymentMethodCategoryType getPaymentMethod() {
        return paymentMethod;
    }

    /**
     * Sets the value of the paymentMethod property.
     * 
     * @param value
     *     allowed object is
     *     {@link PaymentMethodCategoryType }
     *     
     */
    public void setPaymentMethod(PaymentMethodCategoryType value) {
        this.paymentMethod = value;
    }

    /**
     * Gets the value of the additionalPaymentDetail property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdditionalPaymentDetail() {
        return additionalPaymentDetail;
    }

    /**
     * Sets the value of the additionalPaymentDetail property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdditionalPaymentDetail(String value) {
        this.additionalPaymentDetail = value;
    }

    /**
     * Gets the value of the counterpartDetail property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the counterpartDetail property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCounterpartDetail().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CounterpartDetailType }
     * 
     * 
     */
    public List<CounterpartDetailType> getCounterpartDetail() {
        if (counterpartDetail == null) {
            counterpartDetail = new ArrayList<CounterpartDetailType>();
        }
        return this.counterpartDetail;
    }

}
