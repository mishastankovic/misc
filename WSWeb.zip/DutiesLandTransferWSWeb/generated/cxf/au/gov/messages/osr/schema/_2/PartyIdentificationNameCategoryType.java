
package au.gov.messages.osr.schema._2;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for partyIdentificationNameCategoryType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="partyIdentificationNameCategoryType"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="ABN"/&gt;
 *     &lt;enumeration value="ACLN"/&gt;
 *     &lt;enumeration value="ACN"/&gt;
 *     &lt;enumeration value="ARBN"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "partyIdentificationNameCategoryType")
@XmlEnum
public enum PartyIdentificationNameCategoryType {

    ABN,
    ACLN,
    ACN,
    ARBN;

    public String value() {
        return name();
    }

    public static PartyIdentificationNameCategoryType fromValue(String v) {
        return valueOf(v);
    }

}
