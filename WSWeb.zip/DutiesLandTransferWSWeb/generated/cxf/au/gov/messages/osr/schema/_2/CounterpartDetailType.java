
package au.gov.messages.osr.schema._2;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for counterpartDetailType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="counterpartDetailType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CounterpartId" type="{http://osr.messages.gov.au/schema/2.4/}identifierType"/&gt;
 *         &lt;element name="SigningPartyRole" type="{http://osr.messages.gov.au/schema/2.4/}partyRoleCategoryType" minOccurs="0"/&gt;
 *         &lt;element name="CounterpartNecdsVersion" type="{http://osr.messages.gov.au/schema/2.4/}textType" minOccurs="0"/&gt;
 *         &lt;element name="Counterpart" type="{http://www.w3.org/2001/XMLSchema}base64Binary"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "counterpartDetailType", propOrder = {
    "counterpartId",
    "signingPartyRole",
    "counterpartNecdsVersion",
    "counterpart"
})
public class CounterpartDetailType {

    @XmlElement(name = "CounterpartId", required = true)
    protected String counterpartId;
    @XmlElement(name = "SigningPartyRole")
    @XmlSchemaType(name = "string")
    protected PartyRoleCategoryType signingPartyRole;
    @XmlElement(name = "CounterpartNecdsVersion")
    protected String counterpartNecdsVersion;
    @XmlElement(name = "Counterpart", required = true)
    protected byte[] counterpart;

    /**
     * Gets the value of the counterpartId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCounterpartId() {
        return counterpartId;
    }

    /**
     * Sets the value of the counterpartId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCounterpartId(String value) {
        this.counterpartId = value;
    }

    /**
     * Gets the value of the signingPartyRole property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleCategoryType }
     *     
     */
    public PartyRoleCategoryType getSigningPartyRole() {
        return signingPartyRole;
    }

    /**
     * Sets the value of the signingPartyRole property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleCategoryType }
     *     
     */
    public void setSigningPartyRole(PartyRoleCategoryType value) {
        this.signingPartyRole = value;
    }

    /**
     * Gets the value of the counterpartNecdsVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCounterpartNecdsVersion() {
        return counterpartNecdsVersion;
    }

    /**
     * Sets the value of the counterpartNecdsVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCounterpartNecdsVersion(String value) {
        this.counterpartNecdsVersion = value;
    }

    /**
     * Gets the value of the counterpart property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getCounterpart() {
        return counterpart;
    }

    /**
     * Sets the value of the counterpart property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setCounterpart(byte[] value) {
        this.counterpart = value;
    }

}
