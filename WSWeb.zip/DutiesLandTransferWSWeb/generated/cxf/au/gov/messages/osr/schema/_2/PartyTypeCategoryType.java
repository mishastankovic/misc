
package au.gov.messages.osr.schema._2;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for partyTypeCategoryType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="partyTypeCategoryType"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="Indeterminate"/&gt;
 *     &lt;enumeration value="Natural Person"/&gt;
 *     &lt;enumeration value="Partnership"/&gt;
 *     &lt;enumeration value="Organisation"/&gt;
 *     &lt;enumeration value="Sole Trader"/&gt;
 *     &lt;enumeration value="Individual"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "partyTypeCategoryType")
@XmlEnum
public enum PartyTypeCategoryType {

    @XmlEnumValue("Indeterminate")
    INDETERMINATE("Indeterminate"),
    @XmlEnumValue("Natural Person")
    NATURAL_PERSON("Natural Person"),
    @XmlEnumValue("Partnership")
    PARTNERSHIP("Partnership"),
    @XmlEnumValue("Organisation")
    ORGANISATION("Organisation"),
    @XmlEnumValue("Sole Trader")
    SOLE_TRADER("Sole Trader"),
    @XmlEnumValue("Individual")
    INDIVIDUAL("Individual");
    private final String value;

    PartyTypeCategoryType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static PartyTypeCategoryType fromValue(String v) {
        for (PartyTypeCategoryType c: PartyTypeCategoryType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
