
package au.gov.messages.osr.schema._2;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for roadSuffixCodeCategoryType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="roadSuffixCodeCategoryType"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="CN"/&gt;
 *     &lt;enumeration value="DV"/&gt;
 *     &lt;enumeration value="E"/&gt;
 *     &lt;enumeration value="EX"/&gt;
 *     &lt;enumeration value="IN"/&gt;
 *     &lt;enumeration value="LR"/&gt;
 *     &lt;enumeration value="MA"/&gt;
 *     &lt;enumeration value="N"/&gt;
 *     &lt;enumeration value="NE"/&gt;
 *     &lt;enumeration value="NW"/&gt;
 *     &lt;enumeration value="OF"/&gt;
 *     &lt;enumeration value="ON"/&gt;
 *     &lt;enumeration value="OU"/&gt;
 *     &lt;enumeration value="S"/&gt;
 *     &lt;enumeration value="SE"/&gt;
 *     &lt;enumeration value="SW"/&gt;
 *     &lt;enumeration value="UP"/&gt;
 *     &lt;enumeration value="W"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "roadSuffixCodeCategoryType")
@XmlEnum
public enum RoadSuffixCodeCategoryType {


    /**
     * Central [AS4590-2006]
     * 
     */
    CN,

    /**
     * Deviation [Vic Augmentation]
     * 
     */
    DV,

    /**
     * East [AS4590-2006]
     * 
     */
    E,

    /**
     * Extension [AS4590-2006]
     * 
     */
    EX,

    /**
     * Inner [Vic Augmentation]
     * 
     */
    IN,

    /**
     * Lower [AS4590-2006]
     * 
     */
    LR,

    /**
     * Mall [Vic Augmentation]
     * 
     */
    MA,

    /**
     * North [AS4590-2006]
     * 
     */
    N,

    /**
     * North East [AS4590-2006]
     * 
     */
    NE,

    /**
     * North West [AS4590-2006]
     * 
     */
    NW,

    /**
     * Off [Vic Augmentation]
     * 
     */
    OF,

    /**
     * On [Vic Augmentation]
     * 
     */
    ON,

    /**
     * Outer [Vic Augmentation]
     * 
     */
    OU,

    /**
     * South [AS4590-2006]
     * 
     */
    S,

    /**
     * South East [AS4590-2006]
     * 
     */
    SE,

    /**
     * South West [AS4590-2006]
     * 
     */
    SW,

    /**
     * Upper [AS4590-2006]
     * 
     */
    UP,

    /**
     * West [AS4590-2006]
     * 
     */
    W;

    public String value() {
        return name();
    }

    public static RoadSuffixCodeCategoryType fromValue(String v) {
        return valueOf(v);
    }

}
