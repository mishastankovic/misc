
package au.gov.messages.osr.schema._2;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for dutyVerificationReportType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="dutyVerificationReportType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="IssueTimestamp" type="{http://osr.messages.gov.au/schema/2.4/}timestampType"/&gt;
 *         &lt;element name="ComplianceIndicator" type="{http://osr.messages.gov.au/schema/2.4/}yesNoType"/&gt;
 *         &lt;element name="AssessmentNumber" type="{http://osr.messages.gov.au/schema/2.4/}identifierType" minOccurs="0"/&gt;
 *         &lt;element name="CommitmentToPay" type="{http://osr.messages.gov.au/schema/2.4/}yesNoType" minOccurs="0"/&gt;
 *         &lt;element name="PaymentStatus" type="{http://osr.messages.gov.au/schema/2.4/}paymentStatusType" minOccurs="0"/&gt;
 *         &lt;element name="EftPaymentReference" type="{http://osr.messages.gov.au/schema/2.4/}paymentReferenceType" minOccurs="0"/&gt;
 *         &lt;element name="DisbursementAccount" type="{http://osr.messages.gov.au/schema/2.4/}disbursementAccountType" minOccurs="0"/&gt;
 *         &lt;element name="DutyAssessedAmount" type="{http://osr.messages.gov.au/schema/2.4/}monetaryAmountType" minOccurs="0"/&gt;
 *         &lt;element name="DutyAmountPayable" type="{http://osr.messages.gov.au/schema/2.4/}monetaryAmountType" minOccurs="0"/&gt;
 *         &lt;element name="UtiAmount" type="{http://osr.messages.gov.au/schema/2.4/}monetaryAmountType" minOccurs="0"/&gt;
 *         &lt;element name="PenaltyTax" type="{http://osr.messages.gov.au/schema/2.4/}monetaryAmountType" minOccurs="0"/&gt;
 *         &lt;element name="ForeignOwnershipSurcharge" type="{http://osr.messages.gov.au/schema/2.4/}monetaryAmountType" minOccurs="0"/&gt;
 *         &lt;element name="DutiableValue" type="{http://osr.messages.gov.au/schema/2.4/}monetaryAmountType" minOccurs="0"/&gt;
 *         &lt;element name="CertificateIssueDate" type="{http://osr.messages.gov.au/schema/2.4/}dateType" minOccurs="0"/&gt;
 *         &lt;element name="ContractForSaleDate" type="{http://osr.messages.gov.au/schema/2.4/}dateType" minOccurs="0"/&gt;
 *         &lt;element name="VgoValuedIndicator" type="{http://osr.messages.gov.au/schema/2.4/}yesNoType" minOccurs="0"/&gt;
 *         &lt;element name="DutyExemptionFlag" type="{http://osr.messages.gov.au/schema/2.4/}yesNoType" minOccurs="0"/&gt;
 *         &lt;element name="DutyExemptionReason" type="{http://osr.messages.gov.au/schema/2.4/}dutyExemptionCategoryType" minOccurs="0"/&gt;
 *         &lt;element name="NominalDutyReason" type="{http://osr.messages.gov.au/schema/2.4/}nominalDutyReasonType" minOccurs="0"/&gt;
 *         &lt;element name="DutyComplianceDetail" type="{http://osr.messages.gov.au/schema/2.4/}dutyComplianceType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="DocumentId" type="{http://osr.messages.gov.au/schema/2.4/}identifierType" minOccurs="0"/&gt;
 *         &lt;element name="EvidenceDetail" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "dutyVerificationReportType", propOrder = {
    "issueTimestamp",
    "complianceIndicator",
    "assessmentNumber",
    "commitmentToPay",
    "paymentStatus",
    "eftPaymentReference",
    "disbursementAccount",
    "dutyAssessedAmount",
    "dutyAmountPayable",
    "utiAmount",
    "penaltyTax",
    "foreignOwnershipSurcharge",
    "dutiableValue",
    "certificateIssueDate",
    "contractForSaleDate",
    "vgoValuedIndicator",
    "dutyExemptionFlag",
    "dutyExemptionReason",
    "nominalDutyReason",
    "dutyComplianceDetail",
    "documentId",
    "evidenceDetail"
})
public class DutyVerificationReportType {

    @XmlElement(name = "IssueTimestamp", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar issueTimestamp;
    @XmlElement(name = "ComplianceIndicator", required = true)
    protected String complianceIndicator;
    @XmlElement(name = "AssessmentNumber")
    protected String assessmentNumber;
    @XmlElement(name = "CommitmentToPay")
    protected String commitmentToPay;
    @XmlElement(name = "PaymentStatus")
    @XmlSchemaType(name = "string")
    protected PaymentStatusType paymentStatus;
    @XmlElement(name = "EftPaymentReference")
    protected String eftPaymentReference;
    @XmlElement(name = "DisbursementAccount")
    protected DisbursementAccountType disbursementAccount;
    @XmlElement(name = "DutyAssessedAmount")
    protected BigDecimal dutyAssessedAmount;
    @XmlElement(name = "DutyAmountPayable")
    protected BigDecimal dutyAmountPayable;
    @XmlElement(name = "UtiAmount")
    protected BigDecimal utiAmount;
    @XmlElement(name = "PenaltyTax")
    protected BigDecimal penaltyTax;
    @XmlElement(name = "ForeignOwnershipSurcharge")
    protected BigDecimal foreignOwnershipSurcharge;
    @XmlElement(name = "DutiableValue")
    protected BigDecimal dutiableValue;
    @XmlElement(name = "CertificateIssueDate")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar certificateIssueDate;
    @XmlElement(name = "ContractForSaleDate")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar contractForSaleDate;
    @XmlElement(name = "VgoValuedIndicator")
    protected String vgoValuedIndicator;
    @XmlElement(name = "DutyExemptionFlag")
    protected String dutyExemptionFlag;
    @XmlElement(name = "DutyExemptionReason")
    protected String dutyExemptionReason;
    @XmlElement(name = "NominalDutyReason")
    protected String nominalDutyReason;
    @XmlElement(name = "DutyComplianceDetail")
    protected List<DutyComplianceType> dutyComplianceDetail;
    @XmlElement(name = "DocumentId")
    protected String documentId;
    @XmlElement(name = "EvidenceDetail")
    protected byte[] evidenceDetail;

    /**
     * Gets the value of the issueTimestamp property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getIssueTimestamp() {
        return issueTimestamp;
    }

    /**
     * Sets the value of the issueTimestamp property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setIssueTimestamp(XMLGregorianCalendar value) {
        this.issueTimestamp = value;
    }

    /**
     * Gets the value of the complianceIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getComplianceIndicator() {
        return complianceIndicator;
    }

    /**
     * Sets the value of the complianceIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setComplianceIndicator(String value) {
        this.complianceIndicator = value;
    }

    /**
     * Gets the value of the assessmentNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAssessmentNumber() {
        return assessmentNumber;
    }

    /**
     * Sets the value of the assessmentNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAssessmentNumber(String value) {
        this.assessmentNumber = value;
    }

    /**
     * Gets the value of the commitmentToPay property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCommitmentToPay() {
        return commitmentToPay;
    }

    /**
     * Sets the value of the commitmentToPay property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCommitmentToPay(String value) {
        this.commitmentToPay = value;
    }

    /**
     * Gets the value of the paymentStatus property.
     * 
     * @return
     *     possible object is
     *     {@link PaymentStatusType }
     *     
     */
    public PaymentStatusType getPaymentStatus() {
        return paymentStatus;
    }

    /**
     * Sets the value of the paymentStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link PaymentStatusType }
     *     
     */
    public void setPaymentStatus(PaymentStatusType value) {
        this.paymentStatus = value;
    }

    /**
     * Gets the value of the eftPaymentReference property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEftPaymentReference() {
        return eftPaymentReference;
    }

    /**
     * Sets the value of the eftPaymentReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEftPaymentReference(String value) {
        this.eftPaymentReference = value;
    }

    /**
     * Gets the value of the disbursementAccount property.
     * 
     * @return
     *     possible object is
     *     {@link DisbursementAccountType }
     *     
     */
    public DisbursementAccountType getDisbursementAccount() {
        return disbursementAccount;
    }

    /**
     * Sets the value of the disbursementAccount property.
     * 
     * @param value
     *     allowed object is
     *     {@link DisbursementAccountType }
     *     
     */
    public void setDisbursementAccount(DisbursementAccountType value) {
        this.disbursementAccount = value;
    }

    /**
     * Gets the value of the dutyAssessedAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getDutyAssessedAmount() {
        return dutyAssessedAmount;
    }

    /**
     * Sets the value of the dutyAssessedAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setDutyAssessedAmount(BigDecimal value) {
        this.dutyAssessedAmount = value;
    }

    /**
     * Gets the value of the dutyAmountPayable property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getDutyAmountPayable() {
        return dutyAmountPayable;
    }

    /**
     * Sets the value of the dutyAmountPayable property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setDutyAmountPayable(BigDecimal value) {
        this.dutyAmountPayable = value;
    }

    /**
     * Gets the value of the utiAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getUtiAmount() {
        return utiAmount;
    }

    /**
     * Sets the value of the utiAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setUtiAmount(BigDecimal value) {
        this.utiAmount = value;
    }

    /**
     * Gets the value of the penaltyTax property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getPenaltyTax() {
        return penaltyTax;
    }

    /**
     * Sets the value of the penaltyTax property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setPenaltyTax(BigDecimal value) {
        this.penaltyTax = value;
    }

    /**
     * Gets the value of the foreignOwnershipSurcharge property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getForeignOwnershipSurcharge() {
        return foreignOwnershipSurcharge;
    }

    /**
     * Sets the value of the foreignOwnershipSurcharge property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setForeignOwnershipSurcharge(BigDecimal value) {
        this.foreignOwnershipSurcharge = value;
    }

    /**
     * Gets the value of the dutiableValue property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getDutiableValue() {
        return dutiableValue;
    }

    /**
     * Sets the value of the dutiableValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setDutiableValue(BigDecimal value) {
        this.dutiableValue = value;
    }

    /**
     * Gets the value of the certificateIssueDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCertificateIssueDate() {
        return certificateIssueDate;
    }

    /**
     * Sets the value of the certificateIssueDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCertificateIssueDate(XMLGregorianCalendar value) {
        this.certificateIssueDate = value;
    }

    /**
     * Gets the value of the contractForSaleDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getContractForSaleDate() {
        return contractForSaleDate;
    }

    /**
     * Sets the value of the contractForSaleDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setContractForSaleDate(XMLGregorianCalendar value) {
        this.contractForSaleDate = value;
    }

    /**
     * Gets the value of the vgoValuedIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVgoValuedIndicator() {
        return vgoValuedIndicator;
    }

    /**
     * Sets the value of the vgoValuedIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVgoValuedIndicator(String value) {
        this.vgoValuedIndicator = value;
    }

    /**
     * Gets the value of the dutyExemptionFlag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDutyExemptionFlag() {
        return dutyExemptionFlag;
    }

    /**
     * Sets the value of the dutyExemptionFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDutyExemptionFlag(String value) {
        this.dutyExemptionFlag = value;
    }

    /**
     * Gets the value of the dutyExemptionReason property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDutyExemptionReason() {
        return dutyExemptionReason;
    }

    /**
     * Sets the value of the dutyExemptionReason property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDutyExemptionReason(String value) {
        this.dutyExemptionReason = value;
    }

    /**
     * Gets the value of the nominalDutyReason property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNominalDutyReason() {
        return nominalDutyReason;
    }

    /**
     * Sets the value of the nominalDutyReason property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNominalDutyReason(String value) {
        this.nominalDutyReason = value;
    }

    /**
     * Gets the value of the dutyComplianceDetail property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the dutyComplianceDetail property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDutyComplianceDetail().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DutyComplianceType }
     * 
     * 
     */
    public List<DutyComplianceType> getDutyComplianceDetail() {
        if (dutyComplianceDetail == null) {
            dutyComplianceDetail = new ArrayList<DutyComplianceType>();
        }
        return this.dutyComplianceDetail;
    }

    /**
     * Gets the value of the documentId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDocumentId() {
        return documentId;
    }

    /**
     * Sets the value of the documentId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDocumentId(String value) {
        this.documentId = value;
    }

    /**
     * Gets the value of the evidenceDetail property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getEvidenceDetail() {
        return evidenceDetail;
    }

    /**
     * Sets the value of the evidenceDetail property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setEvidenceDetail(byte[] value) {
        this.evidenceDetail = value;
    }

}
