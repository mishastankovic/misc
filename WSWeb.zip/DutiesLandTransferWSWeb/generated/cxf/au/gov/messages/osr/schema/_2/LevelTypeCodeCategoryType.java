
package au.gov.messages.osr.schema._2;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for levelTypeCodeCategoryType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="levelTypeCodeCategoryType"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;maxLength value="4"/&gt;
 *     &lt;enumeration value="B"/&gt;
 *     &lt;enumeration value="FL"/&gt;
 *     &lt;enumeration value="G"/&gt;
 *     &lt;enumeration value="L"/&gt;
 *     &lt;enumeration value="LG"/&gt;
 *     &lt;enumeration value="LL"/&gt;
 *     &lt;enumeration value="M"/&gt;
 *     &lt;enumeration value="OD"/&gt;
 *     &lt;enumeration value="P"/&gt;
 *     &lt;enumeration value="PDM"/&gt;
 *     &lt;enumeration value="PLF"/&gt;
 *     &lt;enumeration value="PTHS"/&gt;
 *     &lt;enumeration value="RT"/&gt;
 *     &lt;enumeration value="SB"/&gt;
 *     &lt;enumeration value="UG"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "levelTypeCodeCategoryType")
@XmlEnum
public enum LevelTypeCodeCategoryType {


    /**
     * Basement
     * 
     */
    B,

    /**
     * Floor
     * 
     */
    FL,

    /**
     * Ground
     * 
     */
    G,

    /**
     * Level
     * 
     */
    L,

    /**
     * Lower Ground Floor
     * 
     */
    LG,

    /**
     * Lower Level
     * 
     */
    LL,

    /**
     * Mezzanine
     * 
     */
    M,

    /**
     * Observation Deck
     * 
     */
    OD,

    /**
     * Parking
     * 
     */
    P,

    /**
     * Podium
     * 
     */
    PDM,

    /**
     * Platform
     * 
     */
    PLF,

    /**
     * Penthouse
     * 
     */
    PTHS,

    /**
     * Rooftop
     * 
     */
    RT,

    /**
     * Sub-Basement
     * 
     */
    SB,

    /**
     * Upper Ground Floor
     * 
     */
    UG;

    public String value() {
        return name();
    }

    public static LevelTypeCodeCategoryType fromValue(String v) {
        return valueOf(v);
    }

}
