
package au.gov.messages.osr.schema._2;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for messageStatusDescriptionCategoryType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="messageStatusDescriptionCategoryType"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="OK"/&gt;
 *     &lt;enumeration value="Bad message format"/&gt;
 *     &lt;enumeration value="Message type not supported"/&gt;
 *     &lt;enumeration value="Message version not supported"/&gt;
 *     &lt;enumeration value="Service not available at this time"/&gt;
 *     &lt;enumeration value="Not eligible for this service"/&gt;
 *     &lt;enumeration value="Content error"/&gt;
 *     &lt;enumeration value="Internal error"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "messageStatusDescriptionCategoryType")
@XmlEnum
public enum MessageStatusDescriptionCategoryType {

    OK("OK"),
    @XmlEnumValue("Bad message format")
    BAD_MESSAGE_FORMAT("Bad message format"),
    @XmlEnumValue("Message type not supported")
    MESSAGE_TYPE_NOT_SUPPORTED("Message type not supported"),
    @XmlEnumValue("Message version not supported")
    MESSAGE_VERSION_NOT_SUPPORTED("Message version not supported"),
    @XmlEnumValue("Service not available at this time")
    SERVICE_NOT_AVAILABLE_AT_THIS_TIME("Service not available at this time"),
    @XmlEnumValue("Not eligible for this service")
    NOT_ELIGIBLE_FOR_THIS_SERVICE("Not eligible for this service"),
    @XmlEnumValue("Content error")
    CONTENT_ERROR("Content error"),
    @XmlEnumValue("Internal error")
    INTERNAL_ERROR("Internal error");
    private final String value;

    MessageStatusDescriptionCategoryType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static MessageStatusDescriptionCategoryType fromValue(String v) {
        for (MessageStatusDescriptionCategoryType c: MessageStatusDescriptionCategoryType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
