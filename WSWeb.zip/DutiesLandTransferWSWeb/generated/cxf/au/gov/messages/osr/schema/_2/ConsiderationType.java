
package au.gov.messages.osr.schema._2;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for considerationType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="considerationType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ConsiderationType" type="{http://osr.messages.gov.au/schema/2.4/}considerationTypeCategoryType" minOccurs="0"/&gt;
 *         &lt;element name="TotalAmountSecured" type="{http://osr.messages.gov.au/schema/2.4/}monetaryAmountType" minOccurs="0"/&gt;
 *         &lt;element name="GrossConsiderationAmount" type="{http://osr.messages.gov.au/schema/2.4/}monetaryAmountType" minOccurs="0"/&gt;
 *         &lt;element name="ConsiderationGstAmount" type="{http://osr.messages.gov.au/schema/2.4/}monetaryAmountType" minOccurs="0"/&gt;
 *         &lt;element name="MarginSchemeApplies" type="{http://osr.messages.gov.au/schema/2.4/}yesNoType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "considerationType", propOrder = {
    "considerationType",
    "totalAmountSecured",
    "grossConsiderationAmount",
    "considerationGstAmount",
    "marginSchemeApplies"
})
public class ConsiderationType {

    @XmlElement(name = "ConsiderationType")
    protected String considerationType;
    @XmlElement(name = "TotalAmountSecured")
    protected BigDecimal totalAmountSecured;
    @XmlElement(name = "GrossConsiderationAmount")
    protected BigDecimal grossConsiderationAmount;
    @XmlElement(name = "ConsiderationGstAmount")
    protected BigDecimal considerationGstAmount;
    @XmlElement(name = "MarginSchemeApplies")
    protected String marginSchemeApplies;

    /**
     * Gets the value of the considerationType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConsiderationType() {
        return considerationType;
    }

    /**
     * Sets the value of the considerationType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConsiderationType(String value) {
        this.considerationType = value;
    }

    /**
     * Gets the value of the totalAmountSecured property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTotalAmountSecured() {
        return totalAmountSecured;
    }

    /**
     * Sets the value of the totalAmountSecured property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTotalAmountSecured(BigDecimal value) {
        this.totalAmountSecured = value;
    }

    /**
     * Gets the value of the grossConsiderationAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getGrossConsiderationAmount() {
        return grossConsiderationAmount;
    }

    /**
     * Sets the value of the grossConsiderationAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setGrossConsiderationAmount(BigDecimal value) {
        this.grossConsiderationAmount = value;
    }

    /**
     * Gets the value of the considerationGstAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getConsiderationGstAmount() {
        return considerationGstAmount;
    }

    /**
     * Sets the value of the considerationGstAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setConsiderationGstAmount(BigDecimal value) {
        this.considerationGstAmount = value;
    }

    /**
     * Gets the value of the marginSchemeApplies property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMarginSchemeApplies() {
        return marginSchemeApplies;
    }

    /**
     * Sets the value of the marginSchemeApplies property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMarginSchemeApplies(String value) {
        this.marginSchemeApplies = value;
    }

}
