
package au.gov.messages.osr.schema._2;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for messageHeaderType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="messageHeaderType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="MessageCategory" type="{http://osr.messages.gov.au/schema/2.4/}messageCategoryCategoryType"/&gt;
 *         &lt;element name="MessageService" type="{http://osr.messages.gov.au/schema/2.4/}messageServiceCategoryType"/&gt;
 *         &lt;element name="MessageId" type="{http://osr.messages.gov.au/schema/2.4/}messageIdType"/&gt;
 *         &lt;element name="TransmissionTimestamp" type="{http://osr.messages.gov.au/schema/2.4/}timestampType"/&gt;
 *         &lt;element name="MessageOrigin" type="{http://osr.messages.gov.au/schema/2.4/}messageEntityIdType"/&gt;
 *         &lt;element name="MessageDestination" type="{http://osr.messages.gov.au/schema/2.4/}messageEntityIdType"/&gt;
 *         &lt;element name="Environment" type="{http://osr.messages.gov.au/schema/2.4/}environmentCategoryType"/&gt;
 *         &lt;element name="OriginalMessageId" type="{http://osr.messages.gov.au/schema/2.4/}messageIdType" minOccurs="0"/&gt;
 *         &lt;element name="MessageStatus" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="MessageStatusCode" type="{http://osr.messages.gov.au/schema/2.4/}messageStatusCodeCategoryType"/&gt;
 *                   &lt;element name="MessageStatusDescription" type="{http://osr.messages.gov.au/schema/2.4/}messageStatusDescriptionCategoryType"/&gt;
 *                   &lt;element name="MessageStatusReason" type="{http://osr.messages.gov.au/schema/2.4/}textType" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "messageHeaderType", propOrder = {
    "messageCategory",
    "messageService",
    "messageId",
    "transmissionTimestamp",
    "messageOrigin",
    "messageDestination",
    "environment",
    "originalMessageId",
    "messageStatus"
})
public class MessageHeaderType {

    @XmlElement(name = "MessageCategory", required = true)
    @XmlSchemaType(name = "string")
    protected MessageCategoryCategoryType messageCategory;
    @XmlElement(name = "MessageService", required = true)
    @XmlSchemaType(name = "string")
    protected MessageServiceCategoryType messageService;
    @XmlElement(name = "MessageId", required = true)
    protected String messageId;
    @XmlElement(name = "TransmissionTimestamp", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar transmissionTimestamp;
    @XmlElement(name = "MessageOrigin", required = true)
    protected String messageOrigin;
    @XmlElement(name = "MessageDestination", required = true)
    protected String messageDestination;
    @XmlElement(name = "Environment", required = true)
    @XmlSchemaType(name = "string")
    protected EnvironmentCategoryType environment;
    @XmlElement(name = "OriginalMessageId")
    protected String originalMessageId;
    @XmlElement(name = "MessageStatus")
    protected List<MessageHeaderType.MessageStatus> messageStatus;

    /**
     * Gets the value of the messageCategory property.
     * 
     * @return
     *     possible object is
     *     {@link MessageCategoryCategoryType }
     *     
     */
    public MessageCategoryCategoryType getMessageCategory() {
        return messageCategory;
    }

    /**
     * Sets the value of the messageCategory property.
     * 
     * @param value
     *     allowed object is
     *     {@link MessageCategoryCategoryType }
     *     
     */
    public void setMessageCategory(MessageCategoryCategoryType value) {
        this.messageCategory = value;
    }

    /**
     * Gets the value of the messageService property.
     * 
     * @return
     *     possible object is
     *     {@link MessageServiceCategoryType }
     *     
     */
    public MessageServiceCategoryType getMessageService() {
        return messageService;
    }

    /**
     * Sets the value of the messageService property.
     * 
     * @param value
     *     allowed object is
     *     {@link MessageServiceCategoryType }
     *     
     */
    public void setMessageService(MessageServiceCategoryType value) {
        this.messageService = value;
    }

    /**
     * Gets the value of the messageId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMessageId() {
        return messageId;
    }

    /**
     * Sets the value of the messageId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMessageId(String value) {
        this.messageId = value;
    }

    /**
     * Gets the value of the transmissionTimestamp property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getTransmissionTimestamp() {
        return transmissionTimestamp;
    }

    /**
     * Sets the value of the transmissionTimestamp property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setTransmissionTimestamp(XMLGregorianCalendar value) {
        this.transmissionTimestamp = value;
    }

    /**
     * Gets the value of the messageOrigin property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMessageOrigin() {
        return messageOrigin;
    }

    /**
     * Sets the value of the messageOrigin property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMessageOrigin(String value) {
        this.messageOrigin = value;
    }

    /**
     * Gets the value of the messageDestination property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMessageDestination() {
        return messageDestination;
    }

    /**
     * Sets the value of the messageDestination property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMessageDestination(String value) {
        this.messageDestination = value;
    }

    /**
     * Gets the value of the environment property.
     * 
     * @return
     *     possible object is
     *     {@link EnvironmentCategoryType }
     *     
     */
    public EnvironmentCategoryType getEnvironment() {
        return environment;
    }

    /**
     * Sets the value of the environment property.
     * 
     * @param value
     *     allowed object is
     *     {@link EnvironmentCategoryType }
     *     
     */
    public void setEnvironment(EnvironmentCategoryType value) {
        this.environment = value;
    }

    /**
     * Gets the value of the originalMessageId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginalMessageId() {
        return originalMessageId;
    }

    /**
     * Sets the value of the originalMessageId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginalMessageId(String value) {
        this.originalMessageId = value;
    }

    /**
     * Gets the value of the messageStatus property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the messageStatus property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMessageStatus().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MessageHeaderType.MessageStatus }
     * 
     * 
     */
    public List<MessageHeaderType.MessageStatus> getMessageStatus() {
        if (messageStatus == null) {
            messageStatus = new ArrayList<MessageHeaderType.MessageStatus>();
        }
        return this.messageStatus;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="MessageStatusCode" type="{http://osr.messages.gov.au/schema/2.4/}messageStatusCodeCategoryType"/&gt;
     *         &lt;element name="MessageStatusDescription" type="{http://osr.messages.gov.au/schema/2.4/}messageStatusDescriptionCategoryType"/&gt;
     *         &lt;element name="MessageStatusReason" type="{http://osr.messages.gov.au/schema/2.4/}textType" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "messageStatusCode",
        "messageStatusDescription",
        "messageStatusReason"
    })
    public static class MessageStatus {

        @XmlElement(name = "MessageStatusCode", required = true)
        protected String messageStatusCode;
        @XmlElement(name = "MessageStatusDescription", required = true)
        @XmlSchemaType(name = "string")
        protected MessageStatusDescriptionCategoryType messageStatusDescription;
        @XmlElement(name = "MessageStatusReason")
        protected String messageStatusReason;

        /**
         * Gets the value of the messageStatusCode property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getMessageStatusCode() {
            return messageStatusCode;
        }

        /**
         * Sets the value of the messageStatusCode property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setMessageStatusCode(String value) {
            this.messageStatusCode = value;
        }

        /**
         * Gets the value of the messageStatusDescription property.
         * 
         * @return
         *     possible object is
         *     {@link MessageStatusDescriptionCategoryType }
         *     
         */
        public MessageStatusDescriptionCategoryType getMessageStatusDescription() {
            return messageStatusDescription;
        }

        /**
         * Sets the value of the messageStatusDescription property.
         * 
         * @param value
         *     allowed object is
         *     {@link MessageStatusDescriptionCategoryType }
         *     
         */
        public void setMessageStatusDescription(MessageStatusDescriptionCategoryType value) {
            this.messageStatusDescription = value;
        }

        /**
         * Gets the value of the messageStatusReason property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getMessageStatusReason() {
            return messageStatusReason;
        }

        /**
         * Sets the value of the messageStatusReason property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setMessageStatusReason(String value) {
            this.messageStatusReason = value;
        }

    }

}
