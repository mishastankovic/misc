
package au.gov.messages.osr.schema._2;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for dxAddressType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="dxAddressType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="DxNumber" type="{http://osr.messages.gov.au/schema/2.4/}textType"/&gt;
 *         &lt;element name="LocationName" type="{http://osr.messages.gov.au/schema/2.4/}textType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "dxAddressType", propOrder = {
    "dxNumber",
    "locationName"
})
public class DxAddressType {

    @XmlElement(name = "DxNumber", required = true)
    protected String dxNumber;
    @XmlElement(name = "LocationName", required = true)
    protected String locationName;

    /**
     * Gets the value of the dxNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDxNumber() {
        return dxNumber;
    }

    /**
     * Sets the value of the dxNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDxNumber(String value) {
        this.dxNumber = value;
    }

    /**
     * Gets the value of the locationName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocationName() {
        return locationName;
    }

    /**
     * Sets the value of the locationName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocationName(String value) {
        this.locationName = value;
    }

}
