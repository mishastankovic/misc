
package au.gov.messages.osr.schema._2;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for partyRoleCategoryType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="partyRoleCategoryType"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="Party Receiving"/&gt;
 *     &lt;enumeration value="Party Relinquishing"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "partyRoleCategoryType")
@XmlEnum
public enum PartyRoleCategoryType {

    @XmlEnumValue("Party Receiving")
    PARTY_RECEIVING("Party Receiving"),
    @XmlEnumValue("Party Relinquishing")
    PARTY_RELINQUISHING("Party Relinquishing");
    private final String value;

    PartyRoleCategoryType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static PartyRoleCategoryType fromValue(String v) {
        for (PartyRoleCategoryType c: PartyRoleCategoryType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
