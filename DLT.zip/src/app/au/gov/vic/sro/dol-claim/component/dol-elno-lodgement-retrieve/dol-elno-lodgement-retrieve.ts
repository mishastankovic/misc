import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl, FormBuilder, Validators, AbstractControl } from '@angular/forms';
import { AlertService, FormUtils } from 'sro-ngcomponent-library';
import { UIMessageService } from 'src/app/au/gov/vic/sro/dol-claim/service/ui-message.service';
import { DolClaimUIService } from 'src/app/au/gov/vic/sro/dol-claim/service/dol-claim-ui.service';
import { DolClaimService } from '../../service/dol-claim.service';
import { DolError } from '../../model/claim.interface';
import { isNullOrUndefined } from 'util';
import { DolErrorHandler } from '../../service/dol-error-handler';

@Component({
	selector: 'dol-elno-lodgement-retrieve',
	templateUrl: './dol-elno-lodgement-retrieve.html'
})
export class DolElnoLodgementRetrieve implements OnInit {

	form: FormGroup;
	elnoLodgementCaseId: FormControl;
	caseReferenceId: FormControl;

	constructor(private formBuilder: FormBuilder,
				private router: Router,
				private alertService: AlertService,
				public errorHandler: DolErrorHandler,
				public uiMessageService: UIMessageService,
				private dolClaimService: DolClaimService,
				private dolClaimUIService: DolClaimUIService) { }

	ngOnInit() {
		this.buildForm();
	}

	buildForm() {
		this.elnoLodgementCaseId = new FormControl('', Validators.compose([Validators.required]));
		this.caseReferenceId = new FormControl('', Validators.compose([Validators.required, Validators.pattern('^N?[0-9]{1,8}$')]));

		this.form = this.formBuilder.group({
			elnoLodgementCaseId: this.elnoLodgementCaseId,
			caseReferenceId: this.caseReferenceId
		});
	}

	onSubmit() {
		this.alertService.clear();
		FormUtils.validate(this.form);
		if (this.form.valid) {
			if (new RegExp('^[0-9]{6,8}$').test(this.caseReferenceId.value)) {
				window.location.href = '/duties/faces/pexa/retrieve.xhtml?documentId=' + this.elnoLodgementCaseId.value + '&transactionId=' + this.caseReferenceId.value;
				return;
			}
			this.dolClaimUIService.clear();
			this.dolClaimUIService.elnoLodgementCaseId = this.elnoLodgementCaseId.value;
			this.dolClaimUIService.caseReferenceId = this.caseReferenceId.value;
			this.dolClaimService.getLodgement(this.caseReferenceId.value, this.elnoLodgementCaseId.value).subscribe( (response: any) => {
				this.dolClaimUIService.lodgement = response.lodgement;
				if (response.lodgement.esysLodgementId) {
					this.router.navigate(['/link-forms']);
				} else {
					this.router.navigate(['/claim-lodgement']);
				}
			}, (response: any) => {
				this.alertService.error(this.errorHandler.getErrorMessage(response.error));
			});
		}
	}

	isNotValid(control: AbstractControl, type?: string): boolean {
		if (!control) { return; }
		return FormUtils.isNotValid(control, type);
	}
}
