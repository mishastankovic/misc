export interface Category1 {
	id: string;
	value: string;
	subCategories: SubCategory[];
}

export interface Category {
	categoryCode: string;
	categoryName: string;
	categoryOrder: number;
	parentCategoryCode: string;
	subCategories: Category[];
	assessingType: string;
}

export interface SubCategory {
	id: string;
	value: string;
}

export class AssessingType {
	static readonly INTERNAL: string = 'MANUAL';
	static readonly EXTERNAL: string = 'SYSTEM';
}

export interface Document {
	elnoDocId: string;
	elnoId: string;
	formId: number;
	formVersion: number;
	id: string;
	properties: Property[];
	transferees: Transferee[];
}

export interface Transferee {
	name: string;
}

export interface Form {
	property: Property;
}

export interface Lodgement {
	elnoId: string;
	elnoLodgementCaseId: string;
	caseReferenceId: string;
	esysLodgementId: number;
	clientReference: string;
	category: string;
	status: string;
	documents: Document [];
}

export interface Property {
	address: string;
	volfol: string;
}

export interface ClaimedForm {
	formId: number;
	documentId: string;
}

export interface DolError {
	errorCode: string;
	errorMsg: string;
	errorId: string;
}

export interface DolFieldError {
	errorCode: string;
	field: string;
	errorMsg: string;
}

export interface LodgementDocumentType {
	code: string;
	name: string;
}

