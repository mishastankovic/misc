import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable, EventEmitter } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Lodgement, Form } from 'src/app/au/gov/vic/sro/dol-claim/model/claim.interface';
import { fetch } from 'node-fetch';

@Injectable()
export class DolClaimService {
	protected basePath = environment.apiBasePath;

	constructor(protected http: HttpClient) { }

	public getLodgement(caseReferenceId: string, elnoLodgementCaseId: string): Observable<Lodgement> {
		const headers = new HttpHeaders({
			// 'Access-Control-Allow-Origin': 'https://localhost:9444'
		});
		const options = caseReferenceId ?
			{
				params: new HttpParams().set('elnoLodgementCaseId', elnoLodgementCaseId),
				headers: headers
			} : {};
		return this.http.get<Lodgement>(`${this.basePath}lodgement/${caseReferenceId}`, options);
	}

	/*
	public async getJsfHeaderForm() : Promise<string> {
		const url = environment.dolApiBasePath +  'faces/common/header.xhtml';
		return this.http.get(url, {responseType: 'text'}).toPromise();
	}*/

	public claimLodgement(lodgement: Lodgement): Observable<Lodgement> {
		const data = {
			'elnoLodgementCaseId': lodgement.elnoLodgementCaseId,
			'lodgementCategory': lodgement.category,
			'caseReferenceId': lodgement.caseReferenceId,
			'clientReference': lodgement.clientReference
		};
		return this.http.post<Lodgement>(`${this.basePath}lodgement/claim`, data);
	}

	public submitLodgement(lodgement: Lodgement): Observable<Lodgement> {
		const data = {
			'elnoLodgementCaseId': lodgement.elnoLodgementCaseId,
			'lodgementCategory': lodgement.category,
			'caseReferenceId': lodgement.caseReferenceId
		};
		return this.http.post<Lodgement>(`${this.basePath}lodgement/submit`, data);
	}

	public certifyLodgement(lodgement: Lodgement): Observable<Lodgement> {
		const data = {
			'elnoLodgementCaseId': lodgement.elnoLodgementCaseId,
			'lodgementCategory': lodgement.category,
			'caseReferenceId': lodgement.caseReferenceId
		};
		return this.http.post<Lodgement>(`${this.basePath}lodgement/certify`, data);
	}
}
