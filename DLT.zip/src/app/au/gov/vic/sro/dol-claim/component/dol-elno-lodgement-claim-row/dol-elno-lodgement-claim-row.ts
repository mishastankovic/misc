import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators, AbstractControl, FormArray, ValidatorFn, ValidationErrors } from '@angular/forms';
import { FormUtils } from 'sro-ngcomponent-library';
import { UIMessageService } from 'src/app/au/gov/vic/sro/dol-claim/service/ui-message.service';
import { DolClaimUIService } from 'src/app/au/gov/vic/sro/dol-claim/service/dol-claim-ui.service';
import { DolClaimService } from 'src/app/au/gov/vic/sro/dol-claim/service/dol-claim.service';
import { DutiesFormService } from 'src/app/au/gov/vic/sro/dol-claim/service/duties-form.service';
import { AssessingType, Document, DolError, DolFieldError, Lodgement } from 'src/app/au/gov/vic/sro/dol-claim/model/claim.interface';
import { DolErrorHandler } from '../../service/dol-error-handler';

@Component({
	selector: '[dol-elno-lodgement-claim-row]',
	templateUrl: './dol-elno-lodgement-claim-row.html',
	styleUrls: ['./dol-elno-lodgement-claim-row.scss']
})
export class DolElnoLodgementClaimRow implements OnInit {

	protected documentErrors: DolFieldError[];

	protected documentWarnings: DolFieldError[];

	@Input()
	public index: number;

	@Input()
	public document: Document;

	@Input()
	private claimForm: FormGroup;

	@Input()
	public lodgementId: string;

	@Input()
	public assessingType: AssessingType;

	@Input()
	public editable: boolean;

	public dutiesMatchForm: FormGroup;
	private dutiesFormId: FormControl;
	private propertyAddress: FormControl;
	private claimedDutiesFormId: FormControl;
	private warningsAck: FormControl;

	constructor(private formBuilder: FormBuilder,
				private errorHandler: DolErrorHandler,
				public uiMessageService: UIMessageService,
				private dolClaimService: DolClaimService,
				private dolClaimUIService: DolClaimUIService,
				private dutiesFormService: DutiesFormService) {
	}

	ngOnInit() {
		this.buildForm();
	}

	buildForm() {
		// this.dutiesFormId = new FormControl('', [Validators.required, this.propertyRequired, this.claimedFormIdChanged]);
		if (this.isClaimFormMode() && !this.document.formId) {
			this.dutiesFormId = new FormControl('', Validators.compose([Validators.required]));
		} else {
			this.dutiesFormId = new FormControl('');
		}
		this.propertyAddress = new FormControl('');
		this.claimedDutiesFormId = new FormControl('');
		this.warningsAck = new FormControl(false);
		this.dutiesMatchForm = this.formBuilder.group({
			dutiesFormId: this.dutiesFormId,
			propertyAddress: this.propertyAddress,
			claimedDutiesFormId: this.claimedDutiesFormId,
			warningsAck: this.warningsAck
		});
		this.claimForm.addControl('document' + this.document.id, this.dutiesMatchForm);
	}

	onLink() {
		if (this.isClaimFormMode() && !this.document.formId) {
			this.dutiesFormId.markAsTouched();
			FormUtils.validate(this.dutiesFormId);
			const validationErors: ValidationErrors = this.dutiesFormId.errors;
			const ackWarnings = [];
			if (this.warningsAck.value && this.documentWarnings) {
				this.documentWarnings.forEach(item => {
					ackWarnings.push(item);
				});
			}
			this.documentErrors = [];
			this.documentWarnings = [];
			this.warningsAck.setValue(false);
			if (!validationErors) {
				const formId: number = this.dutiesMatchForm.get('dutiesFormId').value;
				this.dutiesFormService.linkForm(formId, this.document.id, this.dolClaimUIService.lodgement.esysLodgementId, ackWarnings)
					.subscribe((response: boolean ) => {
						this.document.formId = formId;
						// this.dolClaimUiService.setClaimedForm({formId: formId, id: this.document.id});
					}, (response) => {
						this.handleError(response);
					});
			}
		}
	}

	onUnlink() {
		if (this.isClaimFormMode() && this.document.formId) {
			const formId: number = this.document.formId;
			this.documentErrors = [];
			this.dutiesFormService.unlinkForm(formId, this.document.id, this.dolClaimUIService.lodgement.esysLodgementId)
				.subscribe((response: boolean ) => {
					this.document.formId = undefined;
					this.dutiesFormId.setValue(undefined);
					// this.dolClaimUiService.setClaimedForm({formId: formId, id: this.document.id});
				}, (response: any) => {
					this.handleError(response);
				});
		}
	}

	getDetailsURL(): string {
		const lodgement: Lodgement = this.dolClaimUIService.lodgement;
		const url: string = '/duties/faces/elno/transaction.xhtml?transactionId=' + this.document.id;
		if (this.assessingType === AssessingType.EXTERNAL) {
			return url;
		} else if (this.assessingType === AssessingType.INTERNAL) {
			return url + '&lodgementId=' + lodgement.esysLodgementId;
		} else {
			return '';
		}
	}

	isNotValid(control: AbstractControl, type?: string): boolean {
		if (!control) { return; }
		const notValid = FormUtils.isNotValid(control, type);
		return notValid;
	}

	// make sure property is populated for parent form level validations before submission
	propertyRequired (control: AbstractControl): ValidationErrors | null {
		if (control.parent) {
			const propertyAddressValue = control.parent.get('propertyAddress').value;
			if (control.value && !propertyAddressValue) {
				return { propertyRequired: 'propertyAddressrequired' };
			}
		}
		return;
	}

	// make sure that formId has not be changed after claiming a form.
	claimedFormIdChanged (control: AbstractControl): ValidationErrors | null {
		if (control.parent &&  control.parent.get('claimedDutiesFormId')) {
			const claimedFormId: string = control.parent.get('claimedDutiesFormId').value;
			const formId = control.value;
			const propertyAddressValue = control.parent.get('propertyAddress').value;
			if (propertyAddressValue && formId && claimedFormId && claimedFormId !== formId ) {
				return { claimedFormIdChanged: 'claimedFormIdChanged' };
			}
		}
		return;
	}

	isClaimFormMode(): boolean {
		return this.lodgementId != null && this.lodgementId !== undefined;
	}

	/**
	 * We can get single or multiple errors.
	 * Multiple errors are used for form matching errors.
	 *
	 * @param error
	 */
	private handleError(response: any) {
		const error: any = response.error;
		if (error && error.errors && error.errors.length > 0) {
			// Multiple errors
			this.documentErrors = this.errorHandler.getErrorMessages(error.errors);
		} else if (!error || !error.warnings || error.warnings.length <= 0) {
			// Single error
			this.documentErrors.push({
				errorCode: '',
				field: '',
				errorMsg: this.errorHandler.getErrorMessage(error)
			});
		}

		if (error && error.warnings && error.warnings.length > 0) {
			// Multiple errors
			this.documentWarnings = this.errorHandler.getErrorMessages(error.warnings);
			this.warningsAck.setValue( false);
		}
	}
}
