import {SecurityInterceptor} from "./security.interceptor";
import {async, fakeAsync, inject, TestBed, tick} from "@angular/core/testing";
import {DolClaimService} from "./dol-claim.service";
import {HttpClientTestingModule, HttpTestingController} from "@angular/common/http/testing";
import {HTTP_INTERCEPTORS, HttpClient, HttpRequest} from "@angular/common/http";
import any = jasmine.any;
import {environment} from "../../../../../../../environments/environment";

describe('ServiceInterceptor', () => {
    //let httpMock: HttpTestingController;
    let securityInterceptor: SecurityInterceptor;


    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [HttpClientTestingModule],
            providers: [
                SecurityInterceptor,
                DolClaimService,
                {provide: HTTP_INTERCEPTORS, useClass: SecurityInterceptor, multi: true},]
        });
        //httpMock = TestBed.get(HttpTestingController);
        securityInterceptor = TestBed.get(SecurityInterceptor);

    });

    it('should be created', inject([SecurityInterceptor, DolClaimService],
        (interceptor: SecurityInterceptor, service: DolClaimService) => {
        expect(interceptor).toBeDefined();
        expect(service).toBeDefined();
    }));


    // TODO - this test needs more work for async operation
    xit('Should redirect to the login page', async(inject([SecurityInterceptor, DolClaimService, HttpTestingController],
        (interceptor: SecurityInterceptor, service: DolClaimService, httpMock: HttpTestingController) => {

        let redirect = spyOn(securityInterceptor, 'redirectToLogin');

        let caseReferenceId = "N100000";
        const url = environment.apiBasePath + 'lodgement/' + caseReferenceId;
        service.getLodgement("calimreferenceid", caseReferenceId).subscribe(response => {
            //expect(response).toBe(any([]))
            console.log("Completed checks");
        }, error => {

        });

        /*
        let req = httpMock.expectOne((request) => {
            return request.url.match(/lodgement/) && request.method === 'GET';
        } );
        req.error(new ErrorEvent(''), {
            status: 401,
            statusText: 'Authentication error'
        });
        //httpMock.verify();


            //tick();
        expect(redirect).toHaveBeenCalled();
        */

    })));

});
