import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dol-elno-file-upload',
  templateUrl: './dol-elno-file-upload.component.html',
  styleUrls: ['./dol-elno-file-upload.component.css']
})
export class DolElnoFileUploadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
