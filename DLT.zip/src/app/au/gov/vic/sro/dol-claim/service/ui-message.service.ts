import { Injectable } from '@angular/core';

/**
 * This class should contain UI validation errors only, e.g. mandatory fields etc.
 * Errors from REST service calls are stored and populated on the server side and then
 * directly displayed on the screen through DolErrorHandler.
 *
 * TODO - clean up server error messages as these are now stored on the server.
 */
@Injectable()
export class UIMessageService {

	private uiValidationMessages: Map<string, string>;

	constructor() {
		this.loadUIMessages();
	}

	loadUIMessages() {
		this.uiValidationMessages = new Map<string, string>();
		const messages = [
			['ELNO_LODGEMENT_CASE_ID_MANDATORY', 'Please provide a case id'],
			['ELNO_LODGEMENT_CASE_ID_INVALID', 'In is is invalid.'],
			['ELNO_LODGEMENT_REFERENCE_ID_MANDATORY', 'Please provide a reference / transaction id.'],
			['ELNO_LODGEMENT_REFERENCE_ID_INVALID', 'Reference / transaction id is invalid.'],
			['ELNO_LODGEMENT_CATEGORY_MANDATORY', 'Please select a category.'],
			['ELNO_LODGEMENT_SUB_CATEGORY_MANDATORY', 'Please select a sub category.'],
			['ELNO_LODGEMENT_DUTIES_FORM_ID_MANDATORY', 'Please provide duties form id.'],
			['ELNO_LODGEMENT_DUTIES_FORM_CLAIM_MANDATORY', 'Please claim the duties form.'],
			['ELNO_LODGEMENT_DUTIES_FORM_CLAIM_MISMATCH', 'Form ID has changed. Please claim form again.'],
			['ELNO_LODGEMENT_RETRIEVED_EMPTY', 'Failed to find any lodgement for the specified id.'],
			['DOL_GENERIC_ERROR', 'Your request cannot be processed at this time due to an internal system error.'],
			['DUTIES_FORM_NOT_FOUND', 'Failed to find form.'],
		];

		for (let i = 0; i < messages.length; i++) {
			this.uiValidationMessages.set(messages[i][0], messages[i][1]);
		}
	}

	getMessage(key: string): string {
		return this.uiValidationMessages.get(key);
	}
}
