import {Injectable} from "@angular/core";
import {
    HttpErrorResponse,
    HttpEvent,
    HttpHandler,
    HttpInterceptor,
    HttpRequest,
    HttpResponse
} from "@angular/common/http";
import {Observable, of, throwError} from "rxjs";
import {catchError, map} from "rxjs/operators";
import {environment} from "src/environments/environment";

@Injectable()
export class SecurityInterceptor implements HttpInterceptor {
    public static readonly HTTP_STATUS_UNAUTHORISED: number = 401;

    constructor() { }

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {


        return next.handle(request).pipe(
            catchError(err => {
                if (err.status === SecurityInterceptor.HTTP_STATUS_UNAUTHORISED) {
                    this.redirectToLogin();
                    of([]);
                } else {
                    return throwError(err);
                }
            })
        );
    }

    public redirectToLogin() {
        document.location.href = environment.loginUrl;
    }

}
