import { TestBed, inject } from '@angular/core/testing';

import { DolRefDataService } from './dol-ref-data.service';

describe('DolRefDataService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DolRefDataService]
    });
  });

  it('should be created', inject([DolRefDataService], (service: DolRefDataService) => {
    expect(service).toBeTruthy();
  }));
});
