import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DolElnoFileUploadComponent } from './dol-elno-file-upload.component';

describe('DolElnoFileUploadComponent', () => {
  let component: DolElnoFileUploadComponent;
  let fixture: ComponentFixture<DolElnoFileUploadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DolElnoFileUploadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DolElnoFileUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
