import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DolClaimUIService } from '../../service/dol-claim-ui.service';
import { AlertService, FormUtils } from 'sro-ngcomponent-library';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { DolCategoryService } from '../../service/dol-claim-category.service';
import { DolClaimService } from '../../service/dol-claim.service';
import { UIMessageService } from '../../service/ui-message.service';
import { AssessingType, Category, DolError, Lodgement } from '../../model/claim.interface';
import { isNullOrUndefined } from 'util';
import { DutiesFormService } from '../../service/duties-form.service';
import { DolErrorHandler } from '../../service/dol-error-handler';

@Component({
	selector: 'app-dol-elno-lodgement-link-forms',
	templateUrl: './dol-elno-lodgement-link-forms.component.html'
})
export class DolElnoLodgementLinkFormsComponent implements OnInit {

	private category: FormControl;
	private subCategory: FormControl;
	private clientReference: FormControl;

	public lodgementForm: FormGroup;
	public pageErrors: string[];
	public categoryList: Category[];
	public selectedCategory: Category;
	public assessingMethod: string;

	@Output()
	private lodgementSubmittedEvent = new EventEmitter<string>();

	constructor(private alertService: AlertService,
		public dolClaimUIService: DolClaimUIService,
		private dolCategoryService: DolCategoryService,
		private dolClaimService: DolClaimService,
		private dutiesFormService: DutiesFormService,
		private errorHandler: DolErrorHandler,
		public uiMessageService: UIMessageService,
		private formBuilder: FormBuilder,
		private route: ActivatedRoute,
		private router: Router) {
		route.params.subscribe(params => {
			if (params.caseReferenceId != null && params.elnoLodgementCaseId != null) {
				dolClaimUIService.caseReferenceId = params.caseReferenceId;
				dolClaimUIService.elnoLodgementCaseId = params.elnoLodgementCaseId;
			}
		});
	}

	async ngOnInit() {
		await this.dolCategoryService.init();
		this.getLodgement();
		this.category = new FormControl('', Validators.compose([Validators.required]));
		// this.subCategory = new FormControl('', Validators.compose([Validators.required]));
		this.clientReference = new FormControl('');
	}

	onSelectCategory(categoryCode: string) {
		this.selectedCategory = this.categoryList.find(c => c.categoryCode === categoryCode);
	}

	onSubmit() {
		this.alertService.clear();
		FormUtils.validate(this.lodgementForm);
		if (this.selectedCategory.assessingType === AssessingType.EXTERNAL) {
			window.location.href = '/duties/faces/elno/transaction.xhtml?transactionId=' + this.dolClaimUIService.lodgement.documents[0].id;
			return;
		}
		if (this.lodgementForm.valid) {
			if (!this.dolClaimUIService.lodgement.status || this.dolClaimUIService.lodgement.status === 'In Progress') {
				this.dolClaimService.submitLodgement(this.dolClaimUIService.lodgement).subscribe(
					(response: any) => {
						this.dolClaimUIService.lodgement = response.lodgement;
						this.alertService.successDismissable('Lodgement is now ready for submission. Please contact your ELNO to trigger submission for manual assessment.');
					},
					(response: any) => {
						this.alertService.error(this.errorHandler.getErrorMessage(response.error));
					});
			} else if (this.dolClaimUIService.lodgement.status && this.dolClaimUIService.lodgement.status === 'Ready To Pay') {
				this.dolClaimService.certifyLodgement(this.dolClaimUIService.lodgement).subscribe(
					(response: any) => {
						this.dolClaimUIService.lodgement = response.lodgement;
						this.alertService.successDismissable('Lodgement has been successfully certified.');
					},
					(response: any) => {
						this.alertService.error(this.errorHandler.getErrorMessage(response.error));
					});
			}
		}
	}

	private buildForm() {
		const lodgement: Lodgement = this.dolClaimUIService.lodgement;
		if (lodgement.documents.length > 1) {
			this.categoryList = this.dolCategoryService.getCategoriesByAssessingType(AssessingType.INTERNAL);
		} else {
			this.categoryList = this.dolCategoryService.getCategories();
		}
		this.lodgementForm = this.formBuilder.group({
			lodgementCaseId: this.dolClaimUIService.elnoLodgementCaseId,
			sroReferenceId: this.dolClaimUIService.caseReferenceId,
			clientReference: lodgement.clientReference,
			category: lodgement.category
		});
		this.onSelectCategory(lodgement.category);
	}

	private getLodgement(): void {
		if (this.dolClaimUIService.lodgement) {
			this.buildForm();
		} else {
			this.dolClaimService.getLodgement(this.dolClaimUIService.caseReferenceId, this.dolClaimUIService.elnoLodgementCaseId)
				.subscribe((response: any) => {
					this.dolClaimUIService.lodgement = response.lodgement;
					this.buildForm();
					if (!response.lodgement.esysLodgementId) {
						this.router.navigate(['/claim-lodgement']);
					}
				}, (response: any) => {
					this.alertService.error(this.errorHandler.getErrorMessage(response.error));
				});
		}
	}

	isNotValid(control: AbstractControl, type: string): boolean {
		if (!control) { return; }
		return FormUtils.isNotValid(control, type);
	}

	isSubmitable(): boolean {
		if (!this.dolClaimUIService.lodgement || !this.dolClaimUIService.lodgement.documents ||
			this.dolClaimUIService.lodgement.documents.find(document => {
				return !document.formId;
			})) {
			return false;
		} else {
			return true;
		}
	}
}
