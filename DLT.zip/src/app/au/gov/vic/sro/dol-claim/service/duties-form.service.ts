import { HttpClient } from '@angular/common/http';
import { Injectable, EventEmitter } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';
import { environment } from 'src/environments/environment';
import {Lodgement, Form, DolFieldError} from 'src/app/au/gov/vic/sro/dol-claim/model/claim.interface';
import { fetch } from 'node-fetch';


@Injectable()
export class DutiesFormService {
	protected basePath = environment.apiBasePath;

	constructor(protected http: HttpClient) { }

	public async getForm(formId: string): Promise<Form> {
		const url = this.basePath + 'forms/form/' + formId;
		return this.http.get<Form>(url).toPromise();
	}

	/**
	 * Links a Duties form with an esys transaction.
	 *
	 * @param dutiesFormId
	 * @param esysTransactionId
	 * @param crossReferenceId
	 */
	public linkForm(dutiesFormId: number, esysTransactionId: string, esysLodgementId: number, documentWarnings: DolFieldError[]): Observable<boolean> {
		const url = this.basePath + 'form/' + dutiesFormId + '/link';
		let data: any = {
			"transactionId": esysTransactionId,
			"esysLodgementId": esysLodgementId
		}
		if (documentWarnings) {
			data.acknowledgedWarnings = documentWarnings;
		}
		return this.http.put<boolean>(url, data);
	}

	/**
	 *
	 * @param formId
	 */
	public unlinkForm(dutiesFormId: number, esysTransactionId: string, esysLodgementId: number): Observable<boolean> {
		const url = this.basePath + 'form/' + dutiesFormId + '/unlink';
		const data = {
			"formId": dutiesFormId,
			"transactionId": esysTransactionId,
			"esysLodgementId": esysLodgementId
		}
		return this.http.put<boolean>(url, data);
	}

}
