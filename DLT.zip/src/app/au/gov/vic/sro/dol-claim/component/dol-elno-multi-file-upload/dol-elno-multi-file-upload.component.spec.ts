import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DolElnoMultiFileUploadComponent } from './dol-elno-multi-file-upload.component';

describe('DolElnoMultiFileUploadComponent', () => {
  let component: DolElnoMultiFileUploadComponent;
  let fixture: ComponentFixture<DolElnoMultiFileUploadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DolElnoMultiFileUploadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DolElnoMultiFileUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
