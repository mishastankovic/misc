import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl, FormBuilder, Validators, AbstractControl } from '@angular/forms';
import { AlertService, FormUtils } from 'sro-ngcomponent-library';
import { UIMessageService } from 'src/app/au/gov/vic/sro/dol-claim/service/ui-message.service';
import { DolClaimUIService } from 'src/app/au/gov/vic/sro/dol-claim/service/dol-claim-ui.service';
import { DolClaimService } from 'src/app/au/gov/vic/sro/dol-claim/service/dol-claim.service';
import { DolCategoryService } from 'src/app/au/gov/vic/sro/dol-claim/service/dol-claim-category.service';
import { SubCategory, Category, AssessingType } from 'src/app/au/gov/vic/sro/dol-claim/model/claim.interface';
import { DolErrorHandler } from '../../service/dol-error-handler';

@Component({
	selector: '[dol-elno-lodgement-claim]',
	templateUrl: './dol-elno-lodgement-claim.html'
})
export class DolElnoLodgementClaim implements OnInit {

	public claimForm: FormGroup;
	private category: FormControl;
	private subCategory: FormControl;
	private clientReference: FormControl;

	categoryList: Category[];
	// public subCategoryList : Category[];

	constructor(private formBuilder: FormBuilder,
				private router: Router,
				private alertService: AlertService,
				private errorHandler: DolErrorHandler,
				public uiMessageService: UIMessageService,
				private dolClaimService: DolClaimService,
				protected dolClaimUIService: DolClaimUIService,
				private dolCategoryService: DolCategoryService ) {
	}

	async ngOnInit() {
		await this.dolCategoryService.init();
		this.buildForm();
	}

	onSelectCategory(categoryCode: string) {
		// Nothing to do at this stage, used to display subcategory
	}

	buildForm() {
		const lodgement = this.dolClaimUIService.lodgement;
		if (lodgement.documents.length > 1) {
			this.categoryList = this.dolCategoryService.getCategoriesByAssessingType(AssessingType.INTERNAL);
		} else {
			this.categoryList = this.dolCategoryService.getCategories();
		}
		this.category = new FormControl('', Validators.compose([Validators.required]));
		//this.subCategory = new FormControl('', Validators.compose([Validators.required]));
		this.clientReference = new FormControl('');
		this.claimForm = this.formBuilder.group({
			lodgementCaseId: this.dolClaimUIService.elnoLodgementCaseId,
			sroReferenceId: this.dolClaimUIService.caseReferenceId,
			category: this.category,
			//subCategory : this.subCategory
			clientReference: this.clientReference
		});
	}

	onSubmit() {
		this.alertService.clear();
		FormUtils.validate(this.claimForm);
		const lodgement = this.dolClaimUIService.lodgement;
		lodgement.category = this.category.value;
		lodgement.clientReference = this.clientReference.value;
		if (this.claimForm.valid) {
			this.dolClaimService.claimLodgement(lodgement).subscribe(
				(response: any) => {
					this.dolClaimUIService.lodgement = response.lodgement;
					this.router.navigate(['/link-forms']);
				},
				(response: any) => {
					this.alertService.error(this.errorHandler.getErrorMessage(response.error));
				}
			);
		}
	}

	isNotValid(control: AbstractControl, type?: string): boolean {
		if (!control) { return; }
		return FormUtils.isNotValid(control, type);
	}
}
