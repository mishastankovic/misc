import { Injectable } from '@angular/core';
import {Category} from "../model/claim.interface";
import {environment} from "../../../../../../../environments/environment";
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class DolRefDataService {

  protected basePath = environment.apiBasePath + "refData";

  constructor(protected http: HttpClient) { }

  public getDocumentTypesByCategory(lodgementCategory: string): Observable<DocumentType[]> {
    const url = this.basePath + '/documentTypes/lodgementCategory/' + lodgementCategory;
    return this.http.get<DocumentType[]>(url);
  }

}
