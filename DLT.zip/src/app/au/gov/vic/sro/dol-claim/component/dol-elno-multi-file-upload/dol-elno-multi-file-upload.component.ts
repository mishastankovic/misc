import {Component, Input, OnInit} from '@angular/core';
import {FileUploader} from "ng2-file-upload";
import {environment} from "../../../../../../../../environments/environment";
import {AssessingType, Lodgement, LodgementDocumentType} from "../../model/claim.interface";
import {DolRefDataService} from "../../service/dol-ref-data.service";
import {Observable} from "rxjs";
import {FormBuilder, FormControl, FormGroup, Validators} from "@angular/forms";

const fileUploadBaseUrl = environment.fileUploadUrl;

@Component({
  selector: 'dol-elno-multi-file-upload',
  templateUrl: './dol-elno-multi-file-upload.component.html',
  styleUrls: ['./dol-elno-multi-file-upload.component.scss']
})
export class DolElnoMultiFileUploadComponent implements OnInit {

  public uploader: FileUploader;
  private documentType: FormControl;
  private uploadForm: FormGroup;

  @Input()
  lodgement: Lodgement;

  documentTypeList: Observable<DocumentType[]>;


  constructor(private refDataService: DolRefDataService, private formBuilder: FormBuilder) {
  }

  ngOnInit() {
    this.documentTypeList = this.refDataService.getDocumentTypesByCategory(this.lodgement.category);
    const uploadUrl: string = fileUploadBaseUrl + '/lodgement/' + this.lodgement.esysLodgementId;
    this.uploader = new FileUploader({ url: uploadUrl, itemAlias: 'document'})

    this.uploader.onAfterAddingFile = (file) => {
      file.withCredentials = false;
    };
    this.uploader.onCompleteItem = (item: any, response: any, status: any, headers: any) => {
      console.log('ImageUpload:uploaded:', item, status, response);
    };
  }

  buildForm() {
    this.documentType = new FormControl('');
    this.uploadForm = this.formBuilder.group({
      documentType: this.documentType,
    });
  }

}
