import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { AssessingType, Document, ClaimedForm } from 'src/app/au/gov/vic/sro/dol-claim/model/claim.interface';

@Component({
	selector: '[dol-elno-lodgement-claim-array]',
	templateUrl: './dol-elno-lodgement-claim-array.html'
})
export class DolElnoLodgementClaimArray implements OnInit {

	@Input()
	public claimForm: FormGroup;

	@Output()
	private formClaimedEvent: EventEmitter<ClaimedForm> = new EventEmitter<ClaimedForm>();

	@Input()
	public documentList: Document[];

	@Input()
	public lodgementId: string;

	@Input()
	public assessingType: AssessingType;

	@Input()
	public editable: boolean;

	async ngOnInit() {
	}
}
