import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { NgModule } from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { Routes } from '@angular/router';
import { RouterModule } from '@angular/router';

import { FileUploadModule } from 'primeng/components/fileupload/fileupload';
import { TableModule } from 'primeng/components/table/table';
import { ListboxModule } from 'primeng/components/listbox/listbox';

import { SRONgComponentLibraryModule, BsModalService, AlertService, FormUtils } from 'sro-ngcomponent-library';

import { AppComponent } from 'src/app/app.component';
import { environment } from 'src/environments/environment.prod';
import { DolElnoLodgementRetrieve } from 'src/app/au/gov/vic/sro/dol-claim/component/dol-elno-lodgement-retrieve/dol-elno-lodgement-retrieve';
import { DolElnoLodgementClaim } from 'src/app/au/gov/vic/sro/dol-claim/component/dol-elno-lodgement-claim/dol-elno-lodgement-claim';
import { DolElnoLodgementClaimRow } from 'src/app/au/gov/vic/sro/dol-claim/component/dol-elno-lodgement-claim-row/dol-elno-lodgement-claim-row';
import { DolElnoLodgementClaimArray } from 'src/app/au/gov/vic/sro/dol-claim/component/dol-elno-lodgement-claim-array/dol-elno-lodgement-claim-array';

import { UIMessageService } from 'src/app/au/gov/vic/sro/dol-claim/service/ui-message.service';
import { DolClaimUIService } from 'src/app/au/gov/vic/sro/dol-claim/service/dol-claim-ui.service';
import { DolClaimService } from 'src/app/au/gov/vic/sro/dol-claim/service/dol-claim.service';
import { DutiesFormService } from 'src/app/au/gov/vic/sro/dol-claim/service/duties-form.service';
import { DolCategoryService } from 'src/app/au/gov/vic/sro/dol-claim/service/dol-claim-category.service';
import { DolElnoLodgementLinkFormsComponent } from './au/gov/vic/sro/dol-claim/component/dol-elno-lodgement-link-forms/dol-elno-lodgement-link-forms.component';
import { DolErrorHandler } from './au/gov/vic/sro/dol-claim/service/dol-error-handler';
import { SecurityInterceptor } from './au/gov/vic/sro/dol-claim/service/security.interceptor';
import { DolElnoMultiFileUploadComponent } from './au/gov/vic/sro/dol-claim/component/dol-elno-multi-file-upload/dol-elno-multi-file-upload.component';
import {FileSelectDirective} from "ng2-file-upload";
import { DolElnoFileUploadComponent } from './au/gov/vic/sro/dol-claim/component//dol-elno-file-upload/dol-elno-file-upload.component';

const routes: Routes = [
	{ path: '', redirectTo: 'select-lodgement', pathMatch: 'full' },
	{ path: 'select-lodgement', component: DolElnoLodgementRetrieve },
	{ path: 'claim-lodgement', component: DolElnoLodgementClaim },
	{ path: 'link-forms', component: DolElnoLodgementLinkFormsComponent },
	{ path: 'lodgement/:caseReferenceId/:elnoLodgementCaseId', component: DolElnoLodgementLinkFormsComponent },
	{ path: '**', component: DolElnoLodgementRetrieve }
];

@NgModule({
	declarations: [
		AppComponent,
		DolElnoLodgementRetrieve,
		DolElnoLodgementClaim,
		DolElnoLodgementClaimArray,
		DolElnoLodgementClaimRow,
		DolElnoLodgementLinkFormsComponent,
		DolElnoMultiFileUploadComponent,
		FileSelectDirective,
		DolElnoFileUploadComponent
	],
	imports: [
		BrowserModule,
		ReactiveFormsModule,
		SRONgComponentLibraryModule.forRoot(environment),
		RouterModule.forRoot(routes, { useHash: false }),
		FileUploadModule,
		ListboxModule,
		TableModule,
		FormsModule
	],
	providers: [
		FormUtils,
		BsModalService,
		AlertService,
		UIMessageService,
		DolClaimService,
		DolClaimUIService,
		DolCategoryService,
		DutiesFormService,
		DolErrorHandler,
		{ provide: HTTP_INTERCEPTORS, useClass: SecurityInterceptor, multi: true },
	],
	entryComponents: [AppComponent],
	bootstrap: [AppComponent]
})
export class AppModule { }
