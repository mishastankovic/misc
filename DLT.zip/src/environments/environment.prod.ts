export const environment = {
	production: false,
	//apiBasePath: '/dol/claim/',
	apiBasePath: '/dutiesservice/',
	formApiBasePath: '/dutiesformrest/',
	dolApiBasePath: '/duties/',
	serviceHostname: '',
	loginUrl: '/duties/faces/public/login.xhtml'
};
