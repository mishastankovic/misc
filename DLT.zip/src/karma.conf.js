// Karma configuration file, see link for more information
// https://karma-runner.github.io/2.0/config/configuration-file.html

//process.env.CHROME_BIN = revisionInfo.executablePath

module.exports = function (config) {
	config.set({
		frameworks: ['jasmine', '@angular-devkit/build-angular'],
		plugins: [
			require('karma-jasmine'),
			require('karma-chrome-launcher'),
			require('karma-jasmine-html-reporter'),
			require('@angular-devkit/build-angular/plugins/karma')
		],
		client: {
			clearContext: false
		},
		angularCli: {
			environment: 'dev'
		},
		reporters: ['progress', 'kjhtml'],
		port: 9876,
		browsers: ['Chrome'],


	});
};
