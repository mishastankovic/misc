package au.gov.vic.sro.payment.arrangements.util;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.MDC;

public final class LogUtil {
	private static final String CUSTOMER_ID_KEY = "customer";

	public static void putCustomerId(String customerId) {
		MDC.put(CUSTOMER_ID_KEY, StringUtils.trimToEmpty(customerId));
	}

	public static void removeCustomerId() {
		MDC.remove(CUSTOMER_ID_KEY);
	}

	public LogUtil() {
		// No instance.
	}

}
