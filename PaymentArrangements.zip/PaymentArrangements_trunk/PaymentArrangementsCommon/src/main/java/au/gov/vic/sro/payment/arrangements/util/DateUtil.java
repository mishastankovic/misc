package au.gov.vic.sro.payment.arrangements.util;

import java.util.Calendar;
import java.util.Date;

import org.apache.commons.lang3.time.DateUtils;

public final class DateUtil {

	/**
	 * Check if date1 is after date2. This works for the day of year.
	 * 
	 * @param date1
	 * @param date2
	 * @return
	 */
	public static boolean isAfter(Date date1, Date date2) {
		if (date1 == null || date2 == null) {
			throw new IllegalArgumentException("The date must not be null");
		}
		final Calendar cal1 = Calendar.getInstance();
		cal1.setTime(date1);
		stripTimeToZero(cal1);

		final Calendar cal2 = Calendar.getInstance();
		cal2.setTime(date2);
		stripTimeToZero(cal2);

		return cal1.after(cal2);

	}

	/**
	 * Check if date1 is before date2. This works for the day of year.
	 * 
	 * @param date1
	 * @param date2
	 * @return
	 */
	public static boolean isBefore(Date date1, Date date2) {
		if (date1 == null || date2 == null) {
			throw new IllegalArgumentException("The date must not be null");
		}
		final Calendar cal1 = Calendar.getInstance();
		cal1.setTime(date1);
		stripTimeToZero(cal1);

		final Calendar cal2 = Calendar.getInstance();
		cal2.setTime(date2);
		stripTimeToZero(cal2);

		return cal1.before(cal2);

	}

	public static boolean isSameDay(Date date1, Date date2) {
		return DateUtils.isSameDay(date1, date2);
	}

	private static void stripTimeToZero(Calendar cal) {
		cal.set(Calendar.HOUR, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
	}

}
