package au.gov.vic.sro.payment.arrangements.dao.procedure;

import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.IN_OUT_CHECKSUM;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.OUT_MESSAGES;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.OUT_UPDATE;
import static org.apache.commons.lang3.ArrayUtils.EMPTY_OBJECT_ARRAY;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.easymock.EasyMockSupport;
import org.junit.Before;
import org.junit.Test;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import au.gov.vic.sro.payment.arrangements.dto.SaveContactsResponse;
import au.gov.vic.sro.payment.arrangements.model.Contact;
import au.gov.vic.sro.payment.arrangements.model.Message;

public class SaveContactsProcedureTest {
	private EasyMockSupport easyMockSupport;
	private DataSource mockDataSource;
	private JdbcTemplate jdbcTemplate;
	private Map<String, Object> outParameters;
	private Message message;
	private List<Contact> contacts;
	private SaveContactsProcedure procedure;
	private String checksum;

	@Before
	public void setUp() throws Exception {
		easyMockSupport = new EasyMockSupport();
		mockDataSource = easyMockSupport.createNiceMock(DataSource.class);
		jdbcTemplate = new JdbcTemplate(mockDataSource);
		outParameters = new LinkedHashMap<String, Object>();

		message = new Message();
		message.setText("foo");

		Contact contact = new Contact();
		contact.setPersonName("contact1");
		contacts = Arrays.asList(contact);

		procedure = new SaveContactsProcedure(jdbcTemplate) {

			@Override
			public Map<String, Object> execute(Map<String, ?> inParams) throws DataAccessException {
				return outParameters;
			}
		};

		checksum = "O8DHAND75S9SKSJW6WHSUA71BS7SGA6S";
	}

	@Test
	public void testExecute() throws Exception {
		outParameters.put(OUT_UPDATE, true);
		outParameters.put(OUT_MESSAGES, EMPTY_OBJECT_ARRAY);
		outParameters.put(IN_OUT_CHECKSUM, checksum);
		easyMockSupport.replayAll();

		SaveContactsResponse result = procedure.execute(contacts, checksum);

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
		assertThat(result.getSaved(), is(true));
		assertThat(result.getChecksum(), is(checksum));
		assertThat(result.getMessages(), is(empty()));
	}

	@Test
	public void testExecuteNullInput() throws Exception {
		contacts = null;
		easyMockSupport.replayAll();

		SaveContactsResponse result = procedure.execute(contacts, checksum);

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
	}

	@Test
	public void testExecuteNullOutput() throws Exception {
		outParameters = null;
		easyMockSupport.replayAll();

		SaveContactsResponse result = procedure.execute(contacts, checksum);

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
		assertThat(result.getSaved(), is(nullValue()));
		assertThat(result.getMessages(), is(empty()));
	}

}
