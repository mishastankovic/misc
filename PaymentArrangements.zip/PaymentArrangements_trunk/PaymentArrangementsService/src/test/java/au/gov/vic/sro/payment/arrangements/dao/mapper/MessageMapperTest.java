package au.gov.vic.sro.payment.arrangements.dao.mapper;

import static au.gov.vic.sro.payment.arrangements.model.MessageType.ERROR;
import static org.easymock.EasyMock.expect;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;

import java.math.BigDecimal;
import java.util.Arrays;

import org.easymock.EasyMockSupport;
import org.junit.Before;
import org.junit.Test;

import au.gov.vic.sro.payment.arrangements.model.Message;
import oracle.sql.STRUCT;

public class MessageMapperTest {
	private EasyMockSupport easyMockSupport;
	private STRUCT mockStruct;
	private Object[] rec;
	private MessageMapper mapper;

	@Before
	public void setUp() throws Exception {
		easyMockSupport = new EasyMockSupport();
		mockStruct = easyMockSupport.createNiceMock(STRUCT.class);

		rec = new Object[] { BigDecimal.valueOf(9999), // MSG_NUM
				"E", // MSG_TYPE
				"KABOOM!!!" // MSG_TEXT
		};

		mapper = new MessageMapper();
	}

	@Test(expected = UnsupportedOperationException.class)
	public void testToStruct() throws Exception {
		mapper.toStruct(null, null, null);
	}

	@Test
	public void testFromStruct() throws Exception {
		expect(mockStruct.getSQLTypeName()).andReturn("ESYS.PAO_MESSAGE_REC");
		expect(mockStruct.getAttributes()).andReturn(rec).atLeastOnce();
		easyMockSupport.replayAll();

		Message result = mapper.fromStruct(mockStruct);

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
		assertThat(result.getCode(), is(9999));
		assertThat(result.getType(), is(ERROR));
		assertThat(result.isError(), is(true));
		assertThat(result.getText(), is("KABOOM!!!"));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testFromStructNull() throws Exception {
		mapper.fromStruct(null);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testFromStructInvalidTypeName() throws Exception {
		expect(mockStruct.getSQLTypeName()).andReturn("ESYS.BAD_REC");
		expect(mockStruct.debugString()).andStubReturn("BAD!!!");
		easyMockSupport.replayAll();

		mapper.fromStruct(mockStruct);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testFromStructInvalidTypeLength() throws Exception {
		rec = null;
		expect(mockStruct.getSQLTypeName()).andReturn("ESYS.PAO_MESSAGE_REC");
		expect(mockStruct.getAttributes()).andReturn(rec).atLeastOnce();
		expect(mockStruct.debugString()).andStubReturn("BAD!!!");
		easyMockSupport.replayAll();

		mapper.fromStruct(mockStruct);
	}

	@Test
	public void testFromStructNullAttributes() throws Exception {
		Arrays.fill(rec, null);
		expect(mockStruct.getSQLTypeName()).andReturn("ESYS.PAO_MESSAGE_REC");
		expect(mockStruct.getAttributes()).andReturn(rec).atLeastOnce();
		easyMockSupport.replayAll();

		Message result = mapper.fromStruct(mockStruct);

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
		assertThat(result.getCode(), is(nullValue()));
		assertThat(result.getType(), is(nullValue()));
		assertThat(result.isError(), is(false));
		assertThat(result.getText(), is(nullValue()));
	}

}
