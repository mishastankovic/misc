package au.gov.vic.sro.payment.arrangements.service;

import static au.gov.vic.sro.payment.arrangements.model.LiabilityType.ASSESSMENT;
import static au.gov.vic.sro.payment.arrangements.model.RevenueLine.LAND_TAX;
import static org.easymock.EasyMock.eq;
import static org.easymock.EasyMock.expect;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

import java.util.ArrayList;

import org.easymock.EasyMockSupport;
import org.junit.Before;
import org.junit.Test;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDao;
import au.gov.vic.sro.payment.arrangements.dto.AuthenticateResponse;

public class UserDetailsServiceImplTest {
	private EasyMockSupport easyMockSupport;
	private PaymentArrangementsDao mockPaymentArrangementsDao;
	private GrantedAuthority roleUser;
	private AuthenticateResponse mockAuthenticateResult;
	private UserDetailsServiceImpl service;
	private String usernameJson;

	@Before
	public void setUp() throws Exception {
		easyMockSupport = new EasyMockSupport();
		mockPaymentArrangementsDao = easyMockSupport.createNiceMock(PaymentArrangementsDao.class);
		mockAuthenticateResult = easyMockSupport.createNiceMock(AuthenticateResponse.class);
		roleUser = new SimpleGrantedAuthority("ROLE_USER");

		service = new UserDetailsServiceImpl();
		service.setPaymentArrangementsDao(mockPaymentArrangementsDao);
		service.setUserAuthorities(new ArrayList<GrantedAuthority>());
		service.getUserAuthorities().add(roleUser);

		usernameJson =
				"{\"customerId\":\"999\",\"revenueLine\":\"LTX\",\"liabilityType\":\"A\",\"liabilityId\":\"S00000001\"}";
	}

	@Test
	public void testParseUsername() {
		UserDetailsImpl result = service.parseUsername(usernameJson);

		assertThat(result, is(notNullValue()));
		assertThat(result.getCustomerId(), is("999"));
		assertThat(result.getRevenueLine(), is(LAND_TAX));
		assertThat(result.getLiabilityType(), is(ASSESSMENT));
		assertThat(result.getLiabilityId(), is("S00000001"));
		assertThat(result.getNormalizedLiabilityId(), is("00000001"));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testParseUsernameNull() {
		service.parseUsername(null);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testParseUsernameEmpty() {
		service.parseUsername("");
	}

	@Test(expected = IllegalArgumentException.class)
	public void testParseUsernameNoFields() {
		service.parseUsername("{}");
	}

	@Test
	public void testLoadUserByUsername() {
		expect(mockPaymentArrangementsDao.authenticate(eq("999"), eq(LAND_TAX), eq(ASSESSMENT), eq("S00000001")))
				.andReturn(mockAuthenticateResult);
		expect(mockAuthenticateResult.getAuthenticated()).andReturn(true);
		expect(mockAuthenticateResult.getRevenueLineCode()).andReturn("LTX");
		expect(mockAuthenticateResult.getCustomerId()).andReturn("999");
		easyMockSupport.replayAll();

		UserDetailsImpl result = (UserDetailsImpl) service.loadUserByUsername(usernameJson);

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
		assertThat(result.getCustomerId(), is("999"));
		assertThat(result.getRevenueLine(), is(LAND_TAX));
		assertThat(result.getLiabilityType(), is(ASSESSMENT));
		assertThat(result.getLiabilityId(), is("S00000001"));
		assertThat(result.getNormalizedLiabilityId(), is("00000001"));
		assertThat(result.getUsername(), is(usernameJson));
		assertThat(result.getPassword(), is("password"));
		assertThat(result.getAuthorities(), containsInAnyOrder(roleUser));
	}

	@Test(expected = UsernameNotFoundException.class)
	public void testLoadUserByUsernameNotFound() {
		expect(mockPaymentArrangementsDao.authenticate(eq("999"), eq(LAND_TAX), eq(ASSESSMENT), eq("S00000001")))
				.andReturn(mockAuthenticateResult);
		expect(mockAuthenticateResult.getAuthenticated()).andReturn(false);
		expect(mockAuthenticateResult.getRevenueLineCode()).andReturn("LTX");
		expect(mockAuthenticateResult.getCustomerId()).andReturn("999");
		expect(mockAuthenticateResult.getMessages()).andReturn(null);
		easyMockSupport.replayAll();

		service.loadUserByUsername(usernameJson);
	}

}
