package au.gov.vic.sro.payment.arrangements.dao.mapper;

import static au.gov.vic.sro.payment.arrangements.model.LiabilityType.ASSESSMENT;
import static au.gov.vic.sro.payment.arrangements.model.RevenueLine.LAND_TAX;
import static org.apache.commons.lang3.time.DateFormatUtils.ISO_8601_EXTENDED_DATETIME_FORMAT;
import static org.apache.commons.lang3.time.DateFormatUtils.ISO_8601_EXTENDED_DATE_FORMAT;
import static org.easymock.EasyMock.expect;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Date;

import org.easymock.EasyMockSupport;
import org.junit.Before;
import org.junit.Test;

import au.gov.vic.sro.payment.arrangements.model.Arrangement;
import au.gov.vic.sro.payment.arrangements.model.Liability;
import au.gov.vic.sro.util.DateUtil;
import oracle.sql.STRUCT;

public class LiabilityMapperTest {
	private EasyMockSupport easyMockSupport;
	private Connection mockConnection;
	private STRUCT mockStruct;
	private Object[] rec;
	private Liability liability;
	private LiabilityMapper mapper;

	@Before
	public void setUp() throws Exception {
		easyMockSupport = new EasyMockSupport();
		mockConnection = easyMockSupport.createNiceMock(Connection.class);
		mockStruct = easyMockSupport.createNiceMock(STRUCT.class);

		Arrangement arrangement = new Arrangement();
		arrangement.setId(BigInteger.valueOf(123));
		arrangement.setVersion(4);

		liability = new Liability();
		liability.setRevenueLine(LAND_TAX);
		liability.setType(ASSESSMENT);
		liability.setId("00000001");
		liability.setVersion(2);
		liability.setIssueDate(parseDate("2018-02-01"));
		liability.setYear(2017);
		liability.setOutstandingLiabilityAmountDollars(BigDecimal.valueOf(1234.56));
		liability.setArrangement(arrangement);

		rec = new Object[] { ASSESSMENT.getCode(), // PAO_LIABILITY_REFERENCE_TYPE
				"00000001", // LIABILITY_REFERENCE_ID
				BigDecimal.valueOf(2), // LIABILITY_REFERENCE_VERSION
				BigDecimal.valueOf(2017), // LIABILITY_YEAR
				parseTs("2018-02-01"), // LIABILITY_ISSUE_DATE
				LAND_TAX.getCode(), // REVENUE_TYPE
				BigDecimal.valueOf(123), // PAYMENT_ARRANGEMENT_ID
				BigDecimal.valueOf(4), // PAYMENT_ARRANGEMENT_VERSION
				BigDecimal.valueOf(1234.56) // OUTSTANDING_LIABILITY_AMOUNT
				};

		mapper = new LiabilityMapper() {

			@Override
			public STRUCT toStruct(Liability source, Connection connection, String typeName) throws SQLException {
				return mockStruct;
			}
		};
	}

	@Test
	public void testToStruct() throws Exception {
		easyMockSupport.replayAll();

		STRUCT result = mapper.toStruct(liability, mockConnection, "PAO_LIABILITY_REC");

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testToStructNull() throws Exception {
		mapper = new LiabilityMapper();
		mapper.toStruct(null, null, null);
	}

	@Test
	public void testToRec() throws Exception {
		easyMockSupport.replayAll();

		Object[] result = mapper.toRec(liability);

		easyMockSupport.verifyAll();
		assertThat(result, is(rec));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testToRecNull() throws Exception {
		mapper.toRec(null);
	}

	@Test
	public void testFromStruct() throws Exception {
		expect(mockStruct.getSQLTypeName()).andReturn("ESYS.PAO_LIABILITY_REC");
		expect(mockStruct.getAttributes()).andReturn(rec).atLeastOnce();
		easyMockSupport.replayAll();

		Liability result = mapper.fromStruct(mockStruct);

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
		assertThat(result.getRevenueLine(), is(LAND_TAX));
		assertThat(result.getType(), is(ASSESSMENT));
		assertThat(result.getId(), is("00000001"));
		assertThat(result.getVersion(), is(2));
		assertThat(result.getIssueDate(), is(parseDate("2018-02-01")));
		assertThat(result.getYear(), is(2017));
		assertThat(result.getOutstandingLiabilityAmountDollars(), is(BigDecimal.valueOf(1234.56)));
		assertThat(result.getArrangement(), is(nullValue()));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testFromStructNull() throws Exception {
		mapper.fromStruct(null);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testFromStructInvalidTypeName() throws Exception {
		expect(mockStruct.getSQLTypeName()).andReturn("ESYS.BAD_REC");
		expect(mockStruct.debugString()).andStubReturn("BAD!!!");
		easyMockSupport.replayAll();

		mapper.fromStruct(mockStruct);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testFromStructInvalidTypeLength() throws Exception {
		rec = null;
		expect(mockStruct.getSQLTypeName()).andReturn("ESYS.PAO_LIABILITY_REC");
		expect(mockStruct.getAttributes()).andReturn(rec).atLeastOnce();
		expect(mockStruct.debugString()).andStubReturn("BAD!!!");
		easyMockSupport.replayAll();

		mapper.fromStruct(mockStruct);
	}

	@Test
	public void testFromStructNullAttributes() throws Exception {
		Arrays.fill(rec, null);
		expect(mockStruct.getSQLTypeName()).andReturn("ESYS.PAO_LIABILITY_REC");
		expect(mockStruct.getAttributes()).andReturn(rec).atLeastOnce();
		easyMockSupport.replayAll();

		Liability result = mapper.fromStruct(mockStruct);

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
		assertThat(result.getRevenueLine(), is(nullValue()));
		assertThat(result.getType(), is(nullValue()));
		assertThat(result.getId(), is(nullValue()));
		assertThat(result.getVersion(), is(nullValue()));
		assertThat(result.getIssueDate(), is(nullValue()));
		assertThat(result.getYear(), is(nullValue()));
		assertThat(result.getOutstandingLiabilityAmountDollars(), is(nullValue()));
		assertThat(result.getArrangement(), is(nullValue()));
	}

	private Date parseDate(String s) {
		return DateUtil.parseDate(s, ISO_8601_EXTENDED_DATE_FORMAT.getPattern(),
				ISO_8601_EXTENDED_DATETIME_FORMAT.getPattern());
	}

	private Timestamp parseTs(String s) {
		return DateUtil.toSqlTimestamp(DateUtil.parseDate(s, ISO_8601_EXTENDED_DATE_FORMAT.getPattern(),
				ISO_8601_EXTENDED_DATETIME_FORMAT.getPattern()));
	}

}
