package au.gov.vic.sro.payment.arrangements.service;

import static au.gov.vic.sro.payment.arrangements.model.PaymentMethod.CREDIT_CARD;
import static au.gov.vic.sro.payment.arrangements.model.PaymentMethod.DIRECT_DEBIT;
import static org.easymock.EasyMock.eq;
import static org.easymock.EasyMock.expect;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;

import java.math.BigInteger;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;

import org.easymock.EasyMockSupport;
import org.junit.Before;
import org.junit.Test;

import au.gov.vic.sro.payment.arrangements.dto.SaveAccountRequest;
import au.gov.vic.sro.payment.arrangements.model.PaymentMethod;
import au.gov.vic.sro.payment.arrangements.model.RevenueLine;
import au.gov.vic.sro.payment.quickstream3.QuickstreamUtil;

public class QuickVaultServiceImplTest {
	private EasyMockSupport easyMockSupport;
	private Properties properties;
	private QuickstreamUtil mockQuickstreamUtil;
	private QuickVaultServiceImpl service;
	private String checksum;

	@Before
	public void setUp() throws Exception {
		easyMockSupport = new EasyMockSupport();
		mockQuickstreamUtil = easyMockSupport.createNiceMock(QuickstreamUtil.class);

		properties = new Properties();
		properties.setProperty("quickVault.username", "Test_User");
		properties.setProperty("quickVault.password", "Test_Pass");
		properties.setProperty("quickVault.returnUrl", "http://www.example.com/return");
		properties.setProperty("quickVault.cancelUrl", "http://www.example.com/cancel");
		properties.setProperty("quickVault.serverReturnUrl", "http://www.example.com/serverReturn");
		properties.setProperty("quickVault.errorEmailToAddress", "example@example.com");
		properties.setProperty("quickVault.communityCode", "SROPA");
		properties.setProperty("quickVault.supplierBusinessCode.ltx", "LTX");

		service = new QuickVaultServiceImpl() {

			@Override
			protected QuickstreamUtil getQuickstreamUtil() {
				return mockQuickstreamUtil;
			}

		};
		service.setProperties(properties);
		service.setSecurityTokenRequestBaseUrl("http://www.example.com/securityTokenBase");
		service.setBrowserRedirectBaseUrl("http://www.example.com/redirectBase");

		checksum = "JSNDHSBAGSVDTQYW8J3WKS82US6TWE9I";
	}

	@Test
	public void testGetSecurityToken() throws Exception {
		Map<String, String> parameters = new LinkedHashMap<String, String>();
		parameters.put("product", "QUICKVAULT");
		parameters.put("username", "Test_User");
		parameters.put("password", "Test_Pass");
		parameters.put("supplierBusinessCode", "LTX");
		parameters.put("customerReferenceNumber", "123-4");
		parameters.put("accountType", "CREDIT_CARD");
		parameters.put("returnUrl", "http://www.example.com/return");
		parameters.put("cancelUrl", "http://www.example.com/cancel");
		parameters.put("serverReturnUrl", "http://www.example.com/serverReturn");
		parameters.put("errorEmailToAddress", "example@example.com");
		parameters.put("customCustomerId", "999");
		parameters.put("customChecksum", checksum);
		expect(mockQuickstreamUtil.getSecurityToken(eq("http://www.example.com/securityTokenBase"), eq(parameters)))
				.andReturn("Test_Security_Token");
		easyMockSupport.replayAll();

		String result = service.getSecurityToken("999", BigInteger.valueOf(123), 4, RevenueLine.LAND_TAX,
				PaymentMethod.CREDIT_CARD, checksum);

		easyMockSupport.verifyAll();
		assertThat(result, is("Test_Security_Token"));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testGetSecurityTokenNull() throws Exception {
		service.getSecurityToken(null, null, null, null, null, null);
	}

	@Test
	public void testGetBrowserRedirectUrl() throws Exception {
		Map<String, String> parameters = new LinkedHashMap<String, String>();
		parameters.put("communityCode", "SROPA");
		parameters.put("token", "Test_Security_Token");
		expect(mockQuickstreamUtil.getBrowserRedirectUrl(eq("http://www.example.com/redirectBase"), eq(parameters)))
				.andReturn("http://www.example.com/redirect");
		easyMockSupport.replayAll();

		String result = service.getBrowserRedirectUrl("Test_Security_Token");

		easyMockSupport.verifyAll();
		assertThat(result, is("http://www.example.com/redirect"));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testGetBrowserRedirectUrlNull() throws Exception {
		service.getBrowserRedirectUrl(null);
	}

	@Test
	public void testGetParameter() throws Exception {
		Map<String, String[]> map = new LinkedHashMap<String, String[]>();
		map.put("a", null);
		map.put("b", new String[] {});
		map.put("c", new String[] { null });
		map.put("d", new String[] { "\t" });
		map.put("e", new String[] { "x" });
		map.put("f", new String[] { "y", "z" });

		assertThat(service.getParameter(map, "a"), is(nullValue()));
		assertThat(service.getParameter(map, "b"), is(nullValue()));
		assertThat(service.getParameter(map, "c"), is(nullValue()));
		assertThat(service.getParameter(map, "d"), is(nullValue()));
		assertThat(service.getParameter(map, "e"), is("x"));
		assertThat(service.getParameter(map, "f"), is("y"));
	}

	@Test
	public void testToString() throws Exception {
		assertThat(service.toString(null), is("<null>"));
		assertThat(service.toString(generateParameterMap(CREDIT_CARD)), is(notNullValue()));
		assertThat(service.toString(generateParameterMap(DIRECT_DEBIT)), is(notNullValue()));
	}

	@Test
	public void testGetSaveAccountRequestCreditCard() throws Exception {
		SaveAccountRequest result = service.getSaveAccountRequest(generateParameterMap(CREDIT_CARD));

		assertThat(result, is(notNullValue()));
		assertThat(result.getArrangementId(), is(BigInteger.valueOf(123)));
		assertThat(result.getArrangementVersion(), is(4));
		assertThat(result.getAccountToken(), is("Test_Account_Token"));
		assertThat(result.getPaymentMethod(), is(CREDIT_CARD));
		assertThat(result.getCardNumber(), is("411111xxxxxxx111"));
		assertThat(result.getCardExpiryMonth(), is("01"));
		assertThat(result.getCardExpiryYear(), is("2017"));
		assertThat(result.getBankBsb(), is(nullValue()));
		assertThat(result.getBankAccountNumber(), is(nullValue()));
		assertThat(result.getChecksum(), is(checksum));
	}

	@Test
	public void testGetSaveAccountRequestDirectDebit() throws Exception {
		SaveAccountRequest result = service.getSaveAccountRequest(generateParameterMap(DIRECT_DEBIT));

		assertThat(result, is(notNullValue()));
		assertThat(result.getArrangementId(), is(BigInteger.valueOf(123)));
		assertThat(result.getArrangementVersion(), is(4));
		assertThat(result.getAccountToken(), is("Test_Account_Token"));
		assertThat(result.getPaymentMethod(), is(DIRECT_DEBIT));
		assertThat(result.getCardNumber(), is(nullValue()));
		assertThat(result.getCardExpiryMonth(), is(nullValue()));
		assertThat(result.getCardExpiryYear(), is(nullValue()));
		assertThat(result.getBankBsb(), is("xxx-000"));
		assertThat(result.getBankAccountNumber(), is("xxxxxx678"));
		assertThat(result.getChecksum(), is(checksum));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testGetSaveAccountRequestNull() throws Exception {
		service.getSaveAccountRequest(null);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testGetSaveAccountRequestEmpty() throws Exception {
		service.getSaveAccountRequest(new LinkedHashMap<String, String[]>());
	}

	@Test
	public void testGetSaveAccountRequestNoCustomCustomerId() throws Exception {
		Map<String, String[]> map = generateParameterMap(CREDIT_CARD);
		map.remove("customCustomerId");

		SaveAccountRequest result = service.getSaveAccountRequest(map);
		assertThat(result, is(notNullValue()));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testGetSaveAccountRequestInvalidProduct() throws Exception {
		Map<String, String[]> map = generateParameterMap(CREDIT_CARD);
		map.put("product", new String[] { "BAD!!!" });

		service.getSaveAccountRequest(map);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testGetSaveAccountRequestInvalidCommunityCode() throws Exception {
		Map<String, String[]> map = generateParameterMap(CREDIT_CARD);
		map.put("communityCode", new String[] { "BAD!!!" });

		service.getSaveAccountRequest(map);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testGetSaveAccountRequestInvalidCustomerReferenceNumber() throws Exception {
		Map<String, String[]> map = generateParameterMap(CREDIT_CARD);
		map.put("customerReferenceNumber", new String[] { "BAD!!!" });

		service.getSaveAccountRequest(map);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testGetSaveAccountRequestInvalidPreregistrationCode() throws Exception {
		Map<String, String[]> map = generateParameterMap(CREDIT_CARD);
		map.put("preregistrationCode", new String[] {});

		service.getSaveAccountRequest(map);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testGetSaveAccountRequestInvalidMaskedCardNumber() throws Exception {
		Map<String, String[]> map = generateParameterMap(CREDIT_CARD);
		map.put("maskedCardNumber", new String[] {});

		service.getSaveAccountRequest(map);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testGetSaveAccountRequestInvalidExpiryDateMonth() throws Exception {
		Map<String, String[]> map = generateParameterMap(CREDIT_CARD);
		map.put("expiryDateMonth", new String[] {});

		service.getSaveAccountRequest(map);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testGetSaveAccountRequestInvalidExpiryDateYear() throws Exception {
		Map<String, String[]> map = generateParameterMap(CREDIT_CARD);
		map.put("expiryDateYear", new String[] {});

		service.getSaveAccountRequest(map);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testGetSaveAccountRequestInvalidBsb() throws Exception {
		Map<String, String[]> map = generateParameterMap(DIRECT_DEBIT);
		map.put("bsb", new String[] {});

		service.getSaveAccountRequest(map);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testGetSaveAccountRequestAccountNumber() throws Exception {
		Map<String, String[]> map = generateParameterMap(DIRECT_DEBIT);
		map.put("accountNumber", new String[] {});

		service.getSaveAccountRequest(map);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testGetSaveAccountRequestPaymentMethod() throws Exception {
		service.getSaveAccountRequest(generateParameterMap(null));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testChecksumNull() throws Exception {
		Map<String, String[]> map = generateParameterMap(DIRECT_DEBIT);
		map.put("customChecksum", null);

		service.getSaveAccountRequest(map);
	}

	private Map<String, String[]> generateParameterMap(PaymentMethod paymentMethod) {
		Map<String, String[]> map = new LinkedHashMap<String, String[]>();
		map.put("product", new String[] { "QUICKVAULT" });
		map.put("communityCode", new String[] { "SROPA" });
		map.put("supplierBusinessCode", new String[] { "LTX" });
		map.put("customerReferenceNumber", new String[] { "123-4" });
		if (paymentMethod == CREDIT_CARD) {
			map.put("cardholderName", new String[] { "Blast Hardcheese" });
			map.put("maskedCardNumber", new String[] { "411111xxxxxxx111" });
			map.put("expiryDateMonth", new String[] { "01" });
			map.put("expiryDateYear", new String[] { "2017" });
			map.put("cardScheme", new String[] { "VISA" });
		} else if (paymentMethod == DIRECT_DEBIT) {
			map.put("bsb", new String[] { "xxx-000" });
			map.put("accountNumber", new String[] { "xxxxxx678" });
			map.put("accountName", new String[] { "Blast Hardcheese savings" });
		}
		map.put("preregistrationCode", new String[] { "Test_Account_Token" });
		map.put("customCustomerId", new String[] { "999" });
		map.put("customChecksum", new String[] { checksum });
		return map;
	}

}
