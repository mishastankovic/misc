package au.gov.vic.sro.payment.arrangements.dao.procedure;

import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.IN_OUT_CHECKSUM;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.OUT_ARRANGEMENT_ID;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.OUT_ARRANGEMENT_VERSION;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.OUT_MESSAGES;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.easymock.EasyMockSupport;
import org.junit.Before;
import org.junit.Test;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import au.gov.vic.sro.payment.arrangements.dto.SaveArrangementResponse;
import au.gov.vic.sro.payment.arrangements.model.Arrangement;
import au.gov.vic.sro.payment.arrangements.model.Contact;
import au.gov.vic.sro.payment.arrangements.model.Instalment;
import au.gov.vic.sro.payment.arrangements.model.Liability;
import au.gov.vic.sro.payment.arrangements.model.Message;

public class SaveArrangementProcedureTest {
	private EasyMockSupport easyMockSupport;
	private DataSource mockDataSource;
	private JdbcTemplate jdbcTemplate;
	private Map<String, Object> outParameters;
	private Arrangement arrangement;
	private Liability liability;
	private Instalment instalment;
	private Contact contact;
	private Message message;
	private SaveArrangementProcedure procedure;
	private String checksum;

	@Before
	public void setUp() throws Exception {
		easyMockSupport = new EasyMockSupport();
		mockDataSource = easyMockSupport.createNiceMock(DataSource.class);
		jdbcTemplate = new JdbcTemplate(mockDataSource);
		checksum = "JSNDHSBAGSVDTQYW8J3WKS82US6TWE9I";

		arrangement = new Arrangement();
		arrangement.setId(BigInteger.valueOf(123));
		arrangement.setVersion(4);
		arrangement.setChecksum(checksum);

		liability = new Liability();
		liability.setId("liability1");
		liability.setVersion(1);
		arrangement.getLiabilities().add(liability);

		instalment = new Instalment();
		instalment.setId(1);
		arrangement.getInstalments().add(instalment);

		contact = new Contact();
		contact.setPersonName("contact1");
		arrangement.getContacts().add(contact);

		message = new Message();
		message.setText("message1");

		outParameters = new LinkedHashMap<String, Object>();
		outParameters.put(OUT_ARRANGEMENT_ID, BigDecimal.valueOf(123));
		outParameters.put(OUT_ARRANGEMENT_VERSION, BigDecimal.valueOf(4));
		outParameters.put(IN_OUT_CHECKSUM, checksum);
		outParameters.put(OUT_MESSAGES, new Object[] { message });

		procedure = new SaveArrangementProcedure(jdbcTemplate) {

			@Override
			public Map<String, Object> execute(Map<String, ?> inParams) throws DataAccessException {
				return outParameters;
			}
		};
	}

	@Test
	public void testExecute() throws Exception {
		easyMockSupport.replayAll();

		SaveArrangementResponse result = procedure.execute(arrangement);

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
		assertThat(result.getSaved(), is(true));
		assertThat(result.getArrangementId(), is(arrangement.getId()));
		assertThat(result.getArrangementVersion(), is(arrangement.getVersion()));
		assertThat(result.getChecksum(), is(arrangement.getChecksum()));
		assertThat(result.getMessages(), contains(message));
	}

	@Test
	public void testExecuteNullInput() throws Exception {
		arrangement = null;
		easyMockSupport.replayAll();

		SaveArrangementResponse result = procedure.execute(arrangement);

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
	}

	@Test
	public void testExecuteNullOutput() throws Exception {
		outParameters = null;
		easyMockSupport.replayAll();

		SaveArrangementResponse result = procedure.execute(arrangement);

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
		assertThat(result.getSaved(), is(false));
		assertThat(result.getArrangementId(), is(nullValue()));
		assertThat(result.getArrangementVersion(), is(nullValue()));
		assertThat(result.getChecksum(), is(nullValue()));
		assertThat(result.getMessages(), is(empty()));
	}
}