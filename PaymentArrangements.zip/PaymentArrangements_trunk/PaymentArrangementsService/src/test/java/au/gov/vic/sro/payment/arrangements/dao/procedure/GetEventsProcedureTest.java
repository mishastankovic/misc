package au.gov.vic.sro.payment.arrangements.dao.procedure;

import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.OUT_RESULT;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.easymock.EasyMockSupport;
import org.junit.Before;
import org.junit.Test;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import au.gov.vic.sro.payment.arrangements.dto.GetEventsResponse;
import au.gov.vic.sro.payment.arrangements.model.Event;

public class GetEventsProcedureTest {
	private EasyMockSupport easyMockSupport;
	private DataSource mockDataSource;
	private JdbcTemplate jdbcTemplate;
	private Map<String, Object> outParameters;
	private Event event1;
	private Event event2;
	private List<BigInteger> eventIds;
	private GetEventsProcedure procedure;

	@Before
	public void setUp() throws Exception {
		easyMockSupport = new EasyMockSupport();
		mockDataSource = easyMockSupport.createNiceMock(DataSource.class);
		jdbcTemplate = new JdbcTemplate(mockDataSource);

		event1 = new Event();
		event1.setId(BigInteger.valueOf(111));
		event2 = new Event();
		event2.setId(BigInteger.valueOf(222));
		eventIds = Arrays.asList(event1.getId(), event2.getId());

		outParameters = new LinkedHashMap<String, Object>();
		outParameters.put(OUT_RESULT, new Object[] { event1, event2, new Event() });

		procedure = new GetEventsProcedure(jdbcTemplate) {

			@Override
			public Map<String, Object> execute(Map<String, ?> inParams) throws DataAccessException {
				return outParameters;
			}
		};
	}

	@Test
	public void testExecute() throws Exception {
		easyMockSupport.replayAll();

		GetEventsResponse result = procedure.execute(eventIds);

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
		assertThat(result.getEvents(), contains(event1, event2));
	}

	@Test
	public void testExecuteNullInput() throws Exception {
		eventIds = null;
		easyMockSupport.replayAll();

		GetEventsResponse result = procedure.execute(eventIds);

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
	}

	@Test
	public void testExecuteNullOutput() throws Exception {
		outParameters = null;
		easyMockSupport.replayAll();

		GetEventsResponse result = procedure.execute(eventIds);

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
		assertThat(result.getEvents(), is(empty()));
	}

}
