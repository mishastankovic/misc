package au.gov.vic.sro.payment.arrangements.dao.mapper;

import static au.gov.vic.sro.payment.arrangements.model.EventStatus.REQUESTED;
import static au.gov.vic.sro.payment.arrangements.model.EventType.CANCELLED_INTERNAL_USER;
import static org.easymock.EasyMock.expect;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Arrays;

import org.easymock.EasyMockSupport;
import org.junit.Before;
import org.junit.Test;

import au.gov.vic.sro.payment.arrangements.model.Event;
import oracle.sql.STRUCT;

public class EventMapperTest {
	private EasyMockSupport easyMockSupport;
	private STRUCT mockStruct;
	private Object[] rec;
	private EventMapper mapper;

	@Before
	public void setUp() throws Exception {
		easyMockSupport = new EasyMockSupport();
		mockStruct = easyMockSupport.createNiceMock(STRUCT.class);

		rec = new Object[] { BigDecimal.valueOf(3), // PAO_EVENT_NOTIFICATION_ID
				CANCELLED_INTERNAL_USER.getCode(), // PAO_EVENT_NOTIFICATION_TYPE
				BigDecimal.valueOf(123), // PAYMENT_ARRANGEMENT_ID
				BigDecimal.valueOf(4), // PAYMENT_ARRANGEMENT_VERSION
				REQUESTED.getCode() // STATUS
				};

		mapper = new EventMapper();
	}

	@Test(expected = UnsupportedOperationException.class)
	public void testToStruct() throws Exception {
		mapper.toStruct(null, null, null);
	}

	@Test
	public void testFromStruct() throws Exception {
		expect(mockStruct.getSQLTypeName()).andReturn("ESYS.PAO_EVENT_NOTIFICATION_REC");
		expect(mockStruct.getAttributes()).andReturn(rec).atLeastOnce();
		easyMockSupport.replayAll();

		Event result = mapper.fromStruct(mockStruct);

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
		assertThat(result.getId(), is(BigInteger.valueOf(3)));
		assertThat(result.getType(), is(CANCELLED_INTERNAL_USER));
		assertThat(result.getStatus(), is(REQUESTED));
		assertThat(result.getArrangementId(), is(BigInteger.valueOf(123)));
		assertThat(result.getArrangementVersion(), is(4));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testFromStructNull() throws Exception {
		mapper.fromStruct(null);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testFromStructInvalidTypeName() throws Exception {
		expect(mockStruct.getSQLTypeName()).andReturn("ESYS.BAD_REC");
		expect(mockStruct.debugString()).andStubReturn("BAD!!!");
		easyMockSupport.replayAll();

		mapper.fromStruct(mockStruct);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testFromStructInvalidTypeLength() throws Exception {
		rec = null;
		expect(mockStruct.getSQLTypeName()).andReturn("ESYS.PAO_EVENT_NOTIFICATION_REC");
		expect(mockStruct.getAttributes()).andReturn(rec).atLeastOnce();
		expect(mockStruct.debugString()).andStubReturn("BAD!!!");
		easyMockSupport.replayAll();

		mapper.fromStruct(mockStruct);
	}

	@Test
	public void testFromStructNullAttributes() throws Exception {
		Arrays.fill(rec, null);
		expect(mockStruct.getSQLTypeName()).andReturn("ESYS.PAO_EVENT_NOTIFICATION_REC");
		expect(mockStruct.getAttributes()).andReturn(rec).atLeastOnce();
		easyMockSupport.replayAll();

		Event result = mapper.fromStruct(mockStruct);

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
		assertThat(result.getId(), is(nullValue()));
		assertThat(result.getType(), is(nullValue()));
		assertThat(result.getStatus(), is(nullValue()));
		assertThat(result.getArrangementId(), is(nullValue()));
		assertThat(result.getArrangementVersion(), is(nullValue()));
	}

}
