package au.gov.vic.sro.payment.arrangements.dao;

import static au.gov.vic.sro.payment.arrangements.model.LiabilityType.ASSESSMENT;
import static au.gov.vic.sro.payment.arrangements.model.PaymentFrequency.FOUR;
import static au.gov.vic.sro.payment.arrangements.model.PaymentMethod.CREDIT_CARD;
import static au.gov.vic.sro.payment.arrangements.model.RevenueLine.LAND_TAX;
import static org.apache.commons.lang3.time.DateFormatUtils.ISO_8601_EXTENDED_DATETIME_FORMAT;
import static org.apache.commons.lang3.time.DateFormatUtils.ISO_8601_EXTENDED_DATE_FORMAT;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.expectLastCall;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

import java.math.BigInteger;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.easymock.EasyMockSupport;
import org.junit.Before;
import org.junit.Test;

import au.gov.vic.sro.payment.arrangements.dao.procedure.AuthenticateProcedure;
import au.gov.vic.sro.payment.arrangements.dao.procedure.CalculateScheduleProcedure;
import au.gov.vic.sro.payment.arrangements.dao.procedure.CancelArrangementProcedure;
import au.gov.vic.sro.payment.arrangements.dao.procedure.FindArrangementProcedure;
import au.gov.vic.sro.payment.arrangements.dao.procedure.GetNotificationArrangementProcedure;
import au.gov.vic.sro.payment.arrangements.dao.procedure.GetConfirmCancelTextProcedure;
import au.gov.vic.sro.payment.arrangements.dao.procedure.GetDefaultDatesProcedure;
import au.gov.vic.sro.payment.arrangements.dao.procedure.GetEventsProcedure;
import au.gov.vic.sro.payment.arrangements.dao.procedure.GetFrequenciesProcedure;
import au.gov.vic.sro.payment.arrangements.dao.procedure.NextEventProcedure;
import au.gov.vic.sro.payment.arrangements.dao.procedure.SaveAccountProcedure;
import au.gov.vic.sro.payment.arrangements.dao.procedure.SaveArrangementProcedure;
import au.gov.vic.sro.payment.arrangements.dao.procedure.SaveContactsProcedure;
import au.gov.vic.sro.payment.arrangements.dao.procedure.SaveEventProcedure;
import au.gov.vic.sro.payment.arrangements.dto.AuthenticateResponse;
import au.gov.vic.sro.payment.arrangements.dto.CalculateScheduleResponse;
import au.gov.vic.sro.payment.arrangements.dto.CancelArrangementResponse;
import au.gov.vic.sro.payment.arrangements.dto.FindArrangementResponse;
import au.gov.vic.sro.payment.arrangements.dto.GetConfirmCancelTextResponse;
import au.gov.vic.sro.payment.arrangements.dto.GetDefaultDatesResponse;
import au.gov.vic.sro.payment.arrangements.dto.GetEventsResponse;
import au.gov.vic.sro.payment.arrangements.dto.GetFrequenciesResponse;
import au.gov.vic.sro.payment.arrangements.dto.NextEventResponse;
import au.gov.vic.sro.payment.arrangements.dto.SaveAccountRequest;
import au.gov.vic.sro.payment.arrangements.dto.SaveAccountResponse;
import au.gov.vic.sro.payment.arrangements.dto.SaveArrangementResponse;
import au.gov.vic.sro.payment.arrangements.dto.SaveContactsResponse;
import au.gov.vic.sro.payment.arrangements.model.Arrangement;
import au.gov.vic.sro.payment.arrangements.model.Contact;
import au.gov.vic.sro.payment.arrangements.model.Event;
import au.gov.vic.sro.payment.arrangements.model.LiabilityType;
import au.gov.vic.sro.payment.arrangements.model.PaymentFrequency;
import au.gov.vic.sro.payment.arrangements.model.PaymentMethod;
import au.gov.vic.sro.payment.arrangements.model.RevenueLine;
import au.gov.vic.sro.util.DateUtil;

public class PaymentArrangementsDaoImplTest {
	private EasyMockSupport easyMockSupport;
	private AuthenticateProcedure mockAuthenticateProcedure;
	private FindArrangementProcedure mockFindArrangementProcedure;
	private GetNotificationArrangementProcedure mockGetNotificationArrangementProcedure;
	private GetDefaultDatesProcedure mockGetDefaultDatesProcedure;
	private GetFrequenciesProcedure mockGetFrequenciesProcedure;
	private CalculateScheduleProcedure mockCalculateScheduleProcedure;
	private SaveArrangementProcedure mockSaveArrangementProcedure;
	private SaveAccountProcedure mockSaveAccountProcedure;
	private SaveContactsProcedure mockSaveContactsProcedure;
	private GetConfirmCancelTextProcedure mockGetConfirmCancelTextProcedure;
	private CancelArrangementProcedure mockCancelArrangementProcedure;
	private NextEventProcedure mockNextEventProcedure;
	private SaveEventProcedure mockSaveEventProcedure;
	private GetEventsProcedure mockGetEventsProcedure;
	private String customerId;
	private RevenueLine revenueLine;
	private LiabilityType liabilityType;
	private String liabilityId;
	private BigInteger arrangementId;
	private Integer arrangementVersion;
	private Date arrangementStartDate;
	private Date arrangementEndDate;
	private PaymentFrequency paymentFrequency;
	private PaymentMethod paymentMethod;
	private Arrangement arrangement;
	private SaveAccountRequest saveAccountRequest;
	private List<Contact> contacts;
	private Event event;
	private List<BigInteger> eventIds;
	private PaymentArrangementsDaoImpl dao;

	@Before
	public void setUp() throws Exception {
		easyMockSupport = new EasyMockSupport();
		mockAuthenticateProcedure = easyMockSupport.createNiceMock(AuthenticateProcedure.class);
		mockFindArrangementProcedure = easyMockSupport.createNiceMock(FindArrangementProcedure.class);
		mockGetNotificationArrangementProcedure = easyMockSupport.createNiceMock(GetNotificationArrangementProcedure.class);
		mockGetDefaultDatesProcedure = easyMockSupport.createNiceMock(GetDefaultDatesProcedure.class);
		mockGetFrequenciesProcedure = easyMockSupport.createNiceMock(GetFrequenciesProcedure.class);
		mockCalculateScheduleProcedure = easyMockSupport.createNiceMock(CalculateScheduleProcedure.class);
		mockSaveArrangementProcedure = easyMockSupport.createNiceMock(SaveArrangementProcedure.class);
		mockSaveAccountProcedure = easyMockSupport.createNiceMock(SaveAccountProcedure.class);
		mockSaveContactsProcedure = easyMockSupport.createNiceMock(SaveContactsProcedure.class);
		mockGetConfirmCancelTextProcedure = easyMockSupport.createNiceMock(GetConfirmCancelTextProcedure.class);
		mockCancelArrangementProcedure = easyMockSupport.createNiceMock(CancelArrangementProcedure.class);
		mockNextEventProcedure = easyMockSupport.createNiceMock(NextEventProcedure.class);
		mockSaveEventProcedure = easyMockSupport.createNiceMock(SaveEventProcedure.class);
		mockGetEventsProcedure = easyMockSupport.createNiceMock(GetEventsProcedure.class);
		customerId = "999";
		revenueLine = LAND_TAX;
		liabilityType = ASSESSMENT;
		liabilityId = "00000001";
		arrangementId = BigInteger.valueOf(123);
		arrangementVersion = 4;
		arrangementStartDate = parseDate("2017-12-01");
		arrangementEndDate = parseDate("2018-02-01");
		paymentFrequency = FOUR;
		paymentMethod = CREDIT_CARD;
		arrangement = new Arrangement();
		saveAccountRequest = new SaveAccountRequest();
		contacts = Collections.emptyList();
		event = new Event();
		eventIds = Collections.emptyList();

		dao = new PaymentArrangementsDaoImpl() {

			@Override
			protected void initTemplateConfig() {
			}

			@Override
			protected AuthenticateProcedure getAuthenticateProcedure() {
				return mockAuthenticateProcedure;
			}

			@Override
			protected FindArrangementProcedure getFindArrangementProcedure() {
				return mockFindArrangementProcedure;
			}

			@Override
			protected GetNotificationArrangementProcedure getGetNotificationArrangementProcedure() {
				return mockGetNotificationArrangementProcedure;
			}

			@Override
			protected GetDefaultDatesProcedure getGetDefaultDatesProcedure() {
				return mockGetDefaultDatesProcedure;
			}

			@Override
			protected GetFrequenciesProcedure getGetFrequenciesProcedure() {
				return mockGetFrequenciesProcedure;
			}

			@Override
			protected CalculateScheduleProcedure getCalculateScheduleProcedure() {
				return mockCalculateScheduleProcedure;
			}

			@Override
			protected SaveArrangementProcedure getSaveArrangementProcedure() {
				return mockSaveArrangementProcedure;
			}

			@Override
			protected SaveAccountProcedure getSaveAccountProcedure() {
				return mockSaveAccountProcedure;
			}

			@Override
			protected SaveContactsProcedure getSaveContactsProcedure() {
				return mockSaveContactsProcedure;
			}

			@Override
			protected GetConfirmCancelTextProcedure getGetConfirmCancelTextProcedure() {
				return mockGetConfirmCancelTextProcedure;
			}

			@Override
			protected CancelArrangementProcedure getCancelArrangementProcedure() {
				return mockCancelArrangementProcedure;
			}

			@Override
			protected NextEventProcedure getNextEventProcedure() {
				return mockNextEventProcedure;
			}

			@Override
			protected SaveEventProcedure getSaveEventProcedure() {
				return mockSaveEventProcedure;
			}

			@Override
			protected GetEventsProcedure getGetEventsProcedure() {
				return mockGetEventsProcedure;
			}

		};
	}

	@Test
	public void testAuthenticate() {
		expect(mockAuthenticateProcedure.execute(customerId, revenueLine, liabilityType, liabilityId))
				.andReturn(new AuthenticateResponse());
		easyMockSupport.replayAll();

		AuthenticateResponse result = dao.authenticate(customerId, revenueLine, liabilityType, liabilityId);

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
	}

	@Test
	public void testFindArrangement() {
		expect(mockFindArrangementProcedure.execute(customerId, revenueLine, liabilityType, liabilityId))
				.andReturn(new FindArrangementResponse());
		easyMockSupport.replayAll();

		FindArrangementResponse result = dao.findArrangement(customerId, revenueLine, liabilityType, liabilityId);

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
	}

	@Test
	public void testFindNotificationArrangementById() {
		expect(mockGetNotificationArrangementProcedure.execute(arrangementId, arrangementVersion))
				.andReturn(new FindArrangementResponse());
		easyMockSupport.replayAll();
		FindArrangementResponse result = dao.findNotificationArrangement(arrangementId, arrangementVersion);
		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
	}

	@Test
	public void testGetDefaultDates() {
		expect(mockGetDefaultDatesProcedure.execute(customerId, revenueLine, liabilityType, liabilityId))
				.andReturn(new GetDefaultDatesResponse());
		easyMockSupport.replayAll();

		GetDefaultDatesResponse result = dao.getDefaultDates(customerId, revenueLine, liabilityType, liabilityId);

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
	}

	@Test
	public void testGetFrequencies() {
		expect(mockGetFrequenciesProcedure.execute(customerId, revenueLine, liabilityType, liabilityId,
				arrangementStartDate, arrangementEndDate)).andReturn(new GetFrequenciesResponse());
		easyMockSupport.replayAll();

		GetFrequenciesResponse result = dao.getFrequencies(customerId, revenueLine, liabilityType, liabilityId,
				arrangementStartDate, arrangementEndDate);

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
	}

	@Test
	public void testCalculateSchedule() {
		expect(mockCalculateScheduleProcedure.execute(customerId, revenueLine, liabilityType, liabilityId,
				arrangementStartDate, arrangementEndDate, paymentFrequency, paymentMethod))
						.andReturn(new CalculateScheduleResponse());
		easyMockSupport.replayAll();

		CalculateScheduleResponse result = dao.calculateSchedule(customerId, revenueLine, liabilityType, liabilityId,
				arrangementStartDate, arrangementEndDate, paymentFrequency, paymentMethod);

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
	}

	@Test
	public void testSaveArrangement() {
		expect(mockSaveArrangementProcedure.execute(arrangement)).andReturn(new SaveArrangementResponse());
		easyMockSupport.replayAll();

		SaveArrangementResponse result = dao.saveArrangement(arrangement);

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
	}

	@Test
	public void testSaveAccount() {
		expect(mockSaveAccountProcedure.execute(saveAccountRequest)).andReturn(new SaveAccountResponse());
		easyMockSupport.replayAll();

		SaveAccountResponse result = dao.saveAccount(saveAccountRequest);

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
	}

	@Test
	public void testSaveContacts() {
		String checksum = "O8DHAND75S9SKSJW6WHSUA71BS7SGA6S";
		expect(mockSaveContactsProcedure.execute(contacts, checksum)).andReturn(new SaveContactsResponse());
		easyMockSupport.replayAll();

		SaveContactsResponse result = dao.saveContacts(contacts, checksum);

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
	}

	@Test
	public void testGetConfirmCancelText() {
		expect(mockGetConfirmCancelTextProcedure.execute(arrangementId, arrangementVersion))
				.andReturn(new GetConfirmCancelTextResponse());
		easyMockSupport.replayAll();

		GetConfirmCancelTextResponse result = dao.getConfirmCancelText(arrangementId, arrangementVersion);

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
	}

	@Test
	public void testCancelArrangement() {
		expect(mockCancelArrangementProcedure.execute(arrangementId, arrangementVersion))
				.andReturn(new CancelArrangementResponse());
		easyMockSupport.replayAll();

		CancelArrangementResponse result = dao.cancelArrangement(arrangementId, arrangementVersion);

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
	}

	@Test
	public void testNextEvent() {
		expect(mockNextEventProcedure.execute()).andReturn(new NextEventResponse());
		easyMockSupport.replayAll();

		NextEventResponse result = dao.nextEvent();

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
	}

	@Test
	public void testSaveEvent() {
		mockSaveEventProcedure.execute(event);
		expectLastCall();
		easyMockSupport.replayAll();

		dao.saveEvent(event);

		easyMockSupport.verifyAll();
	}

	@Test
	public void testGetEvents() {
		expect(mockGetEventsProcedure.execute(eventIds)).andReturn(new GetEventsResponse());
		expectLastCall();
		easyMockSupport.replayAll();

		GetEventsResponse result = dao.getEvents(eventIds);

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
	}

	private Date parseDate(String s) {
		return DateUtil.parseDate(s, ISO_8601_EXTENDED_DATE_FORMAT.getPattern(),
				ISO_8601_EXTENDED_DATETIME_FORMAT.getPattern());
	}

}
