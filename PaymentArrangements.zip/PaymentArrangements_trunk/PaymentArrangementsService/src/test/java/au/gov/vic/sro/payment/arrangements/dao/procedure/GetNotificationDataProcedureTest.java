package au.gov.vic.sro.payment.arrangements.dao.procedure;

import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.OUT_MESSAGES;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.OUT_VALUE;
import static org.apache.commons.lang3.time.DateFormatUtils.ISO_8601_EXTENDED_DATETIME_FORMAT;
import static org.apache.commons.lang3.time.DateFormatUtils.ISO_8601_EXTENDED_DATE_FORMAT;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.easymock.EasyMockSupport;
import org.junit.Before;
import org.junit.Test;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import au.gov.vic.sro.payment.arrangements.dto.CancelEmailResponse;
import au.gov.vic.sro.payment.arrangements.model.Message;
import au.gov.vic.sro.util.DateUtil;

public class GetNotificationDataProcedureTest {

	private EasyMockSupport easyMockSupport;
	private DataSource mockDataSource;
	private JdbcTemplate jdbcTemplate;
	private Map<String, Object> outParameters;
	private GetNotificationDataProcedure procedure;
	private Message message;
	private BigInteger arrangementId;
	private Integer arrangementVersion;

	@Before
	public void setUp() throws Exception {
		easyMockSupport = new EasyMockSupport();
		mockDataSource = easyMockSupport.createNiceMock(DataSource.class);
		jdbcTemplate = new JdbcTemplate(mockDataSource);

		message = new Message();
		message.setText("message1");

		Calendar calendar = Calendar.getInstance();
		calendar.set(2017, 7, 15);

		outParameters = new LinkedHashMap<String, Object>();
		outParameters.put(OUT_VALUE, parseTs("2017-08-15"));
		outParameters.put(OUT_MESSAGES, new Object[] { message });

		procedure = new GetNotificationDataProcedure(jdbcTemplate) {

			@Override
			public Map<String, Object> execute(Map<String, ?> inParams) throws DataAccessException {
				return outParameters;
			}
		};
	}

	@Test
	public void testExecute() throws Exception {
		easyMockSupport.replayAll();

		arrangementId = BigInteger.ONE;
		arrangementVersion = 22;

		CancelEmailResponse result =
				procedure.execute(arrangementId, arrangementVersion, "cancellationNotificationType");

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));

		Calendar calendar = Calendar.getInstance();
		calendar.set(2017, 7, 15);

		assertThat(result.getReturnDate(), is(parseDate("2017-08-15")));
	}

	@Test
	public void testExecuteNullInput() throws Exception {
		easyMockSupport.replayAll();
		CancelEmailResponse result = procedure.execute(null, null, null);
		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
	}

	private Timestamp parseTs(String s) {
		return DateUtil.toSqlTimestamp(DateUtil.parseDate(s, ISO_8601_EXTENDED_DATE_FORMAT.getPattern(),
				ISO_8601_EXTENDED_DATETIME_FORMAT.getPattern()));
	}

	private Date parseDate(String s) {
		return DateUtil.parseDate(s, ISO_8601_EXTENDED_DATE_FORMAT.getPattern(),
				ISO_8601_EXTENDED_DATETIME_FORMAT.getPattern());
	}
}
