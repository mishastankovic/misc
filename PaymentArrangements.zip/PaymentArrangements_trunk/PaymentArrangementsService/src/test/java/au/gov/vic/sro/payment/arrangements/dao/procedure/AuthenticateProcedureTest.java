package au.gov.vic.sro.payment.arrangements.dao.procedure;

import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.OUT_MESSAGES;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.OUT_VALID;
import static au.gov.vic.sro.payment.arrangements.model.LiabilityType.ASSESSMENT;
import static au.gov.vic.sro.payment.arrangements.model.RevenueLine.LAND_TAX;
import static org.apache.commons.lang3.ArrayUtils.EMPTY_OBJECT_ARRAY;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;

import java.util.LinkedHashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.easymock.EasyMockSupport;
import org.junit.Before;
import org.junit.Test;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import au.gov.vic.sro.payment.arrangements.dto.AuthenticateResponse;
import au.gov.vic.sro.payment.arrangements.model.Message;

public class AuthenticateProcedureTest {
	private EasyMockSupport easyMockSupport;
	private DataSource mockDataSource;
	private JdbcTemplate jdbcTemplate;
	private Map<String, Object> outParameters;
	private Message message;
	private AuthenticateProcedure procedure;

	@Before
	public void setUp() throws Exception {
		easyMockSupport = new EasyMockSupport();
		mockDataSource = easyMockSupport.createNiceMock(DataSource.class);
		jdbcTemplate = new JdbcTemplate(mockDataSource);
		outParameters = new LinkedHashMap<String, Object>();
		message = new Message();
		message.setText("foo");

		procedure = new AuthenticateProcedure(jdbcTemplate) {

			@Override
			public Map<String, Object> execute(Map<String, ?> inParams) throws DataAccessException {
				return outParameters;
			}
		};
	}

	@Test
	public void testExecute() throws Exception {
		outParameters.put(OUT_VALID, true);
		outParameters.put(OUT_MESSAGES, EMPTY_OBJECT_ARRAY);
		easyMockSupport.replayAll();

		AuthenticateResponse result = procedure.execute("999", LAND_TAX, ASSESSMENT, "111");

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
		assertThat(result.getAuthenticated(), is(true));
		assertThat(result.getMessages(), is(empty()));
	}

	@Test
	public void testExecuteNullInput() throws Exception {
		easyMockSupport.replayAll();

		AuthenticateResponse result = procedure.execute(null, null, null, null);

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
	}

	@Test
	public void testExecuteNullOutput() throws Exception {
		outParameters = null;
		easyMockSupport.replayAll();

		AuthenticateResponse result = procedure.execute("999", LAND_TAX, ASSESSMENT, "111");

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
		assertThat(result.getAuthenticated(), is(nullValue()));
		assertThat(result.getMessages(), is(empty()));
	}

}
