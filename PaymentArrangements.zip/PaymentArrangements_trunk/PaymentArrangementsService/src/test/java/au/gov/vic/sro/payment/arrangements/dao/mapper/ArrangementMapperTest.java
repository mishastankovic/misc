package au.gov.vic.sro.payment.arrangements.dao.mapper;

import static au.gov.vic.sro.payment.arrangements.model.ArrangementStatus.CANCELLED;
import static au.gov.vic.sro.payment.arrangements.model.CancelledReason.PAYMENT_NOT_RECEIVED;
import static au.gov.vic.sro.payment.arrangements.model.PaymentFrequency.FORTNIGHTLY;
import static au.gov.vic.sro.payment.arrangements.model.PaymentMethod.CREDIT_CARD;
import static org.apache.commons.lang3.time.DateFormatUtils.ISO_8601_EXTENDED_DATETIME_FORMAT;
import static org.apache.commons.lang3.time.DateFormatUtils.ISO_8601_EXTENDED_DATE_FORMAT;
import static org.easymock.EasyMock.expect;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Date;

import org.easymock.EasyMockSupport;
import org.junit.Before;
import org.junit.Test;

import au.gov.vic.sro.payment.arrangements.model.Arrangement;
import au.gov.vic.sro.util.DateUtil;
import oracle.sql.STRUCT;

public class ArrangementMapperTest {
	private EasyMockSupport easyMockSupport;
	private Connection mockConnection;
	private STRUCT mockStruct;
	private Object[] rec;
	private Arrangement arrangement;
	private ArrangementMapper mapper;

	@Before
	public void setUp() throws Exception {
		easyMockSupport = new EasyMockSupport();
		mockConnection = easyMockSupport.createNiceMock(Connection.class);
		mockStruct = easyMockSupport.createNiceMock(STRUCT.class);

		arrangement = new Arrangement();
		arrangement.setId(BigInteger.valueOf(123));
		arrangement.setVersion(4);
		arrangement.setCustomerId("999");
		arrangement.setStatus(CANCELLED);
		arrangement.setStatusDate(parseDate("2017-12-31T23:59:59"));
		arrangement.setCancelledDate(parseDate("2017-12-25T23:59:59"));
		arrangement.setCancelledReason(PAYMENT_NOT_RECEIVED);
		arrangement.setCancelledUserId("foo");
		arrangement.setStartDate(parseDate("2017-12-01"));
		arrangement.setEndDate(parseDate("2018-02-01"));
		arrangement.setPaymentFrequency(FORTNIGHTLY);
		arrangement.setAllInstalmentAmountDollars(BigDecimal.valueOf(1000.00));
		arrangement.setAllInstalmentSurchargeDollars(BigDecimal.valueOf(0.99));
		arrangement.setAllInstalmentTotalAmountDollars(BigDecimal.valueOf(1000.99));
		arrangement.setAccountToken("Test_Account_Token");
		arrangement.setPaymentMethod(CREDIT_CARD);
		arrangement.setCardNumber("411111xxxxxxx111");
		arrangement.setCardExpiryMonth("01");
		arrangement.setCardExpiryYear("2017");
		arrangement.setBankBsb("xxx-000");
		arrangement.setBankAccountNumber("xxxxxx678");

		rec = new Object[] { BigDecimal.valueOf(123), // PAYMENT_ARRANGEMENT_ID
				BigDecimal.valueOf(4), // PAYMENT_ARRANGEMENT_VERSION
				"999", // CUSTOMER_ID
				"Test_Account_Token", // PAYMENT_TOKEN
				CANCELLED.getCode(), // ARRANGEMENT_STATUS
				parseTs("2017-12-31T23:59:59"), // STATUS_DATE
				parseTs("2017-12-25T23:59:59"), // CANCELLATION_DATE
				"foo", // CANCELLED_BY
				PAYMENT_NOT_RECEIVED.getCode(), // CANCELLATION_REASON
				parseTs("2017-12-01"), // ARRANGEMENT_START_DATE
				parseTs("2018-02-01"), // ARRANGEMENT_END_DATE
				FORTNIGHTLY.getCode(), // PAYMENT_FREQUENCY
				CREDIT_CARD.getCode(), // PAYMENT_METHOD
				"xxxxxx678", // DIRECT_DEBIT_ACCOUNT_NUMBER
				"xxx-000", // BSB_NUMBER
				"411111xxxxxxx111", // CREDIT_CARD_NUMBER
				"01", // CREDIT_CARD_EXPIRY_MONTH
				"2017", // CREDIT_CARD_EXPIRY_YEAR
				BigDecimal.valueOf(1000.00),// ARRANGEMENT_AMOUNT
				BigDecimal.valueOf(0.99),// ARRANGEMENT_SURCHARGE
				BigDecimal.valueOf(1000.99) // ARRANGEMENT_TOTAL_AMOUNT
				};

		mapper = new ArrangementMapper() {

			@Override
			public STRUCT toStruct(Arrangement source, Connection connection, String typeName) throws SQLException {
				return mockStruct;
			}
		};

	}

	@Test
	public void testToStruct() throws Exception {
		easyMockSupport.replayAll();

		STRUCT result = mapper.toStruct(arrangement, mockConnection, "PYMNT_ARRANGEMENT_REC");

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testToStructNull() throws Exception {
		mapper = new ArrangementMapper();
		mapper.toStruct(null, null, null);
	}

	@Test
	public void testToRec() throws Exception {
		easyMockSupport.replayAll();

		Object[] result = mapper.toRec(arrangement);

		easyMockSupport.verifyAll();
		assertThat(result, is(rec));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testToRecNull() throws Exception {
		mapper.toRec(null);
	}

	@Test
	public void testFromStruct() throws Exception {
		expect(mockStruct.getSQLTypeName()).andReturn("ESYS.PYMNT_ARRANGEMENT_REC");
		expect(mockStruct.getAttributes()).andReturn(rec).atLeastOnce();
		easyMockSupport.replayAll();

		Arrangement result = mapper.fromStruct(mockStruct);

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
		assertThat(result.getId(), is(BigInteger.valueOf(123)));
		assertThat(result.getVersion(), is(4));
		assertThat(result.getCustomerId(), is("999"));
		assertThat(result.getStatus(), is(CANCELLED));
		assertThat(result.getStatusDate(), is(parseDate("2017-12-31T23:59:59")));
		assertThat(result.getCancelledDate(), is(parseDate("2017-12-25T23:59:59")));
		assertThat(result.getCancelledReason(), is(PAYMENT_NOT_RECEIVED));
		assertThat(result.getCancelledUserId(), is("foo"));
		assertThat(result.getStartDate(), is(parseDate("2017-12-01")));
		assertThat(result.getEndDate(), is(parseDate("2018-02-01")));
		assertThat(result.getPaymentFrequency(), is(FORTNIGHTLY));
		assertThat(result.getAllInstalmentAmountDollars(), is(BigDecimal.valueOf(1000.00)));
		assertThat(result.getAllInstalmentSurchargeDollars(), is(BigDecimal.valueOf(0.99)));
		assertThat(result.getAllInstalmentTotalAmountDollars(), is(BigDecimal.valueOf(1000.99)));
		assertThat(result.getAccountToken(), is("Test_Account_Token"));
		assertThat(result.getPaymentMethod(), is(CREDIT_CARD));
		assertThat(result.getCardNumber(), is("411111xxxxxxx111"));
		assertThat(result.getCardExpiryMonth(), is("01"));
		assertThat(result.getCardExpiryYear(), is("2017"));
		assertThat(result.getBankBsb(), is("xxx-000"));
		assertThat(result.getBankAccountNumber(), is("xxxxxx678"));
		assertThat(result.getLiabilities(), is(empty()));
		assertThat(result.getInstalments(), is(empty()));
		assertThat(result.getContacts(), is(empty()));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testFromStructNull() throws Exception {
		mapper.fromStruct(null);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testFromStructInvalidTypeName() throws Exception {
		expect(mockStruct.getSQLTypeName()).andReturn("ESYS.BAD_REC");
		expect(mockStruct.debugString()).andStubReturn("BAD!!!");
		easyMockSupport.replayAll();

		mapper.fromStruct(mockStruct);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testFromStructInvalidTypeLength() throws Exception {
		rec = null;
		expect(mockStruct.getSQLTypeName()).andReturn("ESYS.PYMNT_ARRANGEMENT_REC");
		expect(mockStruct.getAttributes()).andReturn(rec).atLeastOnce();
		expect(mockStruct.debugString()).andStubReturn("BAD!!!");
		easyMockSupport.replayAll();

		mapper.fromStruct(mockStruct);
	}

	@Test
	public void testFromStructNullAttributes() throws Exception {
		Arrays.fill(rec, null);
		expect(mockStruct.getSQLTypeName()).andReturn("ESYS.PYMNT_ARRANGEMENT_REC");
		expect(mockStruct.getAttributes()).andReturn(rec).atLeastOnce();
		easyMockSupport.replayAll();

		Arrangement result = mapper.fromStruct(mockStruct);

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
		assertThat(result.getId(), is(nullValue()));
		assertThat(result.getVersion(), is(nullValue()));
		assertThat(result.getCustomerId(), is(nullValue()));
		assertThat(result.getStatus(), is(nullValue()));
		assertThat(result.getStatusDate(), is(nullValue()));
		assertThat(result.getCancelledDate(), is(nullValue()));
		assertThat(result.getCancelledReason(), is(nullValue()));
		assertThat(result.getCancelledUserId(), is(nullValue()));
		assertThat(result.getStartDate(), is(nullValue()));
		assertThat(result.getEndDate(), is(nullValue()));
		assertThat(result.getPaymentFrequency(), is(nullValue()));
		assertThat(result.getAllInstalmentAmountDollars(), is(nullValue()));
		assertThat(result.getAllInstalmentSurchargeDollars(), is(nullValue()));
		assertThat(result.getAllInstalmentTotalAmountDollars(), is(nullValue()));
		assertThat(result.getAccountToken(), is(nullValue()));
		assertThat(result.getPaymentMethod(), is(nullValue()));
		assertThat(result.getCardNumber(), is(nullValue()));
		assertThat(result.getCardExpiryMonth(), is(nullValue()));
		assertThat(result.getCardExpiryYear(), is(nullValue()));
		assertThat(result.getBankBsb(), is(nullValue()));
		assertThat(result.getBankAccountNumber(), is(nullValue()));
		assertThat(result.getLiabilities(), is(empty()));
		assertThat(result.getInstalments(), is(empty()));
		assertThat(result.getContacts(), is(empty()));
	}

	private Date parseDate(String s) {
		return DateUtil.parseDate(s, ISO_8601_EXTENDED_DATE_FORMAT.getPattern(),
				ISO_8601_EXTENDED_DATETIME_FORMAT.getPattern());
	}

	private Timestamp parseTs(String s) {
		return DateUtil.toSqlTimestamp(DateUtil.parseDate(s, ISO_8601_EXTENDED_DATE_FORMAT.getPattern(),
				ISO_8601_EXTENDED_DATETIME_FORMAT.getPattern()));
	}

}
