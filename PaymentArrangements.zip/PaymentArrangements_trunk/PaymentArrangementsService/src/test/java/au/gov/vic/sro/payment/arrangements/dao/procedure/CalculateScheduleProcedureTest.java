package au.gov.vic.sro.payment.arrangements.dao.procedure;

import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.OUT_ALL_INSTALMENT_AMOUNT;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.OUT_ALL_INSTALMENT_SURCHARGE;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.OUT_ALL_INSTALMENT_TOTAL_AMOUNT;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.OUT_INSTALMENTS;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.OUT_MESSAGES;
import static au.gov.vic.sro.payment.arrangements.model.LiabilityType.ASSESSMENT;
import static au.gov.vic.sro.payment.arrangements.model.PaymentFrequency.FOUR;
import static au.gov.vic.sro.payment.arrangements.model.PaymentMethod.CREDIT_CARD;
import static au.gov.vic.sro.payment.arrangements.model.RevenueLine.LAND_TAX;
import static org.apache.commons.lang3.time.DateFormatUtils.ISO_8601_EXTENDED_DATETIME_FORMAT;
import static org.apache.commons.lang3.time.DateFormatUtils.ISO_8601_EXTENDED_DATE_FORMAT;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;

import java.math.BigDecimal;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.easymock.EasyMockSupport;
import org.junit.Before;
import org.junit.Test;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import au.gov.vic.sro.payment.arrangements.dto.CalculateScheduleResponse;
import au.gov.vic.sro.payment.arrangements.model.Instalment;
import au.gov.vic.sro.payment.arrangements.model.Message;
import au.gov.vic.sro.util.DateUtil;

public class CalculateScheduleProcedureTest {
	private EasyMockSupport easyMockSupport;
	private DataSource mockDataSource;
	private JdbcTemplate jdbcTemplate;
	private Map<String, Object> outParameters;
	private Instalment instalment;
	private Message message;
	private CalculateScheduleProcedure procedure;

	@Before
	public void setUp() throws Exception {
		easyMockSupport = new EasyMockSupport();
		mockDataSource = easyMockSupport.createNiceMock(DataSource.class);
		jdbcTemplate = new JdbcTemplate(mockDataSource);

		instalment = new Instalment();
		instalment.setId(1);

		message = new Message();
		message.setText("message1");

		outParameters = new LinkedHashMap<String, Object>();
		outParameters.put(OUT_ALL_INSTALMENT_AMOUNT, BigDecimal.valueOf(1000.00));
		outParameters.put(OUT_ALL_INSTALMENT_SURCHARGE, BigDecimal.valueOf(0.99));
		outParameters.put(OUT_ALL_INSTALMENT_TOTAL_AMOUNT, BigDecimal.valueOf(1000.99));
		outParameters.put(OUT_INSTALMENTS, new Object[] { instalment });
		outParameters.put(OUT_MESSAGES, new Object[] { message });

		procedure = new CalculateScheduleProcedure(jdbcTemplate) {

			@Override
			public Map<String, Object> execute(Map<String, ?> inParams) throws DataAccessException {
				return outParameters;
			}
		};
	}

	@Test
	public void testExecute() throws Exception {
		easyMockSupport.replayAll();

		CalculateScheduleResponse result =
				procedure.execute("999", LAND_TAX, ASSESSMENT, "00000001", parseDate("2017-12-01"),
						parseDate("2018-02-01"), FOUR, CREDIT_CARD);

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
		assertThat(result.getAllInstalmentAmountDollars(), is(BigDecimal.valueOf(1000.00)));
		assertThat(result.getAllInstalmentSurchargeDollars(), is(BigDecimal.valueOf(0.99)));
		assertThat(result.getAllInstalmentTotalAmountDollars(), is(BigDecimal.valueOf(1000.99)));
		assertThat(result.getInstalments(), contains(instalment));
		assertThat(result.getMessages(), contains(message));
	}

	@Test
	public void testExecuteNullInput() throws Exception {
		easyMockSupport.replayAll();

		CalculateScheduleResponse result = procedure.execute(null, null, null, null, null, null, null, null);

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
	}

	@Test
	public void testExecuteNullOutput() throws Exception {
		outParameters = null;
		easyMockSupport.replayAll();

		CalculateScheduleResponse result =
				procedure.execute("999", LAND_TAX, ASSESSMENT, "00000001", parseDate("2017-12-01"),
						parseDate("2018-02-01"), FOUR, CREDIT_CARD);

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
		assertThat(result.getAllInstalmentAmountDollars(), is(nullValue()));
		assertThat(result.getAllInstalmentSurchargeDollars(), is(nullValue()));
		assertThat(result.getAllInstalmentTotalAmountDollars(), is(nullValue()));
		assertThat(result.getInstalments(), is(empty()));
		assertThat(result.getMessages(), is(empty()));
	}

	private Date parseDate(String s) {
		return DateUtil.parseDate(s, ISO_8601_EXTENDED_DATE_FORMAT.getPattern(),
				ISO_8601_EXTENDED_DATETIME_FORMAT.getPattern());
	}

}
