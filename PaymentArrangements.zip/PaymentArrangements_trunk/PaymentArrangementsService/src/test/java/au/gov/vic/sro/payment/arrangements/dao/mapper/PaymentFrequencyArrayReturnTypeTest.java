package au.gov.vic.sro.payment.arrangements.dao.mapper;

import static au.gov.vic.sro.payment.arrangements.model.PaymentFrequency.FORTNIGHTLY;
import static au.gov.vic.sro.payment.arrangements.model.PaymentFrequency.FOUR;
import static au.gov.vic.sro.payment.arrangements.model.PaymentFrequency.MONTHLY;
import static org.easymock.EasyMock.anyInt;
import static org.easymock.EasyMock.expect;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;

import java.sql.CallableStatement;
import java.util.Arrays;

import org.easymock.EasyMockSupport;
import org.junit.Before;
import org.junit.Test;

import oracle.sql.ARRAY;

public class PaymentFrequencyArrayReturnTypeTest {
	private EasyMockSupport easyMockSupport;
	private CallableStatement mockCallableStatement;
	private ARRAY mockArray;
	private Object[] paymentFrequencies;
	private Object[] paymentFrequencyCodes;
	private PaymentFrequencyArrayReturnType returnType;

	@Before
	public void setUp() throws Exception {
		easyMockSupport = new EasyMockSupport();
		mockCallableStatement = easyMockSupport.createNiceMock(CallableStatement.class);
		mockArray = easyMockSupport.createNiceMock(ARRAY.class);
		paymentFrequencies = new Object[] { FORTNIGHTLY, FOUR, MONTHLY };
		paymentFrequencyCodes = new Object[] { FORTNIGHTLY.getCode(), FOUR.getCode(), MONTHLY.getCode() };
		returnType = new PaymentFrequencyArrayReturnType();
	}

	@Test
	public void testGetTypeValueTrue() throws Exception {
		expect(mockCallableStatement.getObject(anyInt())).andReturn(mockArray);
		expect(mockArray.getArray()).andReturn(paymentFrequencyCodes);
		easyMockSupport.replayAll();

		Object result = returnType.getTypeValue(mockCallableStatement, 0, 0, null);

		easyMockSupport.verifyAll();
		assertThat(result, is(instanceOf(Object[].class)));
		assertThat((Object[]) result, is(paymentFrequencies));
	}

	@Test
	public void testGetTypeValueNullValues() throws Exception {
		Arrays.fill(paymentFrequencies, null);
		Arrays.fill(paymentFrequencyCodes, null);
		expect(mockCallableStatement.getObject(anyInt())).andReturn(mockArray);
		expect(mockArray.getArray()).andReturn(paymentFrequencyCodes);
		easyMockSupport.replayAll();

		Object result = returnType.getTypeValue(mockCallableStatement, 0, 0, null);

		easyMockSupport.verifyAll();
		assertThat(result, is(instanceOf(Object[].class)));
		assertThat((Object[]) result, is(paymentFrequencies));
	}

	@Test
	public void testGetTypeValueNull() throws Exception {
		expect(mockCallableStatement.getObject(anyInt())).andReturn(null);
		easyMockSupport.replayAll();

		Object result = returnType.getTypeValue(mockCallableStatement, 0, 0, null);

		easyMockSupport.verifyAll();
		assertThat(result, is(nullValue()));
	}

}
