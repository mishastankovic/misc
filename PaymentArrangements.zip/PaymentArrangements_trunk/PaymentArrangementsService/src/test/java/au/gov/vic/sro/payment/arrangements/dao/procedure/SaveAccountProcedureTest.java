package au.gov.vic.sro.payment.arrangements.dao.procedure;

import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.OUT_MESSAGES;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.OUT_SET;
import static au.gov.vic.sro.payment.arrangements.model.PaymentMethod.CREDIT_CARD;
import static org.apache.commons.lang3.ArrayUtils.EMPTY_OBJECT_ARRAY;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

import java.math.BigInteger;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.easymock.EasyMockSupport;
import org.junit.Before;
import org.junit.Test;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import au.gov.vic.sro.payment.arrangements.dto.SaveAccountRequest;
import au.gov.vic.sro.payment.arrangements.dto.SaveAccountResponse;
import au.gov.vic.sro.payment.arrangements.model.Message;

public class SaveAccountProcedureTest {
	private EasyMockSupport easyMockSupport;
	private DataSource mockDataSource;
	private JdbcTemplate jdbcTemplate;
	private Map<String, Object> outParameters;
	private Message message;
	private SaveAccountRequest request;
	private SaveAccountProcedure procedure;

	@Before
	public void setUp() throws Exception {
		easyMockSupport = new EasyMockSupport();
		mockDataSource = easyMockSupport.createNiceMock(DataSource.class);
		jdbcTemplate = new JdbcTemplate(mockDataSource);
		outParameters = new LinkedHashMap<String, Object>();

		message = new Message();
		message.setText("foo");

		request = new SaveAccountRequest();
		request.setArrangementId(BigInteger.valueOf(123));
		request.setArrangementVersion(4);
		request.setAccountToken("Test_Account_Token");
		request.setPaymentMethod(CREDIT_CARD);
		request.setCardNumber("411111xxxxxxx111");
		request.setCardExpiryMonth("01");
		request.setCardExpiryYear("2017");
		request.setBankBsb("xxx-000");
		request.setBankAccountNumber("xxxxxx678");

		procedure = new SaveAccountProcedure(jdbcTemplate) {

			@Override
			public Map<String, Object> execute(Map<String, ?> inParams) throws DataAccessException {
				return outParameters;
			}
		};
	}

	@Test
	public void testExecute() throws Exception {
		outParameters.put(OUT_SET, true);
		outParameters.put(OUT_MESSAGES, EMPTY_OBJECT_ARRAY);
		easyMockSupport.replayAll();

		SaveAccountResponse result = procedure.execute(request);

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
		assertThat(result.getSaved(), is(Boolean.TRUE));
		assertThat(result.getMessages(), is(empty()));
	}

	@Test
	public void testExecuteNullInput() throws Exception {
		request = null;
		easyMockSupport.replayAll();

		SaveAccountResponse result = procedure.execute(request);

		easyMockSupport.verifyAll();
		assertThat(result.getSaved(), is(Boolean.TRUE));
		assertThat(result, is(notNullValue()));
	}

	@Test
	public void testExecuteNullOutput() throws Exception {
		outParameters = null;
		easyMockSupport.replayAll();

		SaveAccountResponse result = procedure.execute(request);

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
		assertThat(result.getSaved(), is(Boolean.TRUE));
		assertThat(result.getMessages(), is(empty()));
	}

}
