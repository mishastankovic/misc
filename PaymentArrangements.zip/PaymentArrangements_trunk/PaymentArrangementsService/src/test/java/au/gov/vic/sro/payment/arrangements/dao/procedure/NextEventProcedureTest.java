package au.gov.vic.sro.payment.arrangements.dao.procedure;

import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.OUT_RESULT;
import static java.math.BigInteger.ONE;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;

import java.util.LinkedHashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.easymock.EasyMockSupport;
import org.junit.Before;
import org.junit.Test;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import au.gov.vic.sro.payment.arrangements.dto.NextEventResponse;
import au.gov.vic.sro.payment.arrangements.model.Event;

public class NextEventProcedureTest {
	private EasyMockSupport easyMockSupport;
	private DataSource mockDataSource;
	private JdbcTemplate jdbcTemplate;
	private Map<String, Object> outParameters;
	private Event event;
	private NextEventProcedure procedure;

	@Before
	public void setUp() throws Exception {
		easyMockSupport = new EasyMockSupport();
		mockDataSource = easyMockSupport.createNiceMock(DataSource.class);
		jdbcTemplate = new JdbcTemplate(mockDataSource);

		event = new Event();
		event.setId(ONE);

		outParameters = new LinkedHashMap<String, Object>();
		outParameters.put(OUT_RESULT, event);

		procedure = new NextEventProcedure(jdbcTemplate) {

			@Override
			public Map<String, Object> execute(Map<String, ?> inParams) throws DataAccessException {
				return outParameters;
			}
		};
	}

	@Test
	public void testExecute() throws Exception {
		easyMockSupport.replayAll();

		NextEventResponse result = procedure.execute();

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
		assertThat(result.getEvent(), is(event));
	}

	@Test
	public void testExecuteNullOutput() throws Exception {
		outParameters = null;
		easyMockSupport.replayAll();

		NextEventResponse result = procedure.execute();

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
		assertThat(result.getEvent(), is(nullValue()));
	}

}
