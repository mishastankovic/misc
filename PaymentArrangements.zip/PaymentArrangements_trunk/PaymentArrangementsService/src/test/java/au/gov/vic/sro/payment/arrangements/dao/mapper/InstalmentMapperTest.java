package au.gov.vic.sro.payment.arrangements.dao.mapper;

import static au.gov.vic.sro.payment.arrangements.model.InstalmentRequestSent.SENT;
import static au.gov.vic.sro.payment.arrangements.model.InstalmentStatus.DISHONOURED;
import static org.apache.commons.lang3.time.DateFormatUtils.ISO_8601_EXTENDED_DATETIME_FORMAT;
import static org.apache.commons.lang3.time.DateFormatUtils.ISO_8601_EXTENDED_DATE_FORMAT;
import static org.easymock.EasyMock.expect;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Date;

import org.easymock.EasyMockSupport;
import org.junit.Before;
import org.junit.Test;

import au.gov.vic.sro.payment.arrangements.model.Arrangement;
import au.gov.vic.sro.payment.arrangements.model.Instalment;
import au.gov.vic.sro.util.DateUtil;
import oracle.sql.STRUCT;

public class InstalmentMapperTest {
	private EasyMockSupport easyMockSupport;
	private Connection mockConnection;
	private STRUCT mockStruct;
	private Object[] rec;
	private Instalment instalment;
	private InstalmentMapper mapper;

	@Before
	public void setUp() throws Exception {
		easyMockSupport = new EasyMockSupport();
		mockConnection = easyMockSupport.createNiceMock(Connection.class);
		mockStruct = easyMockSupport.createNiceMock(STRUCT.class);

		Arrangement arrangement = new Arrangement();
		arrangement.setId(BigInteger.valueOf(123));
		arrangement.setVersion(4);

		instalment = new Instalment();
		instalment.setId(3);
		instalment.setStatus(DISHONOURED);
		instalment.setDueDate(parseDate("2018-01-01"));
		instalment.setAmountDollars(BigDecimal.valueOf(1000.00));
		instalment.setSurchargeDollars(BigDecimal.valueOf(0.99));
		instalment.setTotalAmountDollars(BigDecimal.valueOf(1000.99));
		instalment.setRequestSent(SENT);
		instalment.setRequestSentDate(parseDate("2017-12-31T23:59:59"));
		instalment.setTransactionNumber("x");
		instalment.setQuickBatchSummaryCode("y");
		instalment.setQuickBatchResponseCode("z");
		instalment.setArrangement(arrangement);

		rec = new Object[] { BigDecimal.valueOf(3), // INSTALLMENT_NO
				BigDecimal.valueOf(123), // PAYMENT_ARRANGEMENT_ID
				BigDecimal.valueOf(4), // PAYMENT_ARRANGEMENT_VERSION
				DISHONOURED.getCode(), // INSTALLMENT_STATUS
				parseTs("2018-01-01"), // DUE_DATE
				BigDecimal.valueOf(1000.00), // AMOUNT
				BigDecimal.valueOf(0.99), // SURCHARGE
				BigDecimal.valueOf(1000.99), // TOTAL_AMOUNT
				SENT.getCode(), // REQUEST_SENT_CODE
				parseTs("2017-12-31T23:59:59"), // DATE_REQUEST_SENT
				"x", // PAO_TRANSACTION_NUMBER
				"y", // QUICKBATCH_SUMMARY_CODE
				"z" // QUICKBATCH_RESPONSE_CODE
		};

		mapper = new InstalmentMapper() {

			@Override
			public STRUCT toStruct(Instalment source, Connection connection, String typeName) throws SQLException {
				return mockStruct;
			}
		};
	}

	@Test
	public void testToStruct() throws Exception {
		easyMockSupport.replayAll();

		STRUCT result = mapper.toStruct(instalment, mockConnection, "PYMNT_ARRANGEMENT_INSTLMNT_REC");

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testToStructNull() throws Exception {
		mapper = new InstalmentMapper();
		mapper.toStruct(null, null, null);
	}

	@Test
	public void testToRec() throws Exception {
		easyMockSupport.replayAll();

		Object[] result = mapper.toRec(instalment);

		easyMockSupport.verifyAll();
		assertThat(result, is(rec));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testToRecNull() throws Exception {
		mapper.toRec(null);
	}

	@Test
	public void testFromStruct() throws Exception {
		expect(mockStruct.getSQLTypeName()).andReturn("ESYS.PYMNT_ARRANGEMENT_INSTLMNT_REC");
		expect(mockStruct.getAttributes()).andReturn(rec).atLeastOnce();
		easyMockSupport.replayAll();

		Instalment result = mapper.fromStruct(mockStruct);

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
		assertThat(result.getId(), is(3));
		assertThat(result.getStatus(), is(DISHONOURED));
		assertThat(result.getDueDate(), is(parseDate("2018-01-01")));
		assertThat(result.getAmountDollars(), is(BigDecimal.valueOf(1000.00)));
		assertThat(result.getSurchargeDollars(), is(BigDecimal.valueOf(0.99)));
		assertThat(result.getTotalAmountDollars(), is(BigDecimal.valueOf(1000.99)));
		assertThat(result.getRequestSent(), is(SENT));
		assertThat(result.getRequestSentDate(), is(parseDate("2017-12-31T23:59:59")));
		assertThat(result.getTransactionNumber(), is("x"));
		assertThat(result.getQuickBatchSummaryCode(), is("y"));
		assertThat(result.getQuickBatchResponseCode(), is("z"));
		assertThat(result.getArrangement(), is(nullValue()));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testFromStructNull() throws Exception {
		mapper.fromStruct(null);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testFromStructInvalidTypeName() throws Exception {
		expect(mockStruct.getSQLTypeName()).andReturn("ESYS.BAD_REC");
		expect(mockStruct.debugString()).andStubReturn("BAD!!!");
		easyMockSupport.replayAll();

		mapper.fromStruct(mockStruct);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testFromStructInvalidTypeLength() throws Exception {
		rec = null;
		expect(mockStruct.getSQLTypeName()).andReturn("ESYS.PYMNT_ARRANGEMENT_INSTLMNT_REC");
		expect(mockStruct.getAttributes()).andReturn(rec).atLeastOnce();
		expect(mockStruct.debugString()).andStubReturn("BAD!!!");
		easyMockSupport.replayAll();

		mapper.fromStruct(mockStruct);
	}

	@Test
	public void testFromStructNullAttributes() throws Exception {
		Arrays.fill(rec, null);
		expect(mockStruct.getSQLTypeName()).andReturn("ESYS.PYMNT_ARRANGEMENT_INSTLMNT_REC");
		expect(mockStruct.getAttributes()).andReturn(rec).atLeastOnce();
		easyMockSupport.replayAll();

		Instalment result = mapper.fromStruct(mockStruct);

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
		assertThat(result.getId(), is(nullValue()));
		assertThat(result.getStatus(), is(nullValue()));
		assertThat(result.getDueDate(), is(nullValue()));
		assertThat(result.getAmountDollars(), is(nullValue()));
		assertThat(result.getSurchargeDollars(), is(nullValue()));
		assertThat(result.getTotalAmountDollars(), is(nullValue()));
		assertThat(result.getRequestSent(), is(nullValue()));
		assertThat(result.getRequestSentDate(), is(nullValue()));
		assertThat(result.getTransactionNumber(), is(nullValue()));
		assertThat(result.getQuickBatchSummaryCode(), is(nullValue()));
		assertThat(result.getQuickBatchResponseCode(), is(nullValue()));
		assertThat(result.getArrangement(), is(nullValue()));
	}

	private Date parseDate(String s) {
		return DateUtil.parseDate(s, ISO_8601_EXTENDED_DATE_FORMAT.getPattern(),
				ISO_8601_EXTENDED_DATETIME_FORMAT.getPattern());
	}

	private Timestamp parseTs(String s) {
		return DateUtil.toSqlTimestamp(DateUtil.parseDate(s, ISO_8601_EXTENDED_DATE_FORMAT.getPattern(),
				ISO_8601_EXTENDED_DATETIME_FORMAT.getPattern()));
	}

}
