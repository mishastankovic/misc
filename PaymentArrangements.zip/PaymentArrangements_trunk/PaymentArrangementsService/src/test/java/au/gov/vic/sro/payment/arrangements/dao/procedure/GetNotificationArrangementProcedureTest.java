package au.gov.vic.sro.payment.arrangements.dao.procedure;

import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.OUT_CONTACTS;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.OUT_INSTALMENTS;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.OUT_LIABILITIES;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.OUT_MESSAGES;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.OUT_PAYMENT_ARRANGEMENT;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

import java.math.BigInteger;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.easymock.EasyMockSupport;
import org.junit.Before;
import org.junit.Test;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import au.gov.vic.sro.payment.arrangements.dto.FindArrangementResponse;
import au.gov.vic.sro.payment.arrangements.model.Arrangement;
import au.gov.vic.sro.payment.arrangements.model.Contact;
import au.gov.vic.sro.payment.arrangements.model.Instalment;
import au.gov.vic.sro.payment.arrangements.model.Liability;
import au.gov.vic.sro.payment.arrangements.model.Message;

public class GetNotificationArrangementProcedureTest {
	private EasyMockSupport easyMockSupport;
	private DataSource mockDataSource;
	private JdbcTemplate jdbcTemplate;
	private Map<String, Object> outParameters;
	private Arrangement arrangement;
	private Liability liability;
	private Instalment instalment;
	private Contact contact;
	private Message message;
	private GetNotificationArrangementProcedure procedure;

	@Before
	public void setUp() throws Exception {
		easyMockSupport = new EasyMockSupport();
		mockDataSource = easyMockSupport.createNiceMock(DataSource.class);
		jdbcTemplate = new JdbcTemplate(mockDataSource);

		arrangement = new Arrangement();
		arrangement.setId(BigInteger.ONE);
		arrangement.setVersion(1);

		liability = new Liability();
		liability.setId("liability1");
		liability.setVersion(1);

		instalment = new Instalment();
		instalment.setId(1);

		contact = new Contact();
		contact.setPersonName("contact1");

		message = new Message();
		message.setText("message1");

		outParameters = new LinkedHashMap<String, Object>();
		outParameters.put(OUT_PAYMENT_ARRANGEMENT, arrangement);
		outParameters.put(OUT_LIABILITIES, new Object[] { liability });
		outParameters.put(OUT_INSTALMENTS, new Object[] { instalment });
		outParameters.put(OUT_CONTACTS, new Object[] { contact });
		outParameters.put(OUT_MESSAGES, new Object[] { message });

		procedure = new GetNotificationArrangementProcedure(jdbcTemplate) {

			@Override
			public Map<String, Object> execute(Map<String, ?> inParams)
					throws DataAccessException {
				return outParameters;
			}
		};
	}

	@Test
	public void testExecute() throws Exception {
		easyMockSupport.replayAll();

		FindArrangementResponse result = procedure.execute(
				BigInteger.valueOf(999), 1);

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
		assertThat(result.getArrangement(), is(arrangement));
		assertThat(arrangement.getLiabilities(), contains(liability));
		assertThat(arrangement.getInstalments(), contains(instalment));
		assertThat(arrangement.getContacts(), contains(contact));
		assertThat(liability.getArrangement(), is(arrangement));
		assertThat(instalment.getArrangement(), is(arrangement));
		assertThat(contact.getArrangement(), is(arrangement));
		assertThat(result.getMessages(), contains(message));
	}

	@Test
	public void testExecuteNullArrangement() throws Exception {
		outParameters.put(OUT_PAYMENT_ARRANGEMENT, null);
		easyMockSupport.replayAll();

		FindArrangementResponse result = procedure.execute(
				BigInteger.valueOf(999), 1);

		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
		Arrangement resultArrangement = result.getArrangement();
		assertThat(resultArrangement, is(notNullValue()));
		assertThat(resultArrangement.getLiabilities(), contains(liability));
		assertThat(resultArrangement.getInstalments(), contains(instalment));
		assertThat(resultArrangement.getContacts(), contains(contact));
		assertThat(liability.getArrangement(), is(resultArrangement));
		assertThat(instalment.getArrangement(), is(resultArrangement));
		assertThat(contact.getArrangement(), is(resultArrangement));
		assertThat(result.getMessages(), contains(message));
	}

	@Test
	public void testExecuteNullInput() throws Exception {
		easyMockSupport.replayAll();
		FindArrangementResponse result = procedure.execute(null, null);
		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
	}

	@Test
	public void testExecuteNullOutput() throws Exception {
		outParameters = null;
		easyMockSupport.replayAll();
		FindArrangementResponse result = procedure.execute(
				BigInteger.valueOf(999), 1);
		easyMockSupport.verifyAll();
		assertThat(result, is(notNullValue()));
		Arrangement resultArrangement = result.getArrangement();
		assertThat(resultArrangement, is(notNullValue()));
		assertThat(resultArrangement.getLiabilities(), is(empty()));
		assertThat(resultArrangement.getInstalments(), is(empty()));
		assertThat(resultArrangement.getContacts(), is(empty()));
		assertThat(result.getMessages(), is(empty()));
	}

}
