package au.gov.vic.sro.payment.arrangements.dao.procedure;

import static au.gov.vic.sro.payment.arrangements.model.EventStatus.SUCCESSFUL;
import static java.math.BigInteger.ONE;

import java.util.LinkedHashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.easymock.EasyMockSupport;
import org.junit.Before;
import org.junit.Test;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import au.gov.vic.sro.payment.arrangements.model.Event;

public class SaveEventProcedureTest {
	private EasyMockSupport easyMockSupport;
	private DataSource mockDataSource;
	private JdbcTemplate jdbcTemplate;
	private Map<String, Object> outParameters;
	private Event event;
	private SaveEventProcedure procedure;

	@Before
	public void setUp() throws Exception {
		easyMockSupport = new EasyMockSupport();
		mockDataSource = easyMockSupport.createNiceMock(DataSource.class);
		jdbcTemplate = new JdbcTemplate(mockDataSource);

		event = new Event();
		event.setId(ONE);
		event.setStatus(SUCCESSFUL);

		outParameters = new LinkedHashMap<String, Object>();

		procedure = new SaveEventProcedure(jdbcTemplate) {

			@Override
			public Map<String, Object> execute(Map<String, ?> inParams) throws DataAccessException {
				return outParameters;
			}
		};
	}

	@Test
	public void testExecute() throws Exception {
		easyMockSupport.replayAll();

		procedure.execute(event);

		easyMockSupport.verifyAll();
	}

	@Test
	public void testExecuteNullInput() throws Exception {
		event = null;
		easyMockSupport.replayAll();

		procedure.execute(event);

		easyMockSupport.verifyAll();
	}

}
