package au.gov.vic.sro.payment.arrangements.dao.mapper;

import static org.easymock.EasyMock.anyInt;
import static org.easymock.EasyMock.expect;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;

import java.sql.CallableStatement;

import org.easymock.EasyMockSupport;
import org.junit.Before;
import org.junit.Test;

public class BooleanReturnTypeTest {
	private EasyMockSupport easyMockSupport;
	private CallableStatement mockCallableStatement;
	private BooleanReturnType returnType;

	@Before
	public void setUp() throws Exception {
		easyMockSupport = new EasyMockSupport();
		mockCallableStatement = easyMockSupport.createNiceMock(CallableStatement.class);
		returnType = new BooleanReturnType();
	}

	@Test
	public void testGetTypeValueTrue() throws Exception {
		expect(mockCallableStatement.getString(anyInt())).andReturn("Y");
		easyMockSupport.replayAll();

		Object result = returnType.getTypeValue(mockCallableStatement, 0, 0, null);

		easyMockSupport.verifyAll();
		assertThat(result, is(instanceOf(Boolean.class)));
		assertThat((Boolean) result, is(Boolean.TRUE));
	}

	@Test
	public void testGetTypeValueFalse() throws Exception {
		expect(mockCallableStatement.getString(anyInt())).andReturn("N");
		easyMockSupport.replayAll();

		Object result = returnType.getTypeValue(mockCallableStatement, 0, 0, null);

		easyMockSupport.verifyAll();
		assertThat(result, is(instanceOf(Boolean.class)));
		assertThat((Boolean) result, is(Boolean.FALSE));
	}

	@Test
	public void testGetTypeValueNull() throws Exception {
		expect(mockCallableStatement.getString(anyInt())).andReturn(null);
		easyMockSupport.replayAll();

		Object result = returnType.getTypeValue(mockCallableStatement, 0, 0, null);

		easyMockSupport.verifyAll();
		assertThat(result, is(nullValue()));
	}

}
