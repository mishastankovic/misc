package au.gov.vic.sro.payment.arrangements.dao;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Random;

import org.apache.log4j.Logger;

import au.gov.vic.sro.payment.arrangements.dto.AuthenticateResponse;
import au.gov.vic.sro.payment.arrangements.dto.CalculateScheduleResponse;
import au.gov.vic.sro.payment.arrangements.dto.CancelArrangementResponse;
import au.gov.vic.sro.payment.arrangements.dto.FindArrangementResponse;
import au.gov.vic.sro.payment.arrangements.dto.GetConfirmCancelTextResponse;
import au.gov.vic.sro.payment.arrangements.dto.GetDefaultDatesResponse;
import au.gov.vic.sro.payment.arrangements.dto.GetEventsResponse;
import au.gov.vic.sro.payment.arrangements.dto.GetFrequenciesResponse;
import au.gov.vic.sro.payment.arrangements.dto.NextEventResponse;
import au.gov.vic.sro.payment.arrangements.dto.SaveAccountRequest;
import au.gov.vic.sro.payment.arrangements.dto.SaveAccountResponse;
import au.gov.vic.sro.payment.arrangements.dto.SaveArrangementResponse;
import au.gov.vic.sro.payment.arrangements.dto.SaveContactsResponse;
import au.gov.vic.sro.payment.arrangements.model.Arrangement;
import au.gov.vic.sro.payment.arrangements.model.ArrangementStatus;
import au.gov.vic.sro.payment.arrangements.model.Contact;
import au.gov.vic.sro.payment.arrangements.model.ContactType;
import au.gov.vic.sro.payment.arrangements.model.Event;
import au.gov.vic.sro.payment.arrangements.model.Instalment;
import au.gov.vic.sro.payment.arrangements.model.Liability;
import au.gov.vic.sro.payment.arrangements.model.LiabilityType;
import au.gov.vic.sro.payment.arrangements.model.Message;
import au.gov.vic.sro.payment.arrangements.model.PaymentFrequency;
import au.gov.vic.sro.payment.arrangements.model.PaymentMethod;
import au.gov.vic.sro.payment.arrangements.model.RevenueLine;

public class DummyPaymentArrangementsDaoImpl extends PaymentArrangementsDaoImpl {
	private static final Logger log = Logger.getLogger(DummyPaymentArrangementsDaoImpl.class);
	private boolean errorMode;

	@Override
	public AuthenticateResponse authenticate(String customerId, RevenueLine revenueLine, LiabilityType liabilityType,
			String liabilityId) {
		logWarning();
		AuthenticateResponse response = new AuthenticateResponse();
		if (customerId.equals("12345") || customerId.equals("12346") || customerId.equals("12347")
				|| customerId.equals("12348") || customerId.equals("12349")) {
			response.setAuthenticated(true);
			return response;
		}
		return super.authenticate(customerId, revenueLine, liabilityType, liabilityId);
	}

	@Override
	public CalculateScheduleResponse calculateSchedule(String customerId, RevenueLine revenueLine,
			LiabilityType liabilityType, String liabilityId, Date arrangementStartDate, Date arrangementEndDate,
			PaymentFrequency paymentFrequency, PaymentMethod paymentMethod) {
		logWarning();
		if (customerId.equals("12345") || customerId.equals("12346")) {
			CalculateScheduleResponse response = new CalculateScheduleResponse();
			if (errorMode) {
				ArrayList<Message> messages = new ArrayList<Message>();
				Message message = new Message();
				message.setText("A schedule could not be generated.");
				messages.add(message);
				response.setMessages(messages);
			} else {
				List<Instalment> instalments = new ArrayList<Instalment>();
				BigDecimal allInstalmentAmountDollars = new BigDecimal(0);
				BigDecimal allInstalmentSurchargeDollars = new BigDecimal(0);
				BigDecimal allInstalmentTotalAmountDollars = new BigDecimal(0);
				Calendar c = Calendar.getInstance();
				c.setTime(arrangementStartDate);
				for (int i = 0; i < new Random().nextInt(5) + 5; i++) {
					Instalment instalment = new Instalment();
					instalment.setAmountDollars(new BigDecimal(5000));
					allInstalmentAmountDollars = allInstalmentAmountDollars.add(instalment.getAmountDollars());
					instalment.setDueDate(c.getTime());
					if (paymentMethod.equals(PaymentMethod.CREDIT_CARD)) {
						instalment.setSurchargeDollars(new BigDecimal(0.033).multiply(instalment.getAmountDollars()));
						allInstalmentSurchargeDollars =
								allInstalmentSurchargeDollars.add(instalment.getSurchargeDollars());
					} else {
						instalment.setSurchargeDollars(new BigDecimal(0));
					}
					instalment
							.setTotalAmountDollars(instalment.getAmountDollars().add(instalment.getSurchargeDollars()));
					allInstalmentTotalAmountDollars =
							allInstalmentTotalAmountDollars.add(instalment.getTotalAmountDollars());
					instalments.add(instalment);
					switch (paymentFrequency) {
					case FORTNIGHTLY:
						c.add(Calendar.DATE, 14);
						break;
					case FOUR: {
						c.add(Calendar.DATE, 15);
						break;
					}
					case MONTHLY:
						c.add(Calendar.MONTH, 1);
						break;
					default:
						break;
					}
				}
				response.setInstalments(instalments);
				response.setAllInstalmentAmountDollars(allInstalmentAmountDollars);
				response.setAllInstalmentSurchargeDollars(allInstalmentSurchargeDollars);
				response.setAllInstalmentTotalAmountDollars(allInstalmentTotalAmountDollars);
			}
			return response;
		}
		return super.calculateSchedule(customerId, revenueLine, liabilityType, liabilityId, arrangementStartDate,
				arrangementEndDate, paymentFrequency, paymentMethod);
	}

	@Override
	public CancelArrangementResponse cancelArrangement(BigInteger arrangementId, Integer arrangementVersion) {
		logWarning();
		if (arrangementId.equals("12346")) {
			CancelArrangementResponse response = new CancelArrangementResponse();
			if (errorMode) {
				response.setCancelled(false);
				response.setMessages(new ArrayList<Message>());
			} else {
				response.setCancelled(true);
			}
			return response;
		}
		return super.cancelArrangement(arrangementId, arrangementVersion);
	}

	@Override
	public FindArrangementResponse findNotificationArrangement(BigInteger arrangementId, Integer arrangementVersion) {
		logWarning();
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public FindArrangementResponse findArrangement(String customerId, RevenueLine revenueLine,
			LiabilityType liabilityType, String liabilityId) {
		logWarning();
		if (errorMode) {
			FindArrangementResponse response = new FindArrangementResponse();
			ArrayList<Message> messages = new ArrayList<Message>();
			messages.add(new Message());
			response.setMessages(messages);
		}
		if (customerId.equals("12345")) {
			FindArrangementResponse response = new FindArrangementResponse();
			Arrangement arrangement = new Arrangement();
			arrangement.setCustomerId(customerId);
			List<Liability> liabilities = new ArrayList<Liability>();
			Liability liability = new Liability();
			liability.setArrangement(arrangement);
			liability.setIssueDate(new Date());
			liability.setRevenueLine(revenueLine);
			liability.setId(liabilityId);
			liability.setType(liabilityType);
			liability.setVersion(1);
			liability.setYear(2016);
			liability.setOutstandingLiabilityAmountDollars(new BigDecimal(50000));
			liabilities.add(liability);
			arrangement.setLiabilities(liabilities);
			response.setArrangement(arrangement);
			return response;
		} else if (customerId.equals("12346")) {
			FindArrangementResponse response = new FindArrangementResponse();
			Arrangement arrangement = new Arrangement();
			arrangement.setCustomerId(customerId);
			arrangement.setId(BigInteger.valueOf(12346));
			arrangement.setVersion(1);
			Calendar c = Calendar.getInstance();
			c.setTime(new Date());
			arrangement.setStartDate(c.getTime());
			c.add(Calendar.DATE, 70);
			arrangement.setEndDate(c.getTime());
			arrangement.setStatus(ArrangementStatus.ACTIVE);
			arrangement.setPaymentFrequency(PaymentFrequency.FORTNIGHTLY);
			arrangement.setPaymentMethod(PaymentMethod.CREDIT_CARD);
			List<Liability> liabilities = new ArrayList<Liability>();
			Liability liability = new Liability();
			liability.setArrangement(arrangement);
			liability.setIssueDate(new Date());
			liability.setRevenueLine(revenueLine);
			liability.setId(liabilityId);
			liability.setType(liabilityType);
			liability.setVersion(1);
			liability.setYear(2016);
			liability.setOutstandingLiabilityAmountDollars(new BigDecimal(50000));
			liabilities.add(liability);
			arrangement.setLiabilities(liabilities);
			List<Contact> contacts = new ArrayList<Contact>();
			Contact contact = new Contact();
			contact.setArrangement(arrangement);
			contact.setType(ContactType.CUSTOMER_REP);
			contact.setPersonName("Dan Rowley");
			contact.setEmailAddress("dan.rowley@sro.vic.gov.au");
			contact.setMobilePhone("0414425329");
			contacts.add(contact);
			arrangement.setContacts(contacts);
			List<Instalment> instalments = new ArrayList<Instalment>();
			BigDecimal allInstalmentAmountDollars = new BigDecimal(0);
			BigDecimal allInstalmentSurchargeDollars = new BigDecimal(0);
			BigDecimal allInstalmentTotalAmountDollars = new BigDecimal(0);
			c.setTime(arrangement.getStartDate());
			for (int i = 0; i < 5; i++) {
				Instalment instalment = new Instalment();
				instalment.setArrangement(arrangement);
				instalment.setAmountDollars(new BigDecimal(10000));
				allInstalmentAmountDollars = allInstalmentAmountDollars.add(instalment.getAmountDollars());
				instalment.setDueDate(c.getTime());
				instalment.setSurchargeDollars(new BigDecimal(0.033).multiply(instalment.getAmountDollars()));
				allInstalmentSurchargeDollars = allInstalmentSurchargeDollars.add(instalment.getSurchargeDollars());
				instalment.setTotalAmountDollars(instalment.getAmountDollars().add(instalment.getSurchargeDollars()));
				allInstalmentTotalAmountDollars =
						allInstalmentTotalAmountDollars.add(instalment.getTotalAmountDollars());
				instalments.add(instalment);
				c.add(Calendar.DATE, 14);
			}
			arrangement.setInstalments(instalments);
			arrangement.setAllInstalmentAmountDollars(allInstalmentAmountDollars);
			arrangement.setAllInstalmentSurchargeDollars(allInstalmentSurchargeDollars);
			arrangement.setAllInstalmentTotalAmountDollars(allInstalmentTotalAmountDollars);
			arrangement.setCardNumber("4111........111");
			response.setArrangement(arrangement);
			return response;
		} else if (customerId.equals("12347")) {
			FindArrangementResponse response = new FindArrangementResponse();
			Arrangement arrangement = new Arrangement();
			arrangement.setCustomerId(customerId);
			arrangement.setId(BigInteger.valueOf(12347));
			arrangement.setVersion(1);
			Calendar c = Calendar.getInstance();
			c.setTime(new Date());
			arrangement.setStartDate(c.getTime());
			c.add(Calendar.DATE, 70);
			arrangement.setEndDate(c.getTime());
			arrangement.setStatus(ArrangementStatus.CANCELLED);
			arrangement.setPaymentFrequency(PaymentFrequency.FORTNIGHTLY);
			arrangement.setPaymentMethod(PaymentMethod.DIRECT_DEBIT);
			List<Liability> liabilities = new ArrayList<Liability>();
			Liability liability = new Liability();
			liability.setArrangement(arrangement);
			liability.setIssueDate(new Date());
			liability.setRevenueLine(revenueLine);
			liability.setId(liabilityId);
			liability.setType(liabilityType);
			liability.setVersion(1);
			liability.setYear(2016);
			liability.setOutstandingLiabilityAmountDollars(new BigDecimal(50000));
			liabilities.add(liability);
			arrangement.setLiabilities(liabilities);
			List<Contact> contacts = new ArrayList<Contact>();
			Contact contact = new Contact();
			contact.setArrangement(arrangement);
			contact.setType(ContactType.CUSTOMER_REP);
			contact.setPersonName("Dan Rowley");
			contact.setEmailAddress("dan.rowley@sro.vic.gov.au");
			contact.setMobilePhone("0414425329");
			contacts.add(contact);
			arrangement.setContacts(contacts);
			List<Instalment> instalments = new ArrayList<Instalment>();
			BigDecimal allInstalmentAmountDollars = new BigDecimal(0);
			BigDecimal allInstalmentSurchargeDollars = new BigDecimal(0);
			BigDecimal allInstalmentTotalAmountDollars = new BigDecimal(0);
			c.setTime(arrangement.getStartDate());
			for (int i = 0; i < 5; i++) {
				Instalment instalment = new Instalment();
				instalment.setArrangement(arrangement);
				instalment.setAmountDollars(new BigDecimal(10000));
				allInstalmentAmountDollars = allInstalmentAmountDollars.add(instalment.getAmountDollars());
				instalment.setDueDate(c.getTime());
				instalment.setSurchargeDollars(new BigDecimal(0));
				allInstalmentSurchargeDollars = allInstalmentSurchargeDollars.add(instalment.getSurchargeDollars());
				instalment.setTotalAmountDollars(instalment.getAmountDollars().add(instalment.getSurchargeDollars()));
				allInstalmentTotalAmountDollars =
						allInstalmentTotalAmountDollars.add(instalment.getTotalAmountDollars());
				instalments.add(instalment);
				c.add(Calendar.DATE, 14);
			}
			arrangement.setInstalments(instalments);
			arrangement.setAllInstalmentAmountDollars(allInstalmentAmountDollars);
			arrangement.setAllInstalmentSurchargeDollars(allInstalmentSurchargeDollars);
			arrangement.setAllInstalmentTotalAmountDollars(allInstalmentTotalAmountDollars);
			arrangement.setCardNumber("4111........111");
			response.setArrangement(arrangement);
			return response;
		} else if (customerId.equals("12348")) {
			FindArrangementResponse response = new FindArrangementResponse();
			Arrangement arrangement = new Arrangement();
			arrangement.setCustomerId(customerId);
			arrangement.setId(BigInteger.valueOf(12348));
			arrangement.setVersion(1);
			Calendar c = Calendar.getInstance();
			c.setTime(new Date());
			arrangement.setStartDate(c.getTime());
			c.add(Calendar.DATE, 70);
			arrangement.setEndDate(c.getTime());
			arrangement.setStatus(ArrangementStatus.COMPLETED);
			arrangement.setPaymentFrequency(PaymentFrequency.FORTNIGHTLY);
			arrangement.setPaymentMethod(PaymentMethod.DIRECT_DEBIT);
			List<Liability> liabilities = new ArrayList<Liability>();
			Liability liability = new Liability();
			liability.setArrangement(arrangement);
			liability.setIssueDate(new Date());
			liability.setRevenueLine(revenueLine);
			liability.setId(liabilityId);
			liability.setType(liabilityType);
			liability.setVersion(1);
			liability.setYear(2016);
			liability.setOutstandingLiabilityAmountDollars(new BigDecimal(100000));
			liabilities.add(liability);
			arrangement.setLiabilities(liabilities);
			List<Contact> contacts = new ArrayList<Contact>();
			Contact contact = new Contact();
			contact.setArrangement(arrangement);
			contact.setType(ContactType.CUSTOMER_REP);
			contact.setPersonName("Dan Rowley");
			contact.setEmailAddress("dan.rowley@sro.vic.gov.au");
			contact.setMobilePhone("0414425329");
			contacts.add(contact);
			arrangement.setContacts(contacts);
			List<Instalment> instalments = new ArrayList<Instalment>();
			BigDecimal allInstalmentAmountDollars = new BigDecimal(0);
			BigDecimal allInstalmentSurchargeDollars = new BigDecimal(0);
			BigDecimal allInstalmentTotalAmountDollars = new BigDecimal(0);
			c.setTime(arrangement.getStartDate());
			for (int i = 0; i < 5; i++) {
				Instalment instalment = new Instalment();
				instalment.setArrangement(arrangement);
				instalment.setAmountDollars(new BigDecimal(20000));
				allInstalmentAmountDollars = allInstalmentAmountDollars.add(instalment.getAmountDollars());
				instalment.setDueDate(c.getTime());
				instalment.setSurchargeDollars(new BigDecimal(0));
				allInstalmentSurchargeDollars = allInstalmentSurchargeDollars.add(instalment.getSurchargeDollars());
				instalment.setTotalAmountDollars(instalment.getAmountDollars().add(instalment.getSurchargeDollars()));
				allInstalmentTotalAmountDollars =
						allInstalmentTotalAmountDollars.add(instalment.getTotalAmountDollars());
				instalments.add(instalment);
				c.add(Calendar.DATE, 14);
			}
			arrangement.setInstalments(instalments);
			arrangement.setAllInstalmentAmountDollars(allInstalmentAmountDollars);
			arrangement.setAllInstalmentSurchargeDollars(allInstalmentSurchargeDollars);
			arrangement.setAllInstalmentTotalAmountDollars(allInstalmentTotalAmountDollars);
			arrangement.setCardNumber("4111........111");
			response.setArrangement(arrangement);
			return response;
		} else if (customerId.equals("12349")) {
			FindArrangementResponse response = new FindArrangementResponse();
			Arrangement arrangement = new Arrangement();
			arrangement.setCustomerId(customerId);
			arrangement.setId(BigInteger.valueOf(12349));
			arrangement.setVersion(1);
			Calendar c = Calendar.getInstance();
			c.setTime(new Date());
			arrangement.setStartDate(c.getTime());
			c.add(Calendar.DATE, 70);
			arrangement.setEndDate(c.getTime());
			arrangement.setStatus(ArrangementStatus.PENDING);
			arrangement.setPaymentFrequency(PaymentFrequency.FORTNIGHTLY);
			arrangement.setPaymentMethod(PaymentMethod.DIRECT_DEBIT);
			List<Liability> liabilities = new ArrayList<Liability>();
			Liability liability = new Liability();
			liability.setArrangement(arrangement);
			liability.setIssueDate(new Date());
			liability.setRevenueLine(revenueLine);
			liability.setId(liabilityId);
			liability.setType(liabilityType);
			liability.setVersion(1);
			liability.setYear(2016);
			liability.setOutstandingLiabilityAmountDollars(new BigDecimal(100000));
			liabilities.add(liability);
			arrangement.setLiabilities(liabilities);
			List<Contact> contacts = new ArrayList<Contact>();
			Contact contact = new Contact();
			contact.setArrangement(arrangement);
			contact.setType(ContactType.CUSTOMER_REP);
			contact.setPersonName("Dan Rowley");
			contact.setEmailAddress("dan.rowley@sro.vic.gov.au");
			contact.setMobilePhone("0414425329");
			contacts.add(contact);
			arrangement.setContacts(contacts);
			List<Instalment> instalments = new ArrayList<Instalment>();
			BigDecimal allInstalmentAmountDollars = new BigDecimal(0);
			BigDecimal allInstalmentSurchargeDollars = new BigDecimal(0);
			BigDecimal allInstalmentTotalAmountDollars = new BigDecimal(0);
			c.setTime(arrangement.getStartDate());
			for (int i = 0; i < 5; i++) {
				Instalment instalment = new Instalment();
				instalment.setArrangement(arrangement);
				instalment.setAmountDollars(new BigDecimal(20000));
				allInstalmentAmountDollars = allInstalmentAmountDollars.add(instalment.getAmountDollars());
				instalment.setDueDate(c.getTime());
				instalment.setSurchargeDollars(new BigDecimal(0));
				allInstalmentSurchargeDollars = allInstalmentSurchargeDollars.add(instalment.getSurchargeDollars());
				instalment.setTotalAmountDollars(instalment.getAmountDollars().add(instalment.getSurchargeDollars()));
				allInstalmentTotalAmountDollars =
						allInstalmentTotalAmountDollars.add(instalment.getTotalAmountDollars());
				instalments.add(instalment);
				c.add(Calendar.DATE, 14);
			}
			arrangement.setInstalments(instalments);
			arrangement.setAllInstalmentAmountDollars(allInstalmentAmountDollars);
			arrangement.setAllInstalmentSurchargeDollars(allInstalmentSurchargeDollars);
			arrangement.setAllInstalmentTotalAmountDollars(allInstalmentTotalAmountDollars);
			arrangement.setCardNumber("4111........111");
			response.setArrangement(arrangement);
			return response;
		}
		return super.findArrangement(customerId, revenueLine, liabilityType, liabilityId);
	}

	@Override
	public GetConfirmCancelTextResponse getConfirmCancelText(BigInteger arrangementId, Integer arrangementVersion) {
		logWarning();
		if (arrangementId.equals(BigInteger.valueOf(12346))) {
			GetConfirmCancelTextResponse response = new GetConfirmCancelTextResponse();
			if (errorMode) {
				ArrayList<Message> messages = new ArrayList<Message>();
				messages.add(new Message());
				response.setMessages(messages);
			} else {
				response.setText("Dan is awesome!");
			}
			return response;
		}
		return super.getConfirmCancelText(arrangementId, arrangementVersion);
	}

	@Override
	public GetDefaultDatesResponse getDefaultDates(String customerId, RevenueLine revenueLine,
			LiabilityType liabilityType, String liabilityId) {
		logWarning();
		if (customerId.equals("12345") || customerId.equals("12346") || customerId.equals("12348")) {
			GetDefaultDatesResponse response = new GetDefaultDatesResponse();
			Calendar c = Calendar.getInstance();
			c.setTime(new Date());
			c.set(Calendar.HOUR_OF_DAY, 0);
			c.set(Calendar.MINUTE, 0);
			c.set(Calendar.SECOND, 0);
			c.set(Calendar.MILLISECOND, 0);
			response.setArrangementStartDate(c.getTime());
			c.add(Calendar.DATE, 14);
			response.setArrangementMaxStartDate(c.getTime());
			c.add(Calendar.MONTH, 3);
			response.setArrangementEndDate(c.getTime());
			return response;
		}
		return super.getDefaultDates(customerId, revenueLine, liabilityType, liabilityId);
	}

	@Override
	public GetEventsResponse getEvents(List<BigInteger> eventIds) {
		logWarning();
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public GetFrequenciesResponse getFrequencies(String customerId, RevenueLine revenueLine,
			LiabilityType liabilityType, String liabilityId, Date arrangementStartDate, Date arrangementEndDate) {
		logWarning();
		if (customerId.equals("12345") || customerId.equals("12346")) {
			GetFrequenciesResponse response = new GetFrequenciesResponse();
			if (errorMode) {
				ArrayList<Message> messages = new ArrayList<Message>();
				messages.add(new Message());
				response.setMessages(messages);
			} else {
				List<PaymentFrequency> paymentFrequencies = new ArrayList<PaymentFrequency>();
				paymentFrequencies.addAll(Arrays.asList(PaymentFrequency.FORTNIGHTLY, PaymentFrequency.MONTHLY));
				response.setPaymentFrequencies(paymentFrequencies);
			}
			return response;
		}
		return super.getFrequencies(customerId, revenueLine, liabilityType, liabilityId, arrangementStartDate,
				arrangementEndDate);
	}

	public boolean isErrorMode() {
		logWarning();
		return errorMode;
	}

	@Override
	public NextEventResponse nextEvent() {
		logWarning();
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SaveAccountResponse saveAccount(SaveAccountRequest request) {
		logWarning();
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SaveArrangementResponse saveArrangement(Arrangement arrangement) {
		logWarning();
		if ("12345".equals(arrangement.getCustomerId())) {
			SaveArrangementResponse response = new SaveArrangementResponse();
			if (errorMode) {
				response.setSaved(false);
				List<Message> messages = new ArrayList<Message>();
				Message message = new Message();
				message.setText("1");
				messages.add(message);
				message = new Message();
				message.setText("2");
				messages.add(message);
				response.setMessages(messages);
			} else {
				response.setSaved(true);
				response.setArrangementId(BigInteger.ONE);
				response.setArrangementVersion(1);
			}
			return response;
		}
		return super.saveArrangement(arrangement);
	}

	@Override
	public SaveContactsResponse saveContacts(List<Contact> contacts, String checksum) {
		logWarning();
		String customerId = contacts.get(0).getArrangement().getCustomerId();
		if (customerId.equals("12346")) {
			SaveContactsResponse response = new SaveContactsResponse();
			if (errorMode) {
				response.setSaved(false);
				List<Message> messages = new ArrayList<Message>();
				messages.add(new Message());
				response.setMessages(messages);
			} else {
				response.setSaved(true);
			}
			return response;
		}
		return super.saveContacts(contacts, checksum);
	}

	@Override
	public void saveEvent(Event event) {
		logWarning();
		// TODO Auto-generated method stub

	}

	public void setErrorMode(boolean errorMode) {
		logWarning();
		this.errorMode = errorMode;
	}

	private void logWarning() {
		log.warn(String.format("%n%n>>>>>>>>>> DUMMY DAO!!! <<<<<<<<<<%n%n"));
	}

}
