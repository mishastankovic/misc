package au.gov.vic.sro.payment.arrangements.service;

import static au.gov.vic.sro.payment.arrangements.model.LiabilityType.ASSESSMENT;
import static au.gov.vic.sro.payment.arrangements.model.RevenueLine.LAND_TAX;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.is;

import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

public class UserDetailsImplTest {
	private GrantedAuthority authority1;
	private GrantedAuthority authority2;
	private List<GrantedAuthority> authorities;
	private UserDetailsImpl user1;
	private UserDetailsImpl user2;

	@Before
	public void setUp() throws Exception {
		authority1 = new SimpleGrantedAuthority("z");
		authority2 = new SimpleGrantedAuthority("a");
		authorities = Arrays.asList(authority1, null, authority1, authority2);

		user1 = new UserDetailsImpl();
		user1.setCustomerId("999");
		user1.setRevenueLine(LAND_TAX);
		user1.setLiabilityType(ASSESSMENT);
		user1.setLiabilityId("S00000001");

		user2 = new UserDetailsImpl();
		user2.setCustomerId("999");
		user2.setRevenueLine(LAND_TAX);
		user2.setLiabilityType(ASSESSMENT);
		user2.setLiabilityId("00000001");
	}

	@Test
	public void testSetAuthorities() {
		user1.setAuthorities(authorities);
		assertThat(user1.getAuthorities(), contains(authority2, authority1));

		user1.setAuthorities(null);
		assertThat(user1.getAuthorities(), is(empty()));
	}

	@Test
	public void testGetNormalizedLiabilityId() {
		assertThat(user1.getNormalizedLiabilityId(), is("00000001"));
		assertThat(user2.getNormalizedLiabilityId(), is("00000001"));
	}

	@Test
	public void testEquals() {
		assertThat(user1.equals(user1), is(true));
		assertThat(user1.equals(user2), is(true));
		assertThat(user1.equals("BAD!!!"), is(false));
		assertThat(user1.equals(null), is(false));
		assertThat(user2.equals(user2), is(true));
		assertThat(user2.equals(user1), is(true));
		assertThat(user2.equals("BAD!!!"), is(false));
		assertThat(user2.equals(null), is(false));
	}

	@Test
	public void testHashCode() {
		assertThat(user1.hashCode(), is(user2.hashCode()));
	}

}
