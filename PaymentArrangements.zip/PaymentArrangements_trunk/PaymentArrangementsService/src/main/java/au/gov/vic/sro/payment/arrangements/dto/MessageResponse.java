package au.gov.vic.sro.payment.arrangements.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;

import au.gov.vic.sro.payment.arrangements.model.Message;

public abstract class MessageResponse implements Serializable {
	private static final long serialVersionUID = 3256270036138599493L;
	private List<Message> messages = new ArrayList<Message>();

	public List<Message> getMessages() {
		return messages;
	}

	public void setMessages(List<Message> messages) {
		this.messages.clear();
		if (CollectionUtils.isNotEmpty(messages)) {
			this.messages.addAll(messages);
		}
	}

	public void setMessages(Object[] messages) {
		this.messages.clear();
		if (ArrayUtils.isNotEmpty(messages)) {
			for (Object message : messages) {
				this.messages.add((Message) message);
			}
		}
	}

}
