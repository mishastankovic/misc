package au.gov.vic.sro.payment.arrangements.dto;

import static au.gov.vic.sro.builder.ToStringStyleFactory.getToStringStyle;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import au.gov.vic.sro.payment.arrangements.model.Event;

public class GetEventsResponse implements Serializable {
	private static final long serialVersionUID = -1823225322004900541L;
	private List<Event> events = new ArrayList<Event>();

	public List<Event> getEvents() {
		return events;
	}

	public void setEvents(List<Event> events) {
		this.events.clear();
		if (CollectionUtils.isNotEmpty(events)) {
			for (Event event : events) {
				if (event != null && event.getId() != null) {
					this.events.add(event);
				}
			}
		}
	}

	public void setEvents(Object[] events) {
		this.events.clear();
		if (ArrayUtils.isNotEmpty(events)) {
			for (Object obj : events) {
				Event event = (Event) obj;
				if (event != null && event.getId() != null) {
					this.events.add(event);
				}
			}
		}
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, getToStringStyle());
	}

}
