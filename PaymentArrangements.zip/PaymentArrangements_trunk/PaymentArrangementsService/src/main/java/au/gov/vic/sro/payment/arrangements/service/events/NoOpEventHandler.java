package au.gov.vic.sro.payment.arrangements.service.events;

import static au.gov.vic.sro.payment.arrangements.model.EventStatus.SUCCESSFUL;

import au.gov.vic.sro.payment.arrangements.model.Event;

public class NoOpEventHandler implements EventHandler {

	@Override
	public void handle(Event event) {
		event.setStatus(SUCCESSFUL);
	}

}
