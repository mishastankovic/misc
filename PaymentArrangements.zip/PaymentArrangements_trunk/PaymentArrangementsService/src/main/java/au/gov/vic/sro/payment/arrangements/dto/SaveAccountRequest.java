package au.gov.vic.sro.payment.arrangements.dto;

import static au.gov.vic.sro.builder.ToStringStyleFactory.getToStringStyle;

import java.io.Serializable;
import java.math.BigInteger;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import au.gov.vic.sro.payment.arrangements.model.PaymentMethod;

public class SaveAccountRequest implements Serializable {
	private static final long serialVersionUID = 6525470969321235985L;

	private BigInteger arrangementId;
	private Integer arrangementVersion;
	private String accountToken;
	private PaymentMethod paymentMethod;
	private String cardNumber;
	private String cardExpiryMonth;
	private String cardExpiryYear;
	private String bankBsb;
	private String bankAccountNumber;
	private String checksum;

	public BigInteger getArrangementId() {
		return arrangementId;
	}

	public void setArrangementId(BigInteger arrangementId) {
		this.arrangementId = arrangementId;
	}

	public Integer getArrangementVersion() {
		return arrangementVersion;
	}

	public void setArrangementVersion(Integer arrangementVersion) {
		this.arrangementVersion = arrangementVersion;
	}

	public String getAccountToken() {
		return accountToken;
	}

	public void setAccountToken(String accountToken) {
		this.accountToken = accountToken;
	}

	public PaymentMethod getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(PaymentMethod paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public String getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getCardExpiryMonth() {
		return cardExpiryMonth;
	}

	public void setCardExpiryMonth(String cardExpiryMonth) {
		this.cardExpiryMonth = cardExpiryMonth;
	}

	public String getCardExpiryYear() {
		return cardExpiryYear;
	}

	public void setCardExpiryYear(String cardExpiryYear) {
		this.cardExpiryYear = cardExpiryYear;
	}

	public String getBankBsb() {
		return bankBsb;
	}

	public void setBankBsb(String bankBsb) {
		this.bankBsb = bankBsb;
	}

	public String getBankAccountNumber() {
		return bankAccountNumber;
	}

	public void setBankAccountNumber(String bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}

	public String getChecksum() {
		return checksum;
	}

	public void setChecksum(String checksum) {
		this.checksum = checksum;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, getToStringStyle());
	}

}
