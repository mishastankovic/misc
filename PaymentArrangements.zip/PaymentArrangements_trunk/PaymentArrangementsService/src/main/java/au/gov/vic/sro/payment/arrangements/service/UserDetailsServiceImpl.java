package au.gov.vic.sro.payment.arrangements.service;

import java.util.List;

import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;

import au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDao;
import au.gov.vic.sro.payment.arrangements.dto.AuthenticateResponse;
import au.gov.vic.sro.payment.arrangements.model.RevenueLine;
import au.gov.vic.sro.payment.arrangements.util.LogUtil;

public class UserDetailsServiceImpl implements UserDetailsService {
	private static final Logger log = Logger.getLogger(UserDetailsServiceImpl.class);
	private static final String PASSWORD = "password";
	private PaymentArrangementsDao paymentArrangementsDao;
	private List<GrantedAuthority> userAuthorities;
	private ObjectReader objectReader;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

		UserDetailsImpl user = parseUsername(username);
		LogUtil.putCustomerId(user.getCustomerId());
		AuthenticateResponse result = getPaymentArrangementsDao().authenticate(user.getCustomerId(),
				user.getRevenueLine(), user.getLiabilityType(), user.getLiabilityId());

		if (BooleanUtils.isNotTrue(result.getAuthenticated())) {
			log.info(String.format("Login failed. messages=%s", result.getMessages()));
			throw new UsernameNotFoundException("Username was not found.");
		}
		user.setUsername(username);
		user.setPassword(PASSWORD);
		user.setCustomerId(result.getCustomerId());
		user.setRevenueLine(RevenueLine.fromCode(result.getRevenueLineCode()));
		user.setAuthorities(getUserAuthorities());
		log.info("Login successful.");
		return user;

	}

	public PaymentArrangementsDao getPaymentArrangementsDao() {
		return paymentArrangementsDao;
	}

	public void setPaymentArrangementsDao(PaymentArrangementsDao paymentArrangementsDao) {
		this.paymentArrangementsDao = paymentArrangementsDao;
	}

	public List<GrantedAuthority> getUserAuthorities() {
		return userAuthorities;
	}

	public void setUserAuthorities(List<GrantedAuthority> userAuthorities) {
		this.userAuthorities = userAuthorities;
	}

	protected ObjectReader getObjectReader() {
		if (objectReader == null) {
			objectReader = new ObjectMapper().reader(UserDetailsImpl.class);
		}
		return objectReader;
	}

	protected UserDetailsImpl parseUsername(String username) {
		UserDetailsImpl user;
		try {
			user = getObjectReader().readValue(username);
		} catch (Exception e) {
			throw new IllegalArgumentException(String.format("username=%s", username), e);
		}
		if (user == null || StringUtils.isBlank(user.getCustomerId()) || user.getRevenueLine() == null
				|| user.getLiabilityType() == null || StringUtils.isBlank(user.getLiabilityId())) {
			throw new IllegalArgumentException(String.format("username=%s", username));
		}
		return user;
	}

}
