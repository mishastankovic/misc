package au.gov.vic.sro.payment.arrangements.service.events;

import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.Properties;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.springframework.core.io.Resource;

import au.gov.vic.sro.emailer.EMailService;
import au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDao;
import au.gov.vic.sro.payment.arrangements.dto.CancelEmailResponse;
import au.gov.vic.sro.payment.arrangements.model.Arrangement;
import au.gov.vic.sro.payment.arrangements.model.Event;

public class NotificationEventHandler {
	private Logger log = Logger.getLogger(getClass());
	private PaymentArrangementsDao paymentArrangementsDao;
	private Properties properties;
	private String emailTemplate;

	protected Arrangement getArrangement(Event event) {
		Arrangement arrangement = getPaymentArrangementsDao()
				.findNotificationArrangement(event.getArrangementId(), event.getArrangementVersion()).getArrangement();
		if (arrangement == null || arrangement.getId() == null || arrangement.getVersion() == null) {
			// Should not happen.
			throw new IllegalArgumentException("Arrangement not found.");
		}
		return arrangement;
	}

	protected Date getDate(Event event, String dateTypeRequired) {
		CancelEmailResponse cancelEmailResponse = getPaymentArrangementsDao()
				.getNotificationData(event.getArrangementId(), event.getArrangementVersion(), dateTypeRequired);
		Date returnDate = null;
		if (cancelEmailResponse == null || cancelEmailResponse.getReturnDate() == null
				|| CollectionUtils.isNotEmpty(cancelEmailResponse.getMessages())) {
			log.warn(String.format("CancelEmailResponse: %s", cancelEmailResponse));
			log.warn(String.format("ReturnDate: %s", cancelEmailResponse != null ? cancelEmailResponse.getReturnDate()
					: "Date could not be fetched as CancelEmailResponse is null."));
			log.warn(String.format("Message received from eSys: %s",
					cancelEmailResponse != null ? cancelEmailResponse.getMessages()
							: "Messages could not be fetched as CancelEmailResponse is null."));
		} else {
			returnDate = cancelEmailResponse.getReturnDate();
		}
		return returnDate;
	}

	protected void sendEmail(String fromName, String fromAddress, String toAddress, String subject, String body) {
		if (log.isDebugEnabled()) {
			log.debug(String.format("fromName=[%s] fromAddress=[%s] toAddress=[%s] subject=[%s] body=[%s]", fromName,
					fromAddress, toAddress, subject, body));
		}
		getEmailService().sendHtml(body, subject, new String[] { toAddress }, null, null, fromAddress, fromName, null,
				null, null, null);
	}

	protected EMailService getEmailService() {
		return new EMailService();
	}

	public PaymentArrangementsDao getPaymentArrangementsDao() {
		return paymentArrangementsDao;
	}

	public void setPaymentArrangementsDao(PaymentArrangementsDao paymentArrangementsDao) {
		this.paymentArrangementsDao = paymentArrangementsDao;
	}

	public Properties getProperties() {
		return properties;
	}

	public void setProperties(Properties properties) {
		this.properties = properties;
	}

	public String getEmailTemplate() {
		return emailTemplate;
	}

	public void setEmailTemplate(String emailTemplate) {
		this.emailTemplate = emailTemplate;
	}

	public void setEmailTemplateResource(Resource resource) throws IOException {
		if (resource == null) {
			emailTemplate = null;
		} else {
			InputStream in = null;
			try {
				in = resource.getInputStream();
				emailTemplate = IOUtils.toString(in, "UTF-8");
			} finally {
				IOUtils.closeQuietly(in);
			}
		}
	}

}
