package au.gov.vic.sro.payment.arrangements.service;

import java.math.BigInteger;
import java.util.Date;
import java.util.List;

import au.gov.vic.sro.payment.arrangements.dto.CalculateScheduleResponse;
import au.gov.vic.sro.payment.arrangements.dto.CancelArrangementResponse;
import au.gov.vic.sro.payment.arrangements.dto.FindArrangementResponse;
import au.gov.vic.sro.payment.arrangements.dto.GetConfirmCancelTextResponse;
import au.gov.vic.sro.payment.arrangements.dto.GetDefaultDatesResponse;
import au.gov.vic.sro.payment.arrangements.dto.GetEventsResponse;
import au.gov.vic.sro.payment.arrangements.dto.GetFrequenciesResponse;
import au.gov.vic.sro.payment.arrangements.dto.NextEventResponse;
import au.gov.vic.sro.payment.arrangements.dto.SaveAccountRequest;
import au.gov.vic.sro.payment.arrangements.dto.SaveAccountResponse;
import au.gov.vic.sro.payment.arrangements.dto.SaveArrangementResponse;
import au.gov.vic.sro.payment.arrangements.dto.SaveContactsResponse;
import au.gov.vic.sro.payment.arrangements.model.Arrangement;
import au.gov.vic.sro.payment.arrangements.model.Contact;
import au.gov.vic.sro.payment.arrangements.model.Event;
import au.gov.vic.sro.payment.arrangements.model.LiabilityType;
import au.gov.vic.sro.payment.arrangements.model.PaymentFrequency;
import au.gov.vic.sro.payment.arrangements.model.PaymentMethod;
import au.gov.vic.sro.payment.arrangements.model.RevenueLine;

public interface PaymentArrangementsService {

	FindArrangementResponse findArrangement(String customerId, RevenueLine revenueLine, LiabilityType liabilityType,
			String liabilityId);

	FindArrangementResponse findArrangement(BigInteger arrangementId, Integer arrangementVersion);

	GetDefaultDatesResponse getDefaultDates(String customerId, RevenueLine revenueLine, LiabilityType liabilityType,
			String liabilityId);

	GetFrequenciesResponse getFrequencies(String customerId, RevenueLine revenueLine, LiabilityType liabilityType,
			String liabilityId, Date arrangementStartDate, Date arrangementEndDate);

	CalculateScheduleResponse calculateSchedule(String customerId, RevenueLine revenueLine, LiabilityType liabilityType,
			String liabilityId, Date arrangementStartDate, Date arrangementEndDate, PaymentFrequency paymentFrequency,
			PaymentMethod paymentMethod);

	SaveArrangementResponse saveArrangement(Arrangement arrangement);

	SaveAccountResponse saveAccount(SaveAccountRequest request);

	SaveContactsResponse saveContacts(List<Contact> contacts, String checksum);

	GetConfirmCancelTextResponse getConfirmCancelText(BigInteger arrangementId, Integer arrangementVersion);

	CancelArrangementResponse cancelArrangement(BigInteger arrangementId, Integer arrangementVersion);

	NextEventResponse nextEvent();

	void saveEvent(Event event);

	GetEventsResponse getEvents(List<BigInteger> eventIds);

}
