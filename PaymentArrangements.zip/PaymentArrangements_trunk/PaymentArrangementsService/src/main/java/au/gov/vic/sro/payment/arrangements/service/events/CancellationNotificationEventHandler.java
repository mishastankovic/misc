package au.gov.vic.sro.payment.arrangements.service.events;

import static au.gov.vic.sro.payment.arrangements.model.EventStatus.SUCCESSFUL;
import static au.gov.vic.sro.util.CollectionUtil.getFirst;
import static org.apache.commons.lang3.StringUtils.defaultIfBlank;
import static org.apache.commons.lang3.StringUtils.isBlank;

import java.text.MessageFormat;
import java.util.Date;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.log4j.Logger;

import au.gov.vic.sro.payment.arrangements.model.Arrangement;
import au.gov.vic.sro.payment.arrangements.model.CancelledReason;
import au.gov.vic.sro.payment.arrangements.model.Contact;
import au.gov.vic.sro.payment.arrangements.model.Event;
import au.gov.vic.sro.payment.arrangements.model.Liability;
import au.gov.vic.sro.payment.arrangements.model.RevenueLine;
import au.gov.vic.sro.payment.arrangements.util.DateUtil;

public class CancellationNotificationEventHandler extends NotificationEventHandler implements EventHandler {
	private static final Logger log = Logger.getLogger(CancellationNotificationEventHandler.class);
	private static final String USER_CANCELLATION_REASON =
			"Your automated instalment payments have been cancelled as requested online.";
	private static final String PAYMENT_NOT_RECEIVED_REASON =
			"This has occurred because a scheduled payment has not been received.";
	private static final String SEVENTEEN_WEEK_CUTOFF_DATE = "17WeekCutOffDate";
	private static final String ASSESSMENT_DUE_DATE = "AssessmentDueDate";
	private static final String ISSUE_DATE_PLUS_FORTYSIX_DAYS = "VLT_LastArrDays";

	private static final String TOTAL_OUTSTANDING_BALANCE_DESC_STR =
			"The total outstanding balance can be determined by referring to the total amount shown on your assessment notice and deducting any instalment payments already made.";
	
	private static final String CREATE_INSTALMENT_PAYMENT_STR ="You may be eligible to create new automated instalment payments.";	
	
	private static final String AUTOPAY_INSTALMENT_LOGIN_STR ="Login to <a href=\"http://www.sro.vic.gov.au/node/5828\">AutoPay Instalments</a> before %s and check your eligibility online.";
	
	private static final String OUTSTANDING_BALANCE_STR = "You will need to pay the total outstanding balance of the assessment by %s.";
	
	private static final String OUTSTANDING_BALANCE_PAY_NOW_STR = "You will need to pay the total outstanding balance immediately.";
	
	private static final String PAYMENT_OPTIONS_STR = "To make your payment, please access <a href=\"http://www.sro.vic.gov.au/node/1972\">assessment payment options.</a>";
	
	@Override
	public void handle(Event event) {
		Arrangement arrangement = getArrangement(event);
		Liability liability = getFirst(arrangement.getLiabilities());
		RevenueLine revenueLine = liability != null ? liability.getRevenueLine() : null;
		if(revenueLine == null)
			log.warn(String.format("No revenue line found. event=%s", event));
		
		CancelledReason cancelledReason = arrangement.getCancelledReason();
		Contact contact = getFirst(arrangement.getContacts());
		if (contact == null || isBlank(contact.getEmailAddress())) {
			log.warn(String.format("No contact email address found. event=%s", event));
		} else {
			String subject = getProperties().getProperty("email.cancellation.subject");
			String arrangementRef = String.format("%s-%s", arrangement.getId(), arrangement.getVersion());
			String body = MessageFormat.format(getEmailTemplate(), defaultIfBlank(contact.getPersonName(), "Customer"),
					getCancelledReason(cancelledReason), getWhatShouldIDoMessage(arrangement, event, revenueLine), arrangementRef,
					getProperties().getProperty("email.further.information"),
					getProperties().getProperty("email.sro.logo.link"),
					getProperties().getProperty("email.disclaimer"));
			sendEmail(getProperties().getProperty("email.from.name"), getProperties().getProperty("email.from.address"),
					contact.getEmailAddress(), subject, body);
		}
		event.setStatus(SUCCESSFUL);
	}
	
	private String getWhatShouldIDoMessage(Arrangement arrangement, Event event, RevenueLine revenueLine) {
		
		switch (revenueLine) {
		case LAND_TAX:
			return getWhatShouldIDoMessageForLTX(arrangement,event);
		case VACANT_LAND_TAX:
			return getWhatShouldIDoMessageForVLT(arrangement,event);
		default:
			return "";
		}
	}
	
	private String getWhatShouldIDoMessageForLTX(Arrangement arrangement, Event event) {
		String message = "";
		Date cancelledDate = arrangement.getCancelledDate();
		Date assessmentIssueDatePlusSeventeenWeeks = getDate(event, SEVENTEEN_WEEK_CUTOFF_DATE); 
		Date assessmentDueDate = getDate(event, ASSESSMENT_DUE_DATE); 
		
		if(cancelledDate == null)
			return "";

		if (assessmentIssueDatePlusSeventeenWeeks != null
				&& (DateUtil.isSameDay(cancelledDate, assessmentIssueDatePlusSeventeenWeeks)
						|| cancelledDate.before(assessmentIssueDatePlusSeventeenWeeks))) {
			return String.format(
					"<li>" + CREATE_INSTALMENT_PAYMENT_STR +"</li><li>" + AUTOPAY_INSTALMENT_LOGIN_STR + "</li>",
					DateFormatUtils.format(assessmentIssueDatePlusSeventeenWeeks, "dd/MMM/yyyy"));
		} else if (assessmentIssueDatePlusSeventeenWeeks != null && assessmentDueDate != null && DateUtil.isAfter(cancelledDate, assessmentIssueDatePlusSeventeenWeeks)
				&& (DateUtil.isSameDay(cancelledDate, assessmentDueDate)
						|| DateUtil.isBefore(cancelledDate, assessmentDueDate))) {
			message = String.format(
					"<li>" + OUTSTANDING_BALANCE_STR + "</li>",
					DateFormatUtils.format(assessmentDueDate, "dd/MMM/yyyy"));
			message += "<li>"+ TOTAL_OUTSTANDING_BALANCE_DESC_STR +"</li>"
					+ "<li>" + PAYMENT_OPTIONS_STR + "</li>";
		} else if (assessmentDueDate != null && DateUtil.isAfter(cancelledDate, assessmentDueDate)) {
			message = "<li>"+ OUTSTANDING_BALANCE_PAY_NOW_STR +"</li>"
					+ "<li>"+ TOTAL_OUTSTANDING_BALANCE_DESC_STR +"</li>"
					+ "<li>"+ PAYMENT_OPTIONS_STR + "</li>";
		}

		return message;
	}

	private String getWhatShouldIDoMessageForVLT(Arrangement arrangement, Event event) {
		Date cancelledDate = arrangement.getCancelledDate();
		Date assessmentIssueDatePlus46Days = getDate(event, ISSUE_DATE_PLUS_FORTYSIX_DAYS); 
		Date assessmentDueDate = getDate(event, ASSESSMENT_DUE_DATE);
		
		if(cancelledDate == null)
			return "";
		
		if (DateUtil.isSameDay(cancelledDate, assessmentIssueDatePlus46Days)
					|| cancelledDate.before(assessmentIssueDatePlus46Days)) {
			return String.format(
					"<li>" + CREATE_INSTALMENT_PAYMENT_STR + "</li><li>" + AUTOPAY_INSTALMENT_LOGIN_STR + "</li>",
					DateFormatUtils.format(assessmentIssueDatePlus46Days, "dd/MMM/yyyy"));
		} else if (assessmentDueDate != null && DateUtil.isAfter(cancelledDate, assessmentIssueDatePlus46Days)
				&& (DateUtil.isSameDay(cancelledDate, assessmentDueDate)
						|| DateUtil.isBefore(cancelledDate, assessmentDueDate))) {
			return String.format("<li>You will need to pay the outstanding balance by %s.</li>",
					DateFormatUtils.format(assessmentDueDate, "dd/MMM/yyyy"));
		} else if(assessmentDueDate != null && DateUtil.isAfter(cancelledDate, assessmentDueDate)) {
			return "<li>" + OUTSTANDING_BALANCE_PAY_NOW_STR + "</li>" 
					+ "<li>" + TOTAL_OUTSTANDING_BALANCE_DESC_STR+ "</li>" 
					+ "<li>" + PAYMENT_OPTIONS_STR + "</li>";		 
		}
		
		return "";
	}
	
	public String getCancelledReason(CancelledReason cancelledReason) {
		switch (cancelledReason) {
		case INTERNAL_USER:
		case EXTERNAL_USER: {
			return USER_CANCELLATION_REASON;
		}
		case PAYMENT_NOT_RECEIVED: {
			return PAYMENT_NOT_RECEIVED_REASON;
		}
		default:
			return "";
		}
	}
}
