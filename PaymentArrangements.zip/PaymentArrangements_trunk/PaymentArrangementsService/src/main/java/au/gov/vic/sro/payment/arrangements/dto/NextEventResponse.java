package au.gov.vic.sro.payment.arrangements.dto;

import static au.gov.vic.sro.builder.ToStringStyleFactory.getToStringStyle;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import au.gov.vic.sro.payment.arrangements.model.Event;

public class NextEventResponse implements Serializable {
	private static final long serialVersionUID = -8698613975910981144L;
	private Event event;

	public Event getEvent() {
		return event;
	}

	public void setEvent(Event event) {
		this.event = event == null || event.getId() == null ? null : event;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, getToStringStyle());
	}

}
