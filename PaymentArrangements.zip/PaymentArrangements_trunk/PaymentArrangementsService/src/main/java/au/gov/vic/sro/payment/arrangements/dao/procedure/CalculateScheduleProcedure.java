package au.gov.vic.sro.payment.arrangements.dao.procedure;

import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.IN_CUSTOMER_ID;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.IN_END_DATE;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.IN_FREQUENCY;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.IN_LIABILITY_ID;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.IN_LIABILITY_TYPE;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.IN_PAYMENT_METHOD;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.INOUT_REVENUE_LINE;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.IN_START_DATE;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.OUT_ALL_INSTALMENT_AMOUNT;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.OUT_ALL_INSTALMENT_SURCHARGE;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.OUT_ALL_INSTALMENT_TOTAL_AMOUNT;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.OUT_INSTALMENTS;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.OUT_MESSAGES;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.PACKAGE_PAYMENT_ARRANGEMENTS_SERVICES;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.PROCEDURE_CALCULATE_SCHEDULE;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.TYPE_INSTALMENTS;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.TYPE_MESSAGES;
import static au.gov.vic.sro.util.DateUtil.toSqlTimestamp;
import static java.sql.Types.ARRAY;
import static java.sql.Types.NUMERIC;
import static java.sql.Types.TIMESTAMP;
import static java.sql.Types.VARCHAR;
import static org.apache.commons.collections4.MapUtils.emptyIfNull;

import java.math.BigDecimal;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.data.jdbc.support.oracle.SqlReturnStructArray;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import au.gov.vic.sro.payment.arrangements.dao.mapper.InstalmentMapper;
import au.gov.vic.sro.payment.arrangements.dao.mapper.MessageMapper;
import au.gov.vic.sro.payment.arrangements.dto.CalculateScheduleResponse;
import au.gov.vic.sro.payment.arrangements.model.Instalment;
import au.gov.vic.sro.payment.arrangements.model.LiabilityType;
import au.gov.vic.sro.payment.arrangements.model.Message;
import au.gov.vic.sro.payment.arrangements.model.PaymentFrequency;
import au.gov.vic.sro.payment.arrangements.model.PaymentMethod;
import au.gov.vic.sro.payment.arrangements.model.RevenueLine;

public class CalculateScheduleProcedure extends StoredProcedure {

	public CalculateScheduleProcedure(JdbcTemplate jdbcTemplate) {
		super(jdbcTemplate, PACKAGE_PAYMENT_ARRANGEMENTS_SERVICES + "." + PROCEDURE_CALCULATE_SCHEDULE);
		declareParameter(new SqlParameter(IN_CUSTOMER_ID, VARCHAR));
		declareParameter(new SqlParameter(INOUT_REVENUE_LINE, VARCHAR));
		declareParameter(new SqlParameter(IN_LIABILITY_TYPE, VARCHAR));
		declareParameter(new SqlParameter(IN_LIABILITY_ID, VARCHAR));
		declareParameter(new SqlParameter(IN_START_DATE, TIMESTAMP));
		declareParameter(new SqlParameter(IN_END_DATE, TIMESTAMP));
		declareParameter(new SqlParameter(IN_FREQUENCY, VARCHAR));
		declareParameter(new SqlParameter(IN_PAYMENT_METHOD, VARCHAR));
		declareParameter(new SqlOutParameter(OUT_ALL_INSTALMENT_AMOUNT, NUMERIC));
		declareParameter(new SqlOutParameter(OUT_ALL_INSTALMENT_SURCHARGE, NUMERIC));
		declareParameter(new SqlOutParameter(OUT_ALL_INSTALMENT_TOTAL_AMOUNT, NUMERIC));
		declareParameter(new SqlOutParameter(OUT_INSTALMENTS, ARRAY, TYPE_INSTALMENTS,
				new SqlReturnStructArray<Instalment>(new InstalmentMapper())));
		declareParameter(new SqlOutParameter(OUT_MESSAGES, ARRAY, TYPE_MESSAGES, new SqlReturnStructArray<Message>(
				new MessageMapper())));
		compile();
	}

	public CalculateScheduleResponse execute(String customerId, RevenueLine revenueLine, LiabilityType liabilityType,
			String liabilityId, Date arrangementStartDate, Date arrangementEndDate, PaymentFrequency paymentFrequency,
			PaymentMethod paymentMethod) {
		Map<String, Object> in = new LinkedHashMap<String, Object>();
		in.put(IN_CUSTOMER_ID, customerId);
		in.put(INOUT_REVENUE_LINE, revenueLine == null ? null : revenueLine.getCode());
		in.put(IN_LIABILITY_TYPE, liabilityType == null ? null : liabilityType.getCode());
		in.put(IN_LIABILITY_ID, liabilityId);
		in.put(IN_START_DATE, toSqlTimestamp(arrangementStartDate));
		in.put(IN_END_DATE, toSqlTimestamp(arrangementEndDate));
		in.put(IN_FREQUENCY, paymentFrequency == null ? null : paymentFrequency.getCode());
		in.put(IN_PAYMENT_METHOD, paymentMethod == null ? null : paymentMethod.getCode());

		Map<String, Object> out = emptyIfNull(execute(in));

		CalculateScheduleResponse response = new CalculateScheduleResponse();
		response.setAllInstalmentAmountDollars((BigDecimal) out.get(OUT_ALL_INSTALMENT_AMOUNT));
		response.setAllInstalmentSurchargeDollars((BigDecimal) out.get(OUT_ALL_INSTALMENT_SURCHARGE));
		response.setAllInstalmentTotalAmountDollars((BigDecimal) out.get(OUT_ALL_INSTALMENT_TOTAL_AMOUNT));
		response.setInstalments((Object[]) out.get(OUT_INSTALMENTS));
		response.setMessages((Object[]) out.get(OUT_MESSAGES));
		return response;
	}

}
