package au.gov.vic.sro.payment.arrangements.dao.mapper;

import java.sql.CallableStatement;
import java.sql.SQLException;

import org.springframework.data.jdbc.support.oracle.SqlReturnArray;

import au.gov.vic.sro.payment.arrangements.model.PaymentFrequency;

public class PaymentFrequencyArrayReturnType extends SqlReturnArray {

	@Override
	public Object getTypeValue(CallableStatement cs, int paramIndex, int sqlType, String typeName) throws SQLException {
		Object[] codes = (Object[]) super.getTypeValue(cs, paramIndex, sqlType, typeName);
		if (codes == null) {
			return null;
		}
		Object[] paymentFrequencies = new Object[codes.length];
		for (int i = 0; i < codes.length; i++) {
			paymentFrequencies[i] = PaymentFrequency.fromCode((String) codes[i]);
		}
		return paymentFrequencies;
	}

}
