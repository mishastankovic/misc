package au.gov.vic.sro.payment.arrangements.dao.procedure;

import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.IN_EVENT_NOTIFICATION_IDS;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.OUT_RESULT;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.PACKAGE_PAYMENT_ARRANGEMENTS_EVENTS;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.PROCEDURE_GET_EVENTS;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.TYPE_EVENTS;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.TYPE_NUMBERS;
import static au.gov.vic.sro.util.NumberUtil.toBigDecimalArray;
import static java.sql.Types.ARRAY;
import static org.apache.commons.collections4.MapUtils.emptyIfNull;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.data.jdbc.support.oracle.SqlReturnStructArray;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import au.gov.vic.sro.payment.arrangements.dao.mapper.EventMapper;
import au.gov.vic.sro.payment.arrangements.dao.support.SqlArrayValue;
import au.gov.vic.sro.payment.arrangements.dto.GetEventsResponse;
import au.gov.vic.sro.payment.arrangements.model.Event;

public class GetEventsProcedure extends StoredProcedure {

	public GetEventsProcedure(JdbcTemplate jdbcTemplate) {
		super(jdbcTemplate, PACKAGE_PAYMENT_ARRANGEMENTS_EVENTS + "." + PROCEDURE_GET_EVENTS);
		declareParameter(new SqlOutParameter(OUT_RESULT, ARRAY, TYPE_EVENTS, new SqlReturnStructArray<Event>(
				new EventMapper())));
		declareParameter(new SqlParameter(IN_EVENT_NOTIFICATION_IDS, ARRAY, TYPE_NUMBERS));
		setFunction(true);
		compile();
	}

	public GetEventsResponse execute(List<BigInteger> eventIds) {
		Map<String, Object> in = new LinkedHashMap<String, Object>();
		in.put(IN_EVENT_NOTIFICATION_IDS, new SqlArrayValue<BigDecimal>(toBigDecimalArray(eventIds, true)));

		Map<String, Object> out = emptyIfNull(execute(in));

		GetEventsResponse response = new GetEventsResponse();
		response.setEvents((Object[]) out.get(OUT_RESULT));
		return response;
	}

}
