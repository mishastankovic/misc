package au.gov.vic.sro.payment.arrangements.dao.support;

import static au.gov.vic.sro.payment.arrangements.dao.support.OracleUtil.unwrap;

import java.sql.Connection;
import java.sql.SQLException;

import org.springframework.jdbc.support.nativejdbc.NativeJdbcExtractorAdapter;

public class WebSphereNativeJdbcExtractor extends NativeJdbcExtractorAdapter {

	/**
	 * Return {@code true}, as WebSphere returns wrapped Statements.
	 */
	@Override
	public boolean isNativeConnectionNecessaryForNativeStatements() {
		return true;
	}

	/**
	 * Return {@code true}, as WebSphere returns wrapped PreparedStatements.
	 */
	@Override
	public boolean isNativeConnectionNecessaryForNativePreparedStatements() {
		return true;
	}

	/**
	 * Return {@code true}, as WebSphere returns wrapped CallableStatements.
	 */
	@Override
	public boolean isNativeConnectionNecessaryForNativeCallableStatements() {
		return true;
	}

	/**
	 * Use JDBC 4.0 wrapper pattern to return the JDBC native connection.
	 *
	 * @see <a href="http://www-01.ibm.com/support/docview.wss?uid=swg21577331">WebSphere Application Server and the
	 *      JDBC 4.0 Wrapper Pattern</a>
	 */
	@Override
	protected Connection doGetNativeConnection(Connection connection) throws SQLException {
		return unwrap(connection);
	}

}
