package au.gov.vic.sro.payment.arrangements.dto;

import static au.gov.vic.sro.builder.ToStringStyleFactory.getToStringStyle;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import au.gov.vic.sro.payment.arrangements.model.Instalment;

public class CalculateScheduleResponse extends MessageResponse implements Serializable {
	private static final long serialVersionUID = 3782352505763664155L;
	private BigDecimal allInstalmentAmountDollars;
	private BigDecimal allInstalmentSurchargeDollars;
	private BigDecimal allInstalmentTotalAmountDollars;
	private List<Instalment> instalments = new ArrayList<Instalment>();

	public BigDecimal getAllInstalmentAmountDollars() {
		return allInstalmentAmountDollars;
	}

	public void setAllInstalmentAmountDollars(BigDecimal allInstalmentAmountDollars) {
		this.allInstalmentAmountDollars = allInstalmentAmountDollars;
	}

	public BigDecimal getAllInstalmentSurchargeDollars() {
		return allInstalmentSurchargeDollars;
	}

	public void setAllInstalmentSurchargeDollars(BigDecimal allInstalmentSurchargeDollars) {
		this.allInstalmentSurchargeDollars = allInstalmentSurchargeDollars;
	}

	public BigDecimal getAllInstalmentTotalAmountDollars() {
		return allInstalmentTotalAmountDollars;
	}

	public void setAllInstalmentTotalAmountDollars(BigDecimal allInstalmentTotalAmountDollars) {
		this.allInstalmentTotalAmountDollars = allInstalmentTotalAmountDollars;
	}

	public List<Instalment> getInstalments() {
		return instalments;
	}

	public void setInstalments(List<Instalment> instalments) {
		this.instalments.clear();
		if (CollectionUtils.isNotEmpty(instalments)) {
			this.instalments.addAll(instalments);
		}
	}

	public void setInstalments(Object[] instalments) {
		this.instalments.clear();
		if (ArrayUtils.isNotEmpty(instalments)) {
			for (Object instalment : instalments) {
				this.instalments.add((Instalment) instalment);
			}
		}
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, getToStringStyle());
	}

}
