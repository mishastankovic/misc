package au.gov.vic.sro.payment.arrangements.service;

import static au.gov.vic.sro.payment.arrangements.model.LiabilityType.ASSESSMENT;
import static au.gov.vic.sro.payment.arrangements.model.RevenueLine.LAND_TAX;
import static au.gov.vic.sro.payment.arrangements.model.RevenueLine.VACANT_LAND_TAX;
import static au.gov.vic.sro.util.CollectionUtil.addAllIgnoreNull;

import java.io.Serializable;
import java.util.Collection;
import java.util.Comparator;
import java.util.TreeSet;
import java.util.regex.Pattern;

import org.apache.commons.lang3.builder.CompareToBuilder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import au.gov.vic.sro.payment.arrangements.model.LiabilityType;
import au.gov.vic.sro.payment.arrangements.model.RevenueLine;

public class UserDetailsImpl implements UserDetails {
	private static final long serialVersionUID = 5841049724756750926L;
	private static final Pattern LAND_TAX_ASSESSMENT_ID_PREFIX = Pattern.compile("^[\\D]+");

	private static class GrantedAuthorityComparator implements Comparator<GrantedAuthority>, Serializable {
		private static final long serialVersionUID = -5143474708569562054L;

		@Override
		public int compare(GrantedAuthority authority1, GrantedAuthority authority2) {
			return new CompareToBuilder().append(authority1.getAuthority(), authority2.getAuthority()).toComparison();
		}
	}

	private Collection<GrantedAuthority> authorities = new TreeSet<GrantedAuthority>(new GrantedAuthorityComparator());
	private String password;
	private String username;
	private boolean accountNonExpired = true;
	private boolean accountNonLocked = true;
	private boolean credentialsNonExpired = true;
	private boolean enabled = true;
	private String customerId;
	private RevenueLine revenueLine;
	private LiabilityType liabilityType;
	private String liabilityId;

	public UserDetailsImpl() {
	}

	@Override
	public Collection<GrantedAuthority> getAuthorities() {
		return authorities;
	}

	public void setAuthorities(Collection<GrantedAuthority> authorities) {
		this.authorities.clear();
		addAllIgnoreNull(this.authorities, authorities);
	}

	@Override
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	@Override
	public boolean isAccountNonExpired() {
		return accountNonExpired;
	}

	public void setAccountNonExpired(boolean accountNonExpired) {
		this.accountNonExpired = accountNonExpired;
	}

	@Override
	public boolean isAccountNonLocked() {
		return accountNonLocked;
	}

	public void setAccountNonLocked(boolean accountNonLocked) {
		this.accountNonLocked = accountNonLocked;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		return credentialsNonExpired;
	}

	public void setCredentialsNonExpired(boolean credentialsNonExpired) {
		this.credentialsNonExpired = credentialsNonExpired;
	}

	@Override
	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public RevenueLine getRevenueLine() {
		return revenueLine;
	}

	public void setRevenueLine(RevenueLine revenueLine) {
		this.revenueLine = revenueLine;
	}

	public LiabilityType getLiabilityType() {
		return liabilityType;
	}

	public void setLiabilityType(LiabilityType liabilityType) {
		this.liabilityType = liabilityType;
	}

	public String getLiabilityId() {
		return liabilityId;
	}

	public String getNormalizedLiabilityId() {
		if (liabilityId != null && (LAND_TAX == revenueLine || VACANT_LAND_TAX == revenueLine) && ASSESSMENT == liabilityType) {
			return LAND_TAX_ASSESSMENT_ID_PREFIX.matcher(liabilityId).replaceFirst("");
		}
		return liabilityId;
	}

	public void setLiabilityId(String liabilityId) {
		this.liabilityId = liabilityId;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		UserDetailsImpl other = (UserDetailsImpl) obj;
		return new EqualsBuilder().append(customerId, other.customerId).append(revenueLine, other.revenueLine)
				.append(liabilityType, other.liabilityType)
				.append(getNormalizedLiabilityId(), other.getNormalizedLiabilityId()).isEquals();
	}

	@Override
	public int hashCode() {
		return new HashCodeBuilder(1, 31).append(customerId).append(revenueLine).append(liabilityType)
				.append(getNormalizedLiabilityId()).toHashCode();
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}

}
