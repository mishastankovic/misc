package au.gov.vic.sro.payment.arrangements.service.events;

import au.gov.vic.sro.payment.arrangements.model.Event;

public interface EventHandler {

	void handle(Event event);

}
