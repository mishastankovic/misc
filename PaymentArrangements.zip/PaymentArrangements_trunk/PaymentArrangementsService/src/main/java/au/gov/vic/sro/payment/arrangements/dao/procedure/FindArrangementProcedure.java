package au.gov.vic.sro.payment.arrangements.dao.procedure;

import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.IN_CUSTOMER_ID;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.IN_LIABILITY_ID;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.IN_LIABILITY_TYPE;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.INOUT_REVENUE_LINE;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.OUT_CHECKSUM;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.OUT_CONTACTS;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.OUT_INSTALMENTS;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.OUT_LIABILITIES;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.OUT_MESSAGES;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.OUT_PAYMENT_ARRANGEMENT;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.PACKAGE_PAYMENT_ARRANGEMENTS_SERVICES;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.PROCEDURE_FIND_ARRANGEMENT;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.TYPE_CONTACTS;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.TYPE_INSTALMENTS;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.TYPE_LIABILITIES;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.TYPE_MESSAGES;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.TYPE_PAYMENT_ARRANGEMENT;
import static java.sql.Types.ARRAY;
import static java.sql.Types.STRUCT;
import static java.sql.Types.VARCHAR;
import static org.apache.commons.collections4.MapUtils.emptyIfNull;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.data.jdbc.support.oracle.SqlReturnStruct;
import org.springframework.data.jdbc.support.oracle.SqlReturnStructArray;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import au.gov.vic.sro.payment.arrangements.dao.mapper.ArrangementMapper;
import au.gov.vic.sro.payment.arrangements.dao.mapper.ContactMapper;
import au.gov.vic.sro.payment.arrangements.dao.mapper.InstalmentMapper;
import au.gov.vic.sro.payment.arrangements.dao.mapper.LiabilityMapper;
import au.gov.vic.sro.payment.arrangements.dao.mapper.MessageMapper;
import au.gov.vic.sro.payment.arrangements.dto.FindArrangementResponse;
import au.gov.vic.sro.payment.arrangements.model.Arrangement;
import au.gov.vic.sro.payment.arrangements.model.Contact;
import au.gov.vic.sro.payment.arrangements.model.Instalment;
import au.gov.vic.sro.payment.arrangements.model.Liability;
import au.gov.vic.sro.payment.arrangements.model.LiabilityType;
import au.gov.vic.sro.payment.arrangements.model.Message;
import au.gov.vic.sro.payment.arrangements.model.RevenueLine;

public class FindArrangementProcedure extends StoredProcedure {

	public FindArrangementProcedure(JdbcTemplate jdbcTemplate) {
		super(jdbcTemplate, PACKAGE_PAYMENT_ARRANGEMENTS_SERVICES + "." + PROCEDURE_FIND_ARRANGEMENT);
		declareParameter(new SqlParameter(IN_CUSTOMER_ID, VARCHAR));
		declareParameter(new SqlParameter(INOUT_REVENUE_LINE, VARCHAR));
		declareParameter(new SqlParameter(IN_LIABILITY_TYPE, VARCHAR));
		declareParameter(new SqlParameter(IN_LIABILITY_ID, VARCHAR));
		declareParameter(new SqlOutParameter(OUT_PAYMENT_ARRANGEMENT, STRUCT, TYPE_PAYMENT_ARRANGEMENT,
				new SqlReturnStruct(new ArrangementMapper())));
		declareParameter(new SqlOutParameter(OUT_LIABILITIES, ARRAY, TYPE_LIABILITIES,
				new SqlReturnStructArray<Liability>(new LiabilityMapper())));
		declareParameter(new SqlOutParameter(OUT_INSTALMENTS, ARRAY, TYPE_INSTALMENTS,
				new SqlReturnStructArray<Instalment>(new InstalmentMapper())));
		declareParameter(new SqlOutParameter(OUT_CONTACTS, ARRAY, TYPE_CONTACTS,
				new SqlReturnStructArray<Contact>(new ContactMapper())));
		declareParameter(new SqlOutParameter(OUT_MESSAGES, ARRAY, TYPE_MESSAGES,
				new SqlReturnStructArray<Message>(new MessageMapper())));
		declareParameter(new SqlOutParameter(OUT_CHECKSUM, VARCHAR));
		compile();
	}

	public FindArrangementResponse execute(String customerId, RevenueLine revenueLine, LiabilityType liabilityType,
			String liabilityId) {
		Map<String, Object> in = new LinkedHashMap<String, Object>();
		in.put(IN_CUSTOMER_ID, customerId);
		in.put(INOUT_REVENUE_LINE, revenueLine == null ? null : revenueLine.getCode());
		in.put(IN_LIABILITY_TYPE, liabilityType == null ? null : liabilityType.getCode());
		in.put(IN_LIABILITY_ID, liabilityId);

		Map<String, Object> out = emptyIfNull(execute(in));

		FindArrangementResponse response = new FindArrangementResponse();
		Arrangement arrangement = (Arrangement) out.get(OUT_PAYMENT_ARRANGEMENT);
		if (arrangement == null) {
			arrangement = new Arrangement();
		}
		arrangement.setCustomerId(customerId);
		arrangement.setLiabilities((Object[]) out.get(OUT_LIABILITIES));
		arrangement.setInstalments((Object[]) out.get(OUT_INSTALMENTS));
		arrangement.setContacts((Object[]) out.get(OUT_CONTACTS));
		arrangement.setChecksum((String) out.get(OUT_CHECKSUM));
		response.setArrangement(arrangement);
		response.setMessages((Object[]) out.get(OUT_MESSAGES));
		return response;
	}

}
