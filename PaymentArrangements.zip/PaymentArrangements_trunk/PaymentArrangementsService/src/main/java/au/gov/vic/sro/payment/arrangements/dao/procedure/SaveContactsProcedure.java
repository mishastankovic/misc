package au.gov.vic.sro.payment.arrangements.dao.procedure;

import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.IN_CONTACTS;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.IN_OUT_CHECKSUM;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.OUT_MESSAGES;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.OUT_UPDATE;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.PACKAGE_PAYMENT_ARRANGEMENTS_SERVICES;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.PROCEDURE_SAVE_CONTACTS;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.TYPE_CONTACT;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.TYPE_CONTACTS;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.TYPE_MESSAGES;
import static java.sql.Types.ARRAY;
import static java.sql.Types.VARCHAR;
import static org.apache.commons.collections4.MapUtils.emptyIfNull;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.data.jdbc.support.oracle.SqlReturnStructArray;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlInOutParameter;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import au.gov.vic.sro.payment.arrangements.dao.mapper.BooleanReturnType;
import au.gov.vic.sro.payment.arrangements.dao.mapper.ContactMapper;
import au.gov.vic.sro.payment.arrangements.dao.mapper.MessageMapper;
import au.gov.vic.sro.payment.arrangements.dao.support.SqlStructArrayValue;
import au.gov.vic.sro.payment.arrangements.dto.SaveContactsResponse;
import au.gov.vic.sro.payment.arrangements.model.Contact;
import au.gov.vic.sro.payment.arrangements.model.Message;

public class SaveContactsProcedure extends StoredProcedure {

	public SaveContactsProcedure(JdbcTemplate jdbcTemplate) {
		super(jdbcTemplate, PACKAGE_PAYMENT_ARRANGEMENTS_SERVICES + "." + PROCEDURE_SAVE_CONTACTS);
		declareParameter(new SqlParameter(IN_CONTACTS, ARRAY, TYPE_CONTACTS));
		declareParameter(new SqlOutParameter(OUT_UPDATE, VARCHAR, null, new BooleanReturnType()));
		declareParameter(new SqlOutParameter(OUT_MESSAGES, ARRAY, TYPE_MESSAGES,
				new SqlReturnStructArray<Message>(new MessageMapper())));
		declareParameter(new SqlInOutParameter(IN_OUT_CHECKSUM, VARCHAR));

		compile();
	}

	public SaveContactsResponse execute(List<Contact> contacts, String checksum) {
		Map<String, Object> in = new LinkedHashMap<String, Object>();
		in.put(IN_CONTACTS,
				new SqlStructArrayValue<Contact>(Contact.toArray(contacts, true), new ContactMapper(), TYPE_CONTACT));
		in.put(IN_OUT_CHECKSUM, checksum);

		Map<String, Object> out = emptyIfNull(execute(in));

		SaveContactsResponse response = new SaveContactsResponse();
		response.setSaved((Boolean) out.get(OUT_UPDATE));
		response.setChecksum((String) out.get(IN_OUT_CHECKSUM));
		response.setMessages((Object[]) out.get(OUT_MESSAGES));
		return response;
	}

}
