package au.gov.vic.sro.payment.arrangements.dao.mapper;

import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.TYPE_CONTACT;
import static au.gov.vic.sro.payment.arrangements.dao.support.OracleUtil.createStruct;
import static au.gov.vic.sro.payment.arrangements.dao.support.OracleUtil.getValues;
import static au.gov.vic.sro.util.NumberUtil.toBigDecimal;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.regex.Pattern;

import org.springframework.data.jdbc.support.oracle.StructMapper;

import au.gov.vic.sro.payment.arrangements.model.Arrangement;
import au.gov.vic.sro.payment.arrangements.model.Contact;
import au.gov.vic.sro.payment.arrangements.model.ContactType;
import oracle.sql.STRUCT;

public class ContactMapper implements StructMapper<Contact> {

	private enum RecField {
		PAO_CONTACT_TYPE,
		PAYMENT_ARRANGEMENT_ID,
		PAYMENT_ARRANGEMENT_VERSION,
		FREE_FORMAT_NAME_TEXT,
		EMAIL_ADDRESS,
		MOBILE_PHONE_NUMBER,
		PAYMENT_REMINDER_IND;
	}

	private static final Pattern TYPE_NAME_PATTERN = Pattern.compile("(.+\\.)*" + TYPE_CONTACT);
	private static final int TYPE_LENGTH = RecField.values().length;

	@Override
	public STRUCT toStruct(Contact source, Connection connection, String typeName) throws SQLException {
		return createStruct(typeName, connection, toRec(source));
	}

	protected Object[] toRec(Contact source) {
		if (source == null) {
			throw new IllegalArgumentException(String.format("source=%s", source));
		}
		Object[] rec = new Object[TYPE_LENGTH];
		rec[RecField.PAO_CONTACT_TYPE.ordinal()] = ContactType.toCode(source.getType());
		rec[RecField.FREE_FORMAT_NAME_TEXT.ordinal()] = source.getPersonName();
		rec[RecField.EMAIL_ADDRESS.ordinal()] = source.getEmailAddress();
		rec[RecField.MOBILE_PHONE_NUMBER.ordinal()] = source.getMobilePhone();
		rec[RecField.PAYMENT_REMINDER_IND.ordinal()] = source.getReminderEmails();
		Arrangement arrangement = source.getArrangement();
		if (arrangement != null) {
			rec[RecField.PAYMENT_ARRANGEMENT_ID.ordinal()] = toBigDecimal(arrangement.getId());
			rec[RecField.PAYMENT_ARRANGEMENT_VERSION.ordinal()] = toBigDecimal(arrangement.getVersion());
		}
		return rec;
	}

	@Override
	public Contact fromStruct(STRUCT struct) throws SQLException {
		Object[] rec = getValues(struct, TYPE_NAME_PATTERN, TYPE_LENGTH);
		Contact target = new Contact();
		target.setType(ContactType.fromCode((String) rec[RecField.PAO_CONTACT_TYPE.ordinal()]));
		target.setPersonName((String) rec[RecField.FREE_FORMAT_NAME_TEXT.ordinal()]);
		target.setEmailAddress((String) rec[RecField.EMAIL_ADDRESS.ordinal()]);
		target.setMobilePhone((String) rec[RecField.MOBILE_PHONE_NUMBER.ordinal()]);
		target.setReminderEmails((String) rec[RecField.PAYMENT_REMINDER_IND.ordinal()]);
		return target;
	}

}
