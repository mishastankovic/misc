package au.gov.vic.sro.payment.arrangements.service.events;

import static au.gov.vic.sro.payment.arrangements.model.EventStatus.SUCCESSFUL;
import static au.gov.vic.sro.util.CollectionUtil.getFirst;
import static org.apache.commons.lang3.StringUtils.defaultIfBlank;
import static org.apache.commons.lang3.StringUtils.isBlank;

import java.text.MessageFormat;

import org.apache.log4j.Logger;

import au.gov.vic.sro.payment.arrangements.model.Arrangement;
import au.gov.vic.sro.payment.arrangements.model.CancelledReason;
import au.gov.vic.sro.payment.arrangements.model.Contact;
import au.gov.vic.sro.payment.arrangements.model.Event;

public class WithdrawnNotificationEventHandler extends NotificationEventHandler implements EventHandler {
	private static final Logger log = Logger.getLogger(CancellationNotificationEventHandler.class);

	@Override
	public void handle(Event event) {
		Arrangement arrangement = getArrangement(event);
		CancelledReason cancelledReason = arrangement.getCancelledReason();
		Contact contact = getFirst(arrangement.getContacts());
		if (contact == null || isBlank(contact.getEmailAddress())) {
			log.warn(String.format("No contact email address found. event=%s", event));
		} else {
			String subject = getProperties().getProperty("email.cancellation.subject");
			String arrangementRef = String.format("%s-%s", arrangement.getId(), arrangement.getVersion());
			String body = MessageFormat.format(getEmailTemplate(), defaultIfBlank(contact.getPersonName(), "Customer"),
					arrangementRef, getProperties().getProperty("email.further.information"),
					getProperties().getProperty("email.sro.logo.link"),
					getProperties().getProperty("email.disclaimer"));
			sendEmail(getProperties().getProperty("email.from.name"), getProperties().getProperty("email.from.address"),
					contact.getEmailAddress(), subject, body);
		}
		event.setStatus(SUCCESSFUL);
	}

	public String getCancelledReason(CancelledReason cancelledReason) {
		String paoUrl = getProperties().getProperty("pao.url");
		switch (cancelledReason) {
		case ASSESSMENT_WITHDRAWN: {
			return " because the assessment has been withdrawn due to your liability being changed or removed.<br/><br/>If your liability has changed, a reassessment could be issued and you may <a href=\""
					+ paoUrl + "\" target=\"_blank\">create a new payment arrangement</a>";
		}
		case ESYS_SYSTEM: {
			return " because the assessment has been withdrawn due to your liability being changed or removed.<br/><br/>If your liability has changed, a reassessment could be issued and you may <a href=\""
					+ paoUrl + "\" target=\"_blank\">create a new payment arrangement</a>";
		}
		case LIABILITY_RECALCULATED: {
			return " because the assessment has been withdrawn due to your liability being changed or removed.<br/><br/>If your liability has changed, a reassessment could be issued and you may <a href=\""
					+ paoUrl + "\" target=\"_blank\">create a new payment arrangement</a>";
		}
		default:
			return "";
		}
	}
}
