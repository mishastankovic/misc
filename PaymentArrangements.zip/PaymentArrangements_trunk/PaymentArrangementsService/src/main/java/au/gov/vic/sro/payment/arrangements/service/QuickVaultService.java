package au.gov.vic.sro.payment.arrangements.service;

import java.io.IOException;
import java.math.BigInteger;
import java.util.Map;

import org.apache.http.client.ClientProtocolException;

import au.gov.vic.sro.payment.arrangements.dto.SaveAccountRequest;
import au.gov.vic.sro.payment.arrangements.model.PaymentMethod;
import au.gov.vic.sro.payment.arrangements.model.RevenueLine;

public interface QuickVaultService {

	String getSecurityToken(String customerId, BigInteger arrangementId, Integer arrangementVersion,
			RevenueLine revenueLine, PaymentMethod paymentMethod, String checksum)
			throws ClientProtocolException, IOException;

	String getBrowserRedirectUrl(String securityToken);

	SaveAccountRequest getSaveAccountRequest(Map<String, String[]> parameters);

}