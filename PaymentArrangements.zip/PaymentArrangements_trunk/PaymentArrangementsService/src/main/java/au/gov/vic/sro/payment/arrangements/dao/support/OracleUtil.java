package au.gov.vic.sro.payment.arrangements.dao.support;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import oracle.sql.STRUCT;
import oracle.sql.StructDescriptor;

public final class OracleUtil {
	private static final Logger log = Logger.getLogger(OracleUtil.class);

	private OracleUtil() {
		// No instance.
	}

	/**
	 * Use JDBC 4.0 wrapper pattern to return the JDBC native connection.
	 */
	public static Connection unwrap(Connection connection) throws SQLException {
		if (log.isTraceEnabled()) {
			log.trace(String.format("connection=%s", connection));
		}
		if (connection != null && connection.isWrapperFor(oracle.jdbc.OracleConnection.class)) {
			return connection.unwrap(oracle.jdbc.OracleConnection.class);
		}
		return connection;
	}

	public static STRUCT createStruct(String typeName, Connection connection, Object[] values) throws SQLException {
		if (StringUtils.isBlank(typeName) || connection == null) {
			throw new IllegalArgumentException(String.format("typeName=%s, connection=%s", typeName, connection));
		}
		Connection conn = unwrap(connection);
		return new STRUCT(StructDescriptor.createDescriptor(typeName, conn), conn, values);
	}

	public static Object[] getValues(STRUCT struct, Pattern expectedTypeName, int expectedTypeLength)
			throws SQLException {
		if (struct == null || expectedTypeName == null || expectedTypeLength < 0) {
			throw new IllegalArgumentException(String.format("struct=[%s], expectedTypeName=%s, expectedTypeLength=%s",
					struct == null ? null : struct.debugString(), expectedTypeName, expectedTypeLength));
		}
		if (!expectedTypeName.matcher(struct.getSQLTypeName()).matches()) {
			throw new IllegalArgumentException(String.format(
					"Unexpected type name. struct=[%s], expectedTypeName=%s, expectedTypeLength=%s",
					struct.debugString(), expectedTypeName, expectedTypeLength));
		}
		Object[] values = struct.getAttributes();
		if (values == null || values.length != expectedTypeLength) {
			throw new IllegalArgumentException(String.format(
					"Unexpected type length. struct=[%s], expectedTypeName=%s, expectedTypeLength=%s",
					struct.debugString(), expectedTypeName, expectedTypeLength));
		}
		return values;
	}

}
