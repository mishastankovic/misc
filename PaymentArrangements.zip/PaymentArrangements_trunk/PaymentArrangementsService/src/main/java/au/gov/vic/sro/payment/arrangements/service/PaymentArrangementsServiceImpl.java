package au.gov.vic.sro.payment.arrangements.service;

import java.math.BigInteger;
import java.util.Date;
import java.util.List;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDao;
import au.gov.vic.sro.payment.arrangements.dto.CalculateScheduleResponse;
import au.gov.vic.sro.payment.arrangements.dto.CancelArrangementResponse;
import au.gov.vic.sro.payment.arrangements.dto.FindArrangementResponse;
import au.gov.vic.sro.payment.arrangements.dto.GetConfirmCancelTextResponse;
import au.gov.vic.sro.payment.arrangements.dto.GetDefaultDatesResponse;
import au.gov.vic.sro.payment.arrangements.dto.GetEventsResponse;
import au.gov.vic.sro.payment.arrangements.dto.GetFrequenciesResponse;
import au.gov.vic.sro.payment.arrangements.dto.NextEventResponse;
import au.gov.vic.sro.payment.arrangements.dto.SaveAccountRequest;
import au.gov.vic.sro.payment.arrangements.dto.SaveAccountResponse;
import au.gov.vic.sro.payment.arrangements.dto.SaveArrangementResponse;
import au.gov.vic.sro.payment.arrangements.dto.SaveContactsResponse;
import au.gov.vic.sro.payment.arrangements.model.Arrangement;
import au.gov.vic.sro.payment.arrangements.model.Contact;
import au.gov.vic.sro.payment.arrangements.model.Event;
import au.gov.vic.sro.payment.arrangements.model.LiabilityType;
import au.gov.vic.sro.payment.arrangements.model.PaymentFrequency;
import au.gov.vic.sro.payment.arrangements.model.PaymentMethod;
import au.gov.vic.sro.payment.arrangements.model.RevenueLine;

@Transactional(value = "transactionManager", propagation = Propagation.REQUIRED, readOnly = true)
public class PaymentArrangementsServiceImpl implements PaymentArrangementsService {
	private PaymentArrangementsDao paymentArrangementsDao;

	@Override
	public FindArrangementResponse findArrangement(String customerId, RevenueLine revenueLine,
			LiabilityType liabilityType, String liabilityId) {
		return getPaymentArrangementsDao().findArrangement(customerId, revenueLine, liabilityType, liabilityId);
	}

	@Override
	public FindArrangementResponse findArrangement(BigInteger arrangementId, Integer arrangementVersion) {
		return getPaymentArrangementsDao().findNotificationArrangement(arrangementId, arrangementVersion);
	}

	@Override
	public GetDefaultDatesResponse getDefaultDates(String customerId, RevenueLine revenueLine,
			LiabilityType liabilityType, String liabilityId) {
		return getPaymentArrangementsDao().getDefaultDates(customerId, revenueLine, liabilityType, liabilityId);
	}

	@Override
	public GetFrequenciesResponse getFrequencies(String customerId, RevenueLine revenueLine,
			LiabilityType liabilityType, String liabilityId, Date arrangementStartDate, Date arrangementEndDate) {
		return getPaymentArrangementsDao().getFrequencies(customerId, revenueLine, liabilityType, liabilityId,
				arrangementStartDate, arrangementEndDate);
	}

	@Override
	public CalculateScheduleResponse calculateSchedule(String customerId, RevenueLine revenueLine,
			LiabilityType liabilityType, String liabilityId, Date arrangementStartDate, Date arrangementEndDate,
			PaymentFrequency paymentFrequency, PaymentMethod paymentMethod) {
		return getPaymentArrangementsDao().calculateSchedule(customerId, revenueLine, liabilityType, liabilityId,
				arrangementStartDate, arrangementEndDate, paymentFrequency, paymentMethod);
	}

	@Override
	@Transactional(readOnly = false)
	public SaveArrangementResponse saveArrangement(Arrangement arrangement) {
		return getPaymentArrangementsDao().saveArrangement(arrangement);
	}

	@Override
	@Transactional(readOnly = false)
	public SaveAccountResponse saveAccount(SaveAccountRequest request) {
		return getPaymentArrangementsDao().saveAccount(request);
	}

	@Override
	@Transactional(readOnly = false)
	public SaveContactsResponse saveContacts(List<Contact> contacts, String checksum) {
		return getPaymentArrangementsDao().saveContacts(contacts, checksum);
	}

	@Override
	public GetConfirmCancelTextResponse getConfirmCancelText(BigInteger arrangementId, Integer arrangementVersion) {
		return getPaymentArrangementsDao().getConfirmCancelText(arrangementId, arrangementVersion);
	}

	@Override
	@Transactional(readOnly = false)
	public CancelArrangementResponse cancelArrangement(BigInteger arrangementId, Integer arrangementVersion) {
		return getPaymentArrangementsDao().cancelArrangement(arrangementId, arrangementVersion);
	}

	@Override
	@Transactional(readOnly = false)
	public NextEventResponse nextEvent() {
		return getPaymentArrangementsDao().nextEvent();
	}

	@Override
	@Transactional(readOnly = false)
	public void saveEvent(Event event) {
		getPaymentArrangementsDao().saveEvent(event);
	}

	@Override
	public GetEventsResponse getEvents(List<BigInteger> eventIds) {
		return getPaymentArrangementsDao().getEvents(eventIds);
	}

	public PaymentArrangementsDao getPaymentArrangementsDao() {
		return paymentArrangementsDao;
	}

	public void setPaymentArrangementsDao(PaymentArrangementsDao paymentArrangementsDao) {
		this.paymentArrangementsDao = paymentArrangementsDao;
	}

}
