package au.gov.vic.sro.payment.arrangements.dao;

public final class PaymentArrangementsDaoConstants {

	public static final String IN_ACCOUNT_TOKEN = "PCI_PAYMENT_TOKEN";
	public static final String IN_ARRANGEMENT_ID = "PNI_PAYMENT_ARRANGEMENT_ID";
	public static final String IN_ARRANGEMENT_VERSION = "PNI_PAYMENT_ARRANGEMENT_VER";
	public static final String IN_BANK_ACCOUNT_BSB = "PCI_BSB_NUMBER";
	public static final String IN_BANK_ACCOUNT_NUMBER = "PCI_DIRECT_DEBIT_ACCOUNT_NO";
	public static final String IN_CARD_EXPIRY_MONTH = "PCI_CREDIT_CARD_EXPIRY_MONTH";
	public static final String IN_CARD_EXPIRY_YEAR = "PCI_CREDIT_CARD_EXPIRY_YEAR";
	public static final String IN_CARD_NUMBER = "PCI_CREDIT_CARD_NUMBER";
	public static final String IN_CONTACTS = "PTI_PAO_CUSTOMER_CONTACT_TAB";
	public static final String IN_CUSTOMER_ID = "PCI_CUSTOMER_ID";
	public static final String INOUT_CUSTOMER_ID = "PCI_CUSTOMER_ID";
	public static final String IN_END_DATE = "PDI_END_DATE";
	public static final String IN_EVENT_ID = "PNI_PAO_EVENT_NOTIFICATION_ID";
	public static final String IN_EVENT_NOTIFICATION_IDS = "PTI_EVENT_NOTIFICATION_ID_TAB";
	public static final String IN_FREQUENCY = "PCI_PAYMENT_FREQUENCY";
	public static final String IN_INSTALMENTS = "PTI_PYMNT_ARR_INSTLMNT_TAB";
	public static final String IN_LIABILITIES = "PTI_LIABILITY_TAB";
	public static final String IN_LIABILITY_ID = "PCI_LIABILITY_REFERENCE_ID";
	public static final String IN_LIABILITY_TYPE = "PCI_LIABILITY_REFERENCE_TYPE";
	public static final String IN_PAYMENT_ARRANGEMENT = "PTI_PYMNT_ARRANGEMENT_REC";
	public static final String IN_PAYMENT_METHOD = "PCI_PAYMENT_METHOD";
	public static final String INOUT_REVENUE_LINE = "PCI_REVENUE_TYPE";
	public static final String IN_START_DATE = "PDI_START_DATE";
	public static final String IN_STATUS = "PCI_STATUS";
	public static final String IN_DATE_TYPE = "PCI_TYPE";
	public static final String OUT_ALL_INSTALMENT_AMOUNT = "PNO_ARRANGEMENT_AMOUNT";
	public static final String OUT_ALL_INSTALMENT_SURCHARGE = "PNO_ARRANGEMENT_SURCHARGE";
	public static final String OUT_ALL_INSTALMENT_TOTAL_AMOUNT = "PNO_ARRANGEMENT_TOTAL_AMOUNT";
	public static final String OUT_ARRANGEMENT_ID = "PNO_PAYMENT_ARRANGEMENT_ID";
	public static final String OUT_ARRANGEMENT_VERSION = "PNO_PAYMENT_ARRANGEMENT_VER";
	public static final String OUT_CANCEL = "PCO_CANCEL";
	public static final String OUT_CONTACTS = "PTO_PAO_CUSTOMER_CONTACT_TAB";
	public static final String OUT_END_DATE = "PDO_END_DATE";
	public static final String OUT_FREQUENCIES = "PTO_PAO_PAYMENT_FREQUENCY_TAB";
	public static final String OUT_INSTALMENTS = "PTO_PYMNT_ARR_INSTLMNT_TAB";
	public static final String OUT_LIABILITIES = "PTO_PAO_LIABILITY_TAB";
	public static final String OUT_MAX_START_DATE = "PDO_MAX_START_DATE";
	public static final String OUT_MESSAGE_TEXT = "PCO_MESSAGE_TEXT";
	public static final String OUT_MESSAGES = "PTO_MESSAGE_TAB";
	public static final String OUT_MIN_START_DATE = "PDO_MIN_START_DATE";
	public static final String OUT_PAYMENT_ARRANGEMENT = "PTO_PYMNT_ARRANGEMENT_REC";
	public static final String OUT_RESULT = "RESULT";
	public static final String OUT_SET = "PCO_SET";
	public static final String OUT_UPDATE = "PCO_UPDATE";
	public static final String OUT_VALID = "PCO_VALID";
	public static final String OUT_CHECKSUM = "PCO_CHECKSUM_ID";
	public static final String OUT_VALUE = "PDO_VALUE";
	public static final String IN_OUT_CHECKSUM = "PCIO_CHECKSUM_ID";
	public static final String PACKAGE_PAYMENT_ARRANGEMENTS_EVENTS = "PAO_EVENTS_PKG";
	public static final String PACKAGE_PAYMENT_ARRANGEMENTS_SERVICES = "PAO_SERVICES_PKG";
	public static final String PROCEDURE_AUTHENTICATE = "VALIDATE_INPUT_DATA_P";
	public static final String PROCEDURE_CALCULATE_SCHEDULE = "CALC_PAYMENT_SCHEDULE_P";
	public static final String PROCEDURE_CANCEL_ARRANGEMENT = "CANCEL_PAO_P";
	public static final String PROCEDURE_FIND_ARRANGEMENT = "GET_ARRANGEMENT_P";
	public static final String PROCEDURE_GET_NOTIFICATION_ARRANGEMENT = "GET_NOTIFICATION_ARRANGEMENT_P";
	public static final String PROCEDURE_GET_NOTIFICATION_DATA = "GET_PAO_NOTIFICATION_DATA_P";
	public static final String PROCEDURE_GET_CONFIRM_CANCEL_TEXT = "GET_CANCEL_CONFIRMATION_MSG_P";
	public static final String PROCEDURE_GET_DEFAULT_DATES = "GET_ARR_DEFAULT_DATES_P";
	public static final String PROCEDURE_GET_EVENTS = "GET_EVENT_NOTIFICATION_F";
	public static final String PROCEDURE_GET_FREQUENCIES = "GET_VALID_FREQUENCIES_P";
	public static final String PROCEDURE_NEXT_EVENT = "GET_NEXT_EVENT_NOTIFICATION_F";
	public static final String PROCEDURE_SAVE_ACCOUNT = "SET_TOKEN_P";
	public static final String PROCEDURE_SAVE_ARRANGEMENT = "SAVE_ARRANGEMENT_P";
	public static final String PROCEDURE_SAVE_CONTACTS = "UPDATE_CONTACT_DETAILS_P";
	public static final String PROCEDURE_SAVE_EVENT = "UPDATE_EVENT_STATUS_P";
	public static final String TYPE_CONTACT = "PAO_CUSTOMER_CONTACT_REC";
	public static final String TYPE_CONTACTS = "PAO_CUSTOMER_CONTACT_TAB";
	public static final String TYPE_EVENT = "PAO_EVENT_NOTIFICATION_REC";
	public static final String TYPE_EVENTS = "PAO_EVENT_NOTIFICATION_TAB";
	public static final String TYPE_FREQUENCIES = "PAO_PAYMENT_FREQUENCY_TAB";
	public static final String TYPE_INSTALMENT = "PYMNT_ARRANGEMENT_INSTLMNT_REC";
	public static final String TYPE_INSTALMENTS = "PYMNT_ARRANGEMENT_INSTLMNT_TAB";
	public static final String TYPE_LIABILITIES = "PAO_LIABILITY_TAB";
	public static final String TYPE_LIABILITY = "PAO_LIABILITY_REC";
	public static final String TYPE_MESSAGE = "PAO_MESSAGE_REC";
	public static final String TYPE_MESSAGES = "PAO_MESSAGE_TAB";
	public static final String TYPE_NUMBERS = "SIMPLENUMBERARRAY";
	public static final String TYPE_PAYMENT_ARRANGEMENT = "PYMNT_ARRANGEMENT_REC";

	private PaymentArrangementsDaoConstants() {
		// No instance.
	}

}
