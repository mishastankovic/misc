package au.gov.vic.sro.payment.arrangements.dao.procedure;

import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.IN_CUSTOMER_ID;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.IN_LIABILITY_ID;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.IN_LIABILITY_TYPE;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.INOUT_REVENUE_LINE;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.OUT_END_DATE;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.OUT_MAX_START_DATE;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.OUT_MESSAGES;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.OUT_MIN_START_DATE;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.PACKAGE_PAYMENT_ARRANGEMENTS_SERVICES;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.PROCEDURE_GET_DEFAULT_DATES;
import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.TYPE_MESSAGES;
import static java.sql.Types.ARRAY;
import static java.sql.Types.TIMESTAMP;
import static java.sql.Types.VARCHAR;
import static org.apache.commons.collections4.MapUtils.emptyIfNull;

import java.sql.Timestamp;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.data.jdbc.support.oracle.SqlReturnStructArray;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import au.gov.vic.sro.payment.arrangements.dao.mapper.MessageMapper;
import au.gov.vic.sro.payment.arrangements.dto.GetDefaultDatesResponse;
import au.gov.vic.sro.payment.arrangements.model.LiabilityType;
import au.gov.vic.sro.payment.arrangements.model.Message;
import au.gov.vic.sro.payment.arrangements.model.RevenueLine;
import au.gov.vic.sro.util.DateUtil;

public class GetDefaultDatesProcedure extends StoredProcedure {

	public GetDefaultDatesProcedure(JdbcTemplate jdbcTemplate) {
		super(jdbcTemplate, PACKAGE_PAYMENT_ARRANGEMENTS_SERVICES + "." + PROCEDURE_GET_DEFAULT_DATES);
		declareParameter(new SqlParameter(IN_CUSTOMER_ID, VARCHAR));
		declareParameter(new SqlParameter(INOUT_REVENUE_LINE, VARCHAR));
		declareParameter(new SqlParameter(IN_LIABILITY_TYPE, VARCHAR));
		declareParameter(new SqlParameter(IN_LIABILITY_ID, VARCHAR));
		declareParameter(new SqlOutParameter(OUT_MIN_START_DATE, TIMESTAMP));
		declareParameter(new SqlOutParameter(OUT_MAX_START_DATE, TIMESTAMP));
		declareParameter(new SqlOutParameter(OUT_END_DATE, TIMESTAMP));
		declareParameter(new SqlOutParameter(OUT_MESSAGES, ARRAY, TYPE_MESSAGES, new SqlReturnStructArray<Message>(
				new MessageMapper())));
		compile();
	}

	public GetDefaultDatesResponse execute(String customerId, RevenueLine revenueLine, LiabilityType liabilityType,
			String liabilityId) {
		Map<String, Object> in = new LinkedHashMap<String, Object>();
		in.put(IN_CUSTOMER_ID, customerId);
		in.put(INOUT_REVENUE_LINE, revenueLine == null ? null : revenueLine.getCode());
		in.put(IN_LIABILITY_TYPE, liabilityType == null ? null : liabilityType.getCode());
		in.put(IN_LIABILITY_ID, liabilityId);

		Map<String, Object> out = emptyIfNull(execute(in));

		GetDefaultDatesResponse response = new GetDefaultDatesResponse();
		response.setArrangementStartDate(DateUtil.toDate((Timestamp) out.get(OUT_MIN_START_DATE)));
		response.setArrangementMaxStartDate(DateUtil.toDate((Timestamp) out.get(OUT_MAX_START_DATE)));
		response.setArrangementEndDate(DateUtil.toDate((Timestamp) out.get(OUT_END_DATE)));
		response.setMessages((Object[]) out.get(OUT_MESSAGES));
		return response;
	}

}
