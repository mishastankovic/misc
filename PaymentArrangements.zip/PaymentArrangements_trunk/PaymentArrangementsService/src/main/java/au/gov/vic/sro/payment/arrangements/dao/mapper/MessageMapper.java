package au.gov.vic.sro.payment.arrangements.dao.mapper;

import static au.gov.vic.sro.payment.arrangements.dao.PaymentArrangementsDaoConstants.TYPE_MESSAGE;
import static au.gov.vic.sro.payment.arrangements.dao.support.OracleUtil.getValues;
import static au.gov.vic.sro.util.NumberUtil.toIntegerExact;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.regex.Pattern;

import org.springframework.data.jdbc.support.oracle.StructMapper;

import au.gov.vic.sro.payment.arrangements.model.Message;
import au.gov.vic.sro.payment.arrangements.model.MessageType;
import oracle.sql.STRUCT;

public class MessageMapper implements StructMapper<Message> {

	private enum RecField {
		MSG_NUM,
		MSG_TYPE,
		MSG_TEXT;
	}

	private static final Pattern TYPE_NAME_PATTERN = Pattern.compile("(.+\\.)*" + TYPE_MESSAGE);
	private static final int TYPE_LENGTH = RecField.values().length;

	@Override
	public STRUCT toStruct(Message source, Connection conn, String typeName) throws SQLException {
		throw new UnsupportedOperationException();
	}

	@Override
	public Message fromStruct(STRUCT struct) throws SQLException {
		Object[] rec = getValues(struct, TYPE_NAME_PATTERN, TYPE_LENGTH);
		Message target = new Message();
		target.setCode(toIntegerExact((BigDecimal) rec[RecField.MSG_NUM.ordinal()]));
		target.setType(MessageType.fromCode((String) rec[RecField.MSG_TYPE.ordinal()]));
		target.setText((String) rec[RecField.MSG_TEXT.ordinal()]);
		return target;
	}

}
