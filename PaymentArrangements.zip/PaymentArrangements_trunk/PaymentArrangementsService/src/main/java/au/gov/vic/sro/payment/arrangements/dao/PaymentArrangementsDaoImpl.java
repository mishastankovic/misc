package au.gov.vic.sro.payment.arrangements.dao;

import java.math.BigInteger;
import java.util.Date;
import java.util.List;

import org.springframework.jdbc.core.support.JdbcDaoSupport;

import au.gov.vic.sro.payment.arrangements.dao.procedure.AuthenticateProcedure;
import au.gov.vic.sro.payment.arrangements.dao.procedure.CalculateScheduleProcedure;
import au.gov.vic.sro.payment.arrangements.dao.procedure.CancelArrangementProcedure;
import au.gov.vic.sro.payment.arrangements.dao.procedure.FindArrangementProcedure;
import au.gov.vic.sro.payment.arrangements.dao.procedure.GetNotificationArrangementProcedure;
import au.gov.vic.sro.payment.arrangements.dao.procedure.GetConfirmCancelTextProcedure;
import au.gov.vic.sro.payment.arrangements.dao.procedure.GetDefaultDatesProcedure;
import au.gov.vic.sro.payment.arrangements.dao.procedure.GetEventsProcedure;
import au.gov.vic.sro.payment.arrangements.dao.procedure.GetFrequenciesProcedure;
import au.gov.vic.sro.payment.arrangements.dao.procedure.GetNotificationDataProcedure;
import au.gov.vic.sro.payment.arrangements.dao.procedure.NextEventProcedure;
import au.gov.vic.sro.payment.arrangements.dao.procedure.SaveAccountProcedure;
import au.gov.vic.sro.payment.arrangements.dao.procedure.SaveArrangementProcedure;
import au.gov.vic.sro.payment.arrangements.dao.procedure.SaveContactsProcedure;
import au.gov.vic.sro.payment.arrangements.dao.procedure.SaveEventProcedure;
import au.gov.vic.sro.payment.arrangements.dto.AuthenticateResponse;
import au.gov.vic.sro.payment.arrangements.dto.CalculateScheduleResponse;
import au.gov.vic.sro.payment.arrangements.dto.CancelArrangementResponse;
import au.gov.vic.sro.payment.arrangements.dto.CancelEmailResponse;
import au.gov.vic.sro.payment.arrangements.dto.FindArrangementResponse;
import au.gov.vic.sro.payment.arrangements.dto.GetConfirmCancelTextResponse;
import au.gov.vic.sro.payment.arrangements.dto.GetDefaultDatesResponse;
import au.gov.vic.sro.payment.arrangements.dto.GetEventsResponse;
import au.gov.vic.sro.payment.arrangements.dto.GetFrequenciesResponse;
import au.gov.vic.sro.payment.arrangements.dto.NextEventResponse;
import au.gov.vic.sro.payment.arrangements.dto.SaveAccountRequest;
import au.gov.vic.sro.payment.arrangements.dto.SaveAccountResponse;
import au.gov.vic.sro.payment.arrangements.dto.SaveArrangementResponse;
import au.gov.vic.sro.payment.arrangements.dto.SaveContactsResponse;
import au.gov.vic.sro.payment.arrangements.model.Arrangement;
import au.gov.vic.sro.payment.arrangements.model.Contact;
import au.gov.vic.sro.payment.arrangements.model.Event;
import au.gov.vic.sro.payment.arrangements.model.LiabilityType;
import au.gov.vic.sro.payment.arrangements.model.PaymentFrequency;
import au.gov.vic.sro.payment.arrangements.model.PaymentMethod;
import au.gov.vic.sro.payment.arrangements.model.RevenueLine;

public class PaymentArrangementsDaoImpl extends JdbcDaoSupport implements PaymentArrangementsDao {
	private AuthenticateProcedure authenticateProcedure;
	private FindArrangementProcedure findArrangementProcedure;
	private GetNotificationArrangementProcedure getNotificationArrangementProcedure;
	private GetDefaultDatesProcedure getDefaultDatesProcedure;
	private GetFrequenciesProcedure getFrequenciesProcedure;
	private CalculateScheduleProcedure calculateScheduleProcedure;
	private SaveArrangementProcedure saveArrangementProcedure;
	private SaveAccountProcedure saveAccountProcedure;
	private SaveContactsProcedure saveContactsProcedure;
	private GetConfirmCancelTextProcedure getConfirmCancelTextProcedure;
	private CancelArrangementProcedure cancelArrangementProcedure;
	private NextEventProcedure nextEventProcedure;
	private SaveEventProcedure saveEventProcedure;
	private GetEventsProcedure getEventsProcedure;
	private GetNotificationDataProcedure getGetNotificationDataProcedure;

	@Override
	protected void initTemplateConfig() {
		authenticateProcedure = new AuthenticateProcedure(getJdbcTemplate());
		findArrangementProcedure = new FindArrangementProcedure(getJdbcTemplate());
		getNotificationArrangementProcedure = new GetNotificationArrangementProcedure(getJdbcTemplate());
		getDefaultDatesProcedure = new GetDefaultDatesProcedure(getJdbcTemplate());
		getFrequenciesProcedure = new GetFrequenciesProcedure(getJdbcTemplate());
		calculateScheduleProcedure = new CalculateScheduleProcedure(getJdbcTemplate());
		saveArrangementProcedure = new SaveArrangementProcedure(getJdbcTemplate());
		saveAccountProcedure = new SaveAccountProcedure(getJdbcTemplate());
		saveContactsProcedure = new SaveContactsProcedure(getJdbcTemplate());
		getConfirmCancelTextProcedure = new GetConfirmCancelTextProcedure(getJdbcTemplate());
		nextEventProcedure = new NextEventProcedure(getJdbcTemplate());
		saveEventProcedure = new SaveEventProcedure(getJdbcTemplate());
		getEventsProcedure = new GetEventsProcedure(getJdbcTemplate());
		cancelArrangementProcedure = new CancelArrangementProcedure(getJdbcTemplate());
		getGetNotificationDataProcedure = new GetNotificationDataProcedure(getJdbcTemplate());
	}

	@Override
	public AuthenticateResponse authenticate(String customerId, RevenueLine revenueLine, LiabilityType liabilityType,
			String liabilityId) {
		return getAuthenticateProcedure().execute(customerId, revenueLine, liabilityType, liabilityId);
	}

	@Override
	public FindArrangementResponse findArrangement(String customerId, RevenueLine revenueLine,
			LiabilityType liabilityType, String liabilityId) {
		return getFindArrangementProcedure().execute(customerId, revenueLine, liabilityType, liabilityId);
	}

	@Override
	public FindArrangementResponse findNotificationArrangement(BigInteger arrangementId, Integer arrangementVersion) {
		return getGetNotificationArrangementProcedure().execute(arrangementId, arrangementVersion);
	}

	@Override
	public CancelEmailResponse getNotificationData(BigInteger arrangementId, Integer arrangementVersion,
			String dateTypeRequired) {
		return getGetNotificationDataProcedure().execute(arrangementId, arrangementVersion, dateTypeRequired);
	}

	@Override
	public GetDefaultDatesResponse getDefaultDates(String customerId, RevenueLine revenueLine,
			LiabilityType liabilityType, String liabilityId) {
		return getGetDefaultDatesProcedure().execute(customerId, revenueLine, liabilityType, liabilityId);
	}

	@Override
	public GetFrequenciesResponse getFrequencies(String customerId, RevenueLine revenueLine,
			LiabilityType liabilityType, String liabilityId, Date arrangementStartDate, Date arrangementEndDate) {
		return getGetFrequenciesProcedure().execute(customerId, revenueLine, liabilityType, liabilityId,
				arrangementStartDate, arrangementEndDate);
	}

	@Override
	public CalculateScheduleResponse calculateSchedule(String customerId, RevenueLine revenueLine,
			LiabilityType liabilityType, String liabilityId, Date arrangementStartDate, Date arrangementEndDate,
			PaymentFrequency paymentFrequency, PaymentMethod paymentMethod) {
		return getCalculateScheduleProcedure().execute(customerId, revenueLine, liabilityType, liabilityId,
				arrangementStartDate, arrangementEndDate, paymentFrequency, paymentMethod);
	}

	@Override
	public SaveArrangementResponse saveArrangement(Arrangement arrangement) {
		return getSaveArrangementProcedure().execute(arrangement);
	}

	@Override
	public SaveAccountResponse saveAccount(SaveAccountRequest request) {
		return getSaveAccountProcedure().execute(request);
	}

	@Override
	public SaveContactsResponse saveContacts(List<Contact> contacts, String checksum) {
		return getSaveContactsProcedure().execute(contacts, checksum);
	}

	@Override
	public GetConfirmCancelTextResponse getConfirmCancelText(BigInteger arrangementId, Integer arrangementVersion) {
		return getGetConfirmCancelTextProcedure().execute(arrangementId, arrangementVersion);
	}

	@Override
	public CancelArrangementResponse cancelArrangement(BigInteger arrangementId, Integer arrangementVersion) {
		return getCancelArrangementProcedure().execute(arrangementId, arrangementVersion);
	}

	@Override
	public NextEventResponse nextEvent() {
		return getNextEventProcedure().execute();
	}

	@Override
	public void saveEvent(Event event) {
		getSaveEventProcedure().execute(event);
	}

	@Override
	public GetEventsResponse getEvents(List<BigInteger> eventIds) {
		return getGetEventsProcedure().execute(eventIds);
	}

	protected AuthenticateProcedure getAuthenticateProcedure() {
		return authenticateProcedure;
	}

	protected FindArrangementProcedure getFindArrangementProcedure() {
		return findArrangementProcedure;
	}

	protected GetNotificationArrangementProcedure getGetNotificationArrangementProcedure() {
		return getNotificationArrangementProcedure;
	}

	protected GetNotificationDataProcedure getGetNotificationDataProcedure() {
		return getGetNotificationDataProcedure;
	}

	protected GetDefaultDatesProcedure getGetDefaultDatesProcedure() {
		return getDefaultDatesProcedure;
	}

	protected GetFrequenciesProcedure getGetFrequenciesProcedure() {
		return getFrequenciesProcedure;
	}

	protected CalculateScheduleProcedure getCalculateScheduleProcedure() {
		return calculateScheduleProcedure;
	}

	protected SaveArrangementProcedure getSaveArrangementProcedure() {
		return saveArrangementProcedure;
	}

	protected SaveAccountProcedure getSaveAccountProcedure() {
		return saveAccountProcedure;
	}

	protected SaveContactsProcedure getSaveContactsProcedure() {
		return saveContactsProcedure;
	}

	protected GetConfirmCancelTextProcedure getGetConfirmCancelTextProcedure() {
		return getConfirmCancelTextProcedure;
	}

	protected CancelArrangementProcedure getCancelArrangementProcedure() {
		return cancelArrangementProcedure;
	}

	protected NextEventProcedure getNextEventProcedure() {
		return nextEventProcedure;
	}

	protected SaveEventProcedure getSaveEventProcedure() {
		return saveEventProcedure;
	}

	protected GetEventsProcedure getGetEventsProcedure() {
		return getEventsProcedure;
	}

}
