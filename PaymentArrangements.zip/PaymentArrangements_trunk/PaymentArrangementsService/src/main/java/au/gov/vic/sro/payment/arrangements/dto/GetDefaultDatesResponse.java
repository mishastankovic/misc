package au.gov.vic.sro.payment.arrangements.dto;

import static au.gov.vic.sro.builder.ToStringStyleFactory.getToStringStyle;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

public class GetDefaultDatesResponse extends MessageResponse implements Serializable {
	private static final long serialVersionUID = 3050899818283750514L;
	private Date arrangementStartDate;
	private Date arrangementMaxStartDate;
	private Date arrangementEndDate;

	public Date getArrangementStartDate() {
		return arrangementStartDate;
	}

	public void setArrangementStartDate(Date arrangementStartDate) {
		this.arrangementStartDate = arrangementStartDate;
	}

	public Date getArrangementMaxStartDate() {
		return arrangementMaxStartDate;
	}

	public void setArrangementMaxStartDate(Date arrangementMaxStartDate) {
		this.arrangementMaxStartDate = arrangementMaxStartDate;
	}

	public Date getArrangementEndDate() {
		return arrangementEndDate;
	}

	public void setArrangementEndDate(Date arrangementEndDate) {
		this.arrangementEndDate = arrangementEndDate;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, getToStringStyle());
	}

}
