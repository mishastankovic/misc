
/* Application-specific JavaScript */

function initialiseHelpPopover() {
	var showTimer = 300, hideTimer = 300;
	$(".help-popover").popover('hide');
	var showPopover = function () {
		$(this).popover('show');
	}
	, hidePopover = function () {
		$(this).popover('hide');
	};

	// See http://stackoverflow.com/questions/15989591/how-can-i-keep-bootstrap-popover-alive-while-the-popover-is-being-hovered
	$("[data-toggle='help-popover']")
			.popover(
					{
						html : true,
						template : '<div class="popover help-popover" role="tooltip"><div class="arrow"></div><h3 class="popover-title"></h3><div class="popover-content"></div></div>',
						trigger: "manual"
					})
			.focus(showPopover)
			.blur(hidePopover)
			.on("mouseenter", function() {
						var _this = this;
						setTimeout(function () {
							$(_this).popover('show');
							$(".help-popover").on("mouseleave", function() {
								setTimeout(function () {
									$(_this).popover('hide');
								}, hideTimer);
							});
						}, showTimer);
					})
			.on("mouseleave", function() {
				var _this = this;
				setTimeout(function () {
					if (!$(".help-popover:hover").length) {
						$(_this).popover('hide');
					}
				}, hideTimer);
			});
}