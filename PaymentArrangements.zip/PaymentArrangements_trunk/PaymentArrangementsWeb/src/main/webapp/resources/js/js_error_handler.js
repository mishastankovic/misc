Err = {};

Err.Remoterr = {};

Err.Remoterr.onerror = function (msg, errorfileurl, lineno) {

	// get some context of where and how the error occurred to make debugging easier
	var pageurl = window.location.href;

	try {
		$.ajax({
			type: "POST",
			url: "/pao/jserror",
			data: "msg=" + msg + "&errorfileurl=" + errorfileurl + "&lineno=" + lineno + "&pageurl=" + pageurl,
			async: false
		});
	} catch(e) {
		//ignore error
	}

	// I don't want the page to 'pretend' to work so I am going to return 'false' here
	// Returning 'true' will clear the error in the browser
	return false;
};

window.onerror = Err.Remoterr.onerror;