package au.gov.vic.sro.payment.arrangements.faces.model;

import static au.gov.vic.sro.util.CollectionUtil.getFirst;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.ValidatorException;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import au.gov.vic.sro.payment.arrangements.faces.util.MessageStatus;
import au.gov.vic.sro.payment.arrangements.model.Arrangement;
import au.gov.vic.sro.payment.arrangements.model.ArrangementStatus;
import au.gov.vic.sro.payment.arrangements.model.Codified;
import au.gov.vic.sro.payment.arrangements.model.Contact;
import au.gov.vic.sro.payment.arrangements.model.ContactType;
import au.gov.vic.sro.payment.arrangements.model.Instalment;
import au.gov.vic.sro.payment.arrangements.model.Liability;
import au.gov.vic.sro.payment.arrangements.model.LiabilityType;
import au.gov.vic.sro.payment.arrangements.model.PaymentFrequency;
import au.gov.vic.sro.payment.arrangements.model.PaymentMethod;
import au.gov.vic.sro.payment.arrangements.model.Presentable;
import au.gov.vic.sro.payment.arrangements.model.RevenueLine;
import au.gov.vic.sro.payment.arrangements.service.UserDetailsImpl;

/*
 * Note there is an issue with marking the label of a radio as being in error.
 * See http://stackoverflow.com/questions/18198246/how-to-add-ui-state-error-to-pselectoneradio-on-failure
 */
public class ArrangementPageModel extends AbstractPageModel implements Serializable {
	public enum Option {
		CANCEL_ARRANGEMENT,
		REGISTER_ARRANGEMENT,
		REPLACE_ARRANGEMENT,
		UPDATE_CONTACT,
		UPDATE_PAYMENT_REGISTRATION
	}

	public static class PaymentFrequencyOption implements Presentable, Codified, Serializable {
		private static final long serialVersionUID = 3617904606218612896L;
		private boolean disabled;
		private PaymentFrequency value;

		public PaymentFrequencyOption() {

		}

		public PaymentFrequencyOption(PaymentFrequency value) {
			setValue(value);
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj) {
				return true;
			}
			if (obj == null) {
				return false;
			}
			if (getClass() != obj.getClass()) {
				return false;
			}
			PaymentFrequencyOption other = (PaymentFrequencyOption) obj;
			return new EqualsBuilder().append(value, other.value).isEquals();
		}

		@Override
		public String getCode() {
			return value.getCode();
		}

		@Override
		public String getLabel() {
			return value.getLabel();
		}

		public PaymentFrequency getValue() {
			return value;
		}

		@Override
		public int hashCode() {
			return new HashCodeBuilder(1, 31).append(value).toHashCode();
		}

		public boolean isDisabled() {
			return disabled;
		}

		public void setDisabled(boolean disabled) {
			this.disabled = disabled;
		}

		public void setValue(PaymentFrequency value) {
			this.value = value;
		}
	}

	private static final String ARRANGEMENT_LIABILITY_REFERENCE = "arrangement_liability_reference";
	private static final String ARRANGEMENT_LIABILITY_VERSION = "arrangement_liability_version";
	private static final String ARRANGEMENT_LIABILITY_YEAR = "arrangement_liability_year";
	private static final String ARRANGEMENT_MERCHANT_FEE_LINK_LABEL = "arrangement_payment_method_visa_or_mastercard";
	private static final long serialVersionUID = -9204294067944657625L;
	private Arrangement arrangement;
	private String confirmCancelText;
	private String confirmLogoutText;
	private String confirmEmailAddress;
	private Contact contactCopy;
	private List<ContactType> contactTypes = new ArrayList<ContactType>();
	private boolean editingContact;
	private String information;
	private Date maxEndDate;
	private Date maxStartDate;
	private Date minEndDate;
	private Date minStartDate;
	private Set<Option> options = new HashSet<Option>();
	private List<PaymentFrequencyOption> paymentFrequencies = new ArrayList<PaymentFrequencyOption>();
	private List<PaymentMethod> paymentMethods = new ArrayList<PaymentMethod>();
	private boolean polling;
	private Boolean termsAndConditionsAccepted;
	private UserDetailsImpl userDetails;
	private MessageStatus contactDetailsUpdatedMessage;
	private MessageStatus paymentMethodUpdatedMessage;
	private MessageStatus paymentArrangementActivatedMessage;
	private boolean displayFirstInstalmentDateCalendar;
	private boolean displayLastInstalmentDateCalendar;
	private boolean frequencyInError;
	private boolean hideStepInformationText;

	public ArrangementPageModel() {
		PaymentFrequencyOption paymentFrequencyOption = new PaymentFrequencyOption(PaymentFrequency.FORTNIGHTLY);
		paymentFrequencyOption.setDisabled(true);
		paymentFrequencies.add(paymentFrequencyOption);
		paymentFrequencyOption = new PaymentFrequencyOption(PaymentFrequency.MONTHLY);
		paymentFrequencyOption.setDisabled(true);
		paymentFrequencies.add(paymentFrequencyOption);
		paymentFrequencyOption = new PaymentFrequencyOption(PaymentFrequency.FOUR);
		paymentFrequencyOption.setDisabled(true);
		paymentFrequencies.add(paymentFrequencyOption);
		contactTypes.add(ContactType.CUSTOMER);
		contactTypes.add(ContactType.CUSTOMER_REP);
		paymentMethods.add(PaymentMethod.DIRECT_DEBIT);
		paymentMethods.add(PaymentMethod.CREDIT_CARD);
	}

	public BigDecimal getAllInstalmentAmountDollars() {
		return arrangement.getAllInstalmentAmountDollars();
	}

	public BigDecimal getAllInstalmentSurchargeDollars() {
		return arrangement.getAllInstalmentSurchargeDollars();
	}

	public BigDecimal getAllInstalmentTotalAmountDollars() {
		return arrangement.getAllInstalmentTotalAmountDollars();
	}

	public BigDecimal getAmountPayable() {
		Liability liability = getFirstLiability();
		return liability == null ? null : liability.getOutstandingLiabilityAmountDollars();
	}

	public Arrangement getArrangement() {
		return arrangement;
	}

	public Date getArrangementEndDate() {
		return arrangement.getEndDate();
	}

	public BigInteger getArrangementNumber() {
		return arrangement.getId();
	}

	public Date getArrangementStartDate() {
		return arrangement.getStartDate();
	}

	public Integer getArrangementVersion() {
		return arrangement.getVersion();
	}

	public String getConfirmCancelText() {
		return confirmCancelText;
	}

	public String getConfirmEmailAddress() {
		return confirmEmailAddress;
	}

	public Contact getContact() {
		return isEditingContact() ? getContactCopy() : getFirstContact();
	}

	public Contact getContactCopy() {
		return contactCopy;
	}

	public String getContactName() {
		Contact contact = getContact();
		return contact == null ? null : contact.getPersonName();
	}

	public ContactType getContactType() {
		Contact contact = getContact();
		return contact == null ? null : contact.getType();
	}

	public List<ContactType> getContactTypes() {
		return contactTypes;
	}

	public String getCustomerId() {
		return arrangement.getCustomerId();
	}

	public String getEmailAddress() {
		Contact contact = getContact();
		return contact == null ? null : contact.getEmailAddress();
	}

	public boolean getEmailReminder() {
		Contact contact = getContact();
		return contact == null ? false : "Y".equalsIgnoreCase(contact.getReminderEmails()); 		
	}
	
	public String getReceiveEmailReminderLabel() {
		String receiveEmailReminderLabel = "";
		Contact contact = getContact();
		if (contact == null) {
			return "";
		} else {
			receiveEmailReminderLabel = "Y".equalsIgnoreCase(contact.getReminderEmails()) ? "Yes" : "No";
		}
		return receiveEmailReminderLabel;
	}
	
	public Contact getFirstContact() {
		return arrangement == null ? null : getFirst(arrangement.getContacts());
	}

	private Liability getFirstLiability() {
		return arrangement == null ? null : getFirst(arrangement.getLiabilities());
	}

	public String getInformation() {
		return information;
	}

	public List<Instalment> getInstalments() {
		return arrangement.getInstalments();
	}

	public String getLiabilityId() {
		Liability liability = getFirstLiability();
		return liability == null ? null : liability.getId();
	}

	public String getLiabilityIdLabel() {
		LiabilityType liabilityType = getLiabilityType();
		if (liabilityType != null) {
			switch (liabilityType) {
			case ASSESSMENT:
				return "Assessment number";
			default:
				break;
			}
		}
		return getResource(ARRANGEMENT_LIABILITY_REFERENCE);
	}

	public Date getLiabilityIssueDate() {
		Liability liability = getFirstLiability();
		return liability == null ? null : liability.getIssueDate();
	}

	public LiabilityType getLiabilityType() {
		Liability liability = getFirstLiability();
		return liability == null ? null : liability.getType();
	}

	public Integer getLiabilityVersion() {
		Liability liability = getFirstLiability();
		return liability == null ? null : liability.getVersion();
	}

	public String getLiabilityVersionLabel() {
		LiabilityType liabilityType = getLiabilityType();
		if (liabilityType != null) {
			switch (liabilityType) {
			case ASSESSMENT:
				return "Assessment version";
			default:
				break;
			}
		}
		return getResource(ARRANGEMENT_LIABILITY_VERSION);
	}

	public Integer getLiabilityYear() {
		Liability liability = getFirstLiability();
		return liability == null ? null : liability.getYear();
	}

	public String getLiabilityYearLabel() {
		LiabilityType liabilityType = getLiabilityType();
		if (liabilityType != null) {
			switch (liabilityType) {
			case ASSESSMENT:
				return "Assessment year";
			default:
				break;
			}
		}
		return getResource(ARRANGEMENT_LIABILITY_YEAR);
	}
		
	public Date getMaxEndDate() {
		return maxEndDate;
	}

	public Date getMaxStartDate() {
		return maxStartDate;
	}

	public Date getMinEndDate() {
		return minEndDate;
	}

	public Date getMinStartDate() {
		return minStartDate;
	}

	public String getMobileTelephoneNumber() {
		Contact contact = getContact();
		return contact == null ? null : contact.getMobilePhone();
	}

	public Set<Option> getOptions() {
		return options;
	}

	public List<PaymentFrequencyOption> getPaymentFrequencies() {
		return paymentFrequencies;
	}

	public PaymentFrequencyOption getPaymentFrequency() {
		for (PaymentFrequencyOption option : paymentFrequencies) {
			PaymentFrequency paymentFrequency = arrangement.getPaymentFrequency();
			if (option.getValue().equals(paymentFrequency)) {
				return option;
			}
		}
		return null;
	}

	public PaymentMethod getPaymentMethod() {
		return arrangement.getPaymentMethod();
	}

	public String getPaymentMethodLabel() {
		String paymentMethodLabel = "";
		PaymentMethod paymentMethod = arrangement.getPaymentMethod();
		if (paymentMethod != null) {
			switch (paymentMethod) {
			case CREDIT_CARD: {
				String cardNumber = arrangement.getCardNumber();
				if (cardNumber != null) {
					paymentMethodLabel += getResource(ARRANGEMENT_MERCHANT_FEE_LINK_LABEL) + " (" + cardNumber + ")";
				}
				break;
			}
			case DIRECT_DEBIT: {
				paymentMethodLabel += paymentMethod.getLabel();
				String bankAccountNumber = arrangement.getBankAccountNumber();
				if (bankAccountNumber != null) {
					paymentMethodLabel += " (" + bankAccountNumber + ")";
				}
				break;
			}
			default:
				break;
			}
		}
		return paymentMethodLabel;
	}

	public List<PaymentMethod> getPaymentMethods() {
		return paymentMethods;
	}

	public RevenueLine getRevenueLine() {
		Liability liability = getFirstLiability();
		return liability != null ? liability.getRevenueLine() : null;
	}

	public ArrangementStatus getStatus() {
		return arrangement.getStatus();
	}

	public Boolean getTermsAndConditionsAccepted() {
		return termsAndConditionsAccepted;
	}

	public UserDetailsImpl getUserDetails() {
		return userDetails;
	}

	public boolean isActive() {
		return arrangement != null && ArrangementStatus.ACTIVE.equals(arrangement.getStatus());
	}

	public boolean isAllowedToCancelArrangement() {
		return options.contains(Option.CANCEL_ARRANGEMENT);
	}

	public boolean isAllowedToRegisterArrangement() {
		return options.contains(Option.REGISTER_ARRANGEMENT);
	}

	public boolean isAllowedToReplaceArrangement() {
		return options.contains(Option.REPLACE_ARRANGEMENT);
	}

	public boolean isAllowedToUpdateContact() {
		return options.contains(Option.UPDATE_CONTACT);
	}

	public boolean isAllowedToUpdatePaymentRegistration() {
		return options.contains(Option.UPDATE_PAYMENT_REGISTRATION);
	}

	public boolean isArrangementExists() {
		return arrangement.getId() != null;
	}

	public boolean isCancelled() {
		return arrangement != null && ArrangementStatus.CANCELLED.equals(arrangement.getStatus());
	}

	public boolean isCompleted() {
		return arrangement != null && ArrangementStatus.COMPLETED.equals(arrangement.getStatus());
	}

	public boolean isEditingContact() {
		return editingContact;
	}

	public boolean isPending() {
		return arrangement != null && ArrangementStatus.PENDING.equals(arrangement.getStatus());
	}

	public boolean isPolling() {
		return polling;
	}

	public void setAllInstalmentAmountDollars(BigDecimal allInstalmentAmountDollars) {
		arrangement.setAllInstalmentAmountDollars(allInstalmentAmountDollars);
	}

	public void setAllInstalmentSurchargeDollars(BigDecimal allInstalmentSurchargeDollars) {
		arrangement.setAllInstalmentSurchargeDollars(allInstalmentSurchargeDollars);
	}

	public void setAllInstalmentTotalAmountDollars(BigDecimal allInstalmentTotalAmountDollars) {
		arrangement.setAllInstalmentTotalAmountDollars(allInstalmentTotalAmountDollars);
	}

	public void setArrangement(Arrangement arrangement) {
		this.arrangement = arrangement;
	}

	public void setArrangementEndDate(Date endDate) {
		arrangement.setEndDate(endDate);

	}

	public void setArrangementStartDate(Date startDate) {
		arrangement.setStartDate(startDate);

	}

	public void setConfirmCancelText(String confirmCancelText) {
		this.confirmCancelText = confirmCancelText;
	}

	public void setConfirmEmailAddress(String confirmEmailAddress) {
		this.confirmEmailAddress = confirmEmailAddress;

	}

	public void setContactCopy(Contact contactCopy) {
		this.contactCopy = contactCopy;
	}

	public void setContactName(String contactName) {
		Contact contact = getContact();
		if (contact != null) {
			contact.setPersonName(contactName);

		}
	}

	public void setContactType(ContactType contactType) {
		Contact contact = getContact();
		if (contact != null) {
			contact.setType(contactType);

		}
	}

	public void setContactTypes(List<ContactType> contactTypes) {
		this.contactTypes = contactTypes;
	}

	public void setEditingContact(boolean editingContact) {
		this.editingContact = editingContact;
	}

	public void setEmailReminder(boolean reminderEmail) {
		Contact contact = getContact();
		if (contact != null) {
			contact.setReminderEmails((reminderEmail ? "Y" : "N"));
		}
	}

	public void setEmailAddress(String emailAddress) {
		Contact contact = getContact();
		if (contact != null) {
			contact.setEmailAddress(emailAddress);

		}
	}

	public void setInformation(String information) {
		this.information = information;
	}

	public void setInstalments(List<Instalment> instalments) {
		arrangement.setInstalments(instalments);

	}

	public void setMaxEndDate(Date maxEndDate) {
		this.maxEndDate = maxEndDate;
	}

	public void setMaxStartDate(Date maxStartDate) {
		this.maxStartDate = maxStartDate;

	}

	public void setMinEndDate(Date minEndDate) {
		this.minEndDate = minEndDate;
	}

	public void setMinStartDate(Date minStartDate) {
		this.minStartDate = minStartDate;
	}

	public void setMobileTelephoneNumber(String mobileTelephoneNumber) {
		Contact contact = getContact();
		if (contact != null) {
			contact.setMobilePhone(mobileTelephoneNumber);

		}
	}

	public void setOptions(Set<Option> options) {
		this.options = options;
	}

	public void setPaymentFrequencies(List<PaymentFrequencyOption> paymentFrequencies) {
		this.paymentFrequencies = paymentFrequencies;
	}

	public void setPaymentFrequency(PaymentFrequencyOption option) {
		PaymentFrequency value = option == null ? null : option.getValue();
		if (arrangement != null) {
			arrangement.setPaymentFrequency(value);

		}
	}

	public void setPaymentMethod(PaymentMethod paymentMethod) {
		if (arrangement != null) {
			arrangement.setPaymentMethod(paymentMethod);

		}
	}

	public String getChecksum() {
		return arrangement.getChecksum();
	}

	public void setChecksum(String checksum) {
		arrangement.setChecksum(checksum);
	}

	public void setPaymentMethods(List<PaymentMethod> paymentMethods) {
		this.paymentMethods = paymentMethods;
	}

	public void setPolling(boolean polling) {
		this.polling = polling;
	}

	public void setTermsAndConditionsAccepted(Boolean termsAndConditionsAccepted) {
		this.termsAndConditionsAccepted = termsAndConditionsAccepted;
	}

	public void setUserDetails(UserDetailsImpl userDetails) {
		this.userDetails = userDetails;
	}

	public void validateConfirmEmailAddress(FacesContext context, UIComponent component, Object value)
			throws ValidatorException {
		if (value instanceof String) {
			String confirmEmail = (String) value;
			String emailAddress = getEmailAddress();
			if (!confirmEmail.equals(emailAddress)) {
				throw new ValidatorException(new FacesMessage("You must provide a matching e-mail address."));
			}
		}
	}

	public String getConfirmLogoutText() {
		return confirmLogoutText;
	}

	public void setConfirmLogoutText(String confirmLogoutText) {
		this.confirmLogoutText = confirmLogoutText;
	}

	public MessageStatus getContactDetailsUpdatedMessage() {
		return contactDetailsUpdatedMessage;
	}

	public void setContactDetailsUpdatedMessage(MessageStatus contactDetailsUpdatedMessage) {
		this.contactDetailsUpdatedMessage = contactDetailsUpdatedMessage;
	}

	public MessageStatus getPaymentMethodUpdatedMessage() {
		return paymentMethodUpdatedMessage;
	}

	public void setPaymentMethodUpdatedMessage(MessageStatus paymentMethodUpdatedMessage) {
		this.paymentMethodUpdatedMessage = paymentMethodUpdatedMessage;
	}

	public MessageStatus getPaymentArrangementActivatedMessage() {
		return paymentArrangementActivatedMessage;
	}

	public void setPaymentArrangementActivatedMessage(MessageStatus paymentArrangementActivatedMessage) {
		this.paymentArrangementActivatedMessage = paymentArrangementActivatedMessage;
	}

	public boolean isDisplayFirstInstalmentDateCalendar() {
		return displayFirstInstalmentDateCalendar;
	}

	public void setDisplayFirstInstalmentDateCalendar(boolean displayFirstInstalmentDateCalendar) {
		this.displayFirstInstalmentDateCalendar = displayFirstInstalmentDateCalendar;
	}

	public boolean isDisplayLastInstalmentDateCalendar() {
		return displayLastInstalmentDateCalendar;
	}

	public void setDisplayLastInstalmentDateCalendar(boolean displayLastInstalmentDateCalendar) {
		this.displayLastInstalmentDateCalendar = displayLastInstalmentDateCalendar;
	}

	public boolean isFrequencyInError() {
		return frequencyInError;
	}

	public void setFrequencyInError(boolean frequencyInError) {
		this.frequencyInError = frequencyInError;
	}

	public boolean isHideStepInformationText() {
		return hideStepInformationText;
	}

	public void setHideStepInformationText(boolean hideStepInformationText) {
		this.hideStepInformationText = hideStepInformationText;
	}

}