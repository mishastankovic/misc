package au.gov.vic.sro.payment.arrangements.web.servlet;

import static java.lang.Boolean.TRUE;
import static javax.servlet.http.HttpServletResponse.SC_INTERNAL_SERVER_ERROR;
import static javax.servlet.http.HttpServletResponse.SC_OK;
import static org.apache.commons.collections4.MapUtils.emptyIfNull;

import java.io.IOException;
import java.io.Serializable;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import au.gov.vic.sro.payment.arrangements.dto.SaveAccountRequest;
import au.gov.vic.sro.payment.arrangements.dto.SaveAccountResponse;
import au.gov.vic.sro.payment.arrangements.service.PaymentArrangementsService;
import au.gov.vic.sro.payment.arrangements.service.QuickVaultService;
import au.gov.vic.sro.payment.arrangements.service.ServiceLocator;

public class QuickVaultRegistrationNotificationServlet extends HttpServlet implements Serializable {
	private static final long serialVersionUID = -5831327368273541294L;
	private static Logger log = Logger.getLogger(QuickVaultRegistrationNotificationServlet.class);
	private ServiceLocator serviceLocator = new ServiceLocator();

	public QuickVaultRegistrationNotificationServlet() {
		super();
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			// Receive request from QuickVault.
			Map<String, String[]> parameters = emptyIfNull(request.getParameterMap());
			SaveAccountRequest saveAccountRequest = getQuickVaultService().getSaveAccountRequest(parameters);
			log.info("QuickVault real time notification.");

			// Save to eSys.
			SaveAccountResponse saveAccountResponse = getPaymentArrangementsService().saveAccount(saveAccountRequest);
			if (log.isDebugEnabled()) {
				log.debug(String.format("saveAccountResponse=%s", saveAccountResponse));
			}

			if (TRUE.equals(saveAccountResponse.getSaved())) {
				// Send response to QuickVault - 200 OK
				response.setStatus(SC_OK);
			} else {
				String message =
						String.format("Unable to save account token: saveAccountRequest=%s saveAccountResponse=%s",
								saveAccountRequest, saveAccountResponse);
				log.warn(message);
				// Send response to QuickVault - 500 Server Error
				response.sendError(SC_INTERNAL_SERVER_ERROR, message);
			}
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			// Send response to QuickVault - 500 Server Error
			throw new ServletException(e);
		}
	}

	protected QuickVaultService getQuickVaultService() {
		return serviceLocator.getQuickVaultService(getServletContext());
	}

	protected PaymentArrangementsService getPaymentArrangementsService() {
		return serviceLocator.getPaymentArrangementsService(getServletContext());
	}

}
