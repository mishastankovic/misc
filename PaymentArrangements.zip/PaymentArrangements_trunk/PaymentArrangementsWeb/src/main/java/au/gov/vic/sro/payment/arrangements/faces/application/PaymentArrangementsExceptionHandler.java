package au.gov.vic.sro.payment.arrangements.faces.application;

import java.io.IOException;
import java.util.Date;
import java.util.Iterator;

import javax.faces.FacesException;
import javax.faces.application.NavigationHandler;
import javax.faces.context.ExceptionHandler;
import javax.faces.context.FacesContext;
import javax.faces.event.ExceptionQueuedEvent;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.commons.lang3.time.FastDateFormat;
import org.apache.log4j.Logger;
import org.primefaces.application.exceptionhandler.ExceptionInfo;
import org.primefaces.application.exceptionhandler.PrimeExceptionHandler;

public class PaymentArrangementsExceptionHandler extends PrimeExceptionHandler {
	private static final Logger log = Logger.getLogger(PaymentArrangementsExceptionHandler.class);
	private static final FastDateFormat DATE_FORMAT = FastDateFormat.getInstance("ddHHmmss");
	private static final String LOGIN_EXPIRED = "/faces/public/login.xhtml?faces-redirect=true&expired=true";

	public PaymentArrangementsExceptionHandler(ExceptionHandler wrapped) {
		super(wrapped);
	}

	@Override
	protected ExceptionInfo createExceptionInfo(Throwable rootCause) throws IOException {
		PaymentArrangementsExceptionInfo info =
				new PaymentArrangementsExceptionInfo(super.createExceptionInfo(rootCause));

		String errorId = DATE_FORMAT.format(new Date()) + rootCause.hashCode() % 100;
		log.error("Error ID : " + errorId + " Full Stack Trace: " + ExceptionUtils.getStackTrace(rootCause));

		info.setErrorId(errorId);
		return info;
	}

	@Override
	public void handle() throws FacesException {

		FacesContext context = FacesContext.getCurrentInstance();

		if (context == null || context.getResponseComplete()) {
			return;
		}

		if (!isValidSession(context) && context.getPartialViewContext().isAjaxRequest()) {
			NavigationHandler navHandler = context.getApplication().getNavigationHandler();
			try {
				navHandler.handleNavigation(context, null, LOGIN_EXPIRED);
			} finally {
				context.responseComplete();
			}
			return;
		}
		Iterable<ExceptionQueuedEvent> exceptionQueuedEvents = getUnhandledExceptionQueuedEvents();
		if (exceptionQueuedEvents != null && exceptionQueuedEvents.iterator() != null) {
			Iterator<ExceptionQueuedEvent> unhandledExceptionQueuedEvents =
					getUnhandledExceptionQueuedEvents().iterator();

			if (unhandledExceptionQueuedEvents.hasNext()) {
				try {
					Throwable throwable = unhandledExceptionQueuedEvents.next().getContext().getException();

					unhandledExceptionQueuedEvents.remove();

					Throwable rootCause = getRootCause(throwable);
					ExceptionInfo info = createExceptionInfo(rootCause);

					if (isLogException(context, rootCause)) {
						logException(rootCause);

					} else {
						NavigationHandler navHandler = context.getApplication().getNavigationHandler();
						try {
							navHandler.handleNavigation(context, null,
									"/faces/public/login.xhtml?faces-redirect=true&expired=true");
						} finally {
							context.responseComplete();
						}

						return;
					}

					if (context.getPartialViewContext().isAjaxRequest()) {
						handleAjaxException(context, rootCause, info);
					} else {
						handleRedirect(context, rootCause, info, false);
					}

				} catch (Exception ex) {
					log.error("Could not handle exception!", ex);
				}
			}

			while (unhandledExceptionQueuedEvents.hasNext()) {
				// Any remaining unhandled exceptions are not interesting. First fix the first.
				unhandledExceptionQueuedEvents.next();
				unhandledExceptionQueuedEvents.remove();
			}
		}
	}

	private boolean isValidSession(FacesContext context) {
		HttpServletRequest httpRequest = (HttpServletRequest) context.getExternalContext().getRequest();
		HttpSession session = httpRequest.getSession(false);

		if (httpRequest.getRequestedSessionId() == null || !httpRequest.isRequestedSessionIdValid()) {
			log.debug("Session timed out or no session");
			return false;
		}

		String remoteUser = httpRequest.getRemoteUser();
		if (remoteUser == null) {
			log.warn("Attempt to access page which should be protected by web.xml config: "
					+ httpRequest.getRequestURI());
			return false;
		}

		if (session == null) {
			log.debug("Session timed out - no session");
			return false;
		}

		return true;
	}
}
