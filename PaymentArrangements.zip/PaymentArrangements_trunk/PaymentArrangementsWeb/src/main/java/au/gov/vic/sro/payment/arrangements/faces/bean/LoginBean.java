package au.gov.vic.sro.payment.arrangements.faces.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import au.gov.vic.sro.payment.arrangements.faces.model.LoginPageModel;
import au.gov.vic.sro.payment.arrangements.model.LiabilityType;
import au.gov.vic.sro.payment.arrangements.model.RevenueLine;

@ViewScoped
@ManagedBean
public class LoginBean extends AbstractManagedBean implements Serializable {
	private static final long serialVersionUID = -5712746037042528322L;
	private LoginPageModel pageModel = new LoginPageModel();

	public LoginPageModel getPageModel() {
		return pageModel;
	}

	public void setPageModel(LoginPageModel pageModel) {
		this.pageModel = pageModel;
	}

	@PostConstruct
	public void initialise() {
	}

	public void onRevenueLineChange() {
		String revenueLineCode = pageModel.getRevenueLineCode();
		RevenueLine revenueLine = RevenueLine.fromCode(revenueLineCode);
		List<LiabilityType> liabilityTypes = new ArrayList<LiabilityType>();
		switch (revenueLine) {
		case LAND_TAX:
			liabilityTypes.addAll(Arrays.asList(LiabilityType.ASSESSMENT));
			break;
		case VACANT_LAND_TAX:
			liabilityTypes.addAll(Arrays.asList(LiabilityType.ASSESSMENT));
			break;
		default:
			liabilityTypes.addAll(Arrays.asList(LiabilityType.values()));
			break;
		}
	}

}
