package au.gov.vic.sro.payment.arrangements.faces.validator;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.component.UIInput;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

public class RequiredCheckboxValidator implements Validator {

	@Override
	public void validate(FacesContext context, UIComponent component, Object value) throws ValidatorException {
		if (value.equals(Boolean.FALSE)) {
			String requiredMessage = ((UIInput) component).getRequiredMessage();

			if (requiredMessage == null) {
				Object label = component.getAttributes().get("label");
				if (label == null || (label instanceof String && ((String) label).length() == 0)) {
					label = component.getValueExpression("label");
				}
				if (label == null) {
					label = component.getClientId(context);
				}
				requiredMessage = "You must agree to the terms and conditions to proceed.";
			}

			throw new ValidatorException(
					new FacesMessage(FacesMessage.SEVERITY_ERROR, requiredMessage, requiredMessage));
		}
	}

}
