package au.gov.vic.sro.payment.arrangements.faces.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import au.gov.vic.sro.payment.arrangements.model.LiabilityType;
import au.gov.vic.sro.payment.arrangements.model.RevenueLine;

public class LoginPageModel extends AbstractPageModel implements Serializable {
	private static final String LOGIN_LIABILITY_ID = "login_liability_id";
	private static final long serialVersionUID = 3047850881498610583L;
	private String customerNumber;
	private String liabilityReference;
	private LiabilityType liabilityType = LiabilityType.ASSESSMENT;
	private List<LiabilityType> liabilityTypes = new ArrayList<LiabilityType>(Arrays.asList(LiabilityType.values()));
	private RevenueLine revenueLine = RevenueLine.LAND_TAX;

	public String getCustomerNumber() {
		return customerNumber;
	}

	public String getLiabilityReference() {
		return liabilityReference;
	}

	public String getLiabilityReferenceLabel() {

		if (liabilityType != null) {
			switch (liabilityType) {
			case ASSESSMENT:
				return "Assessment number";
			default:
				break;
			}
		}
		return getResource(LOGIN_LIABILITY_ID);
	}

	public LiabilityType getLiabilityType() {
		return liabilityType;
	}

	public String getLiabilityTypeCode() {
		return liabilityType != null ? liabilityType.getCode() : null;
	}

	public List<LiabilityType> getLiabilityTypes() {
		return liabilityTypes;
	}

	public RevenueLine getRevenueLine() {
		return revenueLine;
	}

	public String getRevenueLineCode() {
		return revenueLine != null ? revenueLine.getCode() : null;
	}

	public boolean isLiabilityTypeDisabled() {
		return !(LiabilityType.values().length > 1);
	}

	public boolean isRevenueLineDisabled() {
		return !(RevenueLine.values().length > 1);
	}

	public void setCustomerNumber(String customerNumber) {
		this.customerNumber = customerNumber;
	}

	public void setLiabilityReference(String liabilityReference) {
		this.liabilityReference = liabilityReference;
	}

	public void setLiabilityTypeCode(String liabilityTypeCode) {
		liabilityType = LiabilityType.fromCode(liabilityTypeCode);
	}

	public void setLiabilityTypes(List<LiabilityType> liabilityTypes) {
		this.liabilityTypes = liabilityTypes;
	}

	public void setRevenueLineCode(String revenueLineCode) {
		revenueLine = RevenueLine.fromCode(revenueLineCode);
	}
}
