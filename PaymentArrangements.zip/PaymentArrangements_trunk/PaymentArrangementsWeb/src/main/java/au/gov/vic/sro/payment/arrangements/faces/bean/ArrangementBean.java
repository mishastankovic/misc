package au.gov.vic.sro.payment.arrangements.faces.bean;

import static java.lang.Boolean.TRUE;

import java.io.IOException;
import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.application.FacesMessage.Severity;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.ValidatorException;

import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.log4j.Logger;
import org.primefaces.context.RequestContext;
import org.primefaces.event.SelectEvent;

import au.gov.vic.sro.payment.arrangements.dto.CalculateScheduleResponse;
import au.gov.vic.sro.payment.arrangements.dto.CancelArrangementResponse;
import au.gov.vic.sro.payment.arrangements.dto.FindArrangementResponse;
import au.gov.vic.sro.payment.arrangements.dto.GetConfirmCancelTextResponse;
import au.gov.vic.sro.payment.arrangements.dto.GetDefaultDatesResponse;
import au.gov.vic.sro.payment.arrangements.dto.GetFrequenciesResponse;
import au.gov.vic.sro.payment.arrangements.dto.SaveArrangementResponse;
import au.gov.vic.sro.payment.arrangements.dto.SaveContactsResponse;
import au.gov.vic.sro.payment.arrangements.faces.model.ArrangementPageModel;
import au.gov.vic.sro.payment.arrangements.faces.model.ArrangementPageModel.Option;
import au.gov.vic.sro.payment.arrangements.faces.model.ArrangementPageModel.PaymentFrequencyOption;
import au.gov.vic.sro.payment.arrangements.faces.util.MessageStatus;
import au.gov.vic.sro.payment.arrangements.faces.util.MessageUtil;
import au.gov.vic.sro.payment.arrangements.model.Arrangement;
import au.gov.vic.sro.payment.arrangements.model.ArrangementStatus;
import au.gov.vic.sro.payment.arrangements.model.Contact;
import au.gov.vic.sro.payment.arrangements.model.Instalment;
import au.gov.vic.sro.payment.arrangements.model.LiabilityType;
import au.gov.vic.sro.payment.arrangements.model.Message;
import au.gov.vic.sro.payment.arrangements.model.PaymentFrequency;
import au.gov.vic.sro.payment.arrangements.model.PaymentMethod;
import au.gov.vic.sro.payment.arrangements.model.RevenueLine;
import au.gov.vic.sro.payment.arrangements.service.PaymentArrangementsService;
import au.gov.vic.sro.payment.arrangements.service.UserDetailsImpl;
import au.gov.vic.sro.payment.quickstream3.QuickstreamConstants;

@ViewScoped
@ManagedBean
public class ArrangementBean extends AbstractManagedBean implements Serializable {
	private static enum POLL_TYPE {
		CREATE,
		UPDATE
	}

	private enum REGISTRATION_ACTION {
		CANCELLED,
		REGISTERED
	}

	private static final String ARRANGEMENT_CANNOT_CANCEL = "arrangement_notification_arrangement_cannot_cancel";
	private static final String ARRANGEMENT_CANNOT_CREATE = "arrangement_notification_arrangement_cannot_create";
	private static final String RESELECT_PAYMENT_FREQUENCY = "arrangement_reselect_payment_frequency";
	private static final String ARRANGEMENT_CONTACT_DETAILS_NOT_SAVED =
			"arrangement_notification_arrangement_contact_details_not_saved";
	private static final String ARRANGEMENT_LOGOUT_PENDING_WARNING = "arrangement_logout_pending_warning";
	private static final String ARRANGEMENT_NO_PAYMENT_FREQUENCIES =
			"arrangement_notification_arrangement_no_payment_frequencies";
	private static final String ARRANGEMENT_NO_SCHEDULE = "arrangement_notification_arrangement_no_schedule";
	private static final String ARRANGEMENT_NOT_CANCELLED = "arrangement_notification_arrangement_not_cancelled";
	private static final String ARRANGEMENT_NOT_SAVED = "arrangement_notification_arrangement_not_saved";
	private static final String ARRANGEMENT_VALIDATION_END_DATE_REQUIRED = "arrangement_validation_end_date_required";
	private static final String ARRANGEMENT_VALIDATION_START_DATE_REQUIRED =
			"arrangement_validation_start_date_required";
	private static final String ASSESSMENT_NO_LONGER_ELIGIBLE =
			"arrangement_notification_assessment_no_longer_eligible";
	private static final String ASSESSMENT_NOT_ELIGIBLE = "arrangement_notification_assessment_not_eligible";
	private static final String FORM = "form";
	private static final String FORM_ARRANGEMENT_PANEL = "form:arrangementPanel";
	private static final String FORM_CONTACT_PANEL = "form:contactPanel";
	private static Logger log = Logger.getLogger(ArrangementBean.class);
	private static final String LOGOUT_URL = "/pao/j_spring_security_logout";
	private static final String PARAM_ACTION_CANCELLED = "Cancelled";
	private static final String PARAM_ACTION_REGISTERED = "Registered";
	private static final String PLEASE_WAIT = "Please wait...";
	private static final String SHOW_FIRST_INSTALMENT_DATE_CALENDAR = "showFirstInstalmentDateCalendar";
	private static final String SHOW_LAST_INSTALMENT_DATE_CALENDAR = "showLastInstalmentDateCalendar";
	private static final long serialVersionUID = -5712746037042528322L;
	private REGISTRATION_ACTION action;

	private ArrangementPageModel pageModel = new ArrangementPageModel();

	private String paymentMethod;

	private boolean paymentMethodUpdated;

	private POLL_TYPE pollType;

	private CalculateScheduleResponse callCalculateSchedule(String customerId, RevenueLine revenueLine,
			LiabilityType liabilityType, String liabilityId, Date startDate, Date endDate,
			PaymentFrequency paymentFrequency, PaymentMethod paymentMethod) {
		PaymentArrangementsService service = getServiceLocator().getPaymentArrangementsService();
		CalculateScheduleResponse response = service.calculateSchedule(customerId, revenueLine, liabilityType,
				liabilityId, startDate, endDate, paymentFrequency, paymentMethod);
		MessageUtil.checkFatalErrors(response.getMessages());
		return response;
	}

	private CancelArrangementResponse callCancelArrangement(BigInteger arrangementId, Integer arrangementVersion) {
		PaymentArrangementsService service = getServiceLocator().getPaymentArrangementsService();
		CancelArrangementResponse response = service.cancelArrangement(arrangementId, arrangementVersion);
		MessageUtil.checkFatalErrors(response.getMessages());
		return response;
	}

	private FindArrangementResponse callFindArrangement(String customerId, RevenueLine revenueLine,
			LiabilityType liabilityType, String liabilityId) {
		PaymentArrangementsService service = getServiceLocator().getPaymentArrangementsService();
		FindArrangementResponse response = service.findArrangement(customerId, revenueLine, liabilityType, liabilityId);
		MessageUtil.checkFatalErrors(response.getMessages());
		return response;
	}

	private GetConfirmCancelTextResponse callGetConfirmCancelText(BigInteger arrangementId,
			Integer arrangementVersion) {
		PaymentArrangementsService service = getServiceLocator().getPaymentArrangementsService();
		GetConfirmCancelTextResponse response = service.getConfirmCancelText(arrangementId, arrangementVersion);
		MessageUtil.checkFatalErrors(response.getMessages());
		return response;
	}

	private GetDefaultDatesResponse callGetDefaultDates(String customerId, RevenueLine revenueLine,
			LiabilityType liabilityType, String liabilityId) {
		PaymentArrangementsService service = getServiceLocator().getPaymentArrangementsService();
		GetDefaultDatesResponse response = service.getDefaultDates(customerId, revenueLine, liabilityType, liabilityId);
		MessageUtil.checkFatalErrors(response.getMessages());
		return response;
	}

	private GetFrequenciesResponse callGetFrequencies(String customerId, RevenueLine revenueLine,
			LiabilityType liabilityType, String liabilityId, Date startDate, Date endDate) {
		PaymentArrangementsService service = getServiceLocator().getPaymentArrangementsService();
		GetFrequenciesResponse response =
				service.getFrequencies(customerId, revenueLine, liabilityType, liabilityId, startDate, endDate);
		MessageUtil.checkFatalErrors(response.getMessages());
		return response;
	}

	private SaveArrangementResponse callSaveArrangement(Arrangement arrangement) {
		PaymentArrangementsService service = getServiceLocator().getPaymentArrangementsService();
		SaveArrangementResponse response = service.saveArrangement(arrangement);
		MessageUtil.checkFatalErrors(response.getMessages());
		return response;
	}

	private SaveContactsResponse callSaveContacts(List<Contact> contacts, String checksum) {
		PaymentArrangementsService service = getServiceLocator().getPaymentArrangementsService();
		SaveContactsResponse response = service.saveContacts(contacts, getPageModel().getChecksum());
		getPageModel().setChecksum(response.getChecksum());
		MessageUtil.checkFatalErrors(response.getMessages());
		return response;
	}

	public void cancelArrangement() {
		Arrangement arrangement = getPageModel().getArrangement();
		BigInteger id = arrangement.getId();
		Integer version = arrangement.getVersion();
		CancelArrangementResponse cancelArrangementResponse = callCancelArrangement(id, version);
		FacesMessage facesMessage = null;
		if (TRUE.equals(cancelArrangementResponse.getCancelled())) {
			getPageModel().setPaymentArrangementActivatedMessage(MessageStatus.CANCELLED);
			refresh();
		} else {
			List<Message> messages = cancelArrangementResponse.getMessages();
			String message = toHTML(MessageUtil.translate(messages));
			facesMessage = new FacesMessage(FacesMessage.SEVERITY_FATAL,
					MessageUtil.getMessageSummary(getResource(ARRANGEMENT_NOT_CANCELLED), messages), message);
			getFacesContext().addMessage(FORM, facesMessage);
		}

		RequestContext rc = RequestContext.getCurrentInstance();
		rc.execute("PF('confirmCancelDialogWV').hide()");
		scrollToForm();
	}

	public void cancelUpdateContact() {
		getPageModel().setEditingContact(false);
		getPageModel().setContactCopy(null);
	}

	public void editContact() {
		resetMessages();
		Contact contact = getPageModel().getFirstContact();
		Contact contactCopy = new Contact(contact);
		getPageModel().setContactCopy(contactCopy);
		getPageModel().setConfirmEmailAddress(contactCopy.getEmailAddress());
		getPageModel().setEditingContact(true);
	}

	public ArrangementPageModel getPageModel() {
		return pageModel;
	}

	@PostConstruct
	public void initialise() {
		action = null;
		paymentMethodUpdated = false;
		Map<String, String> parameters = MapUtils.emptyIfNull(getExternalContext().getRequestParameterMap());
		if (parameters.containsKey(QuickstreamConstants.PARAM_COMMUNITY_CODE)) {
			if (parameters.containsKey(QuickstreamConstants.PARAM_ACTION)) {
				String actionParameter = parameters.get(QuickstreamConstants.PARAM_ACTION);
				log.info(String.format("QuickVault passback. action=%s", actionParameter));
				if (PARAM_ACTION_REGISTERED.equals(actionParameter)) {
					action = REGISTRATION_ACTION.REGISTERED;
					if (parameters.containsKey(QuickstreamConstants.PARAM_PREREGISTRATION_CODE))
						paymentMethod = parameters.get(QuickstreamConstants.PARAM_PREREGISTRATION_CODE);
				} else if (PARAM_ACTION_CANCELLED.equals(actionParameter)) {
					action = REGISTRATION_ACTION.CANCELLED;
				}
			}
		}
		UserDetailsImpl userDetails = getUserDetails();
		getPageModel().setUserDetails(userDetails);
		FindArrangementResponse findArrangementResponse = callFindArrangement(userDetails.getCustomerId(),
				userDetails.getRevenueLine(), userDetails.getLiabilityType(), userDetails.getLiabilityId());
		Arrangement arrangement = findArrangementResponse.getArrangement();
		getPageModel().setArrangement(arrangement);

		paymentMethodUpdated =
				(arrangement.getAccountToken() != null && arrangement.getAccountToken().equals(paymentMethod));

		if (arrangement.getStatus() == null) {
			arrangement.setStatus(ArrangementStatus.PENDING);
			List<Contact> contacts = arrangement.getContacts();
			if (contacts.isEmpty()) {
				Contact contact = new Contact();
				contact.setArrangement(arrangement);
				contacts.add(contact);
			}
		} else if (getPageModel().isPolling()) {
			if (arrangement.getStatus() == ArrangementStatus.ACTIVE && pollType == POLL_TYPE.CREATE) {
				getPageModel().setPaymentArrangementActivatedMessage(MessageStatus.SUCCESS);
				getPageModel().setInformation(null);
				RequestContext rc = RequestContext.getCurrentInstance();
				rc.execute("PF('pollWV').stop()");
				getPageModel().setPolling(false);
				pollType = null;
				paymentMethod = null;
			} else if (paymentMethodUpdated && pollType == POLL_TYPE.UPDATE) {
				getPageModel().setInformation(null);
				getPageModel().setPaymentMethodUpdatedMessage(MessageStatus.SUCCESS);
				RequestContext rc = RequestContext.getCurrentInstance();
				rc.execute("PF('pollWV').stop()");
				getPageModel().setPolling(false);
				pollType = null;
				paymentMethod = null;
			}
		} else if (action == REGISTRATION_ACTION.REGISTERED && !getPageModel().isPolling()) {
			if (arrangement.getStatus() != ArrangementStatus.ACTIVE) {
				pollType = POLL_TYPE.CREATE;
				log.warn(String.format("Quickvault passback has occurred with. status=%s",
						arrangement.getStatus().getLabel()));
				getPageModel().setInformation(PLEASE_WAIT);
				RequestContext rc = RequestContext.getCurrentInstance();
				rc.execute("PF('pollWV').start()");
				getPageModel().setPolling(true);
			} else if (!paymentMethodUpdated) {
				pollType = POLL_TYPE.UPDATE;
				log.warn(String.format("Quickvault passback has occurred with. status=%s",
						arrangement.getStatus().getLabel()));
				getPageModel().setInformation(PLEASE_WAIT);
				RequestContext rc = RequestContext.getCurrentInstance();
				rc.execute("PF('pollWV').start()");
				getPageModel().setPolling(true);
			} else {
				getPageModel().setPaymentMethodUpdatedMessage(MessageStatus.SUCCESS);
				getPageModel().setInformation(null);
			}
		}
		if (getPageModel().isPolling()) return;
		String customerId = getPageModel().getCustomerId();
		RevenueLine revenueLine = getPageModel().getRevenueLine();
		LiabilityType liabilityType = getPageModel().getLiabilityType();
		String liabilityId = getPageModel().getLiabilityId();
		Set<Option> options = getPageModel().getOptions();
		options.clear();
		GetDefaultDatesResponse getDefaultDatesResponse =
				callGetDefaultDates(customerId, revenueLine, liabilityType, liabilityId);
		List<Message> messages = getDefaultDatesResponse.getMessages();
		if (!messages.isEmpty()) {
			String detail = toHTML(MessageUtil.translate(messages));
			if (arrangement.getId() == null) {
				String header = getResource(ASSESSMENT_NOT_ELIGIBLE);
				String message = "<b>" + header + "</b><br /><br />" + detail;
				getPageModel().setInformation(message);
				getPageModel().setHideStepInformationText(true);
			} else {
				if (ArrangementStatus.PENDING.equals(arrangement.getStatus())) {
					getPageModel().setMinStartDate(null);
					getPageModel().setMaxStartDate(null);
					getPageModel().setMinEndDate(null);
					getPageModel().setMaxEndDate(null);
					getPageModel().setArrangementStartDate(null);
					getPageModel().setArrangementEndDate(null);
					String header = getResource(ASSESSMENT_NO_LONGER_ELIGIBLE);
					String message = "<b>" + header + "</b><br /><br />" + detail;
					getPageModel().setInformation(message);
					getPageModel().setHideStepInformationText(true);
				}
			}
		} else {
			if (ArrangementStatus.PENDING.equals(arrangement.getStatus())) {
				options.add(Option.REGISTER_ARRANGEMENT);
				Date minStartDate = getDefaultDatesResponse.getArrangementStartDate();
				Date maxStartDate = getDefaultDatesResponse.getArrangementMaxStartDate();
				Calendar instance = Calendar.getInstance();
				instance.setTime(minStartDate);
				instance.add(Calendar.DATE, 1);
				Date minEndDate = instance.getTime();
				Date maxEndDate = getDefaultDatesResponse.getArrangementEndDate();
				getPageModel().setMinStartDate(minStartDate);
				getPageModel().setMaxStartDate(maxStartDate);
				getPageModel().setMinEndDate(minEndDate);
				getPageModel().setMaxEndDate(maxEndDate);
				Date arrangementStartDate = getPageModel().getArrangementStartDate();
				Date arrangementEndDate = getPageModel().getArrangementEndDate();
				if (arrangementStartDate == null && arrangementEndDate == null
						|| (arrangementStartDate != null && !arrangementStartDate.equals(minStartDate))) {
					getPageModel().setArrangementStartDate(minStartDate);
					getPageModel().setArrangementEndDate(maxEndDate);
					getPageModel().setPaymentFrequency(null);
					getPageModel().setPaymentMethod(null);
				}

			} else {
				options.add(Option.REPLACE_ARRANGEMENT);
			}
		}
		if (ArrangementStatus.ACTIVE.equals(arrangement.getStatus())) {
			options.add(Option.CANCEL_ARRANGEMENT);
			options.add(Option.UPDATE_PAYMENT_REGISTRATION);
			options.add(Option.UPDATE_CONTACT);
			getPageModel().setHideStepInformationText(true);
		}
		if (ArrangementStatus.PENDING.equals(arrangement.getStatus())) {
			updatePaymentFrequencies();
			updateSchedule();
		}
		getPageModel().setConfirmEmailAddress(getPageModel().getEmailAddress());
	}

	public void logout() throws IOException {
		getExternalContext().redirect(LOGOUT_URL);
	}

	public void onEndDateChange() {
		getPageModel().setPaymentFrequency(null);
		updatePaymentFrequencies();
		addFacesMessageToComponent("form:paymentFrequency", FacesMessage.SEVERITY_ERROR, null,
				getResource(RESELECT_PAYMENT_FREQUENCY));
		getPageModel().setFrequencyInError(true);
	}

	public void onEndDateSelect(SelectEvent event) {
		getPageModel().setPaymentFrequency(null);
		updatePaymentFrequencies();
		addFacesMessageToComponent("form:paymentFrequency", FacesMessage.SEVERITY_ERROR, null,
				getResource(RESELECT_PAYMENT_FREQUENCY));
		getPageModel().setFrequencyInError(true);
	}

	public void onPaymentFrequencyChange() {
		updateSchedule();
		getPageModel().setFrequencyInError(false);
	}

	public void onPaymentMethodChange() {
		updateSchedule();
	}

	public void onStartDateChange() {
		getPageModel().setPaymentFrequency(null);
		updatePaymentFrequencies();
		addFacesMessageToComponent("form:paymentFrequency", FacesMessage.SEVERITY_ERROR, null,
				getResource(RESELECT_PAYMENT_FREQUENCY));
		getPageModel().setFrequencyInError(true);
	}

	public void onStartDateSelect(SelectEvent event) {
		getPageModel().setPaymentFrequency(null);
		updatePaymentFrequencies();
		addFacesMessageToComponent("form:paymentFrequency", FacesMessage.SEVERITY_ERROR, null,
				getResource(RESELECT_PAYMENT_FREQUENCY));
		getPageModel().setFrequencyInError(true);
	}

	private void addFacesMessageToComponent(String compName, Severity severity, String msgSummary, String msgDetail) {
		FacesMessage facesMessage = new FacesMessage(severity, msgSummary, msgDetail);
		getFacesContext().addMessage(compName, facesMessage);
	}

	public void prepareCancelConfirmDialog() {
		RequestContext rc = RequestContext.getCurrentInstance();
		if (getPageModel().isEditingContact()) {
			rc.execute("PF('unsavedChangesDialogWV').show()");
		} else {
			resetMessages();
			BigInteger id = getPageModel().getArrangement().getId();
			Integer version = getPageModel().getArrangement().getVersion();
			GetConfirmCancelTextResponse getConfirmCancelTextResponse = callGetConfirmCancelText(id, version);
			List<Message> messages = getConfirmCancelTextResponse.getMessages();
			if (!messages.isEmpty()) {
				String message = toHTML(MessageUtil.translate(messages));
				FacesMessage facesMessage = new FacesMessage(FacesMessage.SEVERITY_FATAL,
						MessageUtil.getMessageSummary(getResource(ARRANGEMENT_CANNOT_CANCEL), messages), message);
				getFacesContext().addMessage(FORM, facesMessage);
				rc.scrollTo(FORM);
			} else {
				String text = getConfirmCancelTextResponse.getText();
				getPageModel().setConfirmCancelText(text);
				rc.execute("PF('confirmCancelDialogWV').show()");
			}
		}
	}

	public void resetMessages() {
		getPageModel().setContactDetailsUpdatedMessage(null);
		getPageModel().setPaymentMethodUpdatedMessage(null);
		getPageModel().setPaymentArrangementActivatedMessage(null);
	}

	public void prepareLogoutConfirmDialog() throws IOException {
		if (getPageModel().isEditingContact() || getPageModel().getOptions().contains(Option.REGISTER_ARRANGEMENT)) {
			RequestContext rc = RequestContext.getCurrentInstance();
			if (getPageModel().isEditingContact())
				rc.execute("PF('unsavedChangesDialogWV').show()");
			else if (getPageModel().getOptions().contains(Option.REGISTER_ARRANGEMENT)) {
				String text = getResource(ARRANGEMENT_LOGOUT_PENDING_WARNING);
				getPageModel().setConfirmLogoutText(text);
				rc.execute("PF('confirmLogoutDialogWV').show()");
			}
		} else
			this.logout();
	}

	public void prepareUpdatePaymentConfirmDialog() throws IOException {
		if (getPageModel().isEditingContact()) {
			RequestContext rc = RequestContext.getCurrentInstance();
			rc.execute("PF('unsavedChangesDialogWV').show()");
		} else
			this.updatePaymentRegistration();
	}

	private void redirectToQuickVault() throws IOException {
		String securityToken = getServiceLocator().getQuickVaultService().getSecurityToken(
				getPageModel().getCustomerId(), getPageModel().getArrangementNumber(),
				getPageModel().getArrangementVersion(), getPageModel().getRevenueLine(),
				getPageModel().getPaymentMethod(), getPageModel().getChecksum());
		String url = getServiceLocator().getQuickVaultService().getBrowserRedirectUrl(securityToken);
		log.info("QuickVault handoff.");
		getExternalContext().redirect(url);
	}

	public void refresh() {
		initialise();
	}

	public void register() throws IOException {
		if (validate()) {
			Arrangement arrangement = getPageModel().getArrangement();
			SaveArrangementResponse response = callSaveArrangement(arrangement);
			if (BooleanUtils.isTrue(response.getSaved())) {
				arrangement.setId(response.getArrangementId());
				arrangement.setVersion(response.getArrangementVersion());
				arrangement.setChecksum(response.getChecksum());
				redirectToQuickVault();
			} else {
				List<Message> messages = response.getMessages();
				String message = toHTML(MessageUtil.translate(messages));
				FacesMessage facesMessage = new FacesMessage(FacesMessage.SEVERITY_FATAL,
						MessageUtil.getMessageSummary(getResource(ARRANGEMENT_NOT_SAVED), messages), message);
				getFacesContext().addMessage(FORM, facesMessage);
				scrollToForm();
			}
		}
	}

	public void replace() throws IOException {
		resetMessages();
		String customerId = getPageModel().getCustomerId();
		RevenueLine revenueLine = getPageModel().getRevenueLine();
		LiabilityType liabilityType = getPageModel().getLiabilityType();
		String liabilityId = getPageModel().getLiabilityId();
		FindArrangementResponse findArrangementResponse =
				callFindArrangement(customerId, revenueLine, liabilityType, liabilityId);
		List<Message> messages = findArrangementResponse.getMessages();
		if (!messages.isEmpty()) {
			String message = toHTML(MessageUtil.translate(messages));
			FacesMessage facesMessage = new FacesMessage(FacesMessage.SEVERITY_FATAL,
					MessageUtil.getMessageSummary(getResource(ARRANGEMENT_CANNOT_CREATE), messages), message);
			getFacesContext().addMessage(FORM, facesMessage);
		} else {
			Arrangement arrangement = findArrangementResponse.getArrangement();
			getPageModel().setArrangement(arrangement);
			GetDefaultDatesResponse getDefaultDatesResponse =
					callGetDefaultDates(customerId, revenueLine, liabilityType, liabilityId);
			Date minStartDate = getDefaultDatesResponse.getArrangementStartDate();
			Date maxStartDate = getDefaultDatesResponse.getArrangementMaxStartDate();
			Calendar instance = Calendar.getInstance();
			instance.setTime(minStartDate);
			instance.add(Calendar.DATE, 1);
			Date minEndDate = instance.getTime();
			Date maxEndDate = getDefaultDatesResponse.getArrangementEndDate();
			getPageModel().setMinStartDate(minStartDate);
			getPageModel().setMaxStartDate(maxStartDate);
			getPageModel().setMinEndDate(minEndDate);
			getPageModel().setMaxEndDate(maxEndDate);
			arrangement.setId(null);
			arrangement.setVersion(null);
			arrangement.setStatus(ArrangementStatus.PENDING);
			arrangement.setStartDate(minStartDate);
			arrangement.setEndDate(maxEndDate);
			updatePaymentFrequencies();
			arrangement.setPaymentFrequency(null);
			arrangement.setPaymentMethod(null);
			List<Contact> contacts = arrangement.getContacts();
			if (contacts.isEmpty()) {
				Contact contact = new Contact();
				contact.setArrangement(arrangement);
				contacts.add(contact);
			} else {
				Contact contact = getPageModel().getFirstContact();
				getPageModel().setConfirmEmailAddress(contact.getEmailAddress());
			}
			arrangement.getInstalments().clear();
			arrangement.setAllInstalmentAmountDollars(null);
			arrangement.setAllInstalmentSurchargeDollars(null);
			arrangement.setAllInstalmentTotalAmountDollars(null);
			getPageModel().getOptions().clear();
			getPageModel().getOptions().add(Option.REGISTER_ARRANGEMENT);
			getPageModel().setTermsAndConditionsAccepted(false);
			getPageModel().setEditingContact(false);
			getPageModel().setDisplayFirstInstalmentDateCalendar(false);
		}
	}

	public void setDisplayFirstInstalmentDateCalendar() {
		getPageModel().setDisplayFirstInstalmentDateCalendar(
				Boolean.valueOf(getParamFromRequestMap(SHOW_FIRST_INSTALMENT_DATE_CALENDAR)));
	}

	public void setDisplayLastInstalmentDateCalendar() {
		getPageModel().setDisplayLastInstalmentDateCalendar(
				Boolean.valueOf(getParamFromRequestMap(SHOW_LAST_INSTALMENT_DATE_CALENDAR)));
	}

	private String getParamFromRequestMap(String paramName) {
		return getFacesContext().getExternalContext().getRequestParameterMap().get(paramName);
	}

	private void scrollToArrangementPanel() {
		RequestContext rc = RequestContext.getCurrentInstance();
		rc.scrollTo(FORM_ARRANGEMENT_PANEL);
	}

	private void scrollToForm() {
		RequestContext rc = RequestContext.getCurrentInstance();
		rc.scrollTo(FORM);
	}

	public void setPageModel(ArrangementPageModel pageModel) {
		this.pageModel = pageModel;
	}

	public void updateContact() {
		resetMessages();
		Contact contact = getPageModel().getFirstContact();
		Contact contactCopy = getPageModel().getContactCopy();
		contact.setType(contactCopy.getType());
		contact.setPersonName(contactCopy.getPersonName());
		contact.setEmailAddress(contactCopy.getEmailAddress());
		contact.setReminderEmails(contactCopy.getReminderEmails());
		contact.setMobilePhone(contactCopy.getMobilePhone());
		List<Contact> contacts = getPageModel().getArrangement().getContacts();
		SaveContactsResponse saveContactsResponse = callSaveContacts(contacts, getPageModel().getChecksum());
		if (saveContactsResponse.getSaved()) {
			getPageModel().setEditingContact(false);
			getPageModel().setContactCopy(null);
			getPageModel().setContactDetailsUpdatedMessage(MessageStatus.SUCCESS);
		} else {
			List<Message> messages = saveContactsResponse.getMessages();
			String message = toHTML(MessageUtil.translate(messages));
			FacesMessage facesMessage = new FacesMessage(FacesMessage.SEVERITY_FATAL,
					MessageUtil.getMessageSummary(getResource(ARRANGEMENT_CONTACT_DETAILS_NOT_SAVED), messages),
					message);
			getFacesContext().addMessage(FORM_CONTACT_PANEL, facesMessage);
		}
	}

	private void updatePaymentFrequencies() {
		getPageModel().setInstalments(new ArrayList<Instalment>());
		getPageModel().setAllInstalmentAmountDollars(null);
		getPageModel().setAllInstalmentSurchargeDollars(null);
		getPageModel().setAllInstalmentTotalAmountDollars(null);
		Date arrangementStartDate = getPageModel().getArrangementStartDate();
		Date arrangementEndDate = getPageModel().getArrangementEndDate();
		if (arrangementStartDate != null && arrangementEndDate != null) {
			String customerId = getPageModel().getCustomerId();
			RevenueLine revenueLine = getPageModel().getRevenueLine();
			LiabilityType liabilityType = getPageModel().getLiabilityType();
			String liabilityId = getPageModel().getLiabilityId();
			GetFrequenciesResponse getFrequenciesResponse = callGetFrequencies(customerId, revenueLine, liabilityType,
					liabilityId, arrangementStartDate, arrangementEndDate);
			List<Message> messages = getFrequenciesResponse.getMessages();
			List<PaymentFrequency> paymentFrequencies = getFrequenciesResponse.getPaymentFrequencies();
			List<PaymentFrequencyOption> options = getPageModel().getPaymentFrequencies();
			for (PaymentFrequencyOption option : options) {
				option.setDisabled(true);
			}
			if (!messages.isEmpty() && paymentFrequencies.isEmpty()) {
				FacesContext context = FacesContext.getCurrentInstance();
				String message = toHTML(MessageUtil.translate(messages));
				FacesMessage facesMessage = new FacesMessage(FacesMessage.SEVERITY_ERROR,
						MessageUtil.getMessageSummary(getResource(ARRANGEMENT_NO_PAYMENT_FREQUENCIES), messages),
						message);
				context.addMessage(FORM_ARRANGEMENT_PANEL, facesMessage);
				scrollToArrangementPanel();
			} else {
				if (!messages.isEmpty()) {
					FacesContext context = FacesContext.getCurrentInstance();
					String message = toHTML(MessageUtil.translate(messages));
					FacesMessage facesMessage = new FacesMessage(FacesMessage.SEVERITY_INFO,
							"Not all payment frequencies are available", message);
					context.addMessage(FORM_ARRANGEMENT_PANEL, facesMessage);
				}
				for (PaymentFrequency paymentFrequency : paymentFrequencies) {
					for (PaymentFrequencyOption option : options) {
						if (option.getValue().equals(paymentFrequency)) {
							option.setDisabled(false);
						}
					}
				}
			}
		}
	}

	public void updatePaymentRegistration() throws IOException {
		if (validate()) {
			redirectToQuickVault();
		}
	}

	private void updateSchedule() {
		getPageModel().setInstalments(new ArrayList<Instalment>());
		getPageModel().setAllInstalmentAmountDollars(null);
		getPageModel().setAllInstalmentTotalAmountDollars(null);
		getPageModel().setAllInstalmentSurchargeDollars(null);
		String customerId = getPageModel().getCustomerId();
		RevenueLine revenueLine = getPageModel().getRevenueLine();
		LiabilityType liabilityType = getPageModel().getLiabilityType();
		String liabilityId = getPageModel().getLiabilityId();
		Date startDate = getPageModel().getArrangementStartDate();
		Date arrangementEndDate = getPageModel().getArrangementEndDate();
		PaymentFrequencyOption paymentFrequencyOption = getPageModel().getPaymentFrequency();
		PaymentFrequency paymentFrequency = paymentFrequencyOption == null ? null : paymentFrequencyOption.getValue();
		PaymentMethod paymentMethod = getPageModel().getPaymentMethod();
		if (startDate != null && arrangementEndDate != null && paymentFrequency != null && paymentMethod != null) {
			CalculateScheduleResponse calculateScheduleResponse = callCalculateSchedule(customerId, revenueLine,
					liabilityType, liabilityId, startDate, arrangementEndDate, paymentFrequency, paymentMethod);
			List<Message> messages = calculateScheduleResponse.getMessages();
			if (!messages.isEmpty()) {
				getPageModel().setPaymentFrequency(null);
				getPageModel().setPaymentMethod(null);
				FacesContext context = FacesContext.getCurrentInstance();
				String message = toHTML(MessageUtil.translate(messages));
				FacesMessage facesMessage = new FacesMessage(FacesMessage.SEVERITY_ERROR,
						MessageUtil.getMessageSummary(getResource(ARRANGEMENT_NO_SCHEDULE), messages), message);
				context.addMessage(FORM_ARRANGEMENT_PANEL, facesMessage);
				scrollToArrangementPanel();
			} else {
				BigDecimal allInstalmentAmountDollars = calculateScheduleResponse.getAllInstalmentAmountDollars();
				BigDecimal allInstalmentSurchargeDollars = calculateScheduleResponse.getAllInstalmentSurchargeDollars();
				BigDecimal allInstalmentTotalAmountDollars =
						calculateScheduleResponse.getAllInstalmentTotalAmountDollars();
				List<Instalment> instalments = calculateScheduleResponse.getInstalments();
				getPageModel().setAllInstalmentAmountDollars(allInstalmentAmountDollars);
				getPageModel().setAllInstalmentSurchargeDollars(allInstalmentSurchargeDollars);
				getPageModel().setAllInstalmentTotalAmountDollars(allInstalmentTotalAmountDollars);
				getPageModel().setInstalments(instalments);
			}
		}
	}

	public boolean validate() {
		if (getPageModel().getPaymentFrequency() == null) {
			return false;
		}
		return true;
	}

	public String getFormattedStartDate() {
		return getFormattedDate(getPageModel().getArrangementStartDate());
	}

	public String getFormattedMaxStartDate() {
		return getFormattedDate(getPageModel().getMaxStartDate());
	}

	public String getFormattedMaxLastDate() {
		return getFormattedDate(getPageModel().getMaxEndDate());
	}

	public String getFormattedDate(Date startDate) {
		return startDate == null ? "" : dateFormat.format(startDate);
	}

	public void validateEndDate(FacesContext context, UIComponent component, Object value) throws ValidatorException {
		try {
			if (value instanceof Date) {
				Date endDate = (Date) value;
				getPageModel().setArrangementEndDate(endDate);
				Date startDate = getPageModel().getArrangementStartDate();
				Date maxEndDate = getPageModel().getMaxEndDate();
				if (startDate != null && !endDate.after(startDate)) {
					throw new ValidatorException(
							new FacesMessage("Your end date must be after " + getFormattedDate(startDate) + "."));
				} else if (maxEndDate != null && endDate.after(maxEndDate)) {
					throw new ValidatorException(
							new FacesMessage("Your end date must not be after " + getFormattedDate(maxEndDate) + "."));
				}
			} else {
				getPageModel().setArrangementEndDate(null);
				throw new ValidatorException(new FacesMessage(getResource(ARRANGEMENT_VALIDATION_END_DATE_REQUIRED)));
			}
		} catch (ValidatorException e) {
			getPageModel().setPaymentFrequency(null);
			getPageModel().setInstalments(new ArrayList<Instalment>());
			getPageModel().setAllInstalmentAmountDollars(null);
			getPageModel().setAllInstalmentSurchargeDollars(null);
			getPageModel().setAllInstalmentTotalAmountDollars(null);
			List<PaymentFrequencyOption> options = getPageModel().getPaymentFrequencies();
			for (PaymentFrequencyOption option : options)
				option.setDisabled(true);
			throw e;
		}
	}

	public void validateStartDate(FacesContext context, UIComponent component, Object value) throws ValidatorException {
		try {
			if (value instanceof Date) {
				Date startDate = (Date) value;
				getPageModel().setArrangementStartDate(startDate);
				Date minStartDate = getPageModel().getMinStartDate();
				Date maxStartDate = getPageModel().getMaxStartDate();
				Date endDate = getPageModel().getArrangementEndDate();
				if (minStartDate != null && startDate.before(minStartDate)) {
					String formattedMinStartDate = dateFormat.format(minStartDate);
					throw new ValidatorException(
							new FacesMessage("Your start date must not be before " + formattedMinStartDate + "."));
				} else if (maxStartDate != null && startDate.after(maxStartDate)) {
					String formattedMaxStartDate = dateFormat.format(maxStartDate);
					throw new ValidatorException(
							new FacesMessage("Your start date must not be after " + formattedMaxStartDate + "."));
				} else if (endDate != null && !startDate.before(endDate)) {
					String formattedEndDate = dateFormat.format(endDate);
					throw new ValidatorException(
							new FacesMessage("Your start date must be before " + formattedEndDate + "."));
				}
			} else {
				getPageModel().setArrangementStartDate(null);
				throw new ValidatorException(new FacesMessage(getResource(ARRANGEMENT_VALIDATION_START_DATE_REQUIRED)));
			}
		} catch (ValidatorException e) {
			getPageModel().setPaymentFrequency(null);
			getPageModel().setInstalments(new ArrayList<Instalment>());
			getPageModel().setAllInstalmentAmountDollars(null);
			getPageModel().setAllInstalmentSurchargeDollars(null);
			getPageModel().setAllInstalmentTotalAmountDollars(null);
			List<PaymentFrequencyOption> options = getPageModel().getPaymentFrequencies();
			for (PaymentFrequencyOption option : options)
				option.setDisabled(true);
			throw e;
		}
	}

}