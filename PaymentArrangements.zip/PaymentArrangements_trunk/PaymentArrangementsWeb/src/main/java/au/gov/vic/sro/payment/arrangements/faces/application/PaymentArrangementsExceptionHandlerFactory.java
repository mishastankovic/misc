package au.gov.vic.sro.payment.arrangements.faces.application;

import javax.faces.context.ExceptionHandler;
import javax.faces.context.ExceptionHandlerFactory;

import org.primefaces.application.exceptionhandler.PrimeExceptionHandlerFactory;

public class PaymentArrangementsExceptionHandlerFactory extends PrimeExceptionHandlerFactory {

	public PaymentArrangementsExceptionHandlerFactory(ExceptionHandlerFactory wrapped) {
		super(wrapped);
	}

	@Override
	public ExceptionHandler getExceptionHandler() {
		return new PaymentArrangementsExceptionHandler(getWrapped().getExceptionHandler());
	}

}
