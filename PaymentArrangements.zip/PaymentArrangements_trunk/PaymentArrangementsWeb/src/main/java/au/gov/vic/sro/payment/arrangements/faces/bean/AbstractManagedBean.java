package au.gov.vic.sro.payment.arrangements.faces.bean;

import java.text.Format;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import org.apache.commons.lang3.time.FastDateFormat;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import au.gov.vic.sro.payment.arrangements.model.Message;
import au.gov.vic.sro.payment.arrangements.service.ServiceLocator;
import au.gov.vic.sro.payment.arrangements.service.UserDetailsImpl;

public abstract class AbstractManagedBean {

	private ServiceLocator serviceLocator;
	private static final String RESOURCE_BUNDLE_NAME = "PaymentArrangementsResources";
	protected Format dateFormat = FastDateFormat.getInstance("dd/MM/yyyy");

	protected ServiceLocator getServiceLocator() {
		if (serviceLocator == null) {
			serviceLocator = new ServiceLocator();
		}
		return serviceLocator;
	}

	protected FacesContext getFacesContext() {
		return FacesContext.getCurrentInstance();
	}

	protected ExternalContext getExternalContext() {
		return getFacesContext().getExternalContext();
	}

	public SecurityContext getSecurityContext() {
		return SecurityContextHolder.getContext();
	}

	public UserDetailsImpl getUserDetails() {
		Authentication authentication = getSecurityContext().getAuthentication();
		return authentication == null ? null : (UserDetailsImpl) authentication.getPrincipal();
	}

	public List<Message> toMessageList(String... messages) {
		List<Message> messageList = new ArrayList<Message>();
		for (String text : messages) {
			Message message = new Message();
			message.setText(text);
			messageList.add(message);
		}
		return messageList;
	}

	public String toHTML(List<Message> messages) {
		String html = "<p>";
		for (int i = 0; i < messages.size(); i++) {
			Message message = messages.get(i);
			html += message.getText();
			if (i < messages.size() - 1) {
				html += "<br />";
			}
		}
		html += "</p>";
		return html;
	}

	public static String getResource(String resourceID) {
		return ResourceBundle.getBundle(RESOURCE_BUNDLE_NAME).getString(resourceID);
	}
}
