package au.gov.vic.sro.payment.arrangements.web.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

public class SessionFilter implements Filter {

	private static final Logger log = Logger.getLogger(SessionFilter.class);

	private static final String SESSION_EXPIRED = "/faces/public/login.xhtml?faces-redirect=true&expired=true";

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException,
			ServletException {

		if (request instanceof HttpServletRequest) {

			HttpServletRequest httpRequest = (HttpServletRequest) request;
			HttpServletResponse httpResponse = (HttpServletResponse) response;
			String contextPath = httpRequest.getContextPath();

			HttpSession session = httpRequest.getSession(false);

			if (httpRequest.getRequestedSessionId() == null || !httpRequest.isRequestedSessionIdValid()) {
				if (log.isDebugEnabled()) {
					log.debug("Session timed out or no session");
				}
				httpResponse.sendRedirect(contextPath + SESSION_EXPIRED);
				return;
			}

			if (session == null) {
				if (log.isDebugEnabled()) {
					log.debug("Session timed out - no session");
				}
				httpResponse.sendRedirect(contextPath + SESSION_EXPIRED);
				return;
			}
		}

		chain.doFilter(request, response);
	}

	@Override
	public void destroy() {
	}

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
	}

}
