package au.gov.vic.sro.payment.arrangements.web.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import au.gov.vic.sro.payment.arrangements.service.UserDetailsImpl;
import au.gov.vic.sro.payment.arrangements.util.LogUtil;

/**
 * Log4JFilter updates the log4j parameters, setting the Customer ID and removing it.
 */
public class Log4jFilter implements Filter {
	public static final String CUSTOMER_ID_KEY = "customer";

	@Override
	public void init(final FilterConfig filterConfig) throws ServletException {
	}

	@Override
	public void doFilter(final ServletRequest request, final ServletResponse response, final FilterChain chain)
			throws IOException, ServletException {

		try {
			LogUtil.putCustomerId(getCustomerId());
			chain.doFilter(request, response);
		} finally {
			LogUtil.removeCustomerId();
		}

	}

	protected String getCustomerId() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if (authentication != null && authentication.getPrincipal() instanceof UserDetailsImpl) {
			return ((UserDetailsImpl) authentication.getPrincipal()).getCustomerId();
		}
		return null;
	}

	@Override
	public void destroy() {
	}

}
