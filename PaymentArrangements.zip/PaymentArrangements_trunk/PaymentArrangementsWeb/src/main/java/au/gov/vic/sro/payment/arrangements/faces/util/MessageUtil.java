package au.gov.vic.sro.payment.arrangements.faces.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import au.gov.vic.sro.payment.arrangements.model.Message;

public class MessageUtil {
	private static final Set<Integer> changeHeaderErrorCodes =
			new TreeSet<Integer>(Arrays.asList(10, 14, 15, 16, 17, 18));
	private static final Set<Integer> fatalErrorCodes = new TreeSet<Integer>(Arrays.asList(7, 9, 11, 12, 19, 20, 22, 23,
			25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 38, 39, 40, 41, 42, 49, 50, 57, 58, 62, 64));

	private static final Set<Integer> ignorableErrorCodes = new TreeSet<Integer>(Arrays.asList(10, 14, 15, 16, 55));

	public static void checkFatalErrors(List<Message> messages) {
		for (Message message : messages) {
			if (fatalErrorCodes.contains(message.getCode())) {
				throw new IllegalStateException(String.format("messages=%s", messages));
			}
		}
	};

	public static boolean contains(Collection<Message> messages, Integer type) {
		Iterator<Message> iterator = messages.iterator();
		while (iterator.hasNext()) {
			Message next = iterator.next();
			if (next.getCode() == type) return true;
		}
		return false;
	}

	public static String getMessageSummary(String messageSummary, List<Message> messages) {
		if (messages != null) {
			for (Message message : messages) {
				Integer code = message.getCode();
				if (changeHeaderErrorCodes.contains(code))
					return "This assessment is not eligible for a payment arrangement.";
			}
		}
		return messageSummary;
	}

	public static List<Message> translate(List<Message> messages) {
		List<Message> translatedMessages = new ArrayList<Message>();
		for (Message message : messages) {
			Integer code = message.getCode();
			if (!ignorableErrorCodes.contains(code)) translatedMessages.add(translate(message));
		}
		return translatedMessages;
	}

	private static Message translate(Message message) {
		if (message != null) {
			Integer code = message.getCode();
			String text = message.getText();
			if (code == 21) {
				text = "Contact details cannot be amended when the payment arrangement is cancelled or completed.";
			} else if (code == 55) {
				text = "This assessment is not eligible for a payment arrangement.";
			} else if (code == 56) {
				text = "Payment arrangement does not exist for this revenue type. Please login again with correct details.";
			} else if (code == 61) {
				text = "A payment arrangement cancellation is only allowed for an active payment arrangement.";
			} else if (code == 65 || code == 66) {
				text = "A payment arrangement already exists for this assessment. Please refresh your browser.";
			}
			message.setText(text);
		}
		return message;
	}
}
