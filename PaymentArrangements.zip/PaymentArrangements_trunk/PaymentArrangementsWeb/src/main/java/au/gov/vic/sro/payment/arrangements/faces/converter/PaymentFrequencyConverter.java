package au.gov.vic.sro.payment.arrangements.faces.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;
import javax.faces.convert.FacesConverter;

import au.gov.vic.sro.payment.arrangements.faces.model.ArrangementPageModel.PaymentFrequencyOption;
import au.gov.vic.sro.payment.arrangements.model.PaymentFrequency;

@FacesConverter("paymentFrequencyConverter")
public class PaymentFrequencyConverter implements Converter {

	@Override
	public Object getAsObject(FacesContext arg0, UIComponent arg1, String arg2) throws ConverterException {
		if (arg2 != null) {
			return new PaymentFrequencyOption(PaymentFrequency.fromCode(arg2));
		}
		return null;
	}

	@Override
	public String getAsString(FacesContext arg0, UIComponent arg1, Object arg2) throws ConverterException {
		if (arg2 instanceof PaymentFrequencyOption) {
			return ((PaymentFrequencyOption) arg2).getCode();
		}
		return null;
	}

}
