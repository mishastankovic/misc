package au.gov.vic.sro.payment.arrangements.faces.util;

public enum MessageStatus {

	SUCCESS("Success", "Success"),
	FAILURE("Failure", "Failure"),
	CANCELLED("Cancelled", "Cancelled"),
	NO_STATUS("NoStatus", "");

	private final String code;
	private final String label;

	private MessageStatus(String code, String label) {
		this.code = code;
		this.label = label;
	}

	public String getCode() {
		return code;
	}

	public String getLabel() {
		return label;
	}
}