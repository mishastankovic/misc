package au.gov.vic.sro.payment.arrangements.faces.model;

import java.text.Format;
import java.util.ResourceBundle;

import org.apache.commons.lang3.time.FastDateFormat;

public abstract class AbstractPageModel {
	private static final String RESOURCE_BUNDLE_NAME = "PaymentArrangementsResources";
	protected Format dateFormat = FastDateFormat.getInstance("dd/MM/yyyy");

	public static String getResource(String resourceID) {
		return ResourceBundle.getBundle(RESOURCE_BUNDLE_NAME).getString(resourceID);
	}

}