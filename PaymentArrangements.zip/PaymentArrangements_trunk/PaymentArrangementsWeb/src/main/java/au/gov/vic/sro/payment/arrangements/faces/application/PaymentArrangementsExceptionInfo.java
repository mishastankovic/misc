package au.gov.vic.sro.payment.arrangements.faces.application;

import org.primefaces.application.exceptionhandler.ExceptionInfo;

public class PaymentArrangementsExceptionInfo extends ExceptionInfo {

	private static final long serialVersionUID = 7591981179280214010L;

	private String errorId;

	public PaymentArrangementsExceptionInfo(ExceptionInfo exceptionInfo) {
		setException(exceptionInfo.getException());
		setType(exceptionInfo.getType());
		setMessage(exceptionInfo.getMessage());
		setStackTrace(exceptionInfo.getStackTrace());
		setFormattedStackTrace(exceptionInfo.getFormattedStackTrace());
		setTimestamp(exceptionInfo.getTimestamp());
		setFormattedStackTrace(exceptionInfo.getFormattedStackTrace());
	}

	public String getErrorId() {
		return errorId;
	}

	public void setErrorId(String errorId) {
		this.errorId = errorId;
	}

}
