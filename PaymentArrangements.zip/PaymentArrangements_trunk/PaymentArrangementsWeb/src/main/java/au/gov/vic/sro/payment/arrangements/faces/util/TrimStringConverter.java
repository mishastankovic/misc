package au.gov.vic.sro.payment.arrangements.faces.util;

import java.io.Serializable;

import javax.faces.component.UIComponent;
import javax.faces.component.html.HtmlInputText;
import javax.faces.component.html.HtmlInputTextarea;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;
import javax.faces.convert.FacesConverter;

import org.apache.commons.lang3.StringUtils;

@FacesConverter(forClass = String.class)
public class TrimStringConverter implements Serializable, Converter {
	private static final long serialVersionUID = 5378211869046056533L;

	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String value) throws ConverterException {
		return component instanceof HtmlInputText || component instanceof HtmlInputTextarea ? StringUtils
				.trimToNull(value) : value;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component, Object value) throws ConverterException {
		return value == null ? null : value.toString();
	}

}
