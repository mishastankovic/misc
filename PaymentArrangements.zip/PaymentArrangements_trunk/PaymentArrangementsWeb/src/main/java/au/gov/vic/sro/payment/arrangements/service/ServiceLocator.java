package au.gov.vic.sro.payment.arrangements.service;

import java.io.Serializable;
import java.util.Properties;

import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

public class ServiceLocator implements Serializable {
	private static final long serialVersionUID = 1881616091802271653L;
	private static final String PAYMENT_ARRANGEMENTS_PROPERTIES = "paymentArrangementsProperties";
	private static final String PAYMENT_ARRANGEMENTS_SERVICE_BEAN = "paymentArrangementsService";
	private static final String QUICKVAULT_SERVICE_BEAN = "quickVaultService";

	public WebApplicationContext getApplicationContext() {
		FacesContext context = FacesContext.getCurrentInstance();
		return getApplicationContext((ServletContext) context.getExternalContext().getContext());
	}

	public WebApplicationContext getApplicationContext(ServletContext context) {
		WebApplicationContext applicationContext = WebApplicationContextUtils.getWebApplicationContext(context);
		return applicationContext;
	}

	public Object getSpringBean(String beanName) {
		return getApplicationContext().getBean(beanName);
	}

	public Object getSpringBean(String beanName, ServletContext context) {
		return getApplicationContext(context).getBean(beanName);
	}

	public Properties getPaymentArrangementsProperties() {
		return (Properties) getSpringBean(PAYMENT_ARRANGEMENTS_PROPERTIES);
	}

	public Properties getPaymentArrangementsProperties(ServletContext context) {
		return (Properties) getSpringBean(PAYMENT_ARRANGEMENTS_PROPERTIES, context);
	}

	public PaymentArrangementsService getPaymentArrangementsService() {
		return (PaymentArrangementsService) getSpringBean(PAYMENT_ARRANGEMENTS_SERVICE_BEAN);
	}

	public PaymentArrangementsService getPaymentArrangementsService(ServletContext context) {
		return (PaymentArrangementsService) getSpringBean(PAYMENT_ARRANGEMENTS_SERVICE_BEAN, context);
	}

	public QuickVaultService getQuickVaultService() {
		return (QuickVaultService) getSpringBean(QUICKVAULT_SERVICE_BEAN);
	}

	public QuickVaultService getQuickVaultService(ServletContext context) {
		return (QuickVaultService) getSpringBean(QUICKVAULT_SERVICE_BEAN, context);
	}

}
