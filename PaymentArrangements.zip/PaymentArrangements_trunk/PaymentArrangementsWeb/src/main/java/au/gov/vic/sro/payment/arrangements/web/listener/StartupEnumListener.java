package au.gov.vic.sro.payment.arrangements.web.listener;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.apache.log4j.Logger;

import au.gov.vic.sro.payment.arrangements.model.ArrangementStatus;
import au.gov.vic.sro.payment.arrangements.model.CancelledReason;
import au.gov.vic.sro.payment.arrangements.model.ContactType;
import au.gov.vic.sro.payment.arrangements.model.InstalmentRequestSent;
import au.gov.vic.sro.payment.arrangements.model.InstalmentStatus;
import au.gov.vic.sro.payment.arrangements.model.LiabilityType;
import au.gov.vic.sro.payment.arrangements.model.PaymentFrequency;
import au.gov.vic.sro.payment.arrangements.model.PaymentMethod;
import au.gov.vic.sro.payment.arrangements.model.RevenueLine;
import au.gov.vic.sro.payment.arrangements.model.YesNoType;

public class StartupEnumListener implements ServletContextListener {
	private static final Logger log = Logger.getLogger(StartupEnumListener.class);
	// @formatter:off
	private Class<?>[] enumClasses = {
			ArrangementStatus.class,
			CancelledReason.class,
			ContactType.class,
			InstalmentRequestSent.class,
			InstalmentStatus.class,
			LiabilityType.class,
			PaymentFrequency.class,
			PaymentMethod.class,
			RevenueLine.class,
			YesNoType.class
		};
	// @formatter:on

	@Override
	public void contextDestroyed(ServletContextEvent event) {
		// No action
	}

	@Override
	public void contextInitialized(ServletContextEvent event) {
		ServletContext servletContext = event.getServletContext();
		for (Class<?> enumClass : enumClasses) {
			String enumClassName = enumClass.getCanonicalName();
			if (enumClass.isEnum()) {
				servletContext.setAttribute(enumClassName, enumClass);
			} else {
				log.warn("Failed putting enum class into servletContext - not enum: " + enumClassName);
			}
		}
	}

}
