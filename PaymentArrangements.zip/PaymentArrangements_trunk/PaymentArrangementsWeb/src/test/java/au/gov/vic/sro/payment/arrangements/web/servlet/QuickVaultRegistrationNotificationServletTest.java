package au.gov.vic.sro.payment.arrangements.web.servlet;

import static au.gov.vic.sro.payment.arrangements.model.PaymentMethod.CREDIT_CARD;
import static au.gov.vic.sro.payment.arrangements.model.PaymentMethod.DIRECT_DEBIT;
import static au.gov.vic.sro.payment.arrangements.service.QuickVaultServiceImpl.PARAM_CUSTOM_CUSTOMER_ID;
import static au.gov.vic.sro.payment.quickstream3.QuickstreamConstants.PARAM_ACCOUNT_NAME;
import static au.gov.vic.sro.payment.quickstream3.QuickstreamConstants.PARAM_ACCOUNT_NUMBER;
import static au.gov.vic.sro.payment.quickstream3.QuickstreamConstants.PARAM_BSB;
import static au.gov.vic.sro.payment.quickstream3.QuickstreamConstants.PARAM_CARDHOLDER_NAME;
import static au.gov.vic.sro.payment.quickstream3.QuickstreamConstants.PARAM_CARD_SCHEME;
import static au.gov.vic.sro.payment.quickstream3.QuickstreamConstants.PARAM_COMMUNITY_CODE;
import static au.gov.vic.sro.payment.quickstream3.QuickstreamConstants.PARAM_CUSTOMER_REFERENCE_NUMBER;
import static au.gov.vic.sro.payment.quickstream3.QuickstreamConstants.PARAM_EXPIRY_DATE_MONTH;
import static au.gov.vic.sro.payment.quickstream3.QuickstreamConstants.PARAM_EXPIRY_DATE_YEAR;
import static au.gov.vic.sro.payment.quickstream3.QuickstreamConstants.PARAM_MASKED_CARD_NUMBER;
import static au.gov.vic.sro.payment.quickstream3.QuickstreamConstants.PARAM_PREREGISTRATION_CODE;
import static au.gov.vic.sro.payment.quickstream3.QuickstreamConstants.PARAM_PRODUCT;
import static au.gov.vic.sro.payment.quickstream3.QuickstreamConstants.PARAM_SUPPLIER_BUSINESS_CODE;
import static au.gov.vic.sro.payment.quickstream3.QuickstreamConstants.PRODUCT_QUICKVAULT;
import static java.lang.Boolean.TRUE;
import static org.apache.http.Consts.UTF_8;
import static org.apache.http.HttpStatus.SC_OK;
import static org.easymock.EasyMock.anyObject;
import static org.easymock.EasyMock.eq;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.expectLastCall;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.HttpClientUtils;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.ssl.SSLContextBuilder;
import org.easymock.EasyMock;
import org.easymock.EasyMockSupport;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import au.gov.vic.sro.payment.arrangements.dto.SaveAccountRequest;
import au.gov.vic.sro.payment.arrangements.dto.SaveAccountResponse;
import au.gov.vic.sro.payment.arrangements.model.PaymentMethod;
import au.gov.vic.sro.payment.arrangements.service.PaymentArrangementsService;
import au.gov.vic.sro.payment.arrangements.service.QuickVaultService;

public class QuickVaultRegistrationNotificationServletTest {
	private EasyMockSupport easyMockSupport;
	private HttpServletRequest mockRequest;
	private HttpServletResponse mockResponse;
	private PaymentArrangementsService mockPaymentArrangementsService;
	private QuickVaultService mockQuickVaultService;
	private SaveAccountRequest mockSaveAccountRequest;
	private SaveAccountResponse mockSaveAccountResponse;
	private Map<String, String[]> requestParameterMap;
	private QuickVaultRegistrationNotificationServlet servlet;

	@Before
	public void setUp() throws Exception {
		easyMockSupport = new EasyMockSupport();
		mockRequest = easyMockSupport.createNiceMock(HttpServletRequest.class);
		mockResponse = easyMockSupport.createNiceMock(HttpServletResponse.class);
		mockPaymentArrangementsService = easyMockSupport.createNiceMock(PaymentArrangementsService.class);
		mockQuickVaultService = easyMockSupport.createNiceMock(QuickVaultService.class);
		mockSaveAccountRequest = easyMockSupport.createNiceMock(SaveAccountRequest.class);
		mockSaveAccountResponse = easyMockSupport.createNiceMock(SaveAccountResponse.class);

		requestParameterMap = null;

		servlet = new QuickVaultRegistrationNotificationServlet() {
			private static final long serialVersionUID = 1L;

			@Override
			protected QuickVaultService getQuickVaultService() {
				return mockQuickVaultService;
			}

			@Override
			protected PaymentArrangementsService getPaymentArrangementsService() {
				return mockPaymentArrangementsService;
			}
		};
	}

	@Test
	public void testDoPost() throws Exception {
		expect(mockRequest.getParameterMap()).andReturn(requestParameterMap);
		expect(mockQuickVaultService.getSaveAccountRequest(EasyMock.<Map<String, String[]>> anyObject()))
				.andReturn(mockSaveAccountRequest);
		expect(mockPaymentArrangementsService.saveAccount(mockSaveAccountRequest)).andReturn(mockSaveAccountResponse);
		expect(mockSaveAccountResponse.getSaved()).andReturn(TRUE);
		mockResponse.setStatus(200);
		expectLastCall();
		easyMockSupport.replayAll();

		servlet.doPost(mockRequest, mockResponse);

		easyMockSupport.verifyAll();
	}

	// Test the callback for user1 from WestPac-QuickVault and the arrangement has been modified by user2 while user1
	// was in WestPac-QuickVault
	@Test
	public void testOptimisticLocking() throws Exception {
		expect(mockRequest.getParameterMap()).andReturn(requestParameterMap);
		expect(mockQuickVaultService.getSaveAccountRequest(EasyMock.<Map<String, String[]>> anyObject()))
				.andReturn(mockSaveAccountRequest);
		expect(mockPaymentArrangementsService.saveAccount(mockSaveAccountRequest)).andReturn(mockSaveAccountResponse);
		expect(mockSaveAccountResponse.getSaved()).andReturn(null);
		mockResponse.sendError(eq(500), anyObject(String.class));
		expectLastCall();
		easyMockSupport.replayAll();

		servlet.doPost(mockRequest, mockResponse);

		easyMockSupport.verifyAll();
	}

	@Test(expected = ServletException.class)
	public void testDoPostRuntimeException() throws Exception {
		expect(mockRequest.getParameterMap()).andThrow(new RuntimeException("KABOOM!!!"));
		easyMockSupport.replayAll();

		servlet.doPost(mockRequest, mockResponse);
	}

	@Ignore("Not a unit test. Useful for debugging real servlet on localtest.")
	@Test
	public void debugDoPostCreditCard() throws Exception {
		assertThat(postToServlet(CREDIT_CARD), is(SC_OK));
	}

	@Ignore("Not a unit test. Useful for debugging real servlet on localtest.")
	@Test
	public void debugDoPostDirectDebit() throws Exception {
		assertThat(postToServlet(DIRECT_DEBIT), is(SC_OK));
	}

	private int postToServlet(PaymentMethod paymentMethod) throws Exception {
		// Generate parameters.
		List<NameValuePair> parameters = new ArrayList<NameValuePair>();
		parameters.add(new BasicNameValuePair(PARAM_PRODUCT, PRODUCT_QUICKVAULT));
		parameters.add(new BasicNameValuePair(PARAM_COMMUNITY_CODE, "SROPA"));
		parameters.add(new BasicNameValuePair(PARAM_SUPPLIER_BUSINESS_CODE, "LTX"));
		parameters.add(new BasicNameValuePair(PARAM_CUSTOMER_REFERENCE_NUMBER, "123-4"));
		if (paymentMethod == CREDIT_CARD) {
			parameters.add(new BasicNameValuePair(PARAM_CARDHOLDER_NAME, "Blast Hardcheese"));
			parameters.add(new BasicNameValuePair(PARAM_MASKED_CARD_NUMBER, "411111xxxxxxx111"));
			parameters.add(new BasicNameValuePair(PARAM_EXPIRY_DATE_MONTH, "01"));
			parameters.add(new BasicNameValuePair(PARAM_EXPIRY_DATE_YEAR, "2017"));
			parameters.add(new BasicNameValuePair(PARAM_CARD_SCHEME, "VISA"));
		} else if (paymentMethod == DIRECT_DEBIT) {
			parameters.add(new BasicNameValuePair(PARAM_BSB, "xxx-000"));
			parameters.add(new BasicNameValuePair(PARAM_ACCOUNT_NUMBER, "xxxxxx678"));
			parameters.add(new BasicNameValuePair(PARAM_ACCOUNT_NAME, "Blast Hardcheese savings"));
		}
		parameters.add(new BasicNameValuePair(PARAM_PREREGISTRATION_CODE, "testAccountToken"));
		parameters.add(new BasicNameValuePair(PARAM_CUSTOM_CUSTOMER_ID, "999"));

		// Post to servlet.
		SSLContextBuilder builder = new SSLContextBuilder();
		builder.loadTrustMaterial(null, new TrustSelfSignedStrategy());
		SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(builder.build(), new NoopHostnameVerifier());
		CloseableHttpClient client = HttpClients.custom().setSSLSocketFactory(sslsf).build();
		try {
			HttpPost post =
					new HttpPost("https://localtest.e-business.sro.vic.gov.au/pao/QuickVaultRegistrationNotification");
			post.setEntity(new UrlEncodedFormEntity(parameters, UTF_8));
			HttpResponse response = client.execute(post);
			return response.getStatusLine().getStatusCode();
		} finally {
			HttpClientUtils.closeQuietly(client);
		}
	}

}
