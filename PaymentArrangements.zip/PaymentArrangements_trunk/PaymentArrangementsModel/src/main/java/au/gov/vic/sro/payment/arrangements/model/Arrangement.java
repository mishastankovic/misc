package au.gov.vic.sro.payment.arrangements.model;

import static au.gov.vic.sro.builder.ToStringStyleFactory.getToStringStyle;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.ListUtils;
import org.apache.commons.collections4.Transformer;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

/**
 * An arrangement represents a plan for paying an outstanding liability or liabilities.
 */
public class Arrangement implements Serializable {
	private static final long serialVersionUID = -1523645225508983110L;

	private BigInteger id;
	private Integer version;
	private String customerId;
	private ArrangementStatus status;
	private Date statusDate;
	private Date cancelledDate;
	private CancelledReason cancelledReason;
	private String cancelledUserId;
	private Date startDate;
	private Date endDate;
	private PaymentFrequency paymentFrequency;
	private BigDecimal allInstalmentAmountDollars;
	private BigDecimal allInstalmentSurchargeDollars;
	private BigDecimal allInstalmentTotalAmountDollars;
	private String accountToken;
	private PaymentMethod paymentMethod;
	private String cardNumber;
	private String cardExpiryMonth;
	private String cardExpiryYear;
	private String bankBsb;
	private String bankAccountNumber;
	private String checksum;

	private class LiabilityTransformer implements Serializable, Transformer<Liability, Liability> {
		private static final long serialVersionUID = 1L;

		@Override
		public Liability transform(Liability liability) {
			liability.setArrangement(Arrangement.this);
			return liability;
		}
	}

	private class InstalmentTransformer implements Serializable, Transformer<Instalment, Instalment> {
		private static final long serialVersionUID = 1L;

		@Override
		public Instalment transform(Instalment instalment) {
			instalment.setArrangement(Arrangement.this);
			return instalment;
		}
	}

	private class ContactTransformer implements Serializable, Transformer<Contact, Contact> {
		private static final long serialVersionUID = 1L;

		@Override
		public Contact transform(Contact contact) {
			contact.setArrangement(Arrangement.this);
			return contact;
		}
	}

	// Child.
	private List<Liability> liabilities =
			ListUtils.transformedList(new ArrayList<Liability>(), new LiabilityTransformer());
	// Child.
	private List<Instalment> instalments =
			ListUtils.transformedList(new ArrayList<Instalment>(), new InstalmentTransformer());
	// Child.
	private List<Contact> contacts = ListUtils.transformedList(new ArrayList<Contact>(), new ContactTransformer());

	public BigInteger getId() {
		return id;
	}

	public void setId(BigInteger id) {
		this.id = id;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public ArrangementStatus getStatus() {
		return status;
	}

	public void setStatus(ArrangementStatus status) {
		this.status = status;
	}

	public Date getStatusDate() {
		return statusDate;
	}

	public void setStatusDate(Date statusDate) {
		this.statusDate = statusDate;
	}

	public Date getCancelledDate() {
		return cancelledDate;
	}

	public void setCancelledDate(Date cancelledDate) {
		this.cancelledDate = cancelledDate;
	}

	public CancelledReason getCancelledReason() {
		return cancelledReason;
	}

	public void setCancelledReason(CancelledReason cancelledReason) {
		this.cancelledReason = cancelledReason;
	}

	public String getCancelledUserId() {
		return cancelledUserId;
	}

	public void setCancelledUserId(String cancelledUserId) {
		this.cancelledUserId = cancelledUserId;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public PaymentFrequency getPaymentFrequency() {
		return paymentFrequency;
	}

	public void setPaymentFrequency(PaymentFrequency paymentFrequency) {
		this.paymentFrequency = paymentFrequency;
	}

	public BigDecimal getAllInstalmentAmountDollars() {
		return allInstalmentAmountDollars;
	}

	public void setAllInstalmentAmountDollars(BigDecimal allInstalmentAmountDollars) {
		this.allInstalmentAmountDollars = allInstalmentAmountDollars;
	}

	public BigDecimal getAllInstalmentSurchargeDollars() {
		return allInstalmentSurchargeDollars;
	}

	public void setAllInstalmentSurchargeDollars(BigDecimal allInstalmentSurchargeDollars) {
		this.allInstalmentSurchargeDollars = allInstalmentSurchargeDollars;
	}

	public BigDecimal getAllInstalmentTotalAmountDollars() {
		return allInstalmentTotalAmountDollars;
	}

	public void setAllInstalmentTotalAmountDollars(BigDecimal allInstalmentTotalAmountDollars) {
		this.allInstalmentTotalAmountDollars = allInstalmentTotalAmountDollars;
	}

	public String getAccountToken() {
		return accountToken;
	}

	public void setAccountToken(String accountToken) {
		this.accountToken = accountToken;
	}

	public PaymentMethod getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(PaymentMethod paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public String getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getCardExpiryMonth() {
		return cardExpiryMonth;
	}

	public void setCardExpiryMonth(String cardExpiryMonth) {
		this.cardExpiryMonth = cardExpiryMonth;
	}

	public String getCardExpiryYear() {
		return cardExpiryYear;
	}

	public void setCardExpiryYear(String cardExpiryYear) {
		this.cardExpiryYear = cardExpiryYear;
	}

	public String getBankBsb() {
		return bankBsb;
	}

	public void setBankBsb(String bankBsb) {
		this.bankBsb = bankBsb;
	}

	public String getBankAccountNumber() {
		return bankAccountNumber;
	}

	public void setBankAccountNumber(String bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}

	public String getChecksum() {
		return checksum;
	}

	public void setChecksum(String checksum) {
		this.checksum = checksum;
	}

	public List<Liability> getLiabilities() {
		return liabilities;
	}

	public void setLiabilities(List<Liability> liabilities) {
		this.liabilities.clear();
		if (CollectionUtils.isNotEmpty(liabilities)) {
			this.liabilities.addAll(liabilities);
		}
	}

	public void setLiabilities(Object[] liabilities) {
		this.liabilities.clear();
		if (ArrayUtils.isNotEmpty(liabilities)) {
			for (Object liability : liabilities) {
				this.liabilities.add((Liability) liability);
			}
		}
	}

	public List<Instalment> getInstalments() {
		return instalments;
	}

	public void setInstalments(List<Instalment> instalments) {
		this.instalments.clear();
		if (CollectionUtils.isNotEmpty(instalments)) {
			this.instalments.addAll(instalments);
		}
	}

	public void setInstalments(Object[] instalments) {
		this.instalments.clear();
		if (ArrayUtils.isNotEmpty(instalments)) {
			for (Object instalment : instalments) {
				this.instalments.add((Instalment) instalment);
			}
		}
	}

	public List<Contact> getContacts() {
		return contacts;
	}

	public void setContacts(List<Contact> contacts) {
		this.contacts.clear();
		if (CollectionUtils.isNotEmpty(contacts)) {
			this.contacts.addAll(contacts);
		}
	}

	public void setContacts(Object[] contacts) {
		this.contacts.clear();
		if (ArrayUtils.isNotEmpty(contacts)) {
			for (Object contact : contacts) {
				this.contacts.add((Contact) contact);
			}
		}
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, getToStringStyle());
	}

}
