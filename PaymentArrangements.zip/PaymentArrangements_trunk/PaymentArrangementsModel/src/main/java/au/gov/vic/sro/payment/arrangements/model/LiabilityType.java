package au.gov.vic.sro.payment.arrangements.model;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * A liability has a type.
 */
public enum LiabilityType implements Presentable, Codified {
	ASSESSMENT("A", "Assessment");

	private static final Map<String, LiabilityType> codeMap;

	private String code;
	private String label;

	static {
		codeMap = new HashMap<String, LiabilityType>();
		for (LiabilityType value : values()) {
			codeMap.put(value.getCode(), value);
		}
	}

	private LiabilityType(String code, String label) {
		this.code = code;
		this.label = label;
	}

	@Override
	public String getCode() {
		return code;
	}

	@Override
	public String getLabel() {
		return label;
	}

	@JsonCreator
	public static LiabilityType fromCode(String code) {
		return codeMap.get(code);
	}

	public static String toCode(LiabilityType value) {
		return value == null ? null : value.getCode();
	}

}
