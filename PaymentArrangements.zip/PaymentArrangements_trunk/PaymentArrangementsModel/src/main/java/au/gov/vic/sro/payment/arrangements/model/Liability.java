package au.gov.vic.sro.payment.arrangements.model;

import static au.gov.vic.sro.builder.ToStringStyleFactory.getToStringStyle;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.Date;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

/**
 * A tax liability represents a debt to the government incurred by a tax payer as accrued or assessed taxes.
 */
public class Liability implements Serializable {
	private static final long serialVersionUID = -8768008557774428438L;
	public static final Liability[] EMPTY_LIABILITY_ARRAY = {};

	private RevenueLine revenueLine;
	private LiabilityType type;
	private String id;
	private Integer version;
	private Date issueDate;
	private Integer year;
	private BigDecimal outstandingLiabilityAmountDollars;
	// Parent.
	private Arrangement arrangement;

	public static Liability[] toArray(Collection<Liability> liabilities) {
		if (liabilities == null) {
			return null;
		}
		if (liabilities.isEmpty()) {
			return EMPTY_LIABILITY_ARRAY;
		}
		return liabilities.toArray(new Liability[liabilities.size()]);
	}

	public static Liability[] toArray(Collection<Liability> liabilities, boolean nullToEmpty) {
		Liability[] arr = toArray(liabilities);
		return arr == null && nullToEmpty ? EMPTY_LIABILITY_ARRAY : arr;
	}

	public RevenueLine getRevenueLine() {
		return revenueLine;
	}

	public void setRevenueLine(RevenueLine revenueLine) {
		this.revenueLine = revenueLine;
	}

	public LiabilityType getType() {
		return type;
	}

	public void setType(LiabilityType type) {
		this.type = type;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public Date getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(Date issueDate) {
		this.issueDate = issueDate;
	}

	public Integer getYear() {
		return year;
	}

	public void setYear(Integer year) {
		this.year = year;
	}

	/**
	 * @deprecated Oracle developers have advised that the accuracy of this property should not be relied on when using
	 *             a Liability returned from PAO_SERVICES_PKG.GET_NOTIFICATION_ARRANGEMENT_P. This is because there is
	 *             no liability information recorded for past versions of an arrangement; if this property is to be
	 *             used, ensure that the version of the arrangement you requested matches the arrangement version number
	 *             in the liability returned.
	 */
	@Deprecated
	public BigDecimal getOutstandingLiabilityAmountDollars() {
		return outstandingLiabilityAmountDollars;
	}

	public void setOutstandingLiabilityAmountDollars(BigDecimal outstandingLiabilityAmountDollars) {
		this.outstandingLiabilityAmountDollars = outstandingLiabilityAmountDollars;
	}

	public Arrangement getArrangement() {
		return arrangement;
	}

	public void setArrangement(Arrangement arrangement) {
		this.arrangement = arrangement;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, getToStringStyle());
	}

}
