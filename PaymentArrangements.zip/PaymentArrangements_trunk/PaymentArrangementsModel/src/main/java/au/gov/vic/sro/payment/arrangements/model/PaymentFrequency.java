package au.gov.vic.sro.payment.arrangements.model;

import java.util.HashMap;
import java.util.Map;

/**
 * An arrangement has a payment frequency.
 */
public enum PaymentFrequency implements Presentable, Codified {
	FORTNIGHTLY("F", "Fortnightly instalments"),
	MONTHLY("M", "Monthly instalments"),
	FOUR("4", "Four instalments");

	private static final Map<String, PaymentFrequency> codeMap;

	private String code;
	private String label;

	static {
		codeMap = new HashMap<String, PaymentFrequency>();
		for (PaymentFrequency value : values()) {
			codeMap.put(value.getCode(), value);
		}
	}

	private PaymentFrequency(String code, String label) {
		this.code = code;
		this.label = label;
	}

	@Override
	public String getCode() {
		return code;
	}

	@Override
	public String getLabel() {
		return label;
	}

	public static PaymentFrequency fromCode(String code) {
		return codeMap.get(code);
	}

	public static String toCode(PaymentFrequency value) {
		return value == null ? null : value.getCode();
	}

}
