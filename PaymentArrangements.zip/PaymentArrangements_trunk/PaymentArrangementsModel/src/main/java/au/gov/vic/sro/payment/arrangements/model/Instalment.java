package au.gov.vic.sro.payment.arrangements.model;

import static au.gov.vic.sro.builder.ToStringStyleFactory.getToStringStyle;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.Date;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

/**
 * An arrangement represents a plan for paying an outstanding liability or liabilities through instalments (or several
 * parts into which the sum payable is divided for payment at successive fixed times).
 */
public class Instalment implements Serializable {
	private static final long serialVersionUID = -1087495970447707579L;
	public static final Instalment[] EMPTY_INSTALMENT_ARRAY = {};

	private Integer id;
	private InstalmentStatus status;
	private Date dueDate;
	private BigDecimal amountDollars;
	private BigDecimal surchargeDollars;
	private BigDecimal totalAmountDollars;
	private InstalmentRequestSent requestSent;
	private Date requestSentDate;
	private String transactionNumber;
	private String quickBatchSummaryCode;
	private String quickBatchResponseCode;
	// Parent.
	private Arrangement arrangement;

	public static Instalment[] toArray(Collection<Instalment> instalments) {
		if (instalments == null) {
			return null;
		}

		if (instalments.isEmpty()) {
			return EMPTY_INSTALMENT_ARRAY;
		}
		return instalments.toArray(new Instalment[instalments.size()]);
	}

	public static Instalment[] toArray(Collection<Instalment> instalments, boolean nullToEmpty) {
		Instalment[] arr = toArray(instalments);
		return arr == null && nullToEmpty ? EMPTY_INSTALMENT_ARRAY : arr;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public InstalmentStatus getStatus() {
		return status;
	}

	public void setStatus(InstalmentStatus status) {
		this.status = status;
	}

	public Date getDueDate() {
		return dueDate;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	public BigDecimal getAmountDollars() {
		return amountDollars;
	}

	public void setAmountDollars(BigDecimal amountDollars) {
		this.amountDollars = amountDollars;
	}

	public BigDecimal getSurchargeDollars() {
		return surchargeDollars;
	}

	public void setSurchargeDollars(BigDecimal surchargeDollars) {
		this.surchargeDollars = surchargeDollars;
	}

	public BigDecimal getTotalAmountDollars() {
		return totalAmountDollars;
	}

	public void setTotalAmountDollars(BigDecimal totalAmountDollars) {
		this.totalAmountDollars = totalAmountDollars;
	}

	public InstalmentRequestSent getRequestSent() {
		return requestSent;
	}

	public void setRequestSent(InstalmentRequestSent requestSent) {
		this.requestSent = requestSent;
	}

	public Date getRequestSentDate() {
		return requestSentDate;
	}

	public void setRequestSentDate(Date requestSentDate) {
		this.requestSentDate = requestSentDate;
	}

	public String getTransactionNumber() {
		return transactionNumber;
	}

	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}

	public String getQuickBatchSummaryCode() {
		return quickBatchSummaryCode;
	}

	public void setQuickBatchSummaryCode(String quickBatchSummaryCode) {
		this.quickBatchSummaryCode = quickBatchSummaryCode;
	}

	public String getQuickBatchResponseCode() {
		return quickBatchResponseCode;
	}

	public void setQuickBatchResponseCode(String quickBatchResponseCode) {
		this.quickBatchResponseCode = quickBatchResponseCode;
	}

	public Arrangement getArrangement() {
		return arrangement;
	}

	public void setArrangement(Arrangement arrangement) {
		this.arrangement = arrangement;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, getToStringStyle());
	}

}
