package au.gov.vic.sro.payment.arrangements.model;

import static java.lang.Boolean.FALSE;
import static java.lang.Boolean.TRUE;

import java.util.HashMap;
import java.util.Map;

public enum YesNoType implements Presentable, Codified {
	YES("Y", "Yes", TRUE),
	NO("N", "No", FALSE);

	private static final Map<String, YesNoType> codeMap;

	private String code;
	private String label;
	private Boolean bool;

	static {
		codeMap = new HashMap<String, YesNoType>();
		for (YesNoType value : values()) {
			codeMap.put(value.getCode(), value);
		}
	}

	private YesNoType(String code, String label, Boolean bool) {
		this.code = code;
		this.label = label;
		this.bool = bool;
	}

	@Override
	public String getCode() {
		return code;
	}

	@Override
	public String getLabel() {
		return label;
	}

	public Boolean getBoolean() {
		return bool;
	}

	public static YesNoType fromCode(String code) {
		return codeMap.get(code);
	}

	public static String toCode(YesNoType value) {
		return value == null ? null : value.getCode();
	}

}
