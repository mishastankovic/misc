package au.gov.vic.sro.payment.arrangements.model;

import java.util.HashMap;
import java.util.Map;

/**
 * A cancelled arrangement has a reason.
 */
public enum CancelledReason implements Presentable, Codified {
	ASSESSMENT_WITHDRAWN("AW", "Assessment withdrawn"),
	INTERNAL_USER("CI", "Cancelled by SRO internal user"),
	ESYS_SYSTEM("CS", "Cancelled by e-Sys system"),
	EXTERNAL_USER("CE", "Cancelled by external user"),
	LIABILITY_RECALCULATED("LR", "Liability Re-calculated"),
	PAYMENT_NOT_RECEIVED("PN", "Payment not received");

	private static final Map<String, CancelledReason> codeMap;

	private String code;
	private String label;

	static {
		codeMap = new HashMap<String, CancelledReason>();
		for (CancelledReason value : values()) {
			codeMap.put(value.getCode(), value);
		}
	}

	private CancelledReason(String code, String label) {
		this.code = code;
		this.label = label;
	}

	@Override
	public String getCode() {
		return code;
	}

	@Override
	public String getLabel() {
		return label;
	}

	public static CancelledReason fromCode(String code) {
		return codeMap.get(code);
	}

	public static String toCode(CancelledReason value) {
		return value == null ? null : value.getCode();
	}

}
