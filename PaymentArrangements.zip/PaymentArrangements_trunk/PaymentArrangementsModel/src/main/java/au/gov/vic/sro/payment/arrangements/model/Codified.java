package au.gov.vic.sro.payment.arrangements.model;

/**
 * A codified object has a code.
 */
public interface Codified {

	String getCode();

}
