package au.gov.vic.sro.payment.arrangements.model;

import static au.gov.vic.sro.payment.arrangements.model.MessageType.ERROR;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

/**
 * A message from eSys.
 */
public class Message implements Serializable {
	private static final long serialVersionUID = 6199345870051734899L;
	private Integer code;
	private MessageType type;
	private String text;

	public boolean isError() {
		return ERROR == type;
	}

	public Integer getCode() {
		return code;
	}

	public void setCode(Integer code) {
		this.code = code;
	}

	public MessageType getType() {
		return type;
	}

	public void setType(MessageType type) {
		this.type = type;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}

}
