package au.gov.vic.sro.payment.arrangements.support;

import java.util.Map;
import java.util.Properties;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import au.gov.vic.sro.payment.arrangements.model.EventType;
import au.gov.vic.sro.payment.arrangements.service.PaymentArrangementsService;
import au.gov.vic.sro.payment.arrangements.service.events.EventHandler;

public class BeanFactoryLocator {
	private static final String PAYMENT_ARRANGEMENTS_PROPERTIES = "paymentArrangementsProperties";
	private static final String EVENT_HANDLERS = "eventHandlers";
	private static final String PAYMENT_ARRANGEMENTS_SERVICE_BEAN = "paymentArrangementsService";

	// @formatter:off
	private static final BeanFactory BEAN_FACTORY = new ClassPathXmlApplicationContext(
			"classpath:paymentArrangementsContextConfig.xml",
			"classpath:paymentArrangementsContextLogging.xml",
			"classpath:paymentArrangementsContextDataSource.xml",
			"classpath:paymentArrangementsContextPersistence.xml",
			"classpath:paymentArrangementsContextServices.xml");
	// @formatter:on

	public BeanFactory getBeanFactory() {
		return BEAN_FACTORY;
	}

	public Properties getPaymentArrangementsProperties() {
		return (Properties) getBeanFactory().getBean(PAYMENT_ARRANGEMENTS_PROPERTIES);
	}

	@SuppressWarnings("unchecked")
	public Map<EventType, EventHandler> getEventHandlers() {
		return (Map<EventType, EventHandler>) getBeanFactory().getBean(EVENT_HANDLERS);
	}

	public PaymentArrangementsService getPaymentArrangementsService() {
		return (PaymentArrangementsService) getBeanFactory().getBean(PAYMENT_ARRANGEMENTS_SERVICE_BEAN);
	}

}
