package au.gov.vic.sro.payment.arrangements.mte;

import static org.apache.commons.lang3.StringUtils.isNotBlank;
import static org.apache.commons.lang3.math.NumberUtils.isDigits;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.collections4.CollectionUtils;

import au.gov.vic.sro.mte.InputParameterDefinition;
import au.gov.vic.sro.mte.helpers.TaskHelper;
import au.gov.vic.sro.mte.tasks.AbstractTask;
import au.gov.vic.sro.payment.arrangements.model.Event;
import au.gov.vic.sro.payment.arrangements.support.BeanFactoryLocator;

public class HandleEventsTask extends AbstractTask {
	private BeanFactoryLocator beanFactoryLocator;
	private String reprocessEventIdsArg;
	private Set<BigInteger> reprocessEventIds;
	private Set<BigInteger> processedEventIds;
	private Set<BigInteger> erroredEventIds;

	public HandleEventsTask() {
		super();
	}

	@Override
	public List<InputParameterDefinition> getInputParameterDefinitionTemplates() {
		List<InputParameterDefinition> parameters = new ArrayList<InputParameterDefinition>();
		TaskHelper.addDefaultInputParameter(parameters, getClass(), "reprocessEventIdsArg",
				"Comma delimited list of Event IDs to reprocess.", false);
		return parameters;
	}

	@Override
	public void performExecute() throws Exception {
		try {
			if (CollectionUtils.isEmpty(getReprocessEventIds())) {
				Event event = null;
				while ((event = getBeanFactoryLocator().getPaymentArrangementsService().nextEvent().getEvent()) != null) {
					if (getProcessedEventIds().contains(event.getId())) {
						// Should not happen.
						_log.warn(String.format("Already processed. event=%s", event));
						break;
					}
					processEvent(event);
				}
			} else {
				for (Event event : getBeanFactoryLocator().getPaymentArrangementsService()
						.getEvents(new ArrayList<BigInteger>(getReprocessEventIds())).getEvents()) {
					processEvent(event);
				}
			}
		} finally {
			_log.info(String.format("Processed Event IDs: %s", getProcessedEventIds()));
			if (CollectionUtils.isNotEmpty(getErroredEventIds())) {
				_log.error(String.format("Errored Event IDs: %s", getErroredEventIds()));
			}
		}
	}

	public BeanFactoryLocator getBeanFactoryLocator() {
		if (beanFactoryLocator == null) {
			beanFactoryLocator = new BeanFactoryLocator();
		}
		return beanFactoryLocator;
	}

	public void setBeanFactoryLocator(BeanFactoryLocator beanFactoryLocator) {
		this.beanFactoryLocator = beanFactoryLocator;
	}

	public String getReprocessEventIdsArg() {
		return reprocessEventIdsArg;
	}

	public void setReprocessEventIdsArg(String reprocessEventIdsArg) {
		this.reprocessEventIdsArg = reprocessEventIdsArg;
	}

	protected Set<BigInteger> getReprocessEventIds() {
		if (reprocessEventIds == null) {
			reprocessEventIds = new TreeSet<BigInteger>();
			if (isNotBlank(getReprocessEventIdsArg())) {
				Set<BigInteger> ids = new TreeSet<BigInteger>();
				for (String id : getReprocessEventIdsArg().trim().split("\\s*,\\s*")) {
					if (isDigits(id)) {
						ids.add(new BigInteger(id));
					}
				}
				reprocessEventIds.addAll(ids);
			}
		}
		return reprocessEventIds;
	}

	public Set<BigInteger> getProcessedEventIds() {
		if (processedEventIds == null) {
			processedEventIds = new TreeSet<BigInteger>();
		}
		return processedEventIds;
	}

	public Set<BigInteger> getErroredEventIds() {
		if (erroredEventIds == null) {
			erroredEventIds = new TreeSet<BigInteger>();
		}
		return erroredEventIds;
	}

	protected void processEvent(Event event) {
		if (_log.isDebugEnabled()) {
			_log.debug(String.format("event=%s", event));
		}
		try {
			getBeanFactoryLocator().getEventHandlers().get(event.getType()).handle(event);
			getBeanFactoryLocator().getPaymentArrangementsService().saveEvent(event);
		} catch (Exception e) {
			_log.error(String.format("%s event=%s", e, event), e);
			getErroredEventIds().add(event == null ? null : event.getId());
		} finally {
			getProcessedEventIds().add(event == null ? null : event.getId());
		}
	}

}
