package au.gov.vic.sro.security.oauth.authprovider;

import au.gov.vic.sro.security.oauth.config.client.RestClientConfig;
import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.nio.charset.Charset;
import java.security.Principal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

@Component
public class RestAuthenticationProvider {


    public Authentication authenticate(Authentication authentication, RestClientConfig restAuthConfig) throws AuthenticationException {
        String username = authentication.getName();
        String password = (String)authentication.getCredentials().toString();

        HttpEntity<Principal> entity = new HttpEntity<Principal>(createHeaders(restAuthConfig.getClientId(), restAuthConfig.getClientPassword()));
        Map<String, String> requestParams = new HashMap<String, String>();
        //requestParams.put("username", username);
        //requestParams.put("password", password);
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<Map> result =
                restTemplate.exchange(restAuthConfig.getUrl() + "?username=" + username + "&password="+password,
                        HttpMethod.GET, entity, Map.class, requestParams);
        return new UsernamePasswordAuthenticationToken(username, password, new ArrayList<>());
    }


    HttpHeaders createHeaders(String username, String password) {
        HttpHeaders acceptHeaders = new HttpHeaders() {
            {
                set(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON.toString());
            }
        };
        String authorization = username + ":" + password;
        String basic = new String(org.apache.commons.codec.binary.Base64.encodeBase64(authorization.getBytes(Charset.forName("US-ASCII"))));
        acceptHeaders.set("Authorization", "Basic " + basic);

        return acceptHeaders;
    }

}
