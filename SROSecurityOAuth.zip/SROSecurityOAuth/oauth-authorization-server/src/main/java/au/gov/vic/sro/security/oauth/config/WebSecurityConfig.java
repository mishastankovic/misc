package au.gov.vic.sro.security.oauth.config;

import au.gov.vic.sro.security.oauth.authprovider.CustomAuthenticationProvider;
import au.gov.vic.sro.security.oauth.authprovider.ldap.LdapAuthenticationProvider;
import au.gov.vic.sro.security.oauth.authprovider.rest.RestAuthenticationProvider;
import au.gov.vic.sro.security.oauth.authprovider.rest.RestTemplateFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.support.CustomSQLErrorCodesTranslation;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.rcp.RemoteAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@Configuration
@ComponentScan(basePackages = {"au.gov.vic.sro.security"})
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
    //@Autowired
    //private BCryptPasswordEncoder passwordEncoder;

    @Autowired
    private CustomAuthenticationProvider customAuthenticationProvider;

    /**
     * LDAP based authentication.
     *
     * @param auth
     * @throws Exception
     */
    /*
    public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
        auth.ldapAuthentication()
            .userDnPatterns("uid={0},ou=people")
            .groupSearchBase("ou=groups");
    }
    */

    public void configure(AuthenticationManagerBuilder auth) {
        auth.authenticationProvider(customAuthenticationProvider);
    }

    /**
     * Custom authentication provider example.
     * @return
     */
    /*
    @Bean
    public CustomAuthenticationProvider remoteAuthenticationProvider() {
        return new CustomAuthenticationProvider();
    }
    */

    /*
    @Autowired
    public void globalUserDetails(final AuthenticationManagerBuilder auth) throws Exception {
        auth.authenticationProvider(new RemoteAuthenticationProvider());

        // @formatter:off
        auth.inMemoryAuthentication()
          .withUser("john").password("{noop}123").roles("USER").and()
          .withUser("tom").password("111").roles("ADMIN").and()
          .withUser("user1").password("pass").roles("USER").and()
          .withUser("admin").password("nimda").roles("ADMIN");

    }// @formatter:on
    */


    @Override
    @Bean
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return super.authenticationManagerBean();

    }


    @Override
    protected void configure(final HttpSecurity http) throws Exception {
		http
                .csrf().disable()
                .httpBasic().disable()
                .logout().disable()
                .authorizeRequests()
                .antMatchers("/oauth/token").permitAll()
                .anyRequest().permitAll();
    }

}
