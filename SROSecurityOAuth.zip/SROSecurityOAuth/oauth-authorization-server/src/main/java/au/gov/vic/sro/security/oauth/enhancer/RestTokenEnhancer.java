package au.gov.vic.sro.security.oauth.enhancer;

import au.gov.vic.sro.security.oauth.authprovider.rest.RestTemplateFactory;
import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.remoting.RemoteAccessException;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.oauth2.common.DefaultOAuth2AccessToken;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.token.TokenEnhancer;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.nio.charset.Charset;
import java.security.Principal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

@Component
public class RestTokenEnhancer implements TokenEnhancer {

    // TODO - retrive this url from client specific configuration
    private String tokenEnhancerUrl = "http://localhost:8082/sro-security-oauth-resource/token/extraclaims";

    @Override
    public OAuth2AccessToken enhance(OAuth2AccessToken accessToken, OAuth2Authentication authentication) {

        String username = authentication.getName();
        String clientId = authentication.getOAuth2Request().getClientId();

        HttpEntity<Principal> entity = new HttpEntity<Principal>(createHeaders());
        Map<String, String> requestParams = new HashMap<String, String>();
        requestParams.put("username", username);
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<Map> result =
                restTemplate.exchange(tokenEnhancerUrl, HttpMethod.GET, entity, Map.class, requestParams);

        if(result.getStatusCode().isError()) {
            ((DefaultOAuth2AccessToken) accessToken).setAdditionalInformation(result.getBody());
        } else {
            throw new RemoteAccessException("Call to /token/extraclaims failed with error code "
                    + result.getStatusCode().toString());
        }

        return accessToken;

    }

    HttpHeaders createHeaders() {
        HttpHeaders acceptHeaders = new HttpHeaders() {
            {
                set(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON.toString());
            }
        };
        return acceptHeaders;
    }
}
