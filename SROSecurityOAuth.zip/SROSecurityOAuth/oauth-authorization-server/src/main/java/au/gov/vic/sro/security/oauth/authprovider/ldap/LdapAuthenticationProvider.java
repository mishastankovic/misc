package au.gov.vic.sro.security.oauth.authprovider.ldap;

import com.sun.org.apache.xpath.internal.operations.And;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.support.LdapContextSource;
import org.springframework.ldap.filter.AndFilter;
import org.springframework.ldap.filter.EqualsFilter;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import java.util.Collection;
import java.util.Collections;

@Configuration
@Component
public class LdapAuthenticationProvider implements AuthenticationProvider {

    private final Logger log = LoggerFactory.getLogger(LdapAuthenticationProvider.class);

    @Value("${ldap.urls: ldap://localhost:8389/}")
    private String ldapUrl = "ldap://localhost:8389/";

    @Value("${ldap.base.dn: dc=sro,dc=gov}")
    private String ldapBase = "dc=sro,dc=org";

    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {

        String username = authentication.getName();
        String password = (String) authentication.getCredentials();

        Assert.notNull(username,"username parameter not provided");
        Assert.notNull(password,"password parameter not provided");

        LdapContextSource ldapContextSource = new LdapContextSource();
        ldapContextSource.setUrl(ldapUrl);
        ldapContextSource.setBase(ldapBase);
        ldapContextSource.setUserDn(username);
        ldapContextSource.setPassword(password);

        try {
            ldapContextSource.afterPropertiesSet();
            LdapTemplate ldapTemplate = new LdapTemplate(ldapContextSource);
            ldapTemplate.afterPropertiesSet();
            AndFilter filter = new AndFilter();
            boolean authed = ldapTemplate.authenticate("", filter.toString(), password);
            log.info("User %s auuthenticated : %s", username, authed);
        } catch (Exception e) {
            throw new AuthenticationServiceException(e.getMessage(), e);
        }

        Collection<? extends GrantedAuthority> authorities = Collections.singleton(new SimpleGrantedAuthority("ROLE_USER"));
        UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(username, password, authorities);

        return authenticationToken;
        // return new UsernamePasswordAuthenticationToken(username,password);

    }


    @Override
    public boolean supports(Class<?> authentication) {
        return authentication.equals(UsernamePasswordAuthenticationToken.class);
    }


}
