package au.gov.vic.sro.security.oauth.authprovider.ldap;

import com.sun.org.apache.xpath.internal.operations.And;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.ldap.core.AttributesMapper;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.support.LdapContextSource;
import org.springframework.ldap.filter.AndFilter;
import org.springframework.ldap.filter.EqualsFilter;
import org.springframework.ldap.filter.Filter;
import org.springframework.ldap.query.LdapQuery;
import org.springframework.ldap.query.SearchScope;
import org.springframework.ldap.support.LdapUtils;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import javax.naming.Name;
import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

import static org.springframework.ldap.query.LdapQueryBuilder.query;

@Configuration
@Component
public class LdapAuthenticationProvider implements AuthenticationProvider {

    private final Logger log = LoggerFactory.getLogger(LdapAuthenticationProvider.class);

    @Value("${ldap.urls: ldap://localhost:8389/}")
    private String ldapUrl = "ldap://edir-mel2.sro.vic.gov.au:389/";

    @Value("${ldap.base-dn:dc=sro,dc=gov}")
    private String ldapBase = "ou=extranet,o=SRO";

    @Value("${ldap.userDnPattern:(&(objectclass=person)(uid=%s))}")
    private String userDnPattern="cn=%s";

    @Value("${ldap.resultAttributes:cn,sn,objectclass,uid}")
    private String attrListStr="cn,sn";

    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {

        String username = authentication.getName();
        String password = (String) authentication.getCredentials();

        Assert.notNull(username,"username parameter not provided");
        Assert.notNull(password,"password parameter not provided");

        LdapContextSource ldapContextSource = new LdapContextSource();
        ldapContextSource.setUrl(ldapUrl);
        ldapContextSource.setBase(ldapBase);
        ldapContextSource.setPassword("hs6Yuje4");
        ldapContextSource.setUserDn("cn=wasproxy,ou=extranet,o=SRO");

        try {
            ldapContextSource.getContext("cn=wasproxy,ou=extranet,o=SRO","hs6Yuje4");
            ldapContextSource.afterPropertiesSet();
            LdapTemplate ldapTemplate = new LdapTemplate(ldapContextSource);
            ldapTemplate.afterPropertiesSet();

            String filter = String.format(userDnPattern, username);
            boolean authed = ldapTemplate.authenticate("ou=DutiesOnline,ou=eBizCustomers", filter, password);

            String[] attrList = attrListStr.split(",");
            AttributesMapper<String> mapper = new AttributesMapper<String>() {
                @Override
                public String mapFromAttributes(Attributes attributes) throws NamingException {
                    StringBuffer result = new StringBuffer();
                    for(String attr: attrList) {
                        if (!StringUtils.isEmpty(result.toString())) {
                            result.append(", ");
                        }
                        result.append(attr + "=" + attributes.get(attr).get());
                    }
                    log.info("LDAP search result: " + result.toString());
                    return result.toString();
                }
            };

            LdapQuery query = query()
                    .searchScope(SearchScope.SUBTREE)
                    .timeLimit(3000)
                    .countLimit(10)
                    .attributes(attrList)
                    .base("ou=DutiesOnline,ou=eBizCustomers")
                    .filter(filter);

            ldapTemplate.search(query, mapper);
            log.info(String.format("User %s authenticated : %s", username, authed));

        } catch (Exception e) {
            e.printStackTrace();
            throw new AuthenticationServiceException(e.getMessage(), e);
        }

        Collection<? extends GrantedAuthority> authorities = new ArrayList<>(); // Collections.singleton(new SimpleGrantedAuthority("ROLE_USER"));
        UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(username, password, authorities);

        return authenticationToken;
        // return new UsernamePasswordAuthenticationToken(username,password);

    }


    @Override
    public boolean supports(Class<?> authentication) {
        return authentication.equals(UsernamePasswordAuthenticationToken.class);
    }


}
