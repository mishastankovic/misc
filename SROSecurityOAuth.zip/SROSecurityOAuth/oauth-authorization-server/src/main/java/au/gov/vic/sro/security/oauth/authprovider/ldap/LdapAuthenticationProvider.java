package au.gov.vic.sro.security.oauth.authprovider.ldap;

import com.sun.org.apache.xpath.internal.operations.And;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.ldap.core.AttributesMapper;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.support.LdapContextSource;
import org.springframework.ldap.filter.AndFilter;
import org.springframework.ldap.filter.EqualsFilter;
import org.springframework.ldap.filter.Filter;
import org.springframework.ldap.query.LdapQuery;
import org.springframework.ldap.query.SearchScope;
import org.springframework.ldap.support.LdapUtils;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import javax.naming.Name;
import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import static org.springframework.ldap.query.LdapQueryBuilder.query;

@Configuration
@Component
@PropertySource({ "classpath:application.yml" })
public class LdapAuthenticationProvider implements AuthenticationProvider {

    private final Logger log = LoggerFactory.getLogger(LdapAuthenticationProvider.class);

    @Value("${ldap.url: ldap://localhost:8389/}")
    private String ldapUrl;

    @Value("${ldap.base-dn}")
    private String ldapBase;

    @Value("${ldap.userDnPattern:(&(objectclass=person)(uid=%s))}")
    private String userDnPattern;

    @Value("${ldap.resultAttributes:cn,sn,objectclass,uid}")
    private String attrListStr;

    @Value("${ldap.username}")
    private String ldapConnectionUser;

    @Value("${ldap.password}")
    private String ldapConnectionPassword;

    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {

        String username = authentication.getName();
        String password = (String) authentication.getCredentials();

        Assert.notNull(username,"username parameter not provided");
        Assert.notNull(password,"password parameter not provided");

        LdapContextSource ldapContextSource = new LdapContextSource();
        ldapContextSource.setUrl(ldapUrl);
        ldapContextSource.setBase(ldapBase);
        ldapContextSource.setPassword(ldapConnectionPassword);
        ldapContextSource.setUserDn(ldapConnectionUser);
        ldapContextSource.setAnonymousReadOnly(false);

        try {
            //ldapContextSource.getContext("cn=wasproxy,ou=extranet,o=SRO","hs6Yuje4");
            ldapContextSource.afterPropertiesSet();
            LdapTemplate ldapTemplate = new LdapTemplate(ldapContextSource);
            ldapTemplate.afterPropertiesSet();

            String filter = String.format(userDnPattern, username);
            boolean authed = ldapTemplate.authenticate("", filter, password);

            String[] attrList = attrListStr.split(",");
            final Map<String, Object> result = new HashMap<String,Object>();
            AttributesMapper<Map<String, Object>> mapper = new AttributesMapper<Map<String, Object>>() {
                @Override
                public Map<String, Object> mapFromAttributes(Attributes attributes) throws NamingException {
                    result.clear();
                    for(String attr: attrList) {
                        result.put(attr, attributes.get(attr).get());
                        log.info(String.format("%s=%s", attr, result.get(attr)));
                    }
                    return result;
                }
            };

            /*
            LdapQuery query = query()
                    .searchScope(SearchScope.SUBTREE)
                    .timeLimit(3000)
                    .countLimit(10)
                    .attributes(attrList)
                    .base("ou=DutiesOnline,ou=eBizCustomers")
                    .filter(filter);

            ldapTemplate.search(query, mapper);
            */
            log.info(String.format("User %s authenticated : %s", username, authed));

            String userDn = String.format(userDnPattern, username);
            result.clear();
            ldapTemplate.lookup(userDn, mapper);
            result.forEach((key, val) -> log.info(String.format("%s=%s", key, val)));

        } catch (Exception e) {
            e.printStackTrace();
            throw new AuthenticationServiceException(e.getMessage(), e);
        }

        Collection<? extends GrantedAuthority> authorities = new ArrayList<>(); // Collections.singleton(new SimpleGrantedAuthority("ROLE_USER"));
        UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(username, password, authorities);

        return authenticationToken;
    }


    @Override
    public boolean supports(Class<?> authentication) {
        return authentication.equals(UsernamePasswordAuthenticationToken.class);
    }


}
