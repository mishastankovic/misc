package au.gov.vic.sro.security.oauth.authprovider.ldap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.support.LdapContextSource;
import org.springframework.ldap.filter.AndFilter;
import org.springframework.ldap.filter.EqualsFilter;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.Collections;

@Component
public class LdapAuthenticationProvider implements AuthenticationProvider {

    private final Logger log=LoggerFactory.getLogger(LdapAuthenticationProvider.class);

    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {

        String username = authentication.getName();
        String password = (String) authentication.getCredentials();

        if (username == null) {
            throw new BadCredentialsException("User is not found");
        }

        if (password == null) {
            throw new BadCredentialsException("Password is not found");
        }

        try {
            LdapContextSource ldapContextSource = new LdapContextSource();
            ldapContextSource.setUrl("ldap://jnj.com:3268");
            ldapContextSource.setBase("dc=jnj,dc=com");
            ldapContextSource.setUserDn(username);
            ldapContextSource.setPassword(password);

            try {
                // initialize the context
                ldapContextSource.afterPropertiesSet();
            } catch (Exception e) {
                e.printStackTrace();
            }

            LdapTemplate ldapTemplate = new LdapTemplate(ldapContextSource);
            ldapTemplate.afterPropertiesSet();

            // ldapTemplate.setIgnorePartialResultException(true); // Active Directory doesn’t transparently handle referrals. This fixes that.
            AndFilter filter = new AndFilter();
            filter.and(new EqualsFilter("sAMAccountName", username));

            try {
                boolean authed = ldapTemplate.authenticate("", filter.toString(), password);
                log.debug("Auuthenticated : "+authed);
            } catch (org.springframework.ldap.AuthenticationException ee) {
                //userDisplay.setText(“Invalid Username/Password”);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        Collection<? extends GrantedAuthority> authorities = Collections.singleton(new SimpleGrantedAuthority("ROLE_USER"));
        UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(username, password, authorities);

        return  authenticationToken;
        // return new UsernamePasswordAuthenticationToken(username,password);

    }


    @Override
    public boolean supports(Class<?> authentication) {
        return authentication.equals(UsernamePasswordAuthenticationToken.class);
    }

}
