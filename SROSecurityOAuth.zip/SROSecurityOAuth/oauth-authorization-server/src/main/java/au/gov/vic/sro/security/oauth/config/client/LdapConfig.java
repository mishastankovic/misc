package au.gov.vic.sro.security.oauth.config.client;

import org.springframework.beans.factory.annotation.Value;

/**
 * Default from global ldap parameters, allow to override with client specific values.
 */
public class LdapConfig {
    
    @Value("${ldap.url}")
    private String url;

    @Value("${ldap.username}")
    private String username;

    @Value("${ldap.password}")
    private String password;

    private String baseDN;

    private String resultAttributes;

    private String userDnPattern;

    public String getUrl() {
        return url;
    }

    public LdapConfig setUrl(String url) {
        this.url = url;
        return this;
    }

    public String getUsername() {
        return username;
    }

    public LdapConfig setUsername(String username) {
        this.username = username;
        return this;
    }

    public String getPassword() {
        return password;
    }

    public LdapConfig setPassword(String password) {
        this.password = password;
        return this;
    }

    public String getBaseDN() {
        return baseDN;
    }

    public LdapConfig setBaseDN(String baseDN) {
        this.baseDN = baseDN;
        return this;
    }

    public String getResultAttributes() {
        return resultAttributes;
    }

    public LdapConfig setResultAttributes(String resultAttributes) {
        this.resultAttributes = resultAttributes;
        return this;
    }

    public String getUserDnPattern() {
        return userDnPattern;
    }

    public LdapConfig setUserDnPattern(String userDnPattern) {
        this.userDnPattern = userDnPattern;
        return this;
    }
}
