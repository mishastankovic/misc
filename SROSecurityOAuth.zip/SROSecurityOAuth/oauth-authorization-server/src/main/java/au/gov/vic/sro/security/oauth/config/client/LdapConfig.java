package au.gov.vic.sro.security.oauth.config.client;

import org.springframework.beans.factory.annotation.Value;

/**
 * Default from global ldap parameters, allow to override for each client
 */
public class LdapConfig {
    private String baseDN;

    @Value("${ldap.url}")
    private String url;

    @Value("${ldap.username}")
    private String username;

    @Value("${ldap.password}")
    private String password;

    private String resultAttributes;

    private String userDnPattern;
}
