package au.gov.vic.sro.security.oauth.config.client;

import org.springframework.beans.factory.annotation.Value;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static java.util.stream.Collectors.toMap;

/**
 * Default from global ldap parameters, allow to override with client specific values.
 */
public class LdapConfig {
    
    @Value("${ldap.url}")
    private String url;

    @Value("${ldap.username}")
    private String username;

    @Value("${ldap.password}")
    private String password;

    private String baseDN;

    private Map<String, String> resultAttributes = new HashMap<String, String>();

    private String userDnPattern;

    private Map<String, String> mappers = new HashMap<String, String>();

    public String getUrl() {
        return url;
    }

    public LdapConfig setUrl(String url) {
        this.url = url;
        return this;
    }

    public String getUsername() {
        return username;
    }

    public LdapConfig setUsername(String username) {
        this.username = username;
        return this;
    }

    public String getPassword() {
        return password;
    }

    public LdapConfig setPassword(String password) {
        this.password = password;
        return this;
    }

    public String getBaseDN() {
        return baseDN;
    }

    public LdapConfig setBaseDN(String baseDN) {
        this.baseDN = baseDN;
        return this;
    }

    public String getResultAttribute(String key) {
        return resultAttributes.get(key);
    }

    public Set<String> getResultAttrSet() {
        return resultAttributes.keySet();
    }

    public LdapConfig addResultAttributes(String ldapAttr, String targetAttr) {
        resultAttributes.put(ldapAttr, targetAttr);
        return this;
    }

    /**
     * Result attribute mapping allows LDAP attributes to be stored with different name in the token.
     * For example cn=john might be stored as name=john.
     * The mapping syntax is as follows:
     * <pre>
     *  ldapAttrName->tokenAttrName
     *  e.g.
     *  cn->name
     * </pre>
     * In some cases we may want to extract part of the attribute values. This is achieved by providing enother mapping element:
     * <pre>
     *     groupMembership->roles->cn=(\w*),ou=Roles.*
     * </pre>
     * The last item in the above expression is regular expression and it is stored in the mapping hashtable against the
     * token attribute name, in this example roles.
     *
     * @param resultAttrProperty
     * @return
     */
    public LdapConfig setResultAttributes(String resultAttrProperty) {
        Map<String, String> attrMap = Arrays.asList(resultAttrProperty.split(";"))
                .stream()
                .map(str -> str.split("->"))
                .map(str -> {
                        if (str.length > 2) {
                            mappers.put(str[1], str[2]);
                        }
                        return str;
                    })
                .collect(toMap(str ->str[0], str -> str[1]));

        this.resultAttributes = attrMap;
        return this;
    }

    public String getUserDnPattern() {
        return userDnPattern;
    }

    public LdapConfig setUserDnPattern(String userDnPattern) {
        this.userDnPattern = userDnPattern;
        return this;
    }

    public void addMapper(String key, String regexp) {
        mappers.put(key, regexp);
    }

    public String getMapperFor(String key) {
        return mappers.get(key);
    }
}
