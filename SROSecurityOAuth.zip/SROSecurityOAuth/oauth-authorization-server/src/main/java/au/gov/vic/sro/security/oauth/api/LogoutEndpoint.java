package au.gov.vic.sro.security.oauth.api;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.security.oauth2.provider.endpoint.FrameworkEndpoint;
import org.springframework.security.oauth2.provider.token.ConsumerTokenServices;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class LogoutEndpoint {

    @Resource(name = "tokenServices")
    ConsumerTokenServices tokenServices;

    @RequestMapping(method = RequestMethod.GET, value="/revoke/{tokenId}")
    @ResponseBody
    public String dummy() {
        return "dummy GET response";
    }

    @RequestMapping(method = RequestMethod.DELETE, value = "/revoke/{tokenId}")
    @ResponseBody
    public void logout(@PathVariable("tokenId") String tokenId) {
        /*
        String authorization = request.getHeader("Authorization");
        if (authorization != null && authorization.contains("Bearer")) {
            String tokenId = authorization.substring("Bearer".length() + 1);
            tokenServices.revokeToken(tokenId);
        }
        */
        tokenServices.revokeToken(tokenId);

    }

}