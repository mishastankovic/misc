package au.gov.vic.sro.security.oauth.api;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.security.oauth2.provider.endpoint.FrameworkEndpoint;
import org.springframework.security.oauth2.provider.token.ConsumerTokenServices;
import org.springframework.web.bind.annotation.*;


@RestController
public class LogoutEndpoint {

    @Resource(name = "tokenServices")
    ConsumerTokenServices tokenServices;

    @DeleteMapping(value = "/revoke/{tokenId}")
    public void logout(@PathVariable String tokenId) {
        /*
        String authorization = request.getHeader("Authorization");
        if (authorization != null && authorization.contains("Bearer")) {
            String tokenId = authorization.substring("Bearer".length() + 1);
            tokenServices.revokeToken(tokenId);
        }
        */
        tokenServices.revokeToken(tokenId);

    }

}