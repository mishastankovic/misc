package au.gov.vic.sro.security.oauth.config;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import javax.sql.DataSource;

@Configuration
@Profile({"inmemory","jdbc"})
public class DataSourceConfig {

    @Autowired
    private Environment env;

    @Bean
    @ConditionalOnProperty("database.type")
    public DataSource dataSource() {
        String databaseType = env.getProperty("database.type");
        DriverManagerDataSource dataSource = null;
        if(StringUtils.isNotEmpty(databaseType)) {
            dataSource = new DriverManagerDataSource();
            dataSource.setDriverClassName(env.getProperty(databaseType + ".jdbc.driverClassName", databaseType));
            dataSource.setUrl(env.getProperty(databaseType + ".jdbc.url"));
            dataSource.setUsername(env.getProperty(databaseType + ".jdbc.user"));
            dataSource.setPassword(env.getProperty(databaseType + ".jdbc.pass"));
        }
        return dataSource;
    }
}
