package au.gov.vic.sro.security.oauth.authprovider;

import au.gov.vic.sro.security.oauth.authprovider.ldap.LdapAuthenticationProvider;
import au.gov.vic.sro.security.oauth.authprovider.rest.RestAuthenticationProvider;
import au.gov.vic.sro.security.oauth.authprovider.rest.RestTemplateFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

@Component
public class CustomAuthenticationProvider implements AuthenticationProvider {

    @Autowired
    private LdapAuthenticationProvider ldapAuthenticationProvider;

    @Autowired
    private RestAuthenticationProvider restAuthenticationProvider;


    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        AuthenticationProvider provider = null;
        if (true) {
            provider = getLdapAuthenticationProvider();
        } else {
            provider = getRestAuthenticationProvider();
        }
        return provider.authenticate(authentication);
    }

    @Override
    public boolean supports(Class<?> aClass) {
        return aClass.equals(UsernamePasswordAuthenticationToken.class);
    }

    private LdapAuthenticationProvider getLdapAuthenticationProvider() {
        if (ldapAuthenticationProvider == null) {
            ldapAuthenticationProvider = new LdapAuthenticationProvider();
        }
        return ldapAuthenticationProvider;
    }

    private RestAuthenticationProvider getRestAuthenticationProvider() {
        if (restAuthenticationProvider == null) {
           restAuthenticationProvider = new RestAuthenticationProvider();
        }
        return restAuthenticationProvider;
    }

}
