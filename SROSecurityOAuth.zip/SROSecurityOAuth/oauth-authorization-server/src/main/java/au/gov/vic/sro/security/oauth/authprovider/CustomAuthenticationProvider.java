package au.gov.vic.sro.security.oauth.authprovider;

import au.gov.vic.sro.security.oauth.authprovider.ldap.LdapAuthenticationProvider;
import au.gov.vic.sro.security.oauth.authprovider.rest.RestAuthenticationProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

@Component
public class CustomAuthenticationProvider implements AuthenticationProvider {

    @Autowired
    private LdapAuthenticationProvider ldapAuthenticationProvider;

    @Autowired
    private RestAuthenticationProvider restAuthenticationProvider;


    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        AuthenticationProvider provider = null;
        if (true) {
            provider = ldapAuthenticationProvider;
        } else {
            provider = restAuthenticationProvider;
        }
        return provider.authenticate(authentication);
    }

    @Override
    public boolean supports(Class<?> aClass) {
        return aClass.equals(UsernamePasswordAuthenticationToken.class);
    }

}
