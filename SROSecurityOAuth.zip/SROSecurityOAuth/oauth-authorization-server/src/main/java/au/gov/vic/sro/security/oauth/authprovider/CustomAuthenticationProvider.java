package au.gov.vic.sro.security.oauth.authprovider;

import au.gov.vic.sro.security.oauth.config.client.AuthenticationType;
import au.gov.vic.sro.security.oauth.config.client.ClientConfig;
import au.gov.vic.sro.security.oauth.config.client.ClientConfigFactory;
import au.gov.vic.sro.security.oauth.config.client.RestClientConfig;
import au.gov.vic.sro.security.oauth.helper.RequestHelper;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.*;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.InternalAuthenticationServiceException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;
import org.springframework.web.client.RestTemplate;

import javax.servlet.http.HttpServletRequest;
import java.nio.charset.Charset;
import java.security.Principal;
import java.util.*;

@Component
public class CustomAuthenticationProvider implements AuthenticationProvider {

    @Autowired
    private LdapAuthenticationProvider ldapAuthenticationProvider;

    @Autowired
    private RestAuthenticationProvider restAuthenticationProvider;

    @Autowired
    private RequestHelper requestHelper;


    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {

        ClientConfig clientConfig = requestHelper.getClientConfig();
        Assert.notNull(clientConfig, "Null clientConfig for " + requestHelper.getClientId());

        if (AuthenticationType.ldap == clientConfig.getAuthType()) {
            return ldapAuthenticationProvider.authenticate(authentication);
        } else if(AuthenticationType.rest == clientConfig.getAuthType()) {
            return restAuthenticationProvider.authenticate(authentication, clientConfig.getRestAuthConfig());
        } else {
            throw new InternalAuthenticationServiceException("CustomAithenticationProvider: Invalid AuthenticationType "
                    + clientConfig.getAuthType());
        }
    }

    @Override
    public boolean supports(Class<?> aClass) {
        return aClass.equals(UsernamePasswordAuthenticationToken.class);
    }

    private LdapAuthenticationProvider getLdapAuthenticationProvider() {
        if (ldapAuthenticationProvider == null) {
            ldapAuthenticationProvider = new LdapAuthenticationProvider();
        }
        return ldapAuthenticationProvider;
    }

}
