package au.gov.vic.sro.security.oauth.enhancer;

import static org.apache.commons.lang3.RandomStringUtils.randomAlphabetic;

import java.util.HashMap;
import java.util.Map;

import org.springframework.security.oauth2.common.DefaultOAuth2AccessToken;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.token.TokenEnhancer;

public class CustomTokenEnhancer implements TokenEnhancer {

    // TODO - configure from client settings
    private boolean remoteEnhancer = false;

    @Override
    public OAuth2AccessToken enhance(OAuth2AccessToken accessToken, OAuth2Authentication authentication) {

        if(remoteEnhancer) {
            final Map<String, Object> additionalInfo = new HashMap<>();

            additionalInfo.put("organization", authentication.getName() + randomAlphabetic(4));
            additionalInfo.put("username", authentication.getName());
            additionalInfo.put("fullName", authentication.getPrincipal().toString());

            ((DefaultOAuth2AccessToken) accessToken).setAdditionalInformation(additionalInfo);
        } else {

        }
        return accessToken;
    }
}
