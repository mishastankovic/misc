# Configuration
## Token store type
There are currently 3 authentication server configurations in the project as follows:
- OAuth2AuthorizationServerConfig  
Usees JDBC token store and JDBC client configuration

- OAuth2AuthorizationServerConfigInMemory  
Uses JDBC token store and in memory client configuration

- OAuth2AuthorizationServerConfigJwt
Uses JWT token store that does not store tokens anywhere. It uses in memory token store for clients.

Client store is used by Spring to perform basic authentication of clientId / password.  

To switch from one token store type to another, make the following changes:
- Comment out the anotations in the unused server configuraitons above the class declaration (e.g. @Configuration etc)

## Datasource
Currently the authorisation server uses a JDBC datasource, i.e. no connection pooling. This test will be used in the future for local tests only,
while a JNDI data source will be used for WebSphere environment.
The current configuraiton supports 3 types of databases as follows:
- H2  
  In memory database for local testing only. It gets initialised from scratch on every server run.

  
- Oracle database  
Database tables created in EBIZTST database, schema jxj1_shared. Refreshed manually for both schema and data changes.   
 
- MySQL database (not used at present)

When switching from one database type to another the following configuration changes have to be made:
- Make sure the corresponding driver is active / configured in /resources/database/persistence.properties
- Make sure the corresponding JDBC driver is included in pom.xml




# Build
`mvn clean install`

# Run
`mvn spring-boot:run`


