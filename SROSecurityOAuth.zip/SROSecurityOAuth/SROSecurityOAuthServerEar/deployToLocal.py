# Script to deploy the application to the local WebSphere instance
# Intended for developers workstation deployments only

import re
import AdminApplication

# Start DeploymentManager Declaration
class DeploymentManager:

	def isApplicationInstalled(self, applicationName):
		return AdminApplication.checkIfAppExists(applicationName)

	def uninstallApplication(self, applicationName):
		if self.isApplicationInstalled(applicationName) == "true":
			print "Un-Installing (", applicationName, ")"
			AdminApp.uninstall(applicationName)

	def installApplication(self, applicationName, earFile):

		# Ensure the application is not installed before we begin
		self.uninstallApplication(applicationName)

		print "Installing (", applicationName, ")"

		commandOptions = [
			"-verbose",
			"-appname",
			applicationName,
			"-distributeApp",
			"-reloadEnabled",	# Useful for hotdeploy
			"-reloadInterval",
			"3",
			"-usedefaultbindings",
			"-nodeployws", # Make this deployws when we've got web services
			"-nopreCompileJSPs"
		]

		print "Calling Install with app name (", applicationName, ") and command options (", commandOptions, ")"

		AdminApp.install(earFile, commandOptions)

		print "Application (", applicationName, ") installed"

# End DeploymentManager Declaration

deploymentStartTime = java.util.Date()

if len(sys.argv) < 2:
	raise Exception, "You must pass an ear file, and the application name\n"

earFile = sys.argv[0]
applicationName = sys.argv[1]
webName = sys.argv[2]

DeploymentManager().installApplication(applicationName, earFile)

# Configure the class loading (Single ClassLoader)
# AdminApplication.configureClassLoaderPolicyForAnApplication(applicationName, 'SINGLE')
# AdminApplication.configureClassLoaderLoadingModeForAnApplication(applicationName, 'PARENT_LAST')

# Configure the Web Module to use the Parent Last classloader policy
AdminApplication.configureWebModulesOfAnApplication(applicationName, webName, '1', 'PARENT_LAST')


print "Saving changes to the repository\n"

AdminConfig.save()

print "Successfully Saved changes\n"

deploymentEndTime = java.util.Date()
timeElapsed = (deploymentEndTime.getTime() - deploymentStartTime.getTime()) / 1000

print "Deployment Completed @ (", deploymentEndTime, "), Time Elapsed : (", timeElapsed , ") seconds.\n"
