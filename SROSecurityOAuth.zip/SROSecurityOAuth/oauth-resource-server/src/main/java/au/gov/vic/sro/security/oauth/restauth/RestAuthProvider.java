package au.gov.vic.sro.security.oauth.restauth;

import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.constraints.NotNull;
import java.security.Principal;
import java.util.HashMap;
import java.util.Map;

/**
 * Example implementation of a remote authentication service that is used for testing only.
 * The service exposes /authenticate endpoint that authenticates user based on the request boty parameters
 * and returns user details in the result.
 *
 */
@RestController
public class RestAuthProvider {

    @RequestMapping(method = RequestMethod.GET, value="/authenticate")
    public Map<String, Object> authenticate(@RequestParam String username, @RequestParam String password) throws AuthenticationException {
        // todo - implement properly this service
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("name", username);
        return map;
    }

}
