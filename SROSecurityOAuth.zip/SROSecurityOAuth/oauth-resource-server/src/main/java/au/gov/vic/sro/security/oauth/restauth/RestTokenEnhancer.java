package au.gov.vic.sro.security.oauth.restauth;

import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

/**
 * Example implementation of a remote token enhancer.
 * The service exposes /token/extraclaims endpoint that authenticates user based on the request boty parameters
 * and returns user details in the result.
 *
 */
@RestController
public class RestTokenEnhancer {

    @RequestMapping(method = RequestMethod.GET, value="/token/extraclaims")
    public Map<String, Object> enhance(@RequestParam String username) {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("name", username);
        return map;
    }

}
