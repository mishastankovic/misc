drop table oauth_client_details;
drop table oauth_client_token;
drop table oauth_access_token;
drop table oauth_refresh_token;
drop table oauth_code;
drop table oauth_approvals;
drop table ClientDetails;