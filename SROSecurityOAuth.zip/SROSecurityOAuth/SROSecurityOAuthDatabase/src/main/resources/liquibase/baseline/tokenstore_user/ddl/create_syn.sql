CREATE OR REPLACE SYNONYM oauth_client_details for ${liquibase.baseschema}.oauth_client_details;
CREATE OR REPLACE SYNONYM oauth_client_token for ${liquibase.baseschema}.oauth_client_token;
CREATE OR REPLACE SYNONYM oauth_access_token for ${liquibase.baseschema}.oauth_access_token;
CREATE OR REPLACE SYNONYM oauth_refresh_token for ${liquibase.baseschema}.oauth_refresh_token;
CREATE OR REPLACE SYNONYM oauth_code for ${liquibase.baseschema}.oauth_code;
CREATE OR REPLACE SYNONYM oauth_approvals for ${liquibase.baseschema}.oauth_approvals;
CREATE OR REPLACE SYNONYM ClientDetails for ${liquibase.baseschema}.ClientDetails;
