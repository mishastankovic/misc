GRANT SELECT,INSERT,UPDATE,DELETE ON oauth_client_details TO ${liquibase.appschema};
GRANT SELECT,INSERT,UPDATE,DELETE ON oauth_client_token TO ${liquibase.appschema};
GRANT SELECT,INSERT,UPDATE,DELETE ON oauth_access_token TO ${liquibase.appschema};
GRANT SELECT,INSERT,UPDATE,DELETE ON oauth_refresh_token TO ${liquibase.appschema};
GRANT SELECT,INSERT,UPDATE,DELETE ON oauth_code TO ${liquibase.appschema};
GRANT SELECT,INSERT,UPDATE,DELETE ON oauth_approvals TO ${liquibase.appschema};
GRANT SELECT,INSERT,UPDATE,DELETE ON ClientDetails TO ${liquibase.appschema};