delete from oauth_client_details;
INSERT INTO oauth_client_details
	(client_id, client_secret, scope, authorized_grant_types,
	web_server_redirect_uri, authorities, access_token_validity,
	refresh_token_validity, additional_information, autoapprove)
VALUES
	('autopay', '{noop}secret', 'autopay,read,write,foo',
	'password,authorization_code,refresh_token,client_credentials', null, null, 36000, 36000, null, 'true');
INSERT INTO oauth_client_details
	(client_id, client_secret, scope, authorized_grant_types,
	web_server_redirect_uri, authorities, access_token_validity,
	refresh_token_validity, additional_information, autoapprove)
VALUES
	('ddp', '{noop}secret', 'read,write,ddp,foo,bar',
	'implicit', null, null, 36000, 36000, null, 'false');
INSERT INTO oauth_client_details
	(client_id, client_secret, scope, authorized_grant_types,
	web_server_redirect_uri, authorities, access_token_validity,
	refresh_token_validity, additional_information, autoapprove)
VALUES
	('objections', '{noop}secret', 'objections,bar,read,write',
	'password,authorization_code,refresh_token', null, null, 36000, 36000, null, 'true');
INSERT INTO oauth_client_details
	(client_id, client_secret, scope, authorized_grant_types,
	web_server_redirect_uri, authorities, access_token_validity,
	refresh_token_validity, additional_information, autoapprove)
VALUES
	('wbt', '{noop}secret', 'wbt,bar,foo,read,write',
	'password,authorization_code,refresh_token', null, null, 36000, 36000, null, 'true');
