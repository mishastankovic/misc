delete from oauth_client_details;
INSERT INTO oauth_client_details
	(client_id, client_secret, scope, authorized_grant_types,
	web_server_redirect_uri, authorities, access_token_validity,
	refresh_token_validity, additional_information, autoapprove)
VALUES
	('autopay', '{noop}secret', 'autopay',
	'password,refresh_token', null, null, 36000, 36000, null, 'true');
INSERT INTO oauth_client_details
	(client_id, client_secret, scope, authorized_grant_types,
	web_server_redirect_uri, authorities, access_token_validity,
	refresh_token_validity, additional_information, autoapprove)
VALUES
	('ddp', '{noop}secret', 'duties',
	'password,refresh_token', null, null, 36000, 36000, null, 'true');
INSERT INTO oauth_client_details
	(client_id, client_secret, scope, authorized_grant_types,
	web_server_redirect_uri, authorities, access_token_validity,
	refresh_token_validity, additional_information, autoapprove)
VALUES
	('objections', '{noop}secret', 'objections',
	'password,refresh_token', null, null, 36000, 36000, null, 'true');
INSERT INTO oauth_client_details
	(client_id, client_secret, scope, authorized_grant_types,
	web_server_redirect_uri, authorities, access_token_validity,
	refresh_token_validity, additional_information, autoapprove)
VALUES
	('wbt', '{noop}secret', 'wbt',
	'password,refresh_token', null, null, 36000, 36000, null, 'true');
