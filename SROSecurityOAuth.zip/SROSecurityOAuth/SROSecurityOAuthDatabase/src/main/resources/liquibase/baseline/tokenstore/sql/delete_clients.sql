delete from oauth_client_details;
