DROP SYNONYM oauth_client_details;
DROP SYNONYM oauth_client_token;
DROP SYNONYM oauth_access_token;
DROP SYNONYM oauth_refresh_token;
DROP SYNONYM oauth_code;
DROP SYNONYM oauth_approvals;
DROP SYNONYM ClientDetails;