package au.gov.vic.sro.security.oauth.config.client;

import org.springframework.context.annotation.Configuration;

@Configuration
public class ClientConfig {

    private String url;

    private String username;

    private String password;
    
    private String name;

    private AuthenticationType authType;
    
    private LdapConfig ldapConfig;
    
    private RestClientConfig restAuthConfig;
    
    private RestClientConfig restEnhanceConfig;

    public String getUrl() {
        return url;
    }

    public ClientConfig setUrl(String url) {
        this.url = url;
        return this;
    }

    public String getUsername() {
        return username;
    }

    public ClientConfig setUsername(String username) {
        this.username = username;
        return this;
    }

    public String getPassword() {
        return password;
    }

    public ClientConfig setPassword(String password) {
        this.password = password;
        return this;
    }

    public String getName() {
        return name;
    }

    public ClientConfig setName(String name) {
        this.name = name;
        return this;
    }

    public AuthenticationType getAuthType() {
        return authType;
    }

    public ClientConfig setAuthType(AuthenticationType authType) {
        this.authType = authType;
        return this;
    }

    public LdapConfig getLdapConfig() {
        return ldapConfig;
    }

    public ClientConfig setLdapConfig(LdapConfig ldapConfig) {
        this.ldapConfig = ldapConfig;
        return this;
    }

    public RestClientConfig getRestAuthConfig() {
        return restAuthConfig;
    }

    public ClientConfig setRestAuthConfig(RestClientConfig restAuthConfig) {
        this.restAuthConfig = restAuthConfig;
        return this;
    }

    public RestClientConfig getRestEnhanceConfig() {
        return restEnhanceConfig;
    }

    public ClientConfig setRestEnhanceConfig(RestClientConfig restEnhanceConfig) {
        this.restEnhanceConfig = restEnhanceConfig;
        return this;
    }
}
