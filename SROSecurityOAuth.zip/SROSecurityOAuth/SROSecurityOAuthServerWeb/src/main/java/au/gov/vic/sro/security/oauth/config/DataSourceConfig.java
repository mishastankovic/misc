package au.gov.vic.sro.security.oauth.config;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import javax.sql.DataSource;

/**
 * This datasource is used only for local testing on embedded tomcat.
 */
@Configuration
//@Profile("local")
public class DataSourceConfig {

    // Persistence property names
    public static final String PROPERTY_NAME_DATABASE_TYPE = "database.type";
    public static final String PROPERTY_NAME_JDBC_DRIVER_CLASS = "jdbc.driverClassName";
    public static final String PROPERTY_NAME_DATABASE_URL = "jdbc.url";
    public static final String PROPERTY_NAME_DATABASE_USER = "jdbc.user";
    public static final String PROPERTY_NAME_DATABASE_PASSWORD = "jdbc.pass";


    @Autowired
    private Environment env;

    @Bean
    public DataSource dataSource() {
        String databaseType = env.getProperty(PROPERTY_NAME_DATABASE_TYPE);
        DriverManagerDataSource dataSource = null;
        if(StringUtils.isNotEmpty(databaseType)) {
            dataSource = new DriverManagerDataSource();
            dataSource.setDriverClassName(env.getProperty(databaseType + "." + PROPERTY_NAME_JDBC_DRIVER_CLASS));
            dataSource.setUrl(env.getProperty(databaseType + "." + PROPERTY_NAME_DATABASE_URL));
            dataSource.setUsername(env.getProperty(databaseType + "." + PROPERTY_NAME_DATABASE_USER));
            dataSource.setPassword(env.getProperty(databaseType + "." + PROPERTY_NAME_DATABASE_PASSWORD));
        }
        return dataSource;
    }
}
