package au.gov.vic.sro.security.oauth.config.client;

public enum AuthenticationType {
    ldap,
    rest
}
