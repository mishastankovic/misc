package au.gov.vic.sro.security.oauth.authprovider;

import au.gov.vic.sro.security.oauth.config.client.AuthenticationType;
import au.gov.vic.sro.security.oauth.config.client.ClientConfig;
import au.gov.vic.sro.security.oauth.helper.RequestHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.InternalAuthenticationServiceException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@Component
public class CustomAuthenticationProvider implements AuthenticationProvider, UserDetailsService {

    @Autowired
    private LdapAuthenticationProvider ldapAuthenticationProvider;

    @Autowired
    private RestAuthenticationProvider restAuthenticationProvider;

    @Autowired
    private RequestHelper requestHelper;


    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {

        ClientConfig clientConfig = requestHelper.getClientConfig();
        Assert.notNull(clientConfig, "Null clientConfig for " + requestHelper.getClientId());

        if (AuthenticationType.ldap == clientConfig.getAuthType()) {
            return ldapAuthenticationProvider.authenticate(authentication, clientConfig.getLdapConfig());
        } else if(AuthenticationType.rest == clientConfig.getAuthType()) {
            return restAuthenticationProvider.authenticate(authentication, clientConfig.getRestAuthConfig());
        } else {
            throw new InternalAuthenticationServiceException("CustomAithenticationProvider: Invalid AuthenticationType "
                    + clientConfig.getAuthType());
        }
    }

    @Override
    public boolean supports(Class<?> aClass) {
        return aClass.equals(UsernamePasswordAuthenticationToken.class);
    }

    // UserDetailsService methods

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        ClientConfig clientConfig = requestHelper.getClientConfig();
        Collection<? extends GrantedAuthority> authorities;
        if (AuthenticationType.ldap == clientConfig.getAuthType()) {
            authorities = ldapAuthenticationProvider.loadUserAuthorities(username, null, clientConfig.getLdapConfig());
        } else if(AuthenticationType.rest == clientConfig.getAuthType()) {
            authorities = restAuthenticationProvider.loadUserAuthorities(username, null, clientConfig.getRestAuthConfig());
        } else {
            throw new InternalAuthenticationServiceException("CustomAithenticationProvider: Invalid AuthenticationType "
                    + clientConfig.getAuthType());
        }
        return new User(username, "", authorities);
    }
}
