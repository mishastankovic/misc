package au.gov.vic.sro.security.oauth.helper;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import java.nio.charset.Charset;

public class RestHelper {
    /**
     * Auxiliary method that generates headers for the above REST call.
     *
     * @param username
     * @param password
     * @return
     */
    public static HttpHeaders createHeaders(String username, String password) {
        HttpHeaders acceptHeaders = new HttpHeaders() {
            {
                set(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON.toString());
            }
        };
        String authorization = username + ":" + password;
        String basic = new String(org.apache.commons.codec.binary.Base64.encodeBase64(authorization.getBytes(Charset.forName("US-ASCII"))));
        acceptHeaders.set("Authorization", "Basic " + basic);

        return acceptHeaders;
    }
}
