package au.gov.vic.sro.security.oauth.config.client;

public class RestClientConfig {

    private String url;
    private String clientId;
    private String clientPassword;

    public String getUrl() {
        return url;
    }

    public RestClientConfig setUrl(String url) {
        this.url = url;
        return this;
    }

    public String getClientId() {
        return clientId;
    }

    public RestClientConfig setClientId(String clientId) {
        this.clientId = clientId;
        return this;
    }

    public String getClientPassword() {
        return clientPassword;
    }

    public RestClientConfig setClientPassword(String clientPassword) {
        this.clientPassword = clientPassword;
        return this;
    }
}
