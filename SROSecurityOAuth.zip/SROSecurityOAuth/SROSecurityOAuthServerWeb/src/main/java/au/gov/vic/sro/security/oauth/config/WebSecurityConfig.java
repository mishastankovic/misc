package au.gov.vic.sro.security.oauth.config;

import au.gov.vic.sro.security.oauth.authprovider.CustomAuthenticationProvider;
import au.gov.vic.sro.security.oauth.config.client.ClientConfigFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.web.client.RestTemplate;

@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
    //@Autowired
    //private BCryptPasswordEncoder passwordEncoder;

    @Autowired
    private CustomAuthenticationProvider customAuthenticationProvider;

    public void configure(AuthenticationManagerBuilder auth) {
        auth.authenticationProvider(customAuthenticationProvider);
    }

    @Autowired
    public void configure(ClientConfigFactory clientConfigFactory) {
        clientConfigFactory.configure();
    }

    @Override
    @Bean
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return super.authenticationManagerBean();

    }

    @Bean
    public RestTemplate authRestTemplate() {
        return new RestTemplate();
    }

    @Bean
    public RestTemplate enhancerRestTemplate() {
        return new RestTemplate();
    }


    @Override
    protected void configure(final HttpSecurity http) throws Exception {
		http
            .csrf().disable()
            .httpBasic().disable()
            .logout().disable()
            .authorizeRequests()
            .antMatchers("/oauth/token").permitAll()
            .anyRequest().permitAll();
    }

}
