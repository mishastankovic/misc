package au.gov.vic.sro.security.oauth.config.client;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.source.InvalidConfigurationPropertyValueException;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
public class ClientConfigFactory {

    @Autowired
    private Environment env;

    private Map<String, ClientConfig> clientConfigurations = new HashMap<String, ClientConfig>();

    @Value("${clients}")
    private String[] clientNames;

    public void configure() {
        for(String clientName : clientNames) {
            clientConfigurations.put(clientName, readClientConfig(clientName));
        }
    }

    public Map<String, ClientConfig> getClientConfigurations() {
        return clientConfigurations;
    }

    private ClientConfig readClientConfig(String clientName) {
        ClientConfig client = new ClientConfig();
        client.setName(clientName);
        authConfig(client);
        tokenEnhancerConfig(client);
        return client;
    }

    private void authConfig(ClientConfig client) {
        String prefix = client.getName() + ".authentication.";
        client.setAuthType(AuthenticationType.valueOf(env.getProperty(prefix + "type")));
        if (AuthenticationType.ldap.equals(client.getAuthType())) {
            ldapConfig(client, prefix + "ldap.");
        } else if(AuthenticationType.rest.equals(client.getAuthType())) {
            client.setRestAuthConfig(readRestConfig(client, prefix));
        } else {
            throw new InvalidConfigurationPropertyValueException("type", client.getAuthType(),
                    client.getName());
        }
    }

    private void ldapConfig(ClientConfig client, String prefix) {
        LdapConfig ldapConfig = new LdapConfig();
        ldapConfig.setBaseDN(env.getProperty(prefix + "base-dn", env.getProperty("ldap.base-dn")))
                .setUsername(env.getProperty(prefix + "username", env.getProperty("ldap.username")))
                .setPassword(env.getProperty(prefix + "password", env.getProperty("ldap.password")))
                .setResultAttributes(env.getProperty(prefix + "resultAttributes", env.getProperty("ldap.resultAttributes")))
                .setUrl(env.getProperty(prefix + "url", env.getProperty("ldap.url")))
                .setUserDnPattern(env.getProperty(prefix + "userDnPattern", env.getProperty("ldap.userDnPattern")));
        client.setLdapConfig(ldapConfig);
    }

    private RestClientConfig readRestConfig(ClientConfig client, String prefix) {
        RestClientConfig restConfig = new RestClientConfig();
        restConfig.setUrl(env.getProperty(prefix + "url"));
        restConfig.setClientId(env.getProperty(prefix + "clientId"));
        restConfig.setClientPassword(env.getProperty(prefix + "clientPassword"));
        return restConfig;
    }

    private void tokenEnhancerConfig(ClientConfig client) {
        String prefix = client.getName() + ".tokenEnhancement.";
        if(env.containsProperty(prefix + "url")) {
            client.setRestEnhanceConfig(readRestConfig(client, prefix));
        }
    }

}
