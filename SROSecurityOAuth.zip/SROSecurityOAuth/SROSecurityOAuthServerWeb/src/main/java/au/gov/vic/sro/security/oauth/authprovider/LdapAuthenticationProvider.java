package au.gov.vic.sro.security.oauth.authprovider;

import au.gov.vic.sro.security.oauth.config.client.LdapConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.ldap.core.AttributesMapper;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.support.LdapContextSource;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import java.util.*;

@Configuration
@Component
public class LdapAuthenticationProvider {

    private final Logger log = LoggerFactory.getLogger(LdapAuthenticationProvider.class);


    /**
     * Authenticates user against LDAP.
     *
     * @param authentication
     * @param ldapConfig - Client specific LDAP configuration.
     * @return
     * @throws AuthenticationException
     */
    public Authentication authenticate(Authentication authentication, LdapConfig ldapConfig) throws AuthenticationException {

        String username = authentication.getName();
        String password = (String) authentication.getCredentials();

        Assert.notNull(username,"username parameter not provided");
        Assert.notNull(password,"password parameter not provided");

        Collection<? extends GrantedAuthority> authorities = loadUserAuthorities(username, password, ldapConfig);
        UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(username, password, authorities);

        return authenticationToken;
    }

    /**
     *
     */
    public Collection<? extends GrantedAuthority> loadUserAuthorities(String username, String password, LdapConfig ldapConfig) {

        Assert.notNull(username,"username parameter not provided");
        Assert.notNull(ldapConfig, "ldapConfig not found for username " + username);

        LdapContextSource ldapContextSource = new LdapContextSource();
        ldapContextSource.setUrl(ldapConfig.getUrl());
        ldapContextSource.setBase(ldapConfig.getBaseDN());
        ldapContextSource.setPassword(ldapConfig.getPassword());
        ldapContextSource.setUserDn(ldapConfig.getUsername());
        ldapContextSource.setAnonymousReadOnly(false);

        final Map<String, Object> result = new HashMap<String,Object>();
        try {
            ldapContextSource.afterPropertiesSet();
            LdapTemplate ldapTemplate = new LdapTemplate(ldapContextSource);
            ldapTemplate.afterPropertiesSet();

            String userDn = String.format(ldapConfig.getUserDnPattern(), username);
            String baseDn = ldapConfig.getBaseDN();
            if (!StringUtils.isEmpty(password)) {
                boolean authed = ldapContextSource.getContext(userDn +
                        (StringUtils.isEmpty(baseDn) ? "" : ("," + baseDn)), password) != null;
            }

            AttributesMapper<Map<String, Object>> mapper = new AttributesMapper<Map<String, Object>>() {
                @Override
                public Map<String, Object> mapFromAttributes(Attributes attributes) throws NamingException {
                    result.clear();
                    for(String attr: ldapConfig.getResultAttrSet()) {
                        String targetAttr = ldapConfig.getResultAttribute(attr);
                        String mapperRegexp = ldapConfig.getMapperFor(targetAttr);
                        String val = (String)attributes.get(attr).get();
                        if(val != null && mapperRegexp != null) {
                            val = val.replaceAll(mapperRegexp, "$1");
                        }
                        result.put(targetAttr, val);
                        log.info(String.format("%s=%s", targetAttr, val));
                    }
                    return result;
                }
            };

            result.clear();
            ldapTemplate.lookup(userDn, mapper);

        } catch (Exception e) {
            e.printStackTrace();
            throw new AuthenticationServiceException(e.getMessage(), e);
        }

        String roles = (String)result.get("roles");
        Collection<? extends GrantedAuthority> authorities =
                roles != null ? Collections.singleton( new SimpleGrantedAuthority(roles)) : new ArrayList();
        return authorities;

    }

}
