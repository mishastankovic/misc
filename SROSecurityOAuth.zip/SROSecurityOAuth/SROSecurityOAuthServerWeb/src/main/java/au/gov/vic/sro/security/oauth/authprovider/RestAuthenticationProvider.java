package au.gov.vic.sro.security.oauth.authprovider;

import au.gov.vic.sro.security.oauth.config.client.RestClientConfig;
import au.gov.vic.sro.security.oauth.helper.RestHelper;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

import static java.util.stream.Collectors.toList;

@Component
public class RestAuthenticationProvider {

    @Autowired
    private RestTemplate authRestTemplate;

    /**
     * Called during access token generation to authenticate user using the configured REST service.
     *
     * @param authentication
     * @param restAuthConfig - contains service URL end credentials.
     * @return
     * @throws AuthenticationException
     */
    public Authentication authenticate(Authentication authentication, RestClientConfig restAuthConfig) throws AuthenticationException {
        String username = authentication.getName();
        String password = (String)authentication.getCredentials().toString();
        Collection<? extends GrantedAuthority> authorities = call(username, password, restAuthConfig);
        return new UsernamePasswordAuthenticationToken(username, password, authorities);
    }


    /**
     * Called during token refresh to fetch the latest list of user authorities.
     *
     * @param username
     * @param password
     * @param restAuthConfig
     * @return
     */
    public Collection<? extends GrantedAuthority> loadUserAuthorities(String username, String password, RestClientConfig restAuthConfig ) {
        return call(username, password, restAuthConfig);
    }

    /**
     * Fetches user authorities using a REST service.
     * This method is called in two distict cases:
     * <ul>
     *     <li>As path of authentication when access token is generated</li>
     *     <li>As part of token refresh when list of authorities has to be regenerated. This ensures that
     *     the latest changes to the user profile are taken into accoung.</li>
     * </ul>
     *
     * @param username
     * @param password
     * @param restAuthConfig
     * @return
     */
    private Collection<? extends GrantedAuthority> call(String username, String password, RestClientConfig restAuthConfig) {
        HttpEntity<Principal> entity =
                new HttpEntity<Principal>(RestHelper.createHeaders(restAuthConfig.getClientId(), restAuthConfig.getClientPassword()));
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(restAuthConfig.getUrl())
                .queryParam("username", username);
        if (StringUtils.isNotEmpty(password)) {
            builder.queryParam("password", password);
        }
        ResponseEntity<String[]> result =
                authRestTemplate.exchange( builder.toUriString(), HttpMethod.GET, entity, String[].class);
        String[] authorities = result.getBody();
        Collection<? extends GrantedAuthority> authorityList;
        authorityList = (authorities != null && authorities.length > 0) ?
                Arrays.stream(authorities)
                        .map(authority -> new SimpleGrantedAuthority(authority))
                        .collect(toList())
                : new ArrayList();
        return authorityList;
    }


}
