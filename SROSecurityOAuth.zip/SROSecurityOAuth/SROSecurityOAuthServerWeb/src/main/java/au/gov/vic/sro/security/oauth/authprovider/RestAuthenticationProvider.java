package au.gov.vic.sro.security.oauth.authprovider;

import au.gov.vic.sro.security.oauth.config.client.RestClientConfig;
import com.sun.corba.se.impl.orbutil.graph.Graph;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.nio.charset.Charset;
import java.security.Principal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import static java.util.stream.Collectors.toList;

@Component
public class RestAuthenticationProvider {

    @Autowired
    private RestTemplate authRestTemplate;

    public Authentication authenticate(Authentication authentication, RestClientConfig restAuthConfig) throws AuthenticationException {
        String username = authentication.getName();
        String password = (String)authentication.getCredentials().toString();

        HttpEntity<Principal> entity = new HttpEntity<Principal>(createHeaders(restAuthConfig.getClientId(), restAuthConfig.getClientPassword()));
        Map<String, String> requestParams = new HashMap<String, String>();
        ResponseEntity<String[]> result =
                authRestTemplate.exchange(restAuthConfig.getUrl() + "?username=" + username + "&password=" + password,
                        HttpMethod.GET, entity, String[].class, requestParams);
        String[] authorities = result.getBody();
        Collection<? extends GrantedAuthority> authorityList;
        authorityList = (authorities != null && authorities.length > 0) ?
                            Arrays.stream(authorities)
                                .map(authority -> new SimpleGrantedAuthority(authority))
                                .collect(toList())
                            : new ArrayList();
        return new UsernamePasswordAuthenticationToken(username, password, authorityList );
    }


    HttpHeaders createHeaders(String username, String password) {
        HttpHeaders acceptHeaders = new HttpHeaders() {
            {
                set(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON.toString());
            }
        };
        String authorization = username + ":" + password;
        String basic = new String(org.apache.commons.codec.binary.Base64.encodeBase64(authorization.getBytes(Charset.forName("US-ASCII"))));
        acceptHeaders.set("Authorization", "Basic " + basic);

        return acceptHeaders;
    }

    public Collection<? extends GrantedAuthority> loadUserAuthorities(String username, String password, RestClientConfig restAuthConfig ) {
        return new ArrayList<>();
    }

}
