package au.gov.vic.sro.security.oauth.helper;

import au.gov.vic.sro.security.oauth.config.client.ClientConfig;
import au.gov.vic.sro.security.oauth.config.client.ClientConfigFactory;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import java.nio.charset.Charset;
import java.util.Base64;
import java.util.Optional;

/**
 * Utility class that extracts client data and other parameters from a HTTP request.
 * This information is used in the REST calls where clientId has to be added to an outbound request.
 */
@Component
public class RequestHelper {

    @Autowired
    private HttpServletRequest request;

    @Autowired
    private ClientConfigFactory clientConfigFactory;


    public ClientConfig getClientConfig() {
        return clientConfigFactory.getClientConfigurations().get(getClientId());
    }

    public String getClientId() {

        final String authorizationHeaderValue = request.getHeader("Authorization");
        final String base64AuthorizationHeader = Optional.ofNullable(authorizationHeaderValue)
                .map(headerValue->headerValue.substring("Basic ".length())).orElse("");

        if(StringUtils.isNotEmpty(base64AuthorizationHeader)){
            String decodedAuthorizationHeader = new String(Base64.getDecoder().decode(base64AuthorizationHeader), Charset.forName("UTF-8"));
            return decodedAuthorizationHeader.split(":")[0];
        }

        return "";
    }

}
