package au.gov.vic.sro.security.oauth.enhancer;

import au.gov.vic.sro.security.oauth.config.client.RestClientConfig;
import au.gov.vic.sro.security.oauth.helper.RestHelper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.remoting.RemoteAccessException;
import org.springframework.security.oauth2.common.DefaultOAuth2AccessToken;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.security.Principal;
import java.util.Map;

@Component
public class RestTokenEnhancer {

    private static final Logger logger = LogManager.getLogger(RestTokenEnhancer.class);

    @Autowired
    private RestTemplate enhancerRestTemplate;


    /**
     * Makes a REST call to retrieve additional token information from a remote provider.
     *
     * @param accessToken
     * @param authentication
     * @param restConfig
     * @return
     */
    public OAuth2AccessToken enhance(OAuth2AccessToken accessToken, OAuth2Authentication authentication,
                                     RestClientConfig restConfig) {

        String username = authentication.getName();
        HttpEntity<Principal> entity =
                new HttpEntity<Principal>(RestHelper.createHeaders(restConfig.getClientId(), restConfig.getClientPassword()));
        UriComponentsBuilder builder = UriComponentsBuilder
                .fromHttpUrl(restConfig.getUrl())
                .queryParam("username", username);
        ResponseEntity<Map> result =  enhancerRestTemplate.exchange( builder.toUriString(), HttpMethod.GET, entity, Map.class);
        if (result != null) {
            Map<String, Object> data = result.getBody();
            if (!result.getStatusCode().isError()) {
                ((DefaultOAuth2AccessToken) accessToken).setAdditionalInformation(data);
            } else {
                logger.error("HTTP error {} ", result.getStatusCode() );
                //throw new RemoteAccessException(String.format("Call to %s failed with error code %s", restConfig.getUrl(),
                //        result.getStatusCode().toString()));
            }
        }
        return accessToken;
    }

}
