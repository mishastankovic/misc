package au.gov.vic.sro.security.oauth.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.annotation.Order;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import org.springframework.jndi.JndiObjectFactoryBean;

import javax.naming.NamingException;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.Statement;

@Configuration
@Order(1)
@Profile({"localtest","development","integration","integration2","training","production"})
public class WsDataSourceConfig {

    public static final String PROPERTY_NAME_DATASOURCE_JNDI = "datasource.jndi";

    @Autowired
    private Environment env;

    @Bean
    public DataSource dataSource() throws IllegalArgumentException, NamingException {
        JndiDataSourceLookup dsLookup = new JndiDataSourceLookup();
        dsLookup.setResourceRef(true);
        return dsLookup.getDataSource( env.getProperty(PROPERTY_NAME_DATASOURCE_JNDI));
    }

}
