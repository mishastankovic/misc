package au.gov.vic.sro.security.oauth.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.provider.token.ConsumerTokenServices;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class LogoutEndpoint {

    @Autowired
    ConsumerTokenServices tokenServices;

    @DeleteMapping(value = "/revoke/{tokenId}")
    public void logout(@PathVariable String tokenId) {
        tokenServices.revokeToken(tokenId);
    }

}