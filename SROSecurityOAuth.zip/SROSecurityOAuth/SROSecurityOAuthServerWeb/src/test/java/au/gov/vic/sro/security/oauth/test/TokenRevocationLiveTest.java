package au.gov.vic.sro.security.oauth.test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import io.restassured.RestAssured;
import io.restassured.response.Response;

import java.util.HashMap;
import java.util.Map;

import org.junit.Ignore;
import org.junit.Test;

@Ignore
public class TokenRevocationLiveTest {
    public static final String authServer2Url = "http://localhost:8082/spring-security-oauth-resource";
    public static final String authServer1Url = "http://localhost:8081/spring-security-oauth-server";

    @Test
    public void whenObtainingAccessToken_thenCorrect() {
        final Response authServerResponse =
                obtainAccessToken("autopay", "john", "123");
        final String accessToken = authServerResponse.jsonPath().getString("access_token");
        assertNotNull(accessToken);

        final Response resourceServerResponse =
                RestAssured.given().header("Authorization", "Bearer " + accessToken)
                        .get(authServer2Url + "/foos/100");
        assertThat(resourceServerResponse.getStatusCode(), equalTo(200));
    }

    private Response obtainAccessToken(String clientId, String username, String password) {
        final Map<String, String> params = new HashMap<String, String>();
        params.put("grant_type", "password");
        params.put("client_id", clientId);
        params.put("username", username);
        params.put("password", password);
        return RestAssured.given().auth().preemptive().basic(clientId, "secret")
                .and().with().params(params).when()
                .post(authServer1Url + "/oauth/token");
    }

    private String obtainRefreshToken(String clientId, final String refreshToken) {
        final Map<String, String> params = new HashMap<String, String>();
        params.put("grant_type", "refresh_token");
        params.put("client_id", clientId);
        params.put("refresh_token", refreshToken);
        final Response response =
                RestAssured.given().auth().preemptive().basic(clientId, "secret").and().with().params(params)
                        .when().post(authServer1Url + "/oauth/token");
        return response.jsonPath().getString("access_token");
    }

    private void authorizeClient(String clientId) {
        final Map<String, String> params = new HashMap<String, String>();
        params.put("response_type", "code");
        params.put("client_id", clientId);
        params.put("scope", "read,write");
        final Response response =
                RestAssured.given().auth().preemptive().basic(clientId, "secret").and().with().params(params)
                        .when().post(authServer1Url + "/oauth/authorize");
    }

}