package au.gov.vic.sro.security.oauth.test;

import au.gov.vic.sro.security.oauth.AuthorizationServerApplication;
import com.unboundid.util.Base64;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.json.JSONObject;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.util.HashMap;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.isEmptyOrNullString;
import static org.hamcrest.core.IsNull.notNullValue;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

//@Ignore
@RunWith(SpringRunner.class)
@SpringBootTest(classes = AuthorizationServerApplication.class)
@AutoConfigureMockMvc
public class TokenRevocationLiveTest {
    //public static final String authServer2Url = "http://localhost:8082/spring-security-oauth-resource";
    //public static final String authServer1Url = "http://localhost:8081/spring-security-oauth-server";
    @Autowired
    private MockMvc mvc;

    @Test
    public void whenObtainingAccessToken_thenCorrect() throws Exception {
        final MockHttpServletResponse authServerResponse =
                obtainAccessToken("ddp", "PASVER0001", "Password1");
        String content = authServerResponse.getContentAsString();
        JSONObject jsonObj = new JSONObject(content);
        String accessToken = jsonObj.getString("access_token");
        //final String accessToken = authServerResponse.jsonPath().getString("access_token");
        assertNotNull(accessToken);
        System.out.println("Access token: " + accessToken);
    }

    private void obtainRefreshToken(String clientId, final String refreshToken) {
        final Map<String, String> params = new HashMap<String, String>();
        params.put("grant_type", "refresh_token");
        params.put("client_id", clientId);
        params.put("refresh_token", refreshToken);
    }

    private MockHttpServletResponse obtainAccessToken(String clientId, String username, String password) throws Exception {
        final Map<String, String> params = new HashMap<String, String>();
        params.put("grant_type", "password");
        params.put("client_id", clientId);
        params.put("username", username);
        params.put("password", password);

        MvcResult result = mvc.perform(post("/oauth/token")
                .param("grant_type", "password")
                .param("client_id",clientId)
                .param("username", username)
                .param("password", password)
                .header("Authorization","Basic " + Base64.encode(clientId + ":secret" )))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.username", is(username)))
                .andExpect(jsonPath("$.access_token", notNullValue()))
                .andReturn();

        return result.getResponse();
    }

}