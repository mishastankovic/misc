package au.gov.vic.sro.security.oauth.test;


import au.gov.vic.sro.security.oauth.AuthorizationServerApplication;
import au.gov.vic.sro.security.oauth.config.client.ClientConfig;
import au.gov.vic.sro.security.oauth.config.client.ClientConfigFactory;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = AuthorizationServerApplication.class)
public class ClientConfigFactoryTest {

    @Autowired
    private ClientConfigFactory clientConfigFactory;

    @Test
    public void testConfig() {
        clientConfigFactory.configure();
        Map<String, ClientConfig> clients = clientConfigFactory.getClientConfigurations();
        assertNotNull(clients.get("autopay"));
        assertNotNull(clients.get("wbt"));
        assertNotNull(clients.get("ddp"));
        assertNotNull(clients.get("objections"));
    }

    @Test
    public void testRegexp() {
        String regexp = "cn=(\\w*),ou=Roles.*";
        String val = "cn=dutiesonlineuser,ou=Roles,ou=DutiesOnline,ou=Applications,ou=extranet,o=SRO";
        String res = val.replaceAll(regexp, "$1");
        assertEquals(res, ("dutiesonlineuser"));
    }
}
