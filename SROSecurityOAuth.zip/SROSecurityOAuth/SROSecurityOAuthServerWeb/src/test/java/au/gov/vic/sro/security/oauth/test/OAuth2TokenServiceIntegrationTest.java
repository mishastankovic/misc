package au.gov.vic.sro.security.oauth.test;

import au.gov.vic.sro.security.oauth.AuthorizationServerApplication;
import com.unboundid.util.Base64;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.isEmptyOrNullString;
import static org.hamcrest.core.IsNull.notNullValue;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = AuthorizationServerApplication.class)
@AutoConfigureMockMvc
public class OAuth2TokenServiceIntegrationTest {
    //public static final String authServer2Url = "http://localhost:8082/spring-security-oauth-resource";
    //public static final String authServer1Url = "http://localhost:8081/spring-security-oauth-server";
    @Autowired
    private MockMvc mvc;

    @MockBean
    private RestTemplate authRestTemplate;

    /**
     * This test generates token for a user that exists in an LDAP repository.
     * The current test setup assumes that the user exists in the SRO eDirectory.
     *
     * @throws Exception
     */
    //@Test
    public void ldapAuthentication_happyPath() throws Exception {

        String clientId = "ddp";
        String clientSecret = "secret";
        String username = "PASVER0001";
        String pwd = "Password1";
        String scope = "duties";

        // When I provide valid user credentials
        final MockHttpServletResponse generateTokenResponse = generateAccessToken(clientId, username, pwd);
        String content = generateTokenResponse.getContentAsString();
        JSONObject jsonObj = new JSONObject(content);
        String accessToken = jsonObj.getString("access_token");
        String refreshToken = jsonObj.getString("refresh_token");

        // I expect a valid token back
        assertNotNull(accessToken);
        System.out.println("Access token: " + accessToken);

        // And check_token returns token information
        final MockHttpServletResponse checkTokenResponse = checkAccessToken(accessToken, clientId, clientSecret, true);
        content = checkTokenResponse.getContentAsString();
        System.out.println("check_token response: " + content);
        jsonObj = new JSONObject(content);
        assertNotNull(jsonObj);
        assertEquals(jsonObj.get("user_name"), username);
        assertEquals(jsonObj.getJSONArray("scope").get(0), scope);
        assertNotNull(jsonObj.get("exp"));

        // And I can refresh the token
        final MockHttpServletResponse refreshTokenResponse = refreshToken(refreshToken, clientId, clientSecret);
        content = refreshTokenResponse.getContentAsString();
        System.out.println("refresh_token response: " + content);
        jsonObj = new JSONObject(content);
        assertNotNull(jsonObj);
        String newAccessToken = jsonObj.getString("access_token");
        String newRefreshToken = jsonObj.getString("refresh_token");

        // And check_token returns token information
        final MockHttpServletResponse checkNewTokenResponse = checkAccessToken(newAccessToken, clientId, clientSecret, true);
        content = checkNewTokenResponse.getContentAsString();
        System.out.println("check_token refreshed response: " + content);
        jsonObj = new JSONObject(content);
        assertNotNull(jsonObj);
        assertEquals(jsonObj.get("user_name"), username);
        assertEquals(jsonObj.getJSONArray("scope").get(0), scope);
        assertNotNull(jsonObj.get("exp"));

        // And I revoke token
       final  MockHttpServletResponse revokeTokenResponse = revokeToken(newAccessToken, clientId, clientSecret);
        content = revokeTokenResponse.getContentAsString();
        System.out.println("revoke response: " + content);

        // Then check_toke returns invalid token result
        MockHttpServletResponse checkRevokedTokenResponse = checkAccessToken(newAccessToken, clientId, clientSecret, false);
        content = checkTokenResponse.getContentAsString();
        System.out.println("check_token revoked response: " + content);
    }

    @Test
    public void restAuthentication_happyDays() throws Exception {

        String clientId = "autopay";
        String clientSecret = "secret";
        String username = "john";
        String pwd = "password";
        String scope = "autopay";
        String authority = "autopayread";

        String[] authorities = {"autopayread"};
        ResponseEntity<String[]> responseEntity = new ResponseEntity(authorities, HttpStatus.OK);
        Mockito
                .when(
//                        authRestTemplate.exchange(Mockito.anyString(), Mockito.eq(HttpMethod.GET), Mockito.any(HttpEntity.class),
//                        Mockito.eq(String[].class), Mockito.any(Map.class)))
                        authRestTemplate.exchange(
                                Mockito.anyString(),
                                Mockito.eq(HttpMethod.GET),
                                Mockito.any(HttpEntity.class),
                                Mockito.eq(String[].class)))
                .thenReturn(responseEntity);

        // Create access token
        final MockHttpServletResponse generateTokenResponse = generateAccessToken(clientId, username, pwd);
        String content = generateTokenResponse.getContentAsString();
        System.out.println("generateTokenResponse: " + content);
        JSONObject jsonObj = new JSONObject(content);
        String accessToken = jsonObj.getString("access_token");
        String refreshToken = jsonObj.getString("refresh_token");
        System.out.println("access_token: " + accessToken);

        final MockHttpServletResponse checkTokenResponse = checkAccessToken(accessToken, clientId, clientSecret, true);
        content = checkTokenResponse.getContentAsString();
        System.out.println("check_token response: " + content);
        jsonObj = new JSONObject(content);
        assertNotNull(jsonObj);
        assertEquals(jsonObj.get("user_name"), username);
        assertEquals(jsonObj.getJSONArray("scope").get(0), scope);
        assertNotNull(jsonObj.get("exp"));
        assertEquals(jsonObj.getJSONArray("authorities").get(0), authority);

    }

    @Test
    public void restEnhancer_happyDays() {

    }

    /**
     *
     * @param clientId
     * @param refreshToken
     */
    private MockHttpServletResponse refreshToken(final String refreshToken, String clientId, String clientSecret) throws Exception {
        MvcResult result = mvc.perform(post("/oauth/token")
            .param("grant_type", "refresh_token")
            .param("client_id", clientId)
            .param("refresh_token", refreshToken)
            .header("Authorization","Basic " + Base64.encode(clientId + ":" + clientSecret )))
            .andExpect(status().isOk())
            .andReturn();

        return result.getResponse();
    }

    /**
     *
     * @param clientId
     * @param username
     * @param password
     * @return
     * @throws Exception
     */
    private MockHttpServletResponse generateAccessToken(String clientId, String username, String password) throws Exception {

        MvcResult result = mvc.perform(post("/oauth/token")
                .param("grant_type", "password")
                .param("client_id",clientId)
                .param("username", username)
                .param("password", password)
                .header("Authorization","Basic " + Base64.encode(clientId + ":secret" )))
                .andExpect(status().isOk())
                .andReturn();

        return result.getResponse();
    }

    /**
     *
     * @param accessToken
     * @param clientId
     * @param clientSecret
     * @return
     * @throws Exception
     */
    private MockHttpServletResponse checkAccessToken(String accessToken, String clientId, String clientSecret, boolean success) throws Exception {

        MvcResult result = mvc.perform(get("/oauth/check_token")
                .param("token", accessToken)
                .header("Authorization","Basic " + Base64.encode(clientId + ":" + clientSecret)))
                .andExpect(success ? status().isOk() : status().is4xxClientError())
                .andReturn();
        return result.getResponse();
    }

    private MockHttpServletResponse revokeToken(String accessToken, String clientId, String clientSecret) throws Exception {
        MvcResult result = mvc.perform(delete("/revoke/" + accessToken)
                .header("Authorization","Basic " + Base64.encode(clientId + ":" + clientSecret)))
                .andExpect(status().isOk())
                .andReturn();
        return result.getResponse();
    }

}