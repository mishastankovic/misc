# Script to deploy to WebSphere
import re
import AdminApplication

# Start DeploymentManager Declaration
class DeploymentManager:

	def isApplicationInstalled(self, applicationName):
		return AdminApplication.checkIfAppExists(applicationName)

	def uninstallApplication(self, applicationName):
		if self.isApplicationInstalled(applicationName) == "true":
			print "Un-Installing (", applicationName, ")"
			AdminApp.uninstall(applicationName)

	def installApplication(self, applicationName, warFile, contextroot):

		# Ensure the application is not installed before we begin
		self.uninstallApplication(applicationName)
		
		print "Installing (", applicationName, "with context root" , contextroot , ")"

		commandOptions = [
			"-verbose",
			"-appname",	applicationName,
			"-distributeApp",
			"-reloadEnabled",	# Useful for hotdeploy
			"-reloadInterval", "3",
			"-usedefaultbindings",
			"-nodeployws", # Make this deployws when we've got web services
			"-nopreCompileJSPs",
			"-contextroot", contextroot
		]

		print "Calling Install with app name (", applicationName, ") and command options (", commandOptions, ")"

		AdminApp.install(warFile, commandOptions)

		print "Application (", applicationName, ") installed"

# End DeploymentManager Declaration

deploymentStartTime = java.util.Date()

if len(sys.argv) < 2:
	raise Exception, "You must pass  an ear file, and the application name\n"

warFile = sys.argv[0]
applicationName = sys.argv[1]
contextroot = sys.argv[2]

print AdminApp.options()

DeploymentManager().installApplication(applicationName, warFile, contextroot)

# Configure the class loading (Single ClassLoader)
# AdminApplication.configureClassLoaderPolicyForAnApplication(applicationName, 'SINGLE')
AdminApplication.configureClassLoaderLoadingModeForAnApplication(applicationName, 'PARENT_LAST')

# Configure the Web Module to use the Parent Last classloader policy
#AdminApplication.configureWebModulesOfAnApplication('SROSecurityOAuthWar', 'DutiesFormWeb', '1', 'PARENT_LAST')

print "Saving changes to the repository\n"

AdminConfig.save()

print "Successfully Saved changes\n"


deploymentEndTime = java.util.Date()
timeElapsed = (deploymentEndTime.getTime() - deploymentStartTime.getTime()) / 1000

print "Deployment Completed @ (", deploymentEndTime, "), Time Elapsed : (", timeElapsed , ") seconds.\n"
