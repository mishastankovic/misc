package au.gov.vic.sro.security.oauth.remoteauth;

import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.nio.charset.Charset;
import java.security.Principal;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

@Component
public class RemoteAuthenticationProvider implements AuthenticationProvider {

    @Autowired
    private RestTemplateFactory restTemplateFactory;

    @Value("${remoteAuthenticationProvider.uri}")
    private String authenticationUri;

    @Value("${remoteAuthenticationProvider.clientId}")
    private String clientId;

    @Value("${remoteAuthenticationProvider.clientPassword}")
    private String clientPassword;

    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        String username = authentication.getName();
        String password = (String)authentication.getCredentials();

        HttpEntity<Principal> entity = new HttpEntity<Principal>(createHeaders(clientId, clientPassword));
        Map<String, String> requestParams = new HashMap<String, String>();
        requestParams.put("username", username);
        requestParams.put("password", password);
        ResponseEntity<Authentication> result =
                restTemplateFactory.getObject().exchange(authenticationUri, HttpMethod.GET, entity, Authentication.class, requestParams);

        return result.getBody();
        /*
        Principal principal = result.getBody();
        return new Authentication() {

            private boolean authenticated = true;

            @Override
            public Collection<? extends GrantedAuthority> getAuthorities() {
                return null;
            }

            @Override
            public Object getCredentials() {
                return null;
            }

            @Override
            public Object getDetails() {
                return null;
            }

            @Override
            public Object getPrincipal() {
                return principal;
            }

            @Override
            public boolean isAuthenticated() {
                return authenticated;
            }

            @Override
            public void setAuthenticated(boolean b) throws IllegalArgumentException {
                this.authenticated = b;
            }

            @Override
            public String getName() {
                return principal.getName();
            }
        };
        */
    }

    @Override
    public boolean supports(Class<?> aClass) {
        return false;
    }

    HttpHeaders createHeaders(String username, String password) {
        HttpHeaders acceptHeaders = new HttpHeaders() {
            {
                set(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON.toString());
            }
        };
        String authorization = username + ":" + password;
        String basic = new String(Base64.encodeBase64(authorization.getBytes(Charset.forName("US-ASCII"))));
        acceptHeaders.set("Authorization", "Basic " + basic);

        return acceptHeaders;
    }
}
