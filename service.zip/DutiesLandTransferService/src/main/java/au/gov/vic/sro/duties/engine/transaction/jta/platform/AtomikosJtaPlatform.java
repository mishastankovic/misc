package au.gov.vic.sro.duties.engine.transaction.jta.platform;

import javax.transaction.TransactionManager;
import javax.transaction.UserTransaction;

import org.hibernate.boot.registry.classloading.spi.ClassLoaderService;
import org.hibernate.engine.transaction.jta.platform.internal.AbstractJtaPlatform;
import org.hibernate.engine.transaction.jta.platform.spi.JtaPlatformException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * A replica of org.hibernate.engine.transaction.jta.platform.internal.AtomikosJtaPlatform in Hibernate 5.4
 * 
 * Refer to https://github.com/hibernate/hibernate-orm/blob/master/hibernate-core/src/main/java/org/hibernate/engine/transaction/jta/platform/internal/AtomikosJtaPlatform.java
 */
public class AtomikosJtaPlatform extends AbstractJtaPlatform { 

	private static final long serialVersionUID = 833581032180180512L;

	private static final Logger log = LoggerFactory.getLogger(AtomikosJtaPlatform.class);

	public static final String TM_CLASS_NAME = "com.atomikos.icatch.jta.UserTransactionManager";

	@Override
	protected TransactionManager locateTransactionManager() {
		try {
			@SuppressWarnings("rawtypes")
			Class transactionManagerClass = serviceRegistry().getService(ClassLoaderService.class)
					.classForName(TM_CLASS_NAME);
			return (TransactionManager) transactionManagerClass.newInstance();
		} catch (Exception e) {
			log.error("Could not instantiate Atomikos TransactionManager", e);
			throw new JtaPlatformException("Could not instantiate Atomikos TransactionManager", e);
		}
	}

	@Override
	protected UserTransaction locateUserTransaction() {
		return (UserTransaction) jndiService().locate("java:comp/UserTransaction");
	}
}