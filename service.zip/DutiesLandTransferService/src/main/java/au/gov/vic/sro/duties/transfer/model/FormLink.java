package au.gov.vic.sro.duties.transfer.model;

import java.util.ArrayList;
import java.util.List;

public class FormLink {

	private Long transactionId;
	private Long esysLodgementId;
	private List<Error> acknowledgedWarnings = new ArrayList<>();

	public FormLink() {}

	public FormLink(Long transactionId, Long esysLodgementId, List<Error> ackWarnings) {
		this.transactionId = transactionId;
		this.esysLodgementId = esysLodgementId;
		this.acknowledgedWarnings = ackWarnings;
	}

	public FormLink(Long transactionId, Long esysLodgementId) {
		this.transactionId = transactionId;
		this.esysLodgementId = esysLodgementId;
	}

	public Long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Long transactionId) {
		this.transactionId = transactionId;
	}

	public Long getEsysLodgementId() {
		return esysLodgementId;
	}

	public void setEsysLodgementId(Long esysLodgementId) {
		this.esysLodgementId = esysLodgementId;
	}

	public List<Error> getAcknowledgedWarnings() {
		return acknowledgedWarnings;
	}

	public void setAcknowledgedWarnings(List<Error> acknowledgedWarnings) {
		this.acknowledgedWarnings = acknowledgedWarnings;
	}
}
