package au.gov.vic.sro.duties.transfer.model;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Transaction implements Serializable {

	private static final long serialVersionUID = -2143985600275592764L;

	private String id;
	private Long formId;
	private Integer formVersion;
	private String elnoDocumentId;
	private String elnoId;

	private List<Property> propertyList = new ArrayList<Property>();
	private List<Transferor> transferorList = new ArrayList<Transferor>();
	private List<Transferee> transfereeList = new ArrayList<Transferee>();

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Long getFormId() {
		return formId;
	}

	public void setFormId(Long formId) {
		this.formId = formId;
	}

	public Integer getFormVersion() {
		return formVersion;
	}

	public void setFormVersion(Integer formVersion) {
		this.formVersion = formVersion;
	}

	public void setFormVersion(Long formVersion) {
		this.formVersion = formVersion == null ? null : formVersion.intValue();
	}

	public String getElnoDocumentId() {
		return elnoDocumentId;
	}

	public void setElnoDocumentId(String elnoDocumentId) {
		this.elnoDocumentId = elnoDocumentId;
	}

	public String getElnoId() {
		return elnoId;
	}

	public void setElnoId(String elnoId) {
		this.elnoId = elnoId;
	}

	public List<Property> getPropertyList() {
		return propertyList;
	}

	public void setPropertyList(List<Property> propertyList) {
		this.propertyList = propertyList;
	}

	public List<Transferor> getTransferorList() {
		return transferorList;
	}

	public void setTransferorList(List<Transferor> transferorList) {
		this.transferorList = transferorList;
	}

	public List<Transferee> getTransfereeList() {
		return transfereeList;
	}

	public void setTransfereeList(List<Transferee> transfereeList) {
		this.transfereeList = transfereeList;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((elnoDocumentId == null) ? 0 : elnoDocumentId.hashCode());
		result = prime * result + ((elnoId == null) ? 0 : elnoId.hashCode());
		result = prime * result + ((formId == null) ? 0 : formId.hashCode());
		result = prime * result + ((formVersion == null) ? 0 : formVersion.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((propertyList == null) ? 0 : propertyList.hashCode());
		result = prime * result + ((transfereeList == null) ? 0 : transfereeList.hashCode());
		result = prime * result + ((transferorList == null) ? 0 : transferorList.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Transaction other = (Transaction) obj;
		if (elnoDocumentId == null) {
			if (other.elnoDocumentId != null)
				return false;
		} else if (!elnoDocumentId.equals(other.elnoDocumentId))
			return false;
		if (elnoId == null) {
			if (other.elnoId != null)
				return false;
		} else if (!elnoId.equals(other.elnoId))
			return false;
		if (formId == null) {
			if (other.formId != null)
				return false;
		} else if (!formId.equals(other.formId))
			return false;
		if (formVersion == null) {
			if (other.formVersion != null)
				return false;
		} else if (!formVersion.equals(other.formVersion))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (propertyList == null) {
			if (other.propertyList != null)
				return false;
		} else if (!propertyList.equals(other.propertyList))
			return false;
		if (transfereeList == null) {
			if (other.transfereeList != null)
				return false;
		} else if (!transfereeList.equals(other.transfereeList))
			return false;
		if (transferorList == null) {
			if (other.transferorList != null)
				return false;
		} else if (!transferorList.equals(other.transferorList))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Transaction [id=" + id + ", formId=" + formId + ", formVersion=" + formVersion + ", elnoDocumentId="
				+ elnoDocumentId + ", elnoId=" + elnoId + ", propertyList=" + propertyList + ", transferorList="
				+ transferorList + ", transfereeList=" + transfereeList + "]";
	}
}