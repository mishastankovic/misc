package au.gov.vic.sro.duties.transfer.model;

import java.util.ArrayList;
import java.util.List;

import au.gov.vic.sro.duties.lodgement.Lodgement;
import au.gov.vic.sro.duties.transaction.AbstractDutyTransaction;

public class DoElnoExternalResponseRec {

	private Lodgement eSyslodgement;
	private String errorId;
	private Object errorCode;
	private List<AbstractDutyTransaction> dolTransactions = new ArrayList<>();

}