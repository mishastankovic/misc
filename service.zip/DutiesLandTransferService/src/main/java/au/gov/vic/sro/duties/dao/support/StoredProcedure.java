package au.gov.vic.sro.duties.dao.support;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.jdbc.support.SQLExceptionTranslator;

import au.gov.vic.sro.duties.dao.exception.DatabaseValidationMessage;
import au.gov.vic.sro.duties.dao.exception.GenericDaoException;
import au.gov.vic.sro.duties.dao.mapper.transaction.facades.MessageRec;
import au.gov.vic.sro.duties.dao.util.OracleTypeHelper;
import au.gov.vic.sro.duties.transfer.dao.mapper.MessageRecMapper;
import oracle.jdbc.OracleConnection;
import oracle.sql.ARRAY;
import oracle.xdb.XMLType;

public abstract class StoredProcedure extends org.springframework.jdbc.object.StoredProcedure {

	protected static final String XMLTYPE = "SYS.XMLTYPE";

	protected static final String ESYS_COMMON_PKG = "esys_common_pkg";

	protected static final String DO_TRANSACTION_REC = "DO_TRANSACTION_REC";
	protected static final String DO_LODGEMENT_REC = "DO_LODGEMENT_REC";
	protected static final String DO_MESSAGE_TAB = "DO_MESSAGE_TAB";

	protected static final String LVT_LODGEMENT_REC = "lvt_lodgement_rec";
	protected static final String LVT_MSG_TAB = "lvt_msgTab";
	protected static final String LVT_TRANSACTION_REC = "lvt_transaction_rec";

	protected static final String PTI_CUSTOMER_ID = "pti_customer_id";
	protected static final String PTI_DOCUMENT_ID = "pti_document_id";
	protected static final String PTI_LODGEMENT_ID = "pti_lodgement_id";
	protected static final String PTI_LODGEMENT_REC = "pti_lodgement_rec";
	protected static final String PTI_ORIGINAL_XML = "pti_original_xml";
	protected static final String PTI_PEXA_DOCUMENT_ID = "pti_pexa_document_id";
	protected static final String PTI_TRANS_ID = "pti_trans_id";
	protected static final String PTI_TRANS_REC = "pti_trans_rec";

	protected static final String PTO_MESSAGE_TAB = "pto_message_tab";

	/**
	 * Allow use as a bean.
	 */
	protected StoredProcedure() {
		super();
	}

	/**
	 * Create a new object wrapper for a stored procedure.
	 * @param ds DataSource to use throughout the lifetime
	 * of this object to obtain connections
	 * @param name name of the stored procedure in the database
	 */
	protected StoredProcedure(DataSource ds, String name) {
		super(ds, name);
	}

	/**
	 * Create a new object wrapper for a stored procedure.
	 * @param jdbcTemplate JdbcTemplate which wraps DataSource
	 * @param name name of the stored procedure in the database
	 */
	protected StoredProcedure(JdbcTemplate jdbcTemplate, String name) {
		super(jdbcTemplate, name);
	}

	protected StoredProcedure(JdbcTemplate jdbcTemplate, String name, SQLExceptionTranslator sqlExceptionTranslator) {
		super(jdbcTemplate, name);
		getJdbcTemplate().setExceptionTranslator(sqlExceptionTranslator);
	}

	protected Map<?, ?> defaultExecuteHandler(Map<String, Object> inParams, String returnMessagesParameterName) {
		return defaultExecuteHandler(inParams, returnMessagesParameterName, null);
	}

	protected Map<?, ?> defaultExecuteHandler(Map<String, Object> inParams, String returnMessagesParameterName,
			String requiredOutputParameter) {

		if (inParams == null) throw new NullPointerException("Passed inParams was null");

		Map<?, ?> outParams = execute(inParams);

		if (outParams.isEmpty()) {
			throw createGenericDaoException("No output parameters returned!", inParams, outParams);
		}

		if (returnMessagesParameterName != null) {
			throwOracleExceptionMessagesIfPresent(inParams, outParams, returnMessagesParameterName);
		}

		if (requiredOutputParameter != null) {

			Object requiredOutput = outParams.get(requiredOutputParameter);

			if (requiredOutput == null) {
//				throw createGenericDaoException(String.format(
//						"%s; Required output parameter (parameter name=%s) was null",
//						getMessageOnUnrecoverableDatabaseException(inParams), requiredOutputParameter), inParams,
//						outParams);
			}

		}

		return outParams;
	}

	@SuppressWarnings("rawtypes")
	public void throwOracleExceptionMessagesIfPresent(Map inParams, Map outParams, String msgTabName) {
		if (outParams.get(msgTabName) == null) {
			return;
		}
		Object[] messages = OracleTypeHelper.getArrayFrom((ARRAY) outParams.get(msgTabName));
		if (messages != null && messages.length > 0) {
			throw generateOracleExceptionMessages(inParams, outParams, msgTabName);
		}
	}

	@SuppressWarnings("rawtypes")
	public GenericDaoException generateOracleExceptionMessages(Map inParams, Map outParams, String msgTabName) {
		Object[] messages = null;
		if (outParams.get(msgTabName) != null) {
			messages = OracleTypeHelper.getArrayFrom((ARRAY) outParams.get(msgTabName));
		}
		if (messages != null && messages.length > 0) {
			String message = String.format("%s message received from backend", messages.length);
			return createGenericDaoException(message, inParams, outParams, messages);
		}
		String message = "Expected messages from backend but received none.";
		return createGenericDaoException(message, inParams, outParams);
	}

//	protected abstract String getMessageOnUnrecoverableDatabaseException(Map<?, ?> inParams);

	private static final int START = 0;
	private static final int END = 6;

	// TODO: Yuke: What time is eSys unavailable
	@Override
	public Map<String, Object> execute(Map<String, ?> inParams) {
		try {
			return super.execute(inParams);
		} catch (DataAccessResourceFailureException ex) {
			int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
			if (hour >= START && hour <= END) {
				throw new DataAccessResourceFailureException(
						"eSys is unavailable between " + START + ":00 and " + END + ":00", ex);
			} else {
				throw ex;
			}
		}
	}

	@SuppressWarnings({ "rawtypes" })
	protected GenericDaoException createGenericDaoException(String message, Map inParams, Map outParams,
			Object[] _messages) {
		return createGenericDaoException(null, message, inParams, outParams, _messages);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	protected GenericDaoException createGenericDaoException(Throwable cause, String message, Map inParams,
			Map outParams, Object[] messages) {

		GenericDaoException exception = null;

		if (cause == null) {
			exception = new GenericDaoException(message, getSql(), inParams, outParams);
		} else {
			exception = new GenericDaoException(cause, message, getSql(), inParams, outParams);
		}

		if (messages != null) {
			MessageRecMapper mapper = new MessageRecMapper();
			for (MessageRec _message : mapper.mapOracleMessages(messages)) {
				if (_message != null) {
					exception.getMessages()
							.add(new DatabaseValidationMessage(_message.getMSG_TYPE(), _message.getMSG_TEXT(),
									_message.getRELATED_DATA_FIELD(), _message.getMSG_CLASS(), _message.getDATA_ID(),
									_message.getID_TYPE()));
				}
			}
		}

		return exception;
	}

	@SuppressWarnings("rawtypes")
	protected GenericDaoException createGenericDaoException(String message, Map inParams, Map outParams) {
		return createGenericDaoException(message, inParams, outParams, null);
	}

	@SuppressWarnings("rawtypes")
	protected GenericDaoException createGenericDaoException(Throwable cause, String message, Map inParams,
			Map outParams) {
		return createGenericDaoException(cause, message, inParams, outParams, null);
	}

	protected DataAccessException translateSQLException(String message, SQLException exception) {
		return getJdbcTemplate().getExceptionTranslator().translate(message, null, exception);
	}

	protected XMLType getXMLType(String xml) {
		try {
			return new XMLType(getOracleConnection(), xml);
		} catch(SQLException e) {
			throw translateSQLException(String.format("Failed to create XMLType of %s", xml), e);
		}
	}

	protected Connection getOracleConnection() {
		try {
			Connection connection = DataSourceUtils.getConnection(getJdbcTemplate().getDataSource());
			if (connection.isWrapperFor(OracleConnection.class)) {
				return connection.unwrap(OracleConnection.class);
			}
			return connection;
		} catch (SQLException ex) {
			throw translateSQLException("Failed to retrieve Oracle connection", ex);
		}
	}
}
