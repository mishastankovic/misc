package au.gov.vic.sro.duties.transfer.dao;

import java.util.Date;

import javax.annotation.PostConstruct;

import au.gov.vic.sro.duties.transfer.dao.procedure.SubmitLodgementProcedure;
import au.gov.vic.sro.duties.transfer.dao.procedure.UpdateLodgementProcedure;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.support.SQLExceptionTranslator;
import org.springframework.stereotype.Repository;

import au.gov.vic.sro.duties.dao.support.OracleSQLExceptionTranslator;
import au.gov.vic.sro.duties.transfer.model.Lodgement;

@Repository
public class ElnoLodgementDao extends JdbcDaoSupport {

	private static final String PACKAGE_NAME = "do_eln_external_services_pkg";


	private SQLExceptionTranslator sqlExceptionTranslator = new OracleSQLExceptionTranslator();

	private SubmitLodgementProcedure submitLodgementProcedure;

	private UpdateLodgementProcedure updateLodgementProcedure;

	@Autowired
	@Qualifier("elnoJdbcTemplate")
	private JdbcTemplate jdbcTemplate;

	@PostConstruct
	private void initialize() {
		setJdbcTemplate(jdbcTemplate);
	}

	@Override
	protected void initTemplateConfig() {
		submitLodgementProcedure = new SubmitLodgementProcedure(getJdbcTemplate(), sqlExceptionTranslator);
	}

	public Lodgement submit(String elnoLodgementReference, Date intendedSettlementDate, String xml) {
		return submitLodgementProcedure.submit(elnoLodgementReference, intendedSettlementDate, xml);
	}


}
