package au.gov.vic.sro.duties.transfer.model;

public class Transferor extends Party {

	private static final long serialVersionUID = 4898865976807309573L;

	public Transferor() {

	}

	public Transferor(Party party) {
		super(party);
	}

	@Override
	public String toString() {
		return "Transferor [toString()=" + super.toString() + "]";
	}
}
