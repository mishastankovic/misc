package au.gov.vic.sro.duties.transfer.util;

import java.util.Properties;

import javax.naming.Context;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jndi.JndiTemplate;

@Configuration
public class ResourceConfiguration {

	@Value("${jndi.factory:com.ibm.websphere.naming.WsnInitialContextFactory}")
	private String jndiInitialContextFactory;

	@Bean
	public JndiTemplate jndiTemplate() {
		Properties properties = new Properties();
		properties.put(Context.INITIAL_CONTEXT_FACTORY, jndiInitialContextFactory);
		return new JndiTemplate(properties);
	}
}
