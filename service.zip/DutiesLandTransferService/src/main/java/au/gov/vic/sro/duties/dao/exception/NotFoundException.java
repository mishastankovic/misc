package au.gov.vic.sro.duties.dao.exception;

public class NotFoundException extends RuntimeException {

	private static final long serialVersionUID = 3178296362461155307L;

	public NotFoundException(final String message) {
		super(message);
	}
}