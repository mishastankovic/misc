package au.gov.vic.sro.duties.transfer.dao.configuration;

import java.net.MalformedURLException;
import java.net.URL;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Configuration
@Profile({ "local" })
public class TomcatConfiguration {

	private static final Logger log = LoggerFactory.getLogger(TomcatConfiguration.class);

	@Value("${spring.url.sro-security-oauth-server}")
	private String securityServerURL;

	@Bean
	@ConfigurationProperties(prefix = "spring.datasource.esys-dol")
	public DataSource eSysDutiesDataSource() {
		return DataSourceBuilder.create().build();
	}

	@Bean
	@ConfigurationProperties(prefix = "spring.datasource.esys-elno")
	public DataSource eSysElnoDataSource() {
		return DataSourceBuilder.create().build();
	}

	@Bean
	@ConfigurationProperties(prefix = "spring.datasource.elno")
	public DataSource elnoDataSource() {
		return DataSourceBuilder.create().build();
	}

	@Bean
	public URL getOauthServerUrl() throws MalformedURLException {
		log.debug("Security server: {}", securityServerURL);
		return new URL(securityServerURL);
	}
}