package au.gov.vic.sro.duties.transfer.model;

import java.io.Serializable;

/**
 * This class represents eSys UDT DO_MESSAGE_REC
 * 
 * @author pxb8
 *
 */
public class Message implements Serializable {

	private static final long serialVersionUID = -8334577722858398803L;

	private String id;
	private String messageType;
	private String messageText;
	private String relatedField;
	private String messageClass;
	private String dataId;
	private String dataIdType;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getMessageType() {
		return messageType;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	public String getMessageText() {
		return messageText;
	}

	public void setMessageText(String messageText) {
		this.messageText = messageText;
	}

	public String getRelatedField() {
		return relatedField;
	}

	public void setRelatedField(String relatedField) {
		this.relatedField = relatedField;
	}

	public String getMessageClass() {
		return messageClass;
	}

	public void setMessageClass(String messageClass) {
		this.messageClass = messageClass;
	}

	public String getDataId() {
		return dataId;
	}

	public void setDataId(String dataId) {
		this.dataId = dataId;
	}

	public String getDataIdType() {
		return dataIdType;
	}

	public void setDataIdType(String dataIdType) {
		this.dataIdType = dataIdType;
	}

	@Override
	public String toString() {
		return "MessageInfo [id=" + id + ", messageType=" + messageType + ", messageText=" + messageText
				+ ", relatedField=" + relatedField + ", messageClass=" + messageClass + ", dataId=" + dataId
				+ ", dataIdType=" + dataIdType + "]";
	}
}
