package au.gov.vic.sro.duties.transfer.model;

import java.io.Serializable;

import org.apache.commons.lang3.math.Fraction;

import au.gov.vic.sro.duties.transaction.landtransfer.LegalEntityType;

public class Party implements Serializable {

	private static final long serialVersionUID = 8116428904478858580L;

	private String id;
	private String partyId;
	private String elnoPartyId;
	private LegalEntityType partyType;	// TODO Should map to Duties Form party type.
	private Individual individual;
	private Organisation organisation;
	private Fraction shareFraction;

	public Party() {

	}

	public Party(Party party) {
		// TODO: Should I clone?
		id = party.id;
		partyId = party.partyId;
		elnoPartyId = party.elnoPartyId;
		partyType = party.partyType;
		individual = party.individual;
		organisation = party.organisation;
		shareFraction = party.getShareFraction();
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPartyId() {
		return partyId;
	}

	public void setPartyId(String partyId) {
		this.partyId = partyId;
	}

	public String getElnoPartyId() {
		return elnoPartyId;
	}

	public void setElnoPartyId(String elnoPartyId) {
		this.elnoPartyId = elnoPartyId;
	}

	public LegalEntityType getPartyType() {
		return partyType;
	}

	public void setPartyType(LegalEntityType partyType) {
		this.partyType = partyType;
	}

	public Individual getIndividual() {
		return individual;
	}

	public void setIndividual(Individual individual) {
		this.individual = individual;
	}

	public Organisation getOrganisation() {
		return organisation;
	}

	public void setOrganisation(Organisation organisation) {
		this.organisation = organisation;
	}

	public Fraction getShareFraction() {
		return shareFraction;
	}

	public void setShareFraction(Fraction shareFraction) {
		this.shareFraction = shareFraction;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((elnoPartyId == null) ? 0 : elnoPartyId.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((individual == null) ? 0 : individual.hashCode());
		result = prime * result + ((organisation == null) ? 0 : organisation.hashCode());
		result = prime * result + ((partyId == null) ? 0 : partyId.hashCode());
		result = prime * result + ((partyType == null) ? 0 : partyType.hashCode());
		result = prime * result + ((shareFraction == null) ? 0 : shareFraction.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Party other = (Party) obj;
		if (elnoPartyId == null) {
			if (other.elnoPartyId != null)
				return false;
		} else if (!elnoPartyId.equals(other.elnoPartyId))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (individual == null) {
			if (other.individual != null)
				return false;
		} else if (!individual.equals(other.individual))
			return false;
		if (organisation == null) {
			if (other.organisation != null)
				return false;
		} else if (!organisation.equals(other.organisation))
			return false;
		if (partyId == null) {
			if (other.partyId != null)
				return false;
		} else if (!partyId.equals(other.partyId))
			return false;
		if (partyType != other.partyType)
			return false;
		if (shareFraction == null) {
			if (other.shareFraction != null)
				return false;
		} else if (!shareFraction.equals(other.shareFraction))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Party [id=" + id + ", partyId=" + partyId + ", elnoPartyId=" + elnoPartyId + ", partyType=" + partyType
				+ ", individual=" + individual + ", organisation=" + organisation + ", shareFraction=" + shareFraction
				+ "]";
	}
}
