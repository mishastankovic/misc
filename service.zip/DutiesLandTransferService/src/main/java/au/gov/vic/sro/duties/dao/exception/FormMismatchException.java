package au.gov.vic.sro.duties.dao.exception;

import au.gov.vic.sro.duties.transfer.model.MatchResult;

public class FormMismatchException extends RuntimeException {

	private static final long serialVersionUID = 1975697276573259474L;
	
	private MatchResult matchResult;

	public FormMismatchException(MatchResult matchResult) {
		this.matchResult = matchResult;
	}

	public MatchResult getMatchResult() {
		return matchResult;
	}

	public void setMatchResult(MatchResult matchResult) {
		this.matchResult = matchResult;
	}
}
