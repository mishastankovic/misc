package au.gov.vic.sro.duties.transfer.dao.procedure;

public class UpdateLodgementProcedure {
}
