package au.gov.vic.sro.duties.transfer.constant;

public class Constants {

    public static final String ACCESS_TOKEN = "access_token";

}
