package au.gov.vic.sro.duties.transfer.model;

public class Transferee extends Party {

	private static final long serialVersionUID = 2172083803795975998L;

	public Transferee() {

	}

	public Transferee(Party party) {
		super(party);
	}

	@Override
	public String toString() {
		return "Transferee [toString()=" + super.toString() + "]";
	}
}
