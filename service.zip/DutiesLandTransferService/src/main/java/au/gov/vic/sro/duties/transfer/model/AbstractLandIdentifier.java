package au.gov.vic.sro.duties.transfer.model;

import java.io.Serializable;

import au.gov.vic.sro.duties.transaction.landtransfer.LandIdentifierType;

public abstract class AbstractLandIdentifier implements Serializable {

	private static final long serialVersionUID = 1984374225172986905L;

	private LandIdentifierType landIdentifierType;

	public LandIdentifierType getLandIdentifierType() {
		return landIdentifierType;
	}

	public void setLandIdentifierType(LandIdentifierType landIdentifierType) {
		this.landIdentifierType = landIdentifierType;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((landIdentifierType == null) ? 0 : landIdentifierType.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AbstractLandIdentifier other = (AbstractLandIdentifier) obj;
		if (landIdentifierType != other.landIdentifierType)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "AbstractLandIdentifier [landIdentifierType=" + landIdentifierType + "]";
	}
}
