package au.gov.vic.sro.duties.transfer.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

// ClaimCategory is LodgementCategory. Perhaps, it will be different by stage 3A.
public class ClaimCategory implements Serializable {

	private static final long serialVersionUID = -6507103663505636438L;

	private String categoryCode;

	private String categoryName;

	private int categoryOrder;
	
	private String parentCategoryCode;

	private List<ClaimCategory> subCategories = new ArrayList<ClaimCategory>();

	private AssessingType assessingType;

	private boolean active;

	public ClaimCategory() {
		
	}

	public ClaimCategory(String categoryCode, String categoryName, String parentCategoryCode,
			AssessingType assessingType) {
		this.categoryCode = categoryCode;
		this.categoryName = categoryName;
		this.parentCategoryCode = parentCategoryCode;
		this.assessingType = assessingType;
	}

	public String getCategoryCode() {
		return categoryCode;
	}

	public void setCategoryCode(String categoryCode) {
		this.categoryCode = categoryCode;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public int getCategoryOrder() {
		return categoryOrder;
	}

	public void setCategoryOrder(int categoryOrder) {
		this.categoryOrder = categoryOrder;
	}

	public AssessingType getAssessingType() {
		return assessingType;
	}

	public void setAssessingType(AssessingType assessingType) {
		this.assessingType = assessingType;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public String getParentCategoryCode() {
		return parentCategoryCode;
	}

	public void setParentCategoryCode(String parentCategoryCode) {
		this.parentCategoryCode = parentCategoryCode;
	}

	public List<ClaimCategory> getSubCategories() {
		return subCategories;
	}

	public void setSubCategories(List<ClaimCategory> subCategories) {
		this.subCategories = subCategories;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((categoryCode == null) ? 0 : categoryCode.hashCode());
		result = prime * result + ((categoryName == null) ? 0 : categoryName.hashCode());
		result = prime * result + categoryOrder;
		result = prime * result + ((assessingType == null) ? 0 : assessingType.hashCode());
		result = prime * result + ((parentCategoryCode == null) ? 0 : parentCategoryCode.hashCode());
		result = prime * result + ((subCategories == null) ? 0 : subCategories.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ClaimCategory other = (ClaimCategory) obj;
		if (categoryCode == null) {
			if (other.categoryCode != null)
				return false;
		} else if (!categoryCode.equals(other.categoryCode))
			return false;
		if (categoryName == null) {
			if (other.categoryName != null)
				return false;
		} else if (!categoryName.equals(other.categoryName))
			return false;
		if (categoryOrder != other.categoryOrder)
			return false;
		if (assessingType == null) {
			if (other.assessingType != null)
				return false;
		} else if (!assessingType.equals(other.assessingType))
			return false;
		if (parentCategoryCode == null) {
			if (other.parentCategoryCode != null)
				return false;
		} else if (!parentCategoryCode.equals(other.parentCategoryCode))
			return false;
		if (subCategories == null) {
			if (other.subCategories != null)
				return false;
		} else if (!subCategories.equals(other.subCategories))
			return false;
		return true;
	}
}
