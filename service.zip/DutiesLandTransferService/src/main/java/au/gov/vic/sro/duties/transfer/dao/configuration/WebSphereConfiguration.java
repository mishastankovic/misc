package au.gov.vic.sro.duties.transfer.dao.configuration;

import java.net.URL;

import javax.naming.NamingException;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import org.springframework.jndi.JndiTemplate;

@Configuration
@Profile({ "localtest", "development", "integration", "integration2", "training", "production" })
//@ImportResource("classpath:/dutiesContextDataSource.xml")	// Yuke: Won't work! Why?
public class WebSphereConfiguration {

	private static final Logger log = LoggerFactory.getLogger(PersistenceConfiguration.class);

	private static final String ESYS_DOL_DATA_SOURCE_JNDI = "jdbc/esysDS_DOL";
	private static final String ESYS_ELNO_DATA_SOURCE_JNDI = "jdbc/esysDS_DOL"; //"jdbc/esysDS_ELNO";
	private static final String ELNO_DATA_SOURCE_JNDI = "jdbc/elnoDataSource";

	private static final String SECURITY_SERVER_URL_JNDI = "url/SroOAuthServerUrl";

	@Autowired
	private JndiTemplate jndiTemplate;

	@Bean
	public DataSource eSysDutiesDataSource() throws IllegalArgumentException, NamingException {
		JndiDataSourceLookup dsLookup = new JndiDataSourceLookup();
		dsLookup.setResourceRef(true);
		return dsLookup.getDataSource(ESYS_DOL_DATA_SOURCE_JNDI);
	}

	@Bean
	public DataSource eSysElnoDataSource() throws IllegalArgumentException, NamingException {
		JndiDataSourceLookup dsLookup = new JndiDataSourceLookup();
		dsLookup.setResourceRef(true);
		return dsLookup.getDataSource(ESYS_ELNO_DATA_SOURCE_JNDI);
	}

	@Bean
	public DataSource elnoDataSource() throws IllegalArgumentException, NamingException {
		JndiDataSourceLookup dsLookup = new JndiDataSourceLookup();
		dsLookup.setResourceRef(true);
		return dsLookup.getDataSource(ELNO_DATA_SOURCE_JNDI);
	}

	@Bean
	public URL getOauthServerUrl() throws NamingException {
		return jndiTemplate.lookup(SECURITY_SERVER_URL_JNDI, URL.class);
	}
}