package au.gov.vic.sro.duties.transfer.model;

import au.gov.vic.sro.duties.transaction.landtransfer.LandIdentifierType;

public class LotAndPlan extends AbstractLandIdentifier {

	private static final long serialVersionUID = -1453129735643914817L;

	public LotAndPlan() {
		setLandIdentifierType(LandIdentifierType.LotAndPlanNumber);
	}

	private String lot;

	private String plan;

	public String getLot() {
		return lot;
	}

	public void setLot(String lot) {
		this.lot = lot;
	}

	public String getPlan() {
		return plan;
	}

	public void setPlan(String plan) {
		this.plan = plan;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((lot == null) ? 0 : lot.hashCode());
		result = prime * result + ((plan == null) ? 0 : plan.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		LotAndPlan other = (LotAndPlan) obj;
		if (lot == null) {
			if (other.lot != null)
				return false;
		} else if (!lot.equals(other.lot))
			return false;
		if (plan == null) {
			if (other.plan != null)
				return false;
		} else if (!plan.equals(other.plan))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "LotAndPlan [lot=" + lot + ", plan=" + plan + "]";
	}
}
