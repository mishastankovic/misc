package au.gov.vic.sro.duties.transfer.dao;

import java.sql.Types;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlInOutParameter;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.support.SQLExceptionTranslator;
import org.springframework.stereotype.Repository;

import au.gov.vic.sro.duties.dao.exception.NotFoundException;
import au.gov.vic.sro.duties.dao.mapper.transaction.LandTransferJavaToOracleDataTypeMapper;
import au.gov.vic.sro.duties.dao.mapper.transaction.LandTransferOracleDataTypeToJavaMapper;
import au.gov.vic.sro.duties.dao.mapper.transaction.facades.DoLtdTransactionRec;
import au.gov.vic.sro.duties.dao.support.OracleSQLExceptionTranslator;
import au.gov.vic.sro.duties.dao.support.StoredProcedure;
import au.gov.vic.sro.duties.dao.util.OracleTypeHelper;
import au.gov.vic.sro.duties.transaction.landtransfer.LandTransferDutyTransaction;
import oracle.sql.STRUCT;

@Repository
public class TransactionDao extends JdbcDaoSupport {

	private SQLExceptionTranslator sqlExceptionTranslator = new OracleSQLExceptionTranslator();

	private GetDutyTransactionProcedure getDutyTransactionProcedure;
	private UpdateDutyTransactionProcedure updateDutyTransactionProcedure;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@PostConstruct
	private void initialize() {
		setJdbcTemplate(jdbcTemplate);
	}

	@Override
	protected void initTemplateConfig() {
		getDutyTransactionProcedure = new GetDutyTransactionProcedure(getJdbcTemplate(), sqlExceptionTranslator);
		updateDutyTransactionProcedure = new UpdateDutyTransactionProcedure(getJdbcTemplate(), sqlExceptionTranslator);
	}

	public LandTransferDutyTransaction get(Long transactionId) {
		return getDutyTransactionProcedure.get(transactionId);
	}

	public LandTransferDutyTransaction update(LandTransferDutyTransaction transaction) {
		return updateDutyTransactionProcedure.update(transaction);
	}

	private static LandTransferDutyTransaction dutyTransactionFromOracleStructures(STRUCT doTransactionRec) {
		Object[] structAsArray = OracleTypeHelper.getArrayFrom(doTransactionRec);
		return new LandTransferOracleDataTypeToJavaMapper(new DoLtdTransactionRec(structAsArray)).getOut();
	}

	private class GetDutyTransactionProcedure extends StoredProcedure {

		private static final String STORED_PROC_NAME = "do_query_pkg.get_dt_details_f";
		private static final String RESULT = "result";

		public GetDutyTransactionProcedure(JdbcTemplate jdbcTemplate, SQLExceptionTranslator sqlExceptionTranslator) {
			super(jdbcTemplate, STORED_PROC_NAME, sqlExceptionTranslator);
			setFunction(true);

			// Note for parameters: return value must be declared first, then method params in order
			declareParameter(new SqlOutParameter(RESULT, Types.STRUCT, DO_TRANSACTION_REC));
			declareParameter(new SqlParameter(PTI_TRANS_ID, Types.NUMERIC));
			compile();
		}

		public LandTransferDutyTransaction get(Long transactionId) {
			Map<String, Object> inParams = new LinkedHashMap<>();
			inParams.put(PTI_TRANS_ID, transactionId);

			Map<?, ?> outParams = this.execute(inParams);
			if (outParams.isEmpty() || outParams.get(RESULT) == null) {
				throw new NotFoundException(String.format(
						"Could not find a transaction associated with transactionId: %s", transactionId));
			}

			STRUCT struct = (STRUCT) outParams.get(RESULT);

			try {
				return dutyTransactionFromOracleStructures(struct);
			} catch (Exception ex) {
				throw createGenericDaoException(ex, "Exception occurred during mapping", inParams, outParams);
			}
		}
	}

	private class UpdateDutyTransactionProcedure extends StoredProcedure {

		private static final String STORED_PROC_NAME = "do_capture_pkg.update_duty_transaction_f";

		public UpdateDutyTransactionProcedure(JdbcTemplate jdbcTemplate, SQLExceptionTranslator sqlExceptionTranslator) {
			super(jdbcTemplate, STORED_PROC_NAME, sqlExceptionTranslator);
			setFunction(true);

			// Record type must be in upper case
			// Note for parameters: return value must be declared first, then method params in order
			declareParameter(new SqlOutParameter(LVT_MSG_TAB, Types.ARRAY, DO_MESSAGE_TAB));
			declareParameter(new SqlInOutParameter(PTI_TRANS_REC, Types.STRUCT, DO_TRANSACTION_REC));
			compile();
		}

		public LandTransferDutyTransaction update(LandTransferDutyTransaction transaction) {
			Map<String, Object> inParams = new LinkedHashMap<>();
			inParams.put(PTI_TRANS_REC, oracleStructuresFromTransaction(transaction));

			Map<?, ?> outParams = defaultExecuteHandler(inParams, LVT_MSG_TAB, PTI_TRANS_REC);
			try {
				return dutyTransactionFromOracleStructures((STRUCT) outParams.get(PTI_TRANS_REC));
			} catch (Exception ex) {
				throw createGenericDaoException(ex, "Exception occurred during mapping", inParams, outParams);
			}
		}

		private STRUCT oracleStructuresFromTransaction(LandTransferDutyTransaction dutyTransaction) {
			return new LandTransferJavaToOracleDataTypeMapper(dutyTransaction).getOut()
					.getRecordsAsStruct(getOracleConnection());
		}
	}
}
