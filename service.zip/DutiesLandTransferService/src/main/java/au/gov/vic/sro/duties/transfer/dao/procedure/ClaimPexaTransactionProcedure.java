package au.gov.vic.sro.duties.transfer.dao.procedure;

import java.sql.Types;
import java.util.LinkedHashMap;
import java.util.Map;

import oracle.sql.STRUCT;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.support.SQLExceptionTranslator;

import au.gov.vic.sro.duties.dao.mapper.transaction.DoTransactionRec;
import au.gov.vic.sro.duties.dao.mapper.transaction.LandTransferOracleDataTypeToJavaMapper;
import au.gov.vic.sro.duties.dao.mapper.transaction.facades.DoLtdTransactionRec;
import au.gov.vic.sro.duties.dao.support.StoredProcedure;
import au.gov.vic.sro.duties.dao.util.OracleTypeHelper;
import au.gov.vic.sro.duties.transaction.DutyTransactionType;
import au.gov.vic.sro.duties.transaction.Identifier;
import au.gov.vic.sro.duties.transaction.landtransfer.LandTransferDutyTransaction;

public class ClaimPexaTransactionProcedure extends StoredProcedure {

	private static final String STORED_PROC_NAME = "do_capture_pkg.claim_pexa_transaction_f";

	public ClaimPexaTransactionProcedure(JdbcTemplate jdbcTemplate, SQLExceptionTranslator sqlExceptionTranslator) {
		super(jdbcTemplate, STORED_PROC_NAME, sqlExceptionTranslator);
		setFunction(true);

		// Record type must be in upper case
		// Note for parameters: return value must be declared first, then method params in order
		declareParameter(new SqlOutParameter(LVT_TRANSACTION_REC, Types.STRUCT, DO_TRANSACTION_REC));
		declareParameter(new SqlParameter(PTI_PEXA_DOCUMENT_ID, Types.VARCHAR));
		declareParameter(new SqlParameter(PTI_DOCUMENT_ID, Types.VARCHAR));
		declareParameter(new SqlOutParameter(PTO_MESSAGE_TAB, Types.ARRAY, DO_MESSAGE_TAB));
		compile();
	}

	public LandTransferDutyTransaction claim(Identifier pexaDocumentIdentifier, Identifier identifier) {
		Map<String, Object> inParams = new LinkedHashMap<>();
		inParams.put(PTI_PEXA_DOCUMENT_ID, pexaDocumentIdentifier.getIdentifier());
		inParams.put(PTI_DOCUMENT_ID, identifier == null ? null : identifier.getIdentifier());

		Map<?, ?> outParams = defaultExecuteHandler(inParams, PTO_MESSAGE_TAB, LVT_TRANSACTION_REC);

		try {
			return dutyTransactionFromOracleStructures((STRUCT) outParams.get(LVT_TRANSACTION_REC), false);
		} catch (Exception ex) {
			throw createGenericDaoException(ex, "Exception occurred during mapping", inParams, outParams);
		}
	}

	protected LandTransferDutyTransaction dutyTransactionFromOracleStructures(STRUCT doTransactionRec, boolean complex) {

		Object[] structAsArray = OracleTypeHelper.getArrayFrom(doTransactionRec);

		String transactionType = (String) structAsArray[DoTransactionRec.TRANS_TYPE.ordinal()];

		if (DutyTransactionType.TRUST.getOracleCode().equals(transactionType)) {
//			return mapTrustFromArray(structAsArray, complex);
			throw new IllegalArgumentException("Invalid Oracle dutyTransaction type (" + transactionType + ")");
		} else if (DutyTransactionType.TRANSFER.getOracleCode().equals(transactionType)) {
			return mapLandTransferFromArray(structAsArray, complex);
		} else {
			throw new IllegalArgumentException("Unkown Oracle dutyTransaction type (" + transactionType + ")");
		}
	}

	private LandTransferDutyTransaction mapLandTransferFromArray(Object[] structAsArray, boolean complex) {
		LandTransferOracleDataTypeToJavaMapper mapper =
				new LandTransferOracleDataTypeToJavaMapper(new DoLtdTransactionRec(structAsArray));
		return mapper.getOut();
	}

	public LandTransferDutyTransaction claim(Identifier pexaDocumentIdentifier) {
		return claim(pexaDocumentIdentifier, null);
	}
}
