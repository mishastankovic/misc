package au.gov.vic.sro.duties.transfer;

import static org.springframework.http.MediaType.TEXT_PLAIN_VALUE;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class VersionController {

	@Value("${app.name}")
	private String name;

	@Value("${app.version}")
	private String version;

	@GetMapping(path = "/version", produces = TEXT_PLAIN_VALUE)
	public String versionGet() {	
		return String.format("%s%nVersion: %s", name, version);
	}
}