package au.gov.vic.sro.duties.transfer.dao.mapper;

import java.util.ArrayList;
import java.util.List;

import oracle.sql.STRUCT;
import au.gov.vic.sro.duties.beanproperties.ValidationMessage;
import au.gov.vic.sro.duties.dao.mapper.transaction.facades.MessageRec;
import au.gov.vic.sro.duties.dao.util.OracleTypeHelper;

public class MessageRecMapper {

//	public MessageRec fromString(String value) {
//		throw new UnsupportedOperationException("Not yet implemented");
//	}
//
//	public ValidationMessage fromMessageRec(MessageRec value) {
//		throw new UnsupportedOperationException("Not yet implemented");
//	}
//
//	public MessageRec fromValidationMessage(ValidationMessage value) {
//		throw new UnsupportedOperationException("Not yet implemented");
//	}
//
//	public MessageRec[] mapMessages(Object[] values) {
//		List<MessageRec> messages = new ArrayList<MessageRec>();
//		for (Object o : values) {
//			messages.add(fromString((String) o));
//		}
//		return messages.toArray(new MessageRec[messages.size()]);
//	}

	public MessageRec[] mapOracleMessages(Object[] values) {
		List<MessageRec> messages = new ArrayList<MessageRec>();

		for (Object o : values) {
			if (o != null) messages.add(new MessageRec(OracleTypeHelper.getArrayFrom((STRUCT) o)));
		}

		return messages.toArray(new MessageRec[messages.size()]);
	}
}