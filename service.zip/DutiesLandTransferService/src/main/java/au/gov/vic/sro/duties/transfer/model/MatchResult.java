package au.gov.vic.sro.duties.transfer.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class MatchResult implements Serializable {

	private static final long serialVersionUID = 4637609066236524527L;

	private List<Error> errors = new ArrayList<>();
	List<Error> warnings = new ArrayList<>();

	public List<Error> getErrors() {
		return errors;
	}

	public void setErrors(List<Error> mismatchErrors) {
		this.errors = mismatchErrors;
	}

	public List<Error> getWarnings() {
		return warnings;
	}

	public void setWarnings(List<Error> warnings) {
		this.warnings = warnings;
	}

}
