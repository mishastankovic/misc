package au.gov.vic.sro.duties.transfer.model;

import java.io.Serializable;

import au.gov.vic.sro.duties.transaction.landtransfer.LegalEntityType;

public class Organisation implements Serializable {

	private static final long serialVersionUID = -3847642452853844280L;

	private String organisationName;
	private String abn;
	private String acn;

	public String getOrganisationName() {
		return organisationName;
	}

	public void setOrganisationName(String organisationName) {
		this.organisationName = organisationName;
	}

	public String getAbn() {
		return abn;
	}

	public void setAbn(String abn) {
		this.abn = abn;
	}

	public String getAcn() {
		return acn;
	}

	public void setAcn(String acn) {
		this.acn = acn;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((abn == null) ? 0 : abn.hashCode());
		result = prime * result + ((acn == null) ? 0 : acn.hashCode());
		result = prime * result + ((organisationName == null) ? 0 : organisationName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Organisation other = (Organisation) obj;
		if (abn == null) {
			if (other.abn != null)
				return false;
		} else if (!abn.equals(other.abn))
			return false;
		if (acn == null) {
			if (other.acn != null)
				return false;
		} else if (!acn.equals(other.acn))
			return false;
		if (organisationName == null) {
			if (other.organisationName != null)
				return false;
		} else if (!organisationName.equals(other.organisationName))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Organisation [organisationName=" + organisationName + ", abn=" + abn + ", acn=" + acn + "]";
	}
}
