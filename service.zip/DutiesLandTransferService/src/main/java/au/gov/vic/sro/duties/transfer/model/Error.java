package au.gov.vic.sro.duties.transfer.model;

import java.io.Serializable;

public class Error implements Serializable {

	private static final long serialVersionUID = -5530192060162139634L;

	private String errorMsg;
	private String field;
	private Object errorCode;

	public Error() {
	}

	public Error(String errorMsg, String field, Object errorCode) {
		this.errorMsg = errorMsg;
		this.field = field;
		this.errorCode = errorCode;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getField() {
		return field;
	}

	public void setField(String field) {
		this.field = field;
	}

	public Object getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(Object errorCode) {
		this.errorCode = errorCode;
	}

	@Override
	public String toString() {
		return "Error [errorMsg=" + errorMsg + ", field=" + field + ", errorCode=" + errorCode + "]";
	}
}