package au.gov.vic.sro.duties.transfer.model;

import au.gov.vic.sro.duties.transaction.landtransfer.LandIdentifierType;

public class VolumeAndFolio extends AbstractLandIdentifier {

	private static final long serialVersionUID = 351203684003999598L;

	public VolumeAndFolio() {
		setLandIdentifierType(LandIdentifierType.VolumeAndFolio);
	}

	private String volume;

	private String folio;

	public String getVolume() {
		return volume;
	}

	public void setVolume(String volume) {
		this.volume = volume;
	}

	public String getFolio() {
		return folio;
	}

	public void setFolio(String folio) {
		this.folio = folio;
	}

	public String getVolFol() {
		return this.volume + "/" + this.folio;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((folio == null) ? 0 : folio.hashCode());
		result = prime * result + ((volume == null) ? 0 : volume.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		VolumeAndFolio other = (VolumeAndFolio) obj;
		if (folio == null) {
			if (other.folio != null)
				return false;
		} else if (!folio.equals(other.folio))
			return false;
		if (volume == null) {
			if (other.volume != null)
				return false;
		} else if (!volume.equals(other.volume))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "VolumeAndFolio [volume=" + volume + ", folio=" + folio + "]";
	}
}
