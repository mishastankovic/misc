package au.gov.vic.sro.duties.transfer.service.security;

import javax.servlet.http.Cookie;

public class UserSecurity {

    private String username;
    private Cookie accessTokenCookie;

    public UserSecurity(String username, Cookie accessTokenCookie) {
        this.username = username;
        this.accessTokenCookie = accessTokenCookie;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Cookie getAccessTokenCookie() {
        return accessTokenCookie;
    }

    public void setAccessTokenCookie(Cookie accessTokenCookie) {
        this.accessTokenCookie = accessTokenCookie;
    }
}
