package au.gov.vic.sro.duties.dao.exception;

import java.io.Serializable;

/** 
 * A copy of au.gov.vic.sro.duties.dao.dutycapture.DatabaseValidationMessage
 * 
 * @see au.gov.vic.sro.duties.dao.dutycapture.DatabaseValidationMessage
 */
public class DatabaseValidationMessage implements Serializable {

	private static final long serialVersionUID = 2544401632711598236L;

	public static final String WARNING_TYPE = "W";

	private final String type;
	private final String message;
	private final String fieldsInError;
	private final String messageIdentifier;
	private final String recordIdentifier;
	private final String recordIdentifierType;

	public DatabaseValidationMessage(String type, String message,
			String fieldsInError, String messageIdentifier,
			String recordIdentifier, String recordIdentifierType) {
		super();
		this.type = type;
		this.message = message;
		this.fieldsInError = fieldsInError;
		this.messageIdentifier = messageIdentifier;
		this.recordIdentifier = recordIdentifier;
		this.recordIdentifierType = recordIdentifierType;
	}

	public String getType() {
		return type;
	}

	public String getMessage() {
		return message;
	}

	public String getFieldsInError() {
		return fieldsInError;
	}

	public String getMessageIdentifier() {
		return messageIdentifier;
	}

	public String getRecordIdentifier() {
		return recordIdentifier;
	}

	public String getRecordIdentifierType() {
		return recordIdentifierType;
	}

	@Override public String toString() {
		return String.format("DatabaseValidationMessage["
				+ "type=%s,"
				+ "message=%s,"
				+ "fieldsInError=%s,"
				+ "messageIdentifier=%s,"
				+ "recordIdentifier=%s,"
				+ "recordIdentifierType=%s]",
				type,
				message,
				fieldsInError,
				messageIdentifier,
				recordIdentifier,
				recordIdentifierType);
	}
}