package au.gov.vic.sro.duties.transfer.model;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import java.util.Date;

@Entity
@Table(name = "ELNO_LODGEMENT_CASE",
        indexes = {
            @Index(name="ELNO_ID_ELNO_LODGEMENT_CASE_ID_IDX", unique=true, columnList="elno_id, elno_lodgement_case_id")
        }
)

public class ElnoLodgementCase {

    public static final String CASE_REFERENCE_PREFIX = "N";

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "prefixed_sequence_generator")
    @GenericGenerator(
            name = "prefixed_sequence_generator",
            strategy = "au.gov.vic.sro.duties.transfer.model.ElnoCaseReferenceGenerator",
            parameters = {
                    @Parameter(name = "sequence_name", value = "CASE_REFERENCE_SEQ"),
                    @Parameter(name = "allocationSize", value = "1"),
                    @Parameter(name = ElnoCaseReferenceGenerator.INCREMENT_PARAM, value = "1"),
                    @Parameter(name = ElnoCaseReferenceGenerator.VALUE_PREFIX_PARAMETER, value = CASE_REFERENCE_PREFIX),
                    @Parameter(name = ElnoCaseReferenceGenerator.NUMBER_FORMAT_PARAMETER, value = "%05d") })
    @Column(name = "CASE_REFERENCE_ID", precision = 16, scale = 0, unique = true, insertable = false)
    private String caseReferenceId;

    @NotNull
    @Column(name = "ELNO_ID")
    private String elnoId;

    @NotNull
    @Column(name = "ELNO_LODGEMENT_CASE_ID")
    private String elnoLodgementCaseId;

    @Lob
    @Column(name = "LATEST_REQUEST_XML")
    private String latestRequestXml;

    @Column(name = "ESYS_LODGEMENT_ID")
    private Long esysLodgementId;

    @Column(name = "LAST_MODIFIED")
    private Date lastModified;

    public String getElnoId() {
        return elnoId;
    }

    public void setElnoId(String elnoId) {
        this.elnoId = elnoId;
    }

    public String getElnoLodgementCaseId() {
        return elnoLodgementCaseId;
    }

    public void setElnoLodgementCaseId(String elnoLodgementCaseId) {
        this.elnoLodgementCaseId = elnoLodgementCaseId;
    }

    public String getCaseReferenceId() {
        return caseReferenceId;
    }

    public void setCaseReferenceId(String caseReferenceId) {
        this.caseReferenceId = caseReferenceId;
    }

    public String getLatestRequestXml() {
        return latestRequestXml;
    }

    public void setLatestRequestXml(String latestRequestXml) {
        this.latestRequestXml = latestRequestXml;
    }

    public Long getEsysLodgementId() {
        return esysLodgementId;
    }

    public void setEsysLodgementId(Long esysLodgementId) {
        this.esysLodgementId = esysLodgementId;
    }

    public Date getLastModified() {
        return lastModified;
    }

    public void setLastModified(Date lastModified) {
        this.lastModified = lastModified;
    }
}