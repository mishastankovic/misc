package au.gov.vic.sro.duties.transfer.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import au.gov.vic.sro.duties.transfer.dao.ReferenceDataDao;
import au.gov.vic.sro.duties.transfer.model.AssessingType;
import au.gov.vic.sro.duties.transfer.model.ClaimCategory;

@Service
@Transactional(propagation = Propagation.REQUIRED)
public class ReferenceDataService {

	private static final Logger log = LoggerFactory.getLogger(ReferenceDataService.class);

	private ReferenceDataDao referenceDataDao;

	@Autowired
	public ReferenceDataService(ReferenceDataDao referenceDataDao) {
		this.referenceDataDao = referenceDataDao;
	}

	@Transactional(readOnly = true)
	public List<ClaimCategory> getAllClaimCategoryList() {
		return referenceDataDao.getAllClaimCategoryList();
	}

	@Transactional(readOnly = true)
	public List<ClaimCategory> getClaimCategoryList(AssessingType assessingType) {
		return referenceDataDao.getClaimCategoryList(assessingType);
	}
}
