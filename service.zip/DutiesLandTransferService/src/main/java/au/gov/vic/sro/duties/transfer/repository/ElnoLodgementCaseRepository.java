package au.gov.vic.sro.duties.transfer.repository;

import au.gov.vic.sro.duties.transfer.model.ElnoLodgementCase;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ElnoLodgementCaseRepository  extends CrudRepository<ElnoLodgementCase, Long>{

    @Query("SELECT c FROM ElnoLodgementCase c WHERE c.elnoId=:elnoId AND c.elnoLodgementCaseId=:caseId")
    List<ElnoLodgementCase> findByElnoIdAndCaseId(@Param("elnoId") String elnoId, @Param("caseId") String elnoLodgementCaseId);

    @Query("SELECT c FROM ElnoLodgementCase c WHERE c.elnoId=:elnoId")
    List<ElnoLodgementCase> findByElnoId(@Param("elnoId") String elnoId);

    @Query("SELECT count(c) FROM ElnoLodgementCase c WHERE c.elnoId=:elnoId AND c.elnoLodgementCaseId=:caseId")
    int countByElnoIdAndElnoCaseId(@Param("caseId") String elnoLodgementCaseId);

    @Query("SELECT c FROM ElnoLodgementCase c WHERE c.caseReferenceId=:caseReferenceId")
    ElnoLodgementCase findElnoLodgementCaseByPk(String caseReferenceId);

}
