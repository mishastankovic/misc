package au.gov.vic.sro.duties.transfer.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import au.gov.vic.sro.duties.transfer.dao.LodgementDao;
import au.gov.vic.sro.duties.transfer.mapper.Mapper;
import au.gov.vic.sro.duties.transfer.model.ElnoLodgementCase;
import au.gov.vic.sro.duties.transfer.model.Lodgement;
import au.gov.vic.sro.duties.transfer.repository.ElnoLodgementCaseRepository;

@Service
@Transactional(propagation = Propagation.REQUIRED)
public class LodgementService {

	@Autowired
	private ElnoLodgementCaseRepository repo;

	@Autowired
	private LodgementDao lodgementDao;

	@Autowired
	private Mapper mapper;

	@Transactional(readOnly = true)
	public Lodgement getLodgement(Long lodgementId) {
		return mapper.fromESys(lodgementDao.getLodgement(lodgementId));
	}

	@Transactional(readOnly = true)
	public Lodgement getLodgement(String elnoLodgementCaseId, String caseReferenceId) {
		return mapper.fromESys(lodgementDao.getLegacyPexaLodgement(elnoLodgementCaseId, caseReferenceId));
	}

	@Transactional
	public Lodgement claimElnoLodgement(String customerId, String elnoLodgementCaseId, String caseReferenceId,
			String lodgementCategory) {
		ElnoLodgementCase lodgementCase = repo.findElnoLodgementCaseByPk(caseReferenceId);
		if (lodgementCase.getEsysLodgementId() != null) {
			throw new IllegalStateException("Lodgement " + caseReferenceId + " has already been claimed.");
		}
		String latestRequestXml = new String(lodgementCase.getLatestRequestXml());
		Lodgement lodgement = mapper.fromXML(latestRequestXml);
		lodgement.setCaseReference(caseReferenceId);
		lodgement.setLodgementCategoryCode(lodgementCategory);
		lodgement = mapper.fromESys(lodgementDao.claimElnoLodgement(customerId, mapper.toESys(lodgement), latestRequestXml));
		lodgementCase.setEsysLodgementId(Long.parseLong(lodgement.getId()));
		repo.save(lodgementCase);
		return lodgement;
	}

	@Transactional
	public void readyToSubmitLodgement(Lodgement lodgement) {
		lodgementDao.readyToSubmitLodgement(mapper.toESys(lodgement));
	}
}
