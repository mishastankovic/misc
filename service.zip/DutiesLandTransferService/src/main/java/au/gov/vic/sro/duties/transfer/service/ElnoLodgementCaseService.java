package au.gov.vic.sro.duties.transfer.service;

import au.gov.vic.sro.duties.transfer.model.ElnoLodgementCase;
import au.gov.vic.sro.duties.transfer.repository.ElnoLodgementCaseRepository;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

@Service("elnoLodgementCaseService")
@Transactional(propagation = Propagation.REQUIRED)
public class ElnoLodgementCaseService {

    @Autowired
    private ElnoLodgementCaseRepository repo;

    /**
     * Creates or updates an ElnoLodgementCase record in the database.
     *
     * @param elnoCase - ElnoLodgementCase to save or update
     * @return The newly saved ElnoLodgementCase
     */
    public ElnoLodgementCase save(ElnoLodgementCase elnoCase) {

        Objects.requireNonNull(elnoCase, "null ElnoLodgementCase parameter in save operation");

        // Check for an existing record
        ElnoLodgementCase existingRecord = null;
        if (StringUtils.isNotEmpty(elnoCase.getCaseReferenceId())) {
            // Check by caseReferenceId
            existingRecord = repo.findElnoLodgementCaseByPk(elnoCase.getCaseReferenceId());
        } else if (StringUtils.isNotEmpty(elnoCase.getElnoId()) && StringUtils.isNotEmpty(elnoCase.getElnoLodgementCaseId())) {
            // Check by alnoId / elnoLodgementReferenceId
            List<ElnoLodgementCase> result = repo.findByElnoIdAndCaseId(elnoCase.getElnoId(), elnoCase.getElnoLodgementCaseId());
            if ( result != null && result.size() > 0) existingRecord = result.get(0);
        }

        // Save or update
        if (existingRecord != null) {
            // Update the existing record
            existingRecord.setLatestRequestXml(elnoCase.getLatestRequestXml());
            existingRecord.setLastModified(new Date());
            return repo.save(existingRecord);
        } else {
            // Save new record
            elnoCase.setLastModified(new Date());
            return repo.save(elnoCase);
        }
    }

    public void delete(ElnoLodgementCase elnoCase) {
        repo.delete(elnoCase);
    }

    public void delete(String caseReferenceId) {
        ElnoLodgementCase c = repo.findElnoLodgementCaseByPk(caseReferenceId);
        if(c != null){
            repo.delete(c);
        }
    }

    public ElnoLodgementCase findByElnoIdAndCaseId(String elnoId, String elnoLodgementCaseId) {
        List<ElnoLodgementCase> result = repo.findByElnoIdAndCaseId(elnoId, elnoLodgementCaseId);
        return result != null ? result.get(0) : null;
    }

    public ElnoLodgementCase findByPk(String caseReferenceId) {
        return repo.findElnoLodgementCaseByPk(caseReferenceId);
    }

    public List<ElnoLodgementCase> findAll() {
        Iterable<ElnoLodgementCase> it = repo.findAll();
        return it != null ? StreamSupport.stream(it.spliterator(), false).collect(Collectors.toList()) : null;
    }
}
