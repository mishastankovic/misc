package au.gov.vic.sro.duties.transfer.comparator;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.Fraction;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import au.gov.vic.sro.duties.form.model.DutiesForm;
import au.gov.vic.sro.duties.form.model.party.NaturalPerson;
import au.gov.vic.sro.duties.form.model.party.Organisation;
import au.gov.vic.sro.duties.form.model.party.OwnershipShare;
import au.gov.vic.sro.duties.form.model.party.PersonName;
import au.gov.vic.sro.duties.form.model.property.LandIdentifier;
import au.gov.vic.sro.duties.form.model.property.Property;
import au.gov.vic.sro.duties.transfer.model.AbstractLandIdentifier;
import au.gov.vic.sro.duties.transfer.model.Error;
import au.gov.vic.sro.duties.transfer.model.Individual;
import au.gov.vic.sro.duties.transfer.model.MatchResult;
import au.gov.vic.sro.duties.transfer.model.Party;
import au.gov.vic.sro.duties.transfer.model.Transaction;
import au.gov.vic.sro.duties.transfer.model.Transferee;
import au.gov.vic.sro.duties.transfer.model.Transferor;
import au.gov.vic.sro.duties.transfer.model.VolumeAndFolio;

@Service
public class TransactionToDutiesFormComparator implements Serializable {

	private static final String ELNO = " ELNO: ";

	private static final long serialVersionUID = 2574642413740909581L;

	private List<Error> mismatchErrors;
	private List<Error> mismatchWarnings;
	private MatchResult matchResult = new MatchResult();

	public MatchResult compareTransactionToDutiesForm(DutiesForm form, Transaction transaction) {
		mismatchErrors = new ArrayList<>();
		mismatchWarnings = new ArrayList<>();
		matchResult.setErrors(mismatchErrors);
		matchResult.setWarnings(mismatchWarnings);

		if (form == null || transaction == null) {
			throw new IllegalStateException("Form/Transaction null.");
		}
		compareTransferors(form, transaction);
		compareTransferees(form, transaction);
		comparePropertyDetails(form, transaction);

		return matchResult;
	}

	private void comparePropertyDetails(DutiesForm form, Transaction transaction) {
		Set<String> formVolumes = new HashSet<>();
		List<String> formFolios = new ArrayList<>();
		List<String> txnVolumes = new ArrayList<>();
		List<String> txnFolios = new ArrayList<>();

		if (form.getDutiesFormData().getPropertySection() != null
				&& !CollectionUtils.isEmpty(form.getDutiesFormData().getPropertySection().getPropertyList())) {
			List<Property> formProperties = form.getDutiesFormData().getPropertySection().getPropertyList();
			extractFormPropertyLandIdentifiers(formVolumes, formFolios, formProperties);
		}
		if (!CollectionUtils.isEmpty(transaction.getPropertyList())) {
			extractTxnPropertyLandIdentifiers(transaction, txnVolumes, txnFolios);

		}

		if (CollectionUtils.isEmpty(formVolumes) || CollectionUtils.isEmpty(txnVolumes)
				|| formVolumes.size() != txnVolumes.size() || !formVolumes.containsAll(txnVolumes)) {
			addMismatchError(
					new Error("Land identifier list size mismatch", "TXN Land identifier", "landidentifier.mismatch"));
		}

	}

	private void extractTxnPropertyLandIdentifiers(Transaction transaction, List<String> txnVolumes,
			List<String> txnFolios) {
		for (au.gov.vic.sro.duties.transfer.model.Property txnProperty : transaction.getPropertyList()) {
			if (!CollectionUtils.isEmpty(txnProperty.getLandIdentifierList())) {
				for (AbstractLandIdentifier txnLandIdentifier : txnProperty.getLandIdentifierList()) {
					if (txnLandIdentifier != null) {
						VolumeAndFolio txnVolFol = (VolumeAndFolio) txnLandIdentifier;
						txnVolumes.add(txnVolFol.getVolume());
						txnFolios.add(txnVolFol.getFolio());
					}
				}
			}
			if (CollectionUtils.isEmpty(txnVolumes) || CollectionUtils.isEmpty(txnFolios)
					|| (txnVolumes.size() != txnFolios.size())) {
				addMismatchError(
						new Error("Land identifier missing in Transaction property:" + txnProperty.getAddress(),
								"TXN Land identifier", ""));
			}
		}
	}

	private void extractFormPropertyLandIdentifiers(Set<String> formVolumes, List<String> formFolios,
			List<Property> formProperties) {
		for (Property property : formProperties) {
			if (!CollectionUtils.isEmpty(property.getLandIdentifierList())) {
				Set<String> formVolumesSet = (property.getLandIdentifierList().stream().map(LandIdentifier::getVolume)
						.collect(Collectors.toSet()));

				formVolumes.addAll(formVolumesSet);

				Set<String> formFoliosSet = (property.getLandIdentifierList().stream().map(LandIdentifier::getFolio)
						.collect(Collectors.toSet()));
				formFolios.addAll(formFoliosSet);

				if (CollectionUtils.isEmpty(formVolumesSet) || CollectionUtils.isEmpty(formFoliosSet)
						|| (formVolumesSet.size() != formFoliosSet.size())) {
					addMismatchError(new Error("Land identifier missing in Duties form property:"
							+ (StringUtils.isEmpty(property.getPropertyAddress().getFormattedAddress()) ? ""
									: property.getPropertyAddress().getFormattedAddress().toUpperCase()),
							"Land identifier", ""));
				}
			} else {
				addMismatchError(
						new Error(
								"Land identifier missing for property:"
										+ (StringUtils.isEmpty(property.getPropertyAddress().getFormattedAddress()) ? ""
												: property.getPropertyAddress().getFormattedAddress()),
								"Land identifier", ""));
			}
		}
	}

	private void compareTransferees(DutiesForm form, Transaction transaction) {
		List<Transferee> txnTransferees = transaction.getTransfereeList();

		List<au.gov.vic.sro.duties.form.model.party.Transferee> formTransferees =
				form.getDutiesFormData().getTransfereeSection().getTransfereeList();
		// Any of Transferee collection is empty
		emptyTransfereeCollectionCheck(txnTransferees, formTransferees);

		for (au.gov.vic.sro.duties.form.model.party.Transferee formTransferee : formTransferees) {
			boolean matchFound = false;
			for (Transferee txnTransferee : txnTransferees) {
				if (formTransferee != null && txnTransferee != null) {
					matchFound = compareFormTransfereeToTxnTransferee(formTransferee, matchFound, txnTransferee);
				}
			}

			if (!matchFound) {
				addMismatchError(new Error(
						"Matching transaction Transferee not found. <br/> Form transferee: "
								+ (StringUtils.isEmpty(formTransferee.getFormattedName()) ? ""
										: formTransferee.getFormattedName().toUpperCase()),
						"Transferee", "formlink.mismatch.transferee.size"));
			}
		}
	}

	private boolean compareFormTransfereeToTxnTransferee(
			au.gov.vic.sro.duties.form.model.party.Transferee formTransferee, boolean matchFound,
			Transferee txnTransferee) {
		if (formTransferee.isIndividual() && txnTransferee.getIndividual() != null) {
			matchFound = comapreIndividualTransferee(formTransferee, matchFound, txnTransferee);

		} else if (formTransferee.isCompanyOrganisationAssociation() && txnTransferee.getOrganisation() != null) {
			matchFound = compareOrganisationTransferee(formTransferee, matchFound, txnTransferee);
		}
		return matchFound;
	}

	private void emptyTransfereeCollectionCheck(List<Transferee> txnTransferees,
			List<au.gov.vic.sro.duties.form.model.party.Transferee> formTransferees) {
		if (!CollectionUtils.isEmpty(txnTransferees) && !CollectionUtils.isEmpty(formTransferees)) {
			if (txnTransferees.size() != formTransferees.size()) {
				addMismatchError(new Error("Transferee list size mismatch", "Transferees",
						"formlink.mismatch.transferees.size")); // Any of Transferees collection is empty
			}

		} else {
			// Any of the collections is Empty
			addMismatchError(new Error("Missing Transferee", "Transferees", "formlink.mismatch.transferees.missing"));
		}
	}

	private boolean compareOrganisationTransferee(au.gov.vic.sro.duties.form.model.party.Transferee formTransferee,
			boolean matchFound, Transferee txnTransferee) {
		boolean organisationNameMatch =
				comparePartyOrganisationName(formTransferee.getOrganisation(), txnTransferee.getOrganisation());
		if (organisationNameMatch) {
			matchFound = true;
		} else if (StringUtils.compareIgnoreCase(formTransferee.getOrganisation().getAcnArbnAbn(),
				txnTransferee.getOrganisation().getAbn()) == 0
				|| StringUtils.compareIgnoreCase(formTransferee.getOrganisation().getAcnArbnAbn(),
						txnTransferee.getOrganisation().getAcn()) == 0) {
			matchFound = true;
			addFieldError(formTransferee.getOrganisation().getOrganisationName(),
					txnTransferee.getOrganisation().getOrganisationName(), "Organisation name",
					"transferee." + txnTransferee.getId() + "organisation.name.mismatch");
		}
		return matchFound;
	}

	private boolean comapreIndividualTransferee(au.gov.vic.sro.duties.form.model.party.Transferee formTransferee,
			boolean matchFound, Transferee txnTransferee) {
		NaturalPerson formPerson = formTransferee.getNaturalPerson();
		Individual txnPerson = txnTransferee.getIndividual();

		if (formPerson.getPersonName() != null) {
			LocalDate formDoBLocaldate = convertToLocalDate(formPerson.getDateOfBirth());
			LocalDate txnDoBLocaldate = convertToLocalDate(txnPerson.getDateOfBirth());
			if (formDoBLocaldate != null && txnDoBLocaldate != null && formDoBLocaldate.isEqual(txnDoBLocaldate)) {
				matchFound = compareIndividualPartyNames(formTransferee, matchFound, txnTransferee);
			}
		}
		return matchFound;
	}

	private boolean compareIndividualPartyNames(au.gov.vic.sro.duties.form.model.party.Transferee formTransferee,
			boolean matchFound, Transferee txnTransferee) {
		NaturalPerson formPerson = formTransferee.getNaturalPerson();
		PersonName formPersonName = formPerson.getPersonName();
		Individual txnPerson = txnTransferee.getIndividual();

		boolean firstNameMatch = true;
		boolean surnameMatch = true;
		boolean middleNameMatch = true;

		firstNameMatch = comparePartyFirstName(txnTransferee.getIndividual(), formPersonName);

		surnameMatch = comparePartySurname(txnPerson, formPersonName);

		middleNameMatch = comparePartyMiddleName(txnPerson, formPersonName);
		if (firstNameMatch || surnameMatch || middleNameMatch) {
			matchFound = true;
		}
		if (matchFound) {
			if (!firstNameMatch) {
				addFieldError(formPerson.getPersonName().getFirstName(), txnPerson.getFirstName(), "First name",
						"transferee." + txnTransferee.getId() + ".first.name.mismatch");
			}
			if (!surnameMatch) {
				addFieldError(formPerson.getPersonName().getSurname(), txnPerson.getSurname(), "Surname",
						"transferee." + txnTransferee.getId() + ".surname.mismatch");
			}
			if (!middleNameMatch) {
				addFieldWarning(formPerson.getPersonName().getMiddleName(), txnPerson.getMiddleName(), "Middle name",
						"transferee." + txnTransferee.getId() + ".middle.name.mismatch");
			}
			if (!compareTransfereeShareFractions(formTransferee, txnTransferee))
				addMismatchError(new Error("Transferee share fraction mismatch", "share fraction",
						"transferee." + txnTransferee.getId() + ".sharefraction.mismatch"));// Fractions Mismatch
		}
		return matchFound;
	}

	private void compareTransferors(DutiesForm form, Transaction transaction) {
		List<Transferor> txnTransferors = transaction.getTransferorList();

		List<au.gov.vic.sro.duties.form.model.party.Transferor> formTransferors =
				form.getDutiesFormData().getTransferorSection().getTransferorList();
		// Any of Transferors collection is empty
		emptyTransferorCollectionsCheck(txnTransferors, formTransferors);

		for (au.gov.vic.sro.duties.form.model.party.Transferor formTransferor : formTransferors) {
			boolean matchFound = false;
			for (Transferor txnTransferor : txnTransferors) {
				if (formTransferor != null && txnTransferor != null) {
					if (formTransferor.isIndividual() && txnTransferor.getIndividual() != null) {
						matchFound = compareIndividualFormTransferorToTxnTransferor(formTransferor, matchFound,
								txnTransferor);

					} else if (formTransferor.isCompanyOrganisationAssociation()
							&& txnTransferor.getOrganisation() != null) {
						matchFound = comapreorganisationFormTransferorToTxnTransferor(formTransferor, matchFound,
								txnTransferor);
					}
				}
			}

			if (!matchFound) {
				addMismatchError(new Error(
						"Matching transaction Transferor not found. Form transferor: "
								+ formTransferor.getFormattedName(),
						"Transferor", "formlink.mismatch.transferor.size"));
			}
		}
	}

	private void emptyTransferorCollectionsCheck(List<Transferor> txnTransferors,
			List<au.gov.vic.sro.duties.form.model.party.Transferor> formTransferors) {
		if (!CollectionUtils.isEmpty(txnTransferors) && !CollectionUtils.isEmpty(formTransferors)) {
			if (txnTransferors.size() != formTransferors.size()) {
				// Any of Transferors collection is empty
				addMismatchError(
						new Error("Transferor list size mismatch", "Transferor", "formlink.mismatch.transferor.size"));
			}

		} else {
			// Any of the collections is Empty
			addMismatchError(new Error("Missing Transferee", "Transferee", "formlink.mismatch.transferee.missing"));
		}
	}

	private boolean comapreorganisationFormTransferorToTxnTransferor(
			au.gov.vic.sro.duties.form.model.party.Transferor formTransferor, boolean matchFound,
			Transferor txnTransferor) {
		boolean organisationNameMatch =
				comparePartyOrganisationName(formTransferor.getOrganisation(), txnTransferor.getOrganisation());
		if (organisationNameMatch) {
			matchFound = true;
		} else if (StringUtils.compareIgnoreCase(formTransferor.getOrganisation().getAcnArbnAbn(),
				txnTransferor.getOrganisation().getAbn()) == 0
				|| StringUtils.compareIgnoreCase(formTransferor.getOrganisation().getAcnArbnAbn(),
						txnTransferor.getOrganisation().getAcn()) == 0) {
			matchFound = true;
			addFieldError(formTransferor.getOrganisation().getOrganisationName(),
					txnTransferor.getOrganisation().getOrganisationName(), "Organisation name ",
					"transferor." + txnTransferor.getId() + ".organisation.name.mismatch");
		}
		return matchFound;
	}

	private boolean compareIndividualFormTransferorToTxnTransferor(
			au.gov.vic.sro.duties.form.model.party.Transferor formTransferor, boolean matchFound,
			Transferor txnTransferor) {
		NaturalPerson formPerson = formTransferor.getNaturalPerson();
		Individual txnPerson = txnTransferor.getIndividual();
		LocalDate formDoBLocaldate = convertToLocalDate(formPerson.getDateOfBirth());
		LocalDate txnDoBLocaldate = convertToLocalDate(txnPerson.getDateOfBirth());
		if (formDoBLocaldate != null && txnDoBLocaldate != null && formDoBLocaldate.isEqual(txnDoBLocaldate)) {

			PersonName formPersonName = formPerson.getPersonName();
			boolean firstNameMatch = true;
			boolean surnameMatch = true;
			boolean middleNameMatch = true;
			firstNameMatch = comparePartyFirstName(txnPerson, formPersonName);

			surnameMatch = comparePartySurname(txnPerson, formPersonName);

			middleNameMatch = comparePartyMiddleName(txnPerson, formPersonName);
			if (firstNameMatch || surnameMatch || middleNameMatch) {
				matchFound = true;
			}
			if (matchFound) {
				if (!firstNameMatch) {
					addFieldError(formPerson.getPersonName().getFirstName(), txnPerson.getFirstName(), "First name",
							"transferor." + txnTransferor.getId() + ".first.name.mismatch");
				}
				if (!surnameMatch) {
					addFieldError(formPerson.getPersonName().getSurname(), txnPerson.getSurname(), "Surname",
							"transferor." + txnTransferor.getId() + ".surname.mismatch");
				}
				if (!middleNameMatch) {
					addFieldWarning(formPerson.getPersonName().getMiddleName(), txnPerson.getMiddleName(),
							"Middle name ", "transferor." + txnTransferor.getId() + ".middle.name.mismatch");
				}
				if (!compareTransferorShareFractions(formTransferor, txnTransferor))
					addMismatchError(new Error("Transferor share fraction mismatch", "share fraction",
							"transferor." + txnTransferor.getId() + ".sharefraction.mismatch"));// Fractions Mismatch
			}

		}
		return matchFound;
	}

	private boolean comparePartyOrganisationName(Organisation txnOrganisation,
			au.gov.vic.sro.duties.transfer.model.Organisation formOrganisation) {

		String formOrganisationNameClean =
				cleanseString(StringUtils.normalizeSpace(formOrganisation.getOrganisationName()));
		String txnOrganisationNameClean =
				cleanseString(StringUtils.normalizeSpace(txnOrganisation.getOrganisationName()));
		boolean organisationMatch = true;

		if (StringUtils.compareIgnoreCase(formOrganisationNameClean, txnOrganisationNameClean) != 0) {
			organisationMatch = false;
		}

		return organisationMatch;
	}

	private boolean comparePartyMiddleName(Individual txnPerson, PersonName formPersonName) {
		String formMiddleNameClean = cleanseString(StringUtils.normalizeSpace(formPersonName.getMiddleName()));
		String txnMiddleNameClean = cleanseString(StringUtils.normalizeSpace(txnPerson.getMiddleName()));
		boolean middleNameMatch = true;

		if (StringUtils.compareIgnoreCase(formMiddleNameClean, txnMiddleNameClean) != 0) {
			middleNameMatch = false;
		}

		return middleNameMatch;
	}

	private boolean comparePartySurname(Individual txnPerson, PersonName formPersonName) {
		boolean surnameMatch = true;
		String formSurnameClean = cleanseString(StringUtils.normalizeSpace(formPersonName.getSurname()));
		String txnSurnameClean = cleanseString(StringUtils.normalizeSpace(txnPerson.getSurname()));
		if (StringUtils.compareIgnoreCase(formSurnameClean, txnSurnameClean) != 0) {
			surnameMatch = false;
		}

		return surnameMatch;
	}

	private boolean comparePartyFirstName(Individual txnPerson, PersonName formPersonName) {
		boolean firstNameMatch = true;
		String formFirstNameClean = cleanseString(StringUtils.normalizeSpace(formPersonName.getFirstName()));
		String txnFirstNameClean = cleanseString(StringUtils.normalizeSpace(txnPerson.getFirstName()));
		if (StringUtils.compareIgnoreCase(formFirstNameClean, txnFirstNameClean) != 0) {
			firstNameMatch = false;
		}
		return firstNameMatch;
	}

	private void addFieldError(String formvalue, String txnValue, String fieldName, String errorCode) {
		addMismatchError(new Error(
				fieldName + " mismatch. <br/>Form: " + (StringUtils.isEmpty(formvalue) ? "" : formvalue.toUpperCase())
						+ " <br/> " + ELNO + (StringUtils.isEmpty(txnValue) ? "" : txnValue.toUpperCase()),
				fieldName, errorCode));// mismatch
	}

	private void addFieldWarning(String formvalue, String txnValue, String fieldName, String errorCode) {
		addMismatchWarning(new Error(
				fieldName + " mismatch. <br/>Form: " + (StringUtils.isEmpty(formvalue) ? "" : formvalue.toUpperCase())
						+ " <br/> " + ELNO + (StringUtils.isEmpty(txnValue) ? "" : txnValue.toUpperCase()),
				fieldName, errorCode));// mismatch
	}

	private String cleanseString(String val) {
		return StringUtils.isNotEmpty(val) ? val.replaceAll("/[^A-Za-z0-9 ]/g", "") : StringUtils.trimToNull(val);
	}

	private boolean compareTransferorShareFractions(au.gov.vic.sro.duties.form.model.party.Transferor formParty,
			Party txnparty) {
		boolean shareFractionMatch = true;
		OwnershipShare formPartyShare = formParty.getInterestHolding();
		Fraction formPartyFraction = Fraction.getReducedFraction(formPartyShare.getSharesOwned().intValue(),
				formPartyShare.getTotalShares().intValue());
		Fraction txnPartyFraction = txnparty.getShareFraction();
		if (formPartyFraction.compareTo(txnPartyFraction) != 0) {
			shareFractionMatch = false;
		}
		return shareFractionMatch;
	}

	private boolean compareTransfereeShareFractions(au.gov.vic.sro.duties.form.model.party.Transferee formParty,
			Party txnparty) {
		boolean shareFractionMatch = true;
		OwnershipShare formPartyShare = formParty.getInterestHolding();
		Fraction formPartyFraction = Fraction.getReducedFraction(formPartyShare.getSharesOwned().intValue(),
				formPartyShare.getTotalShares().intValue());
		Fraction txnPartyFraction = txnparty.getShareFraction();
		if (formPartyFraction.compareTo(txnPartyFraction) != 0) {
			shareFractionMatch = false;
		}

		return shareFractionMatch;
	}

	private LocalDate convertToLocalDate(Date date) {
		if (date == null) {
			return null;
		}
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);

		return LocalDate.of(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH));
	}

	private void addMismatchError(Error error) {
		this.mismatchErrors.add(error);
	}

	private void addMismatchWarning(Error error) {
		this.mismatchWarnings.add(error);
	}

	public List<Error> getMismatchErrors() {
		return mismatchErrors;
	}

	public List<Error> getMismatchWarnings() {
		return mismatchWarnings;
	}
}
