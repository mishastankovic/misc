package au.gov.vic.sro.duties.transfer.dao.procedure;

import au.gov.vic.sro.duties.dao.mapper.lodgement.LodgementMapper;
import au.gov.vic.sro.duties.dao.mapper.transaction.LandTransferOracleDataTypeToJavaMapper;
import au.gov.vic.sro.duties.dao.mapper.transaction.facades.DoLtdTransactionRec;
import au.gov.vic.sro.duties.dao.support.StoredProcedure;
import au.gov.vic.sro.duties.dao.util.OracleTypeHelper;
import au.gov.vic.sro.duties.transfer.model.Lodgement;
import oracle.jdbc.OracleTypes;
import oracle.sql.STRUCT;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.support.SQLExceptionTranslator;

import java.sql.SQLException;
import java.sql.Types;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

import static com.sun.org.apache.xalan.internal.xsltc.trax.TransformerFactoryImpl.PACKAGE_NAME;

public class SubmitLodgementProcedure extends StoredProcedure {

    private static final String DO_ELNO_EXTENRAL_RESPONSE_REC = "DO_ELNO_EXTERNAL_RESPONSE_REC";
    private static final String LVT_ELNO_EXTENRAL_RESPONSE_REC = "lvt_elno_external_response_rec";
    private static final String PTI_LODGEMENT_REFERENCE = "pti_lodgement_reference";
    private static final String PTI_SETTLEMENT_DATE = "pti_settlement_date";


    private static final String STORED_PROC_NAME = PACKAGE_NAME + ".submit_lodgement_f";

    public SubmitLodgementProcedure(JdbcTemplate jdbcTemplate, SQLExceptionTranslator sqlExceptionTranslator) {
        super(jdbcTemplate, STORED_PROC_NAME, sqlExceptionTranslator);
        setFunction(true);

        // Record type must be in upper case
        // Note for parameters: return value must be declared first, then method params in order
        declareParameter(
                new SqlOutParameter(LVT_ELNO_EXTENRAL_RESPONSE_REC, Types.STRUCT, DO_ELNO_EXTENRAL_RESPONSE_REC));
        declareParameter(new SqlParameter(PTI_LODGEMENT_REFERENCE, Types.VARCHAR));
        declareParameter(new SqlParameter(PTI_SETTLEMENT_DATE, Types.DATE));
        declareParameter(new SqlParameter(PTI_ORIGINAL_XML, OracleTypes.OPAQUE, XMLTYPE));
        declareParameter(new SqlOutParameter(PTO_MESSAGE_TAB, Types.ARRAY, DO_MESSAGE_TAB));
        compile();
    }

    public Lodgement submit(String elnoLodgementReference, Date intendedSettlementDate, String xml) {
        Map<String, Object> inParams = new LinkedHashMap<>();
        inParams.put(PTI_LODGEMENT_REFERENCE, elnoLodgementReference);
        inParams.put(PTI_SETTLEMENT_DATE, intendedSettlementDate);
        inParams.put(PTI_ORIGINAL_XML, getXMLType(xml));

        Map<?, ?> outParams = defaultExecuteHandler(inParams, PTO_MESSAGE_TAB, LVT_ELNO_EXTENRAL_RESPONSE_REC);
        try {
            return lodgementFromOracleStructures((STRUCT)outParams.get(LVT_ELNO_EXTENRAL_RESPONSE_REC));
        } catch (Exception ex) {
            throw createGenericDaoException(ex, "Exception occurred during mapping", inParams, outParams);
        }
    }

    private static au.gov.vic.sro.duties.lodgement.Lodgement lodgementFromOracleStructures(Object[] doLodgementRec)
            throws SQLException {
        LodgementMapper lodgementMapper = new LodgementMapper();
        return lodgementMapper.mapLodgement(doLodgementRec);
    }

    private static Lodgement lodgementFromOracleStructures(STRUCT doElnoExternalResponseRec) throws SQLException {
        Object[] structAsArray = OracleTypeHelper.getArrayFrom(doElnoExternalResponseRec);
        Object[] doLodgementRec = (Object[]) structAsArray[0];
        au.gov.vic.sro.duties.lodgement.Lodgement lodgement = SubmitLodgementProcedure.lodgementFromOracleStructures(doLodgementRec);

        Object[] doExternalResponseRec = (Object[]) structAsArray[1];

        new LandTransferOracleDataTypeToJavaMapper(new DoLtdTransactionRec(structAsArray)).getOut();
        return null;
    }



}
