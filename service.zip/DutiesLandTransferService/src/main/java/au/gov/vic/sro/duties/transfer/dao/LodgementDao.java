package au.gov.vic.sro.duties.transfer.dao;

import java.sql.Types;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import au.gov.vic.sro.duties.transfer.dao.procedure.ClaimElnoLodgementProcedure;
import au.gov.vic.sro.duties.transfer.dao.procedure.ClaimPexaTransactionProcedure;
import au.gov.vic.sro.duties.transfer.dao.procedure.GetLodgementDetailsProcedure;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.support.SQLExceptionTranslator;
import org.springframework.stereotype.Repository;

import au.gov.vic.sro.duties.dao.mapper.lodgement.LodgementMapper;
import au.gov.vic.sro.duties.dao.support.OracleSQLExceptionTranslator;
import au.gov.vic.sro.duties.dao.support.StoredProcedure;
import au.gov.vic.sro.duties.lodgement.Lodgement;
import au.gov.vic.sro.duties.transaction.Identifier;
import au.gov.vic.sro.duties.transaction.landtransfer.LandTransferDutyTransaction;
import oracle.sql.STRUCT;

@Repository
public class LodgementDao extends JdbcDaoSupport {

	private static final String CUSTOMER_ID_MUST_NOT_BE_NULL = "Customer ID must not be null";
	private static final String IDENTIFIER_MUST_NOT_BE_NULL = "identifier must not be null";

	private SQLExceptionTranslator sqlExceptionTranslator = new OracleSQLExceptionTranslator();

	private ClaimElnoLodgementProcedure claimElnoLodgementProcedure;
	private ClaimPexaTransactionProcedure claimPexaTransactionProcedure;
	private GetLodgementDetailsProcedure getLodgementDetailsProcedure;
	private ReadyToSubmitLodgementProcedure readyToSubmitLodgementProcedure;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@PostConstruct
	private void initialize() {
		setJdbcTemplate(jdbcTemplate);
	}

	@Override
	protected void initTemplateConfig() {
		claimElnoLodgementProcedure = new ClaimElnoLodgementProcedure(getJdbcTemplate(), sqlExceptionTranslator);
		claimPexaTransactionProcedure = new ClaimPexaTransactionProcedure(getJdbcTemplate(), sqlExceptionTranslator);
		getLodgementDetailsProcedure = new GetLodgementDetailsProcedure(getJdbcTemplate(), sqlExceptionTranslator);
		readyToSubmitLodgementProcedure = new ReadyToSubmitLodgementProcedure(getJdbcTemplate(), sqlExceptionTranslator);
	}

	public Lodgement getLodgement(Long lodgementId) {
		if (lodgementId == null) throw new IllegalArgumentException(IDENTIFIER_MUST_NOT_BE_NULL);
		return getLodgementDetailsProcedure.getLodgement(lodgementId);
	}

	public Lodgement getLegacyPexaLodgement(String pexaDocumentId, String transactionId) {
		if (pexaDocumentId == null || transactionId == null) {
			throw new IllegalArgumentException(IDENTIFIER_MUST_NOT_BE_NULL);
		}
		LandTransferDutyTransaction transaction = claimPexaTransactionProcedure.claim(
				new Identifier(pexaDocumentId), new Identifier(transactionId));
		Lodgement lodgement = new Lodgement();
		lodgement.getTransactions().add(transaction);
		return lodgement;
	}

	public Lodgement claimElnoLodgement(String customerId, Lodgement lodgement, String xml) {
		if (customerId == null) {
			throw new IllegalArgumentException(CUSTOMER_ID_MUST_NOT_BE_NULL);
		}
		return claimElnoLodgementProcedure.claim(customerId, lodgement, xml);
	}

	public void readyToSubmitLodgement(Lodgement lodgement) {
		readyToSubmitLodgementProcedure.readyToSubmit(lodgement);
	}

	private class ReadyToSubmitLodgementProcedure extends StoredProcedure {

		private static final String STORED_PROC_NAME = "do_lodgement_pkg.ready_to_submit_f";

		public ReadyToSubmitLodgementProcedure(JdbcTemplate jdbcTemplate, SQLExceptionTranslator sqlExceptionTranslator) {
			super(jdbcTemplate, STORED_PROC_NAME, sqlExceptionTranslator);
			setFunction(true);

			// Record type must be in upper case
			// Note for parameters: return value must be declared first, then method params in order
			declareParameter(new SqlOutParameter(LVT_MSG_TAB, Types.ARRAY, DO_MESSAGE_TAB));
			declareParameter(new SqlParameter(PTI_LODGEMENT_REC, Types.STRUCT, DO_LODGEMENT_REC));
			compile();
		}

		public void readyToSubmit(Lodgement lodgement) {
			Map<String, Object> inParams = new LinkedHashMap<>();
			inParams.put(PTI_LODGEMENT_REC, oracleStructuresFromLodgement(lodgement));
			defaultExecuteHandler(inParams, PTO_MESSAGE_TAB);
		}

		private STRUCT oracleStructuresFromLodgement(Lodgement lodgement) {
			LodgementMapper lodgementMapper = new LodgementMapper();
			return (STRUCT) lodgementMapper.createLodgementStructToDoLodgementRec(lodgement, getOracleConnection());
		}
	}
}
