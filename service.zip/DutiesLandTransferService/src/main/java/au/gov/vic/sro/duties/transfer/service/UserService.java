package au.gov.vic.sro.duties.transfer.service;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import au.gov.vic.sro.duties.registration.UserRegistration;
import au.gov.vic.sro.duties.transfer.dao.FoundationDao;
import au.gov.vic.sro.duties.transfer.dao.UserDao;

@Service
@Transactional(propagation = Propagation.REQUIRED)
public class UserService {

	@Autowired
	private FoundationDao foundationDao;

	@Autowired
	private UserDao userDao;

	@Transactional
	public void setCurrentUser(String userId) {
		foundationDao.setUser(StringUtils.isEmpty(userId) ? "NOTLOGGEDIN" : userId);
	}

	@Transactional(readOnly = true)
	public String getCustomerId(String userId) {
		UserRegistration userRegistration = userDao.getUserRegistration(userId);
		return userRegistration.getCustomerID();
	}
}
