package au.gov.vic.sro.duties.transfer.mapper;

import static au.gov.vic.sro.duties.transaction.landtransfer.LegalEntityType.IndividualNaturalPerson;
import static au.gov.vic.sro.duties.transaction.landtransfer.LegalEntityType.IndividualOther;
import static javax.xml.stream.XMLStreamConstants.CHARACTERS;
import static javax.xml.stream.XMLStreamConstants.END_ELEMENT;
import static javax.xml.stream.XMLStreamConstants.START_ELEMENT;

import java.io.StringReader;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.StringJoiner;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import org.apache.commons.lang3.math.Fraction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import au.gov.vic.sro.duties.lodgement.LodgementStatusType;
import au.gov.vic.sro.duties.transaction.AbstractDutyTransaction;
import au.gov.vic.sro.duties.transaction.AddressOther;
import au.gov.vic.sro.duties.transaction.AssessingMethodType;
import au.gov.vic.sro.duties.transaction.DutyTransactionType;
import au.gov.vic.sro.duties.transaction.Identifier;
import au.gov.vic.sro.duties.transaction.PersonName;
import au.gov.vic.sro.duties.transaction.landtransfer.AbstractLandTransferDutyTransaction;
import au.gov.vic.sro.duties.transaction.landtransfer.AbstractTransferee;
import au.gov.vic.sro.duties.transaction.landtransfer.ComplexLandTransfer;
import au.gov.vic.sro.duties.transaction.landtransfer.ComplexTransferee;
import au.gov.vic.sro.duties.transaction.landtransfer.LandIdentifier;
import au.gov.vic.sro.duties.transaction.landtransfer.LandIdentifierType;
import au.gov.vic.sro.duties.transaction.landtransfer.LegalEntity;
import au.gov.vic.sro.duties.transaction.landtransfer.LegalEntityType;
import au.gov.vic.sro.duties.transaction.landtransfer.TransferProperty;
import au.gov.vic.sro.duties.transfer.model.AbstractLandIdentifier;
import au.gov.vic.sro.duties.transfer.model.Individual;
import au.gov.vic.sro.duties.transfer.model.Lodgement;
import au.gov.vic.sro.duties.transfer.model.Organisation;
import au.gov.vic.sro.duties.transfer.model.Party;
import au.gov.vic.sro.duties.transfer.model.Property;
import au.gov.vic.sro.duties.transfer.model.Transaction;
import au.gov.vic.sro.duties.transfer.model.Transferee;
import au.gov.vic.sro.duties.transfer.model.Transferor;
import au.gov.vic.sro.duties.transfer.model.VolumeAndFolio;

@Service
public class Mapper {

	private static final Logger log = LoggerFactory.getLogger(Mapper.class);

	private static final String STAMP_DUTY_VERIFICATION_ELEMENT = "StampDutyVerification";
	private static final String TRANSACTION_ID_ELEMENT = "TransactionId";
	private static final String ELN_LODGEMENT_CASE_ID_ELEMENT = "ElnLodgementCaseId";

	private static final String DOCUMENT_DATA_ELEMENT = "DocumentData";
	private static final String DOCUMENT_ID_ELEMENT = "DocumentId";

	private static final String SUBJECT_LAND_TITLE_ELEMENT = "SubjectLandTitle";
	private static final String LAND_TITLE_REFERENCE_ELEMENT = "LandTitleReference";
	private static final String STREET_ADDRESS_ELEMENT = "StreetAddress";
	private static final String UNSTRUCTURED_ADDRESS_ELEMENT = "UnstructuredAddress";
	private static final String STRUCTURED_ADDRESS_ELEMENT = "StructuredAddress";
	private static final String ADDRESS_LINE_ELEMENT = "AddressLine";

	private static final String COMPLEX_ROAD_ELEMENT = "ComplexRoad";
	private static final String ROAD_ELEMENT = "Road";
	private static final String LOT_NUMBER_ELEMENT = "LotNumber";
	private static final String ROAD_NUMBER_ELEMENT = "RoadNumber";
	private static final String ROAD_NAME_ELEMENT = "RoadName";
	private static final String ROAD_TYPE_CODE_CONSTANT = "RoadTypeCode";
	private static final String ROAD_SUFFIX_CODE_ELEMENT = "RoadSuffixCode";

	private static final String PARTY_RELINQUISHING_DETAIL_ELEMENT = "PartyRelinquishingDetail";
	private static final String PARTY_RECEIVING_DETAIL_ELEMENT = "PartyReceivingDetail";
	private static final String TENANCY_GROUP_ELEMENT = "TenancyGroup";
	private static final String SHARE_FRACTION_ELEMENT = "ShareFraction";
	private static final String NUMERATOR_ELEMENT = "Numerator";
	private static final String DENOMINATOR_ELEMENT = "Denominator";

	private static final String INVOLVED_PARTY_ELEMENT = "InvolvedParty";
	private static final String PARTY_ID_ELEMENT = "PartyId";
	private static final String PARTY_TYPE_ELEMENT = "PartyType";
	private static final String LEGAL_ENTITY_NAME_ELEMENT = "LegalEntityName";
	private static final String PERSON_FULL_NAME_ELEMENT = "PersonFullName";
	private static final String GIVEN_NAME_ELEMENT = "GivenName";
	private static final String FAMILY_NAME_ELEMENT = "FamilyName";
	private static final String BIRTH_DATE_ELEMENT = "BirthDate";
	private static final String PARTY_IDENTIFICATION_ELEMENT = "PartyIdentification";
	private static final String PARTY_IDENTIFICATION_DESIGNATION_ELEMENT = "PartyIdentificationDesignation";
	private static final String PARTY_IDENTIFICATION_NAME_ELEMENT = "PartyIdentificationName";

	private static final String INTENDED_SETTLEMENT_DATE = "IntendedSettlementDate";

	private static final String PEXA = "PEXA";

	private static final String VOLUME = "Volume";
	private static final String FOLIO = "Folio";

	public Lodgement fromESys(au.gov.vic.sro.duties.lodgement.Lodgement eSysLodgement) {
		Lodgement lodgement = new Lodgement();
		lodgement.setId(fromESys(eSysLodgement.getIdentifier()));
		LodgementStatusType status = eSysLodgement.getStatus();
		lodgement.setStatus(status == null ? null : status.getLabel());
		lodgement.setLodgementCategoryCode(eSysLodgement.getLodgementCategoryDbValue());
		lodgement.setElnoLodgementCaseId(eSysLodgement.getElnoLodgementCaseId());
		lodgement.setElnoId(eSysLodgement.getElnoId());
		lodgement.setCaseReference(eSysLodgement.getElnoLodgementReference());
		lodgement.setIntendedSettlementDate(eSysLodgement.getIntendedSettlementDate());

		for (Iterator<AbstractDutyTransaction> i = eSysLodgement.getTransactions().iterator(); i.hasNext();) {
			lodgement.getTransactions().add(fromESys((AbstractLandTransferDutyTransaction) i.next()));
		}

		return lodgement;
	}

	public Transaction fromESys(AbstractLandTransferDutyTransaction eSysTransaction) {
		Transaction transaction = new Transaction();
		transaction.setId(fromESys(eSysTransaction.getIdentifier()));
		transaction.setFormId(eSysTransaction.getDutiesFormId());
		transaction.setFormVersion(eSysTransaction.getDutiesFormVersion());
		transaction.setElnoDocumentId(eSysTransaction.getElnoDocumentId());
		transaction.setElnoId(eSysTransaction.getElnoId());

		for (TransferProperty eSysProperty : eSysTransaction.getProperties()) {
			Property property = new Property();
			transaction.getPropertyList().add(property);
			// TODO: Need to do more?
			property.setAddress(eSysProperty.getPropertyAddress().getAddress());
			if (eSysProperty.getLandIdentifierType() == LandIdentifierType.VolumeAndFolio) {
				for (LandIdentifier landIdentifier : eSysProperty.getLandIdentifiers()) {
					VolumeAndFolio volumeAndFolio = new VolumeAndFolio();
					property.getLandIdentifierList().add(volumeAndFolio);
					volumeAndFolio.setVolume(landIdentifier.getFirstPart());
					volumeAndFolio.setFolio(landIdentifier.getSecondPart());
				}
			}
		}

		for (au.gov.vic.sro.duties.transaction.landtransfer.Transferor eSysTransferor : eSysTransaction
				.getTransferors()) {
			Transferor transferor = new Transferor();
			transaction.getTransferorList().add(transferor);
			fromESys(eSysTransferor, transferor);
			transferor.setShareFraction(fromESys(eSysTransferor.getInterestOnTitle()));
		}

		for (Iterator<? extends LegalEntity> i = eSysTransaction.getTransferees().iterator(); i.hasNext();) {
			AbstractTransferee eSysTransferee = (AbstractTransferee) i.next();
			Transferee transferee = new Transferee();
			transaction.getTransfereeList().add(transferee);
			fromESys(eSysTransferee, transferee);
			transferee.setShareFraction(fromESys(eSysTransferee.getInterestOnTitle()));
		}

		return transaction;
	}

	private String fromESys(Identifier identifier) {
		return identifier == null ? null : identifier.getIdentifier();
	}

	private <T extends Party> T fromESys(LegalEntity eSysParty, T party) {
		party.setId(fromESys(eSysParty.getIdentifier()));
		party.setPartyId(eSysParty.getPartyId());
		party.setElnoPartyId(eSysParty.getElnoPartyId());
		party.setPartyType(eSysParty.getLegalEntityType());
		PersonName personName = eSysParty.getIndividualName();
		Date dateOfBirth = eSysParty.getDateOfBirth();
		if (personName != null || dateOfBirth != null) {
			Individual individual = new Individual();
			party.setIndividual(individual);
			if (personName != null) {
				individual.setFirstName(personName.getFirstName());
				individual.setMiddleName(personName.getMiddleName());
				individual.setSurname(personName.getSurname());
			}
			individual.setDateOfBirth(dateOfBirth);
		}
		String companyName = eSysParty.getCompanyName();
		if (companyName != null) {
			Organisation organisation = new Organisation();
			party.setOrganisation(organisation);
			organisation.setOrganisationName(eSysParty.getCompanyName());
			organisation.setAbn(eSysParty.getABN());
			organisation.setAcn(eSysParty.getACN());
		}

		return party;
	}

	private Fraction fromESys(au.gov.vic.sro.duties.transaction.Fraction fraction) {
		return fraction == null ? null
				: Fraction.getReducedFraction((int) fraction.getNumerator(), (int) fraction.getDenominator());
	}

	public au.gov.vic.sro.duties.lodgement.Lodgement toESys(Lodgement lodgement) {
		au.gov.vic.sro.duties.lodgement.Lodgement eSysLodgement = new au.gov.vic.sro.duties.lodgement.Lodgement();
		eSysLodgement.setIdentifier(toESys(lodgement.getId()));
		eSysLodgement.setDutyType(DutyTransactionType.ELNO);
		// TODO in stage 3 Map category code
		eSysLodgement.setAssessingMethod(AssessingMethodType.MANUAL);
		// eSysLodgement.setStatus(lodgement.getStatus()); // Note. Should not change eSys lodgement status
		eSysLodgement.setLodgementCategoryDbValue(lodgement.getLodgementCategoryCode());
		eSysLodgement.setElnoLodgementCaseId(lodgement.getElnoLodgementCaseId());
		eSysLodgement.setElnoId(lodgement.getElnoId());
		eSysLodgement.setElnoLodgementReference(lodgement.getCaseReference());
		eSysLodgement.setIntendedSettlementDate(lodgement.getIntendedSettlementDate());
		for (Transaction transaction : lodgement.getTransactions()) {
			eSysLodgement.getTransactions().add(toESys(transaction));
		}
		return eSysLodgement;
	}

	public AbstractLandTransferDutyTransaction toESys(Transaction transaction) {
		AbstractLandTransferDutyTransaction eSysTransaction = new ComplexLandTransfer();
		eSysTransaction.setIdentifier(toESys(transaction.getId()));
		eSysTransaction.setDutiesFormId(transaction.getFormId());
		Integer formVersion = transaction.getFormVersion();
		eSysTransaction.setDutiesFormVersion(formVersion == null ? null : Long.valueOf(formVersion));
		eSysTransaction.setElnoDocumentId(transaction.getElnoDocumentId());
		eSysTransaction.setElnoId(transaction.getElnoId());
		for (Property property : transaction.getPropertyList()) {
			TransferProperty eSysProperty = new TransferProperty();
			eSysTransaction.getProperties().add(eSysProperty);
			// TODO: Need to do more?
			AddressOther propertyAddress = new AddressOther();
			propertyAddress.setAddress(property.getAddress());
			eSysProperty.setPropertyAddress(propertyAddress);
			eSysProperty.setLandIdentifierType(LandIdentifierType.VolumeAndFolio);
			for (Iterator<AbstractLandIdentifier> i = property.getLandIdentifierList().iterator(); i.hasNext();) {
				VolumeAndFolio volumeAndFolio = (VolumeAndFolio) i.next();
				LandIdentifier landIdentifier =
						new LandIdentifier(volumeAndFolio.getVolume(), volumeAndFolio.getFolio());
				eSysProperty.getLandIdentifiers().add(landIdentifier);
			}
		}

		for (Transferor transferor : transaction.getTransferorList()) {
			au.gov.vic.sro.duties.transaction.landtransfer.Transferor eSysTransferor =
					new au.gov.vic.sro.duties.transaction.landtransfer.Transferor();
			eSysTransaction.getTransferors().add(eSysTransferor);
			toESys(transferor, eSysTransferor);
			eSysTransferor.setRemainingOnTitle(false); // @Yuke: Not used for matching.
			eSysTransferor.setInterestOnTitle(toESys(transferor.getShareFraction()));
		}

		for (Transferee transferee : transaction.getTransfereeList()) {
			ComplexTransferee eSysTransferee = new ComplexTransferee(); // TODO: stage 3
																		// au.gov.vic.sro.duties.transaction.landtransfer.Transferee();
			((ComplexLandTransfer) eSysTransaction).getTransferees().add(eSysTransferee);
			toESys(transferee, eSysTransferee);
			eSysTransferee.setInterestOnTitle(toESys(transferee.getShareFraction()));
		}
		return eSysTransaction;
	}

	private Identifier toESys(String id) {
		return id == null ? null : new Identifier(id); // new TemporaryIdentifier()
	}

	private <T extends LegalEntity> T toESys(Party party, T eSysParty) {
		eSysParty.setIdentifier(toESys(party.getId()));
		eSysParty.setPartyId(party.getPartyId());
		eSysParty.setElnoPartyId(party.getElnoPartyId());
		eSysParty.setLegalEntityType(party.getPartyType());
		Individual individual = party.getIndividual();
		if (individual != null) {
			PersonName personName = new PersonName();
			eSysParty.setIndividualName(personName);
			personName.setFirstName(individual.getFirstName());
			personName.setMiddleName(individual.getMiddleName());
			personName.setSurname(individual.getSurname());
			eSysParty.setDateOfBirth(individual.getDateOfBirth());
		}
		Organisation organisation = party.getOrganisation();
		if (organisation != null) {
			eSysParty.setCompanyName(organisation.getOrganisationName());
			eSysParty.setABN(organisation.getAbn());
			eSysParty.setACN(organisation.getAcn());
		}

		return eSysParty;
	}

	private au.gov.vic.sro.duties.transaction.Fraction toESys(Fraction fraction) {
		return fraction == null ? null
				: au.gov.vic.sro.duties.transaction.Fraction.getReducedFraction(fraction.getNumerator(),
						fraction.getDenominator());
	}

	public Lodgement fromXML(String xml) {
		XMLInputFactory factory = XMLInputFactory.newInstance();
		XMLStreamReader reader = null;
		try (StringReader stringReader = new StringReader(xml)) {
			reader = factory.createXMLStreamReader(stringReader);
			return getLodgement(reader);
		} catch (XMLStreamException e) {
			String message = "Failed to map stamp duty verification request XML " + xml;
			log.error(message, e);
			throw new IllegalArgumentException(message, e);
		} finally {
			close(reader);
			reader = null;
		}
	}

	private Lodgement getLodgement(XMLStreamReader reader) throws XMLStreamException {
		Lodgement lodgement = new Lodgement();
		Map<String, Party> involvedPartyMap = new HashMap<>();
		while (reader.hasNext()) {
			int event = reader.next();
			if (event == START_ELEMENT) {
				String localName = reader.getLocalName();
				if (STAMP_DUTY_VERIFICATION_ELEMENT.equals(localName)) {
					// lodgement = new Lodgement();
				} else if (TRANSACTION_ID_ELEMENT.equals(localName)) {
					lodgement.setCaseReference(getText(reader));
				} else if (ELN_LODGEMENT_CASE_ID_ELEMENT.equals(localName)) {
					lodgement.setElnoLodgementCaseId(getText(reader));
				} else if (DOCUMENT_DATA_ELEMENT.equals(localName)) {
					lodgement.getTransactions().add(getTransaction(reader));
				} else if (INVOLVED_PARTY_ELEMENT.equals(localName)) {
					Party party = getParty(reader);
					involvedPartyMap.put(party.getElnoPartyId(), party);
				} else if (INTENDED_SETTLEMENT_DATE.equals(localName)) {
					lodgement.setIntendedSettlementDate(getDateTime(reader));
				}
			} else if (event == END_ELEMENT && STAMP_DUTY_VERIFICATION_ELEMENT.equals(reader.getLocalName())) {
				lodgement.setElnoId(PEXA); // TODO: Get it from Security context?
				consolidatePartyList(lodgement, involvedPartyMap);
				return lodgement;
			}
		}
		close(reader);

		return null;
	}

	private void consolidatePartyList(Lodgement lodgement, Map<String, Party> involvedPartyMap) {
		Map<String, String> duplicatePartyMap = new HashMap<String, String>();
		List<Party> partyList = new ArrayList<Party>(involvedPartyMap.values());
		for (int i = 0; i < partyList.size(); i++) {
			for (int j = i + 1; j < partyList.size(); j++) {
				Party party1 = partyList.get(i);
				Party party2 = partyList.get(j);

				LegalEntityType partyType = party1.getPartyType();
				if (partyType == IndividualNaturalPerson || partyType == IndividualOther) {
					if (party1.getIndividual().equals(party2.getIndividual())) {
						String otherElnoPartyId = party2.getElnoPartyId();
						duplicatePartyMap.put(otherElnoPartyId, party1.getElnoPartyId());
						involvedPartyMap.remove(otherElnoPartyId);
					}
				} else {
					// TODO: Match organisation name / ABN / ACN?
				}
			}
		}
		for (Transaction transaction : lodgement.getTransactions()) {
			consolidate(transaction.getTransfereeList(), involvedPartyMap, duplicatePartyMap);
			consolidate(transaction.getTransferorList(), involvedPartyMap, duplicatePartyMap);
		}
	}

	private <T extends Party> void consolidate(List<T> partyList, Map<String, Party> involvedPartyMap,
			Map<String, String> duplicatePartyMap) {

		for (int i = 0; i < partyList.size(); i++) {
			Party party = partyList.get(i);
			String elnoPartyId = party.getElnoPartyId();
			Party involvedParty = involvedPartyMap.get(elnoPartyId);
			if (involvedParty == null) {
				elnoPartyId = duplicatePartyMap.get(elnoPartyId);
				involvedParty = involvedPartyMap.get(elnoPartyId);
				party.setElnoPartyId(elnoPartyId);
				consolidateAndRemoveDuplicateParty(partyList, party);
			}
			consolidatePartyDetails(party, involvedParty);
		}
	}

	private <T extends Party> void consolidateAndRemoveDuplicateParty(List<T> partyList, Party party) {
		String elnoPartyId = party.getElnoPartyId();
		for (int i = 0; i < partyList.size(); i++) {
			Party otherParty = partyList.get(i);
			if (elnoPartyId.equals(otherParty.getElnoPartyId())) {
				party.setShareFraction(party.getShareFraction().multiplyBy(otherParty.getShareFraction()).reduce());
				if (otherParty != party) {
					partyList.remove(otherParty);
				}
			}
		}
	}

	private <T extends Party> void consolidatePartyDetails(T party, Party involvedParty) {
		party.setPartyType(involvedParty.getPartyType());
		party.setIndividual(involvedParty.getIndividual());
		party.setOrganisation(involvedParty.getOrganisation());
	}

	private Transaction getTransaction(XMLStreamReader reader) throws XMLStreamException {
		Transaction transaction = new Transaction();
		transaction.setElnoId(PEXA); // TODO: To be done as part of EB-5557
		while (reader.hasNext()) {
			int event = reader.next();
			if (event == START_ELEMENT) {
				String localName = reader.getLocalName();
				if (DOCUMENT_ID_ELEMENT.equals(localName)) {
					transaction.setElnoDocumentId(getText(reader));
				} else if (SUBJECT_LAND_TITLE_ELEMENT.equals(localName)) {
					transaction.getPropertyList().add(getProperty(reader));
				} else if (PARTY_RECEIVING_DETAIL_ELEMENT.equals(localName)) {
					transaction.getTransfereeList().addAll(getTransfereeList(reader));
				} else if (PARTY_RELINQUISHING_DETAIL_ELEMENT.equals(localName)) {
					transaction.getTransferorList().addAll(getTransferorList(reader));
				}
			} else if (event == END_ELEMENT && DOCUMENT_DATA_ELEMENT.equals(reader.getLocalName())) {
				return transaction;
			}
		}
		return transaction;
	}

	private Property getProperty(XMLStreamReader reader) throws XMLStreamException {
		Property property = new Property();
		while (reader.hasNext()) {
			int event = reader.next();
			if (event == START_ELEMENT) {
				String localName = reader.getLocalName();
				if (LAND_TITLE_REFERENCE_ELEMENT.equals(localName)) {
					AbstractLandIdentifier landIdentifier = getLandIdentifier(reader);
					if (landIdentifier != null) {
						property.getLandIdentifierList().add(landIdentifier);
					}
				} else if (STREET_ADDRESS_ELEMENT.equals(localName)) {
					property.setAddress(getStreetAddress(reader));
				}
			} else if (event == END_ELEMENT && SUBJECT_LAND_TITLE_ELEMENT.equals(reader.getLocalName())) {
				return property;
			}
		}
		return property;
	}

	private AbstractLandIdentifier getLandIdentifier(XMLStreamReader reader) throws XMLStreamException {

		VolumeAndFolio volumeAndFolio = null;
		String componentName = null;

		while (reader.hasNext()) {
			int event = reader.next();
			if (event == START_ELEMENT) {
				String localName = reader.getLocalName();
				if ("Name".equals(localName)) {
					componentName = getText(reader);
					if ((VOLUME.equals(componentName) || FOLIO.equals(componentName)) && volumeAndFolio == null) {
						volumeAndFolio = new VolumeAndFolio();
					}
				} else if ("Value".equals(localName)) {
					if (VOLUME.equals(componentName)) {
						volumeAndFolio.setVolume(getText(reader));
					} else if (FOLIO.equals(componentName)) {
						volumeAndFolio.setFolio(getText(reader));
					}
				}
			} else if (event == END_ELEMENT && LAND_TITLE_REFERENCE_ELEMENT.equals(reader.getLocalName())) {
				return volumeAndFolio;
			}
		}

		throw new XMLStreamException("Invalid land identifier");
	}

	private String getStreetAddress(XMLStreamReader reader) throws XMLStreamException {
		while (reader.hasNext()) {
			int event = reader.next();
			if (event == START_ELEMENT) {
				String localName = reader.getLocalName();
				if (UNSTRUCTURED_ADDRESS_ELEMENT.equals(localName)) {
					return getUnstructuredAddress(reader);
				} else if (STRUCTURED_ADDRESS_ELEMENT.equals(localName)) {
					return getStructuredAddress(reader);
				}
			} else if (event == END_ELEMENT && STREET_ADDRESS_ELEMENT.equals(reader.getLocalName())) {
				throw new XMLStreamException("Invalid street address");
			}
		}
		throw new XMLStreamException("Invalid street address");
	}

	private String getUnstructuredAddress(XMLStreamReader reader) throws XMLStreamException {
		List<Sortable> addressLineList = new ArrayList<Sortable>();
		while (reader.hasNext()) {
			int event = reader.next();
			if (event == START_ELEMENT) {
				if (ADDRESS_LINE_ELEMENT.equals(reader.getLocalName())) {
					Sortable addressLine = new Sortable();
					addressLine.order = getOrder(reader);
					addressLine.string = getText(reader);
				}
			} else if (event == END_ELEMENT && UNSTRUCTURED_ADDRESS_ELEMENT.equals(reader.getLocalName())) {
				Collections.sort(addressLineList, new SortByOrder());
				return join(", ", addressLineList);
			}
		}
		throw new XMLStreamException("Invalid unstructured address " + addressLineList);
	}

	private String getStructuredAddress(XMLStreamReader reader) throws XMLStreamException {

		StringBuilder sb = new StringBuilder();
		String postcode = null;

		while (reader.hasNext()) {
			int event = reader.next();
			if (event == START_ELEMENT) {
				switch (reader.getLocalName()) {
				// case "SubDwellingUnitType":
				case "UnitTypeCode":
					// case "Level":
				case "LevelTypeCode":
					sb.append(getText(reader)).append(" ");
					break;
				case "UnitNumber":
				case "LevelNumber":
				case "SecondaryComplex":
				case "AddressSiteName":
					sb.append(getText(reader)).append(", ");
					break;
				case COMPLEX_ROAD_ELEMENT:
				case ROAD_ELEMENT:
					sb.append(getRoad(reader)).append(", ");
					break;
				case "LocalityName":
					sb.append(getText(reader)).append(", ");
					break;
				case "Postcode":
					postcode = getText(reader);
					break;
				case "State":
					sb.append(getText(reader));
					if (postcode != null) {
						sb.append(" ").append(postcode);
					}
					return sb.toString();
				default:
				}
			} else if (event == END_ELEMENT && STRUCTURED_ADDRESS_ELEMENT.equals(reader.getLocalName())) {
				throw new XMLStreamException("Invalid structured address " + sb.toString());
			}
		}
		throw new XMLStreamException("Invalid structured address " + sb.toString());
	}

	private String getRoad(XMLStreamReader reader) throws XMLStreamException {
		StringBuilder sb = new StringBuilder();
		boolean alreadyARoadNumber = false;

		while (reader.hasNext()) {
			int event = reader.next();
			if (event == START_ELEMENT) {
				switch (reader.getLocalName()) {
				case LOT_NUMBER_ELEMENT:
					sb.append("Lot ").append(getText(reader)).append(", ");
					break;
				case ROAD_NUMBER_ELEMENT:
					if (alreadyARoadNumber) {
						sb.append("-");
					}
					sb.append(getText(reader));
					alreadyARoadNumber = true;
					break;
				case ROAD_NAME_ELEMENT:
				case ROAD_TYPE_CODE_CONSTANT:
				case ROAD_SUFFIX_CODE_ELEMENT:
					sb.append(" ").append(getText(reader));
					break;
				default:
				}
			} else if (event == END_ELEMENT) {
				switch (reader.getLocalName()) {
				case COMPLEX_ROAD_ELEMENT:
				case ROAD_ELEMENT:
					return sb.toString();
				default:
				}
			}
		}
		return sb.toString();
	}

	private List<Transferee> getTransfereeList(XMLStreamReader reader) throws XMLStreamException {
		List<Transferee> transfereeList = new ArrayList<Transferee>();
		while (reader.hasNext()) {
			int event = reader.next();
			if (event == START_ELEMENT) {
				if (TENANCY_GROUP_ELEMENT.equals(reader.getLocalName())) {
					transfereeList.addAll(getPartyList(reader, Transferee.class));
				}
			} else if (event == END_ELEMENT && PARTY_RECEIVING_DETAIL_ELEMENT.equals(reader.getLocalName())) {
				return transfereeList;
			}
		}
		return transfereeList;
	}

	private List<Transferor> getTransferorList(XMLStreamReader reader) throws XMLStreamException {
		List<Transferor> transferorList = new ArrayList<Transferor>();
		while (reader.hasNext()) {
			int event = reader.next();
			if (event == START_ELEMENT) {
				if (TENANCY_GROUP_ELEMENT.equals(reader.getLocalName())) {
					transferorList.addAll(getPartyList(reader, Transferor.class));
				}
			} else if (event == END_ELEMENT && PARTY_RELINQUISHING_DETAIL_ELEMENT.equals(reader.getLocalName())) {
				return transferorList;
			}
		}
		return transferorList;
	}

	private <T extends Party> List<T> getPartyList(XMLStreamReader reader, Class<T> partyClass)
			throws XMLStreamException {
		Fraction shareFraction = Fraction.ONE;
		List<T> partyList = new ArrayList<T>();
		while (reader.hasNext()) {
			int event = reader.next();
			if (event == START_ELEMENT) {
				String localName = reader.getLocalName();
				if (SHARE_FRACTION_ELEMENT.equals(localName)) {
					shareFraction = getShareFraction(reader);
				} else if (PARTY_ID_ELEMENT.equals(localName)) {
					try {
						T party = partyClass.newInstance();
						party.setElnoPartyId(getText(reader));
						partyList.add(party);
					} catch (InstantiationException | IllegalAccessException e) {
						String message = "Failed to instantiate " + partyClass;
						log.error(message, e);
						throw new RuntimeException(message, e);
					}
				}
			} else if (event == END_ELEMENT && TENANCY_GROUP_ELEMENT.equals(reader.getLocalName())) {
				shareFraction = shareFraction.multiplyBy(Fraction.getFraction(1, partyList.size())).reduce();
				for (T party : partyList) {
					party.setShareFraction(shareFraction);
				}
				return partyList;
			}
		}
		return partyList;
	}

	private Fraction getShareFraction(XMLStreamReader reader) throws XMLStreamException {
		int numerator = 0, denominator = 0;
		while (reader.hasNext()) {
			int event = reader.next();
			if (event == START_ELEMENT) {
				String localName = reader.getLocalName();
				if (NUMERATOR_ELEMENT.equals(localName)) {
					numerator = Integer.parseInt(getText(reader));
				} else if (DENOMINATOR_ELEMENT.equals(localName)) {
					denominator = Integer.parseInt(getText(reader));
					return Fraction.getFraction(numerator, denominator);
				}
			} else if (event == END_ELEMENT && SHARE_FRACTION_ELEMENT.equals(reader.getLocalName())) {
				throw new XMLStreamException(String.format("Invalid share fraction (numerator: %s, denominator: %s",
						numerator, denominator));
			}
		}
		throw new XMLStreamException(
				String.format("Invalid share fraction (numerator: %s, denominator: %s", numerator, denominator));
	}

	private Party getParty(XMLStreamReader reader) throws XMLStreamException {
		Party party = new Party();
		String legalEntityName;
		while (reader.hasNext()) {
			int event = reader.next();
			if (event == START_ELEMENT) {
				String localName = reader.getLocalName();
				if (PARTY_ID_ELEMENT.equals(localName)) {
					party.setElnoPartyId(getText(reader));
				} else if (PARTY_TYPE_ELEMENT.equals(localName)) {
					switch (getText(reader)) {
					case "Individual":
					case "Natural Person": // 'Natural Person' is deprecated and is replaced by 'Individual'
						party.setPartyType(LegalEntityType.IndividualNaturalPerson);
						break;
					case "Sole Trader":
						party.setPartyType(LegalEntityType.IndividualOther);
						break;
					case "Partnership": // TODO Do we care?
					case "Organisation":
						party.setPartyType(LegalEntityType.Organisation);
						break;
					case "Indeterminate":
					default:
						// error;
					}
				} else if (LEGAL_ENTITY_NAME_ELEMENT.equals(localName)) {
					legalEntityName = getText(reader);
					if (LegalEntityType.Organisation.equals(party.getPartyType())) {
						Organisation organisation = new Organisation();
						organisation.setOrganisationName(legalEntityName);
						party.setOrganisation(organisation);
					}
				} else if (PERSON_FULL_NAME_ELEMENT.equals(localName)) {
					party.setIndividual(new Individual());
					setPersonFullName(reader, party.getIndividual());
				} else if (BIRTH_DATE_ELEMENT.equals(localName)) {
					party.getIndividual().setDateOfBirth(getDate(reader));
				} else if (PARTY_IDENTIFICATION_ELEMENT.equals(localName)) {
					setPartyIdentification(reader, party);
				}
			} else if (event == END_ELEMENT && INVOLVED_PARTY_ELEMENT.equals(reader.getLocalName())) {
				return party;
			}
		}
		return party;
	}

	private void setPersonFullName(XMLStreamReader reader, Individual individual) throws XMLStreamException {
		List<Sortable> middleNameList = new ArrayList<Sortable>();
		while (reader.hasNext()) {
			int event = reader.next();
			if (event == START_ELEMENT) {
				String localName = reader.getLocalName();
				if (GIVEN_NAME_ELEMENT.equals(localName)) {
					int order = getOrder(reader);
					String givenName = getText(reader);
					if (order > 1) {
						Sortable middleName = new Sortable();
						middleName.order = order;
						middleName.string = givenName;
						middleNameList.add(middleName);
					} else {
						individual.setFirstName(givenName);
					}
				} else if (FAMILY_NAME_ELEMENT.equals(localName)) {
					individual.setSurname(getText(reader));
				}
			} else if (event == END_ELEMENT && PERSON_FULL_NAME_ELEMENT.equals(reader.getLocalName())) {
				individual.setMiddleName(join(" ", middleNameList));
				return;
			}
		}
	}

	private void setPartyIdentification(XMLStreamReader reader, Party party) throws XMLStreamException {
		Organisation organisation = party.getOrganisation();
		if (organisation == null) {
			return;
		}
		String partyIdentificationDesignation = null;
		while (reader.hasNext()) {
			int event = reader.next();
			if (event == START_ELEMENT) {
				String localName = reader.getLocalName();
				if (PARTY_IDENTIFICATION_DESIGNATION_ELEMENT.equals(localName)) {
					partyIdentificationDesignation = getText(reader);
				} else if (PARTY_IDENTIFICATION_NAME_ELEMENT.equals(localName)) {
					String partyIdentificationName = getText(reader);
					if ("ABN".equals(partyIdentificationName)) {
						organisation.setAbn(partyIdentificationDesignation);
					} else if ("ACN".equals(partyIdentificationName)) {
						organisation.setAcn(partyIdentificationDesignation);
					}
				}
			} else if (event == END_ELEMENT && PARTY_IDENTIFICATION_ELEMENT.equals(reader.getLocalName())) {
				return;
			}
		}
	}

	private int getOrder(XMLStreamReader reader) {
		int order = 0;
		int attributeCount = reader.getAttributeCount();
		for (int i = 0; i < attributeCount; i++) {
			if (reader.getAttributeLocalName(i) == "order") {
				order = Integer.parseInt(reader.getAttributeValue(i));
			}
		}
		return order;
	}

	private Date getDate(XMLStreamReader reader) throws XMLStreamException {
		return getDate(reader, new SimpleDateFormat("yyyy-MM-dd"));
	}

	private Date getDateTime(XMLStreamReader reader) throws XMLStreamException {
		return getDate(reader, new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss"));
	}

	private Date getDate(XMLStreamReader reader, DateFormat dateFormat) throws XMLStreamException {
		String text = getText(reader);
		if (text != null) {
			try {
				return dateFormat.parse(text);
			} catch (ParseException e) {
				String message = "Failed to parse date " + text;
				log.error(message, e);
				throw new IllegalArgumentException(message, e);
			}
		}
		return null;
	}

	private String getText(XMLStreamReader reader) throws XMLStreamException {
		while (reader.hasNext()) {
			if (reader.next() == CHARACTERS) {
				String text = reader.getText();
				reader.next();
				return text;
			}
		}
		return null;
	}

	private void close(XMLStreamReader reader) {
		if (reader != null) {
			try {
				reader.close();
			} catch (XMLStreamException e) {
				log.error("Failed to close XML stream reader", e);
			}
		}
	}

	private static String join(CharSequence delimiter, List<Sortable> sortables) {
		Objects.requireNonNull(delimiter);
		Objects.requireNonNull(sortables);
		StringJoiner joiner = new StringJoiner(delimiter);
		for (Sortable sortable : sortables) {
			joiner.add(sortable.string);
		}
		return joiner.toString();
	}
}

class Sortable {
	int order;
	String string;

	@Override
	public String toString() {
		return string;
	}
}

class SortByOrder implements Comparator<Sortable> {
	public int compare(Sortable s1, Sortable s2) {
		return s1.order - s2.order;
	}
}