package au.gov.vic.sro.duties.transfer.dao;

import java.sql.SQLException;
import java.sql.Types;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.support.SQLExceptionTranslator;
import org.springframework.stereotype.Repository;

import au.gov.vic.sro.duties.dao.exception.NotFoundException;
import au.gov.vic.sro.duties.dao.mapper.registration.RegistrationPrivilegesMapper;
import au.gov.vic.sro.duties.dao.mapper.user.UserMapper;
import au.gov.vic.sro.duties.dao.mapper.user.UserRecord;
import au.gov.vic.sro.duties.dao.support.OracleSQLExceptionTranslator;
import au.gov.vic.sro.duties.dao.support.StoredProcedure;
import au.gov.vic.sro.duties.registration.RegistrationPrivileges;
import au.gov.vic.sro.duties.registration.UserRegistration;
import au.gov.vic.sro.duties.user.User;
import oracle.sql.STRUCT;

@Repository
public class UserDao extends JdbcDaoSupport {

	private RegistrationPrivilegesMapper registrationPrivilegesMapper = new RegistrationPrivilegesMapper();
	private UserMapper userMapper = new UserMapper();

	private SQLExceptionTranslator sqlExceptionTranslator = new OracleSQLExceptionTranslator();

	private GetUserDetailsProcedure getUserDetailsProcedure;

	private static class GetUserDetailsProcedure extends StoredProcedure {

		private static final String STORED_PROC_NAME = "do_registration_pkg.get_user_details_p";

		public GetUserDetailsProcedure(JdbcTemplate jdbcTemplate, SQLExceptionTranslator sqlExceptionTranslator) {
			super(jdbcTemplate, STORED_PROC_NAME, sqlExceptionTranslator);
			setFunction(false);

			// Record type must be in upper case
			declareParameter(new SqlParameter("pci_user_id", Types.VARCHAR));
			declareParameter(new SqlOutParameter("pco_customer_id", Types.VARCHAR));
			declareParameter(new SqlOutParameter("pco_customer_name", Types.VARCHAR));
			declareParameter(new SqlOutParameter("pto_user", Types.STRUCT, "DO_USER_REC"));
			declareParameter(new SqlOutParameter("pco_revenue_type", Types.VARCHAR));
			declareParameter(new SqlOutParameter("pto_registration_privileges", Types.STRUCT,
					"DO_REGISTRATION_PRIVILEGES_REC"));
			compile();
		}
	}

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@PostConstruct
	private void initialize() {
		setJdbcTemplate(jdbcTemplate);
	}

	@Override
	protected void initTemplateConfig() {
		getUserDetailsProcedure = new GetUserDetailsProcedure(getJdbcTemplate(), sqlExceptionTranslator);
	}

	public UserRegistration getUserRegistration(String userId) {
		if (userId == null) {
			throw new IllegalArgumentException("Required arguments missing");
		}

		UserRegistration userRegistration = new UserRegistration();
		User user = null;
		RegistrationPrivileges registrationPrivileges = null;
		String customerID = null;
		String legalName = null;
		Map<String, Object> inParams = new LinkedHashMap<String, Object>();
		inParams.put("pci_user_id", userId);

		try {
			Map<?, ?> outParams = getUserDetailsProcedure.execute(inParams);
			if (outParams.size() > 0) {
				customerID = (String) outParams.get("pco_customer_id");
				legalName = (String) outParams.get("pco_customer_name");
				STRUCT struct = (STRUCT) outParams.get("pto_user");
				Object[] userRec = struct.getAttributes();
				// Added condition - check for the ESYS_USER_ID - the proc helpfully returns
				// an empty ODT rather than nothing when a user cannot be found
				if (userRec != null && userRec.length > 0 && userRec[UserRecord.ESYS_USER_ID.ordinal()] != null) {
					user = userMapper.mapUser(userRec);
				}
				STRUCT privsStruct = (STRUCT) outParams.get("pto_registration_privileges");
				Object[] regPrivsRec = privsStruct.getAttributes();
				if (regPrivsRec != null && regPrivsRec.length > 0) {
					registrationPrivileges = registrationPrivilegesMapper.mapRegistrationPrivileges(regPrivsRec);
				}
			}
			if (user == null) {
				throw new NotFoundException(String.format("User %s not found.", userId));
			}
			userRegistration.setUser(user);
			userRegistration.setCustomerID(customerID);
			userRegistration.setLegalName(legalName);
			userRegistration.setRegistrationPrivileges(registrationPrivileges);

		} catch (SQLException e) {
			throw sqlExceptionTranslator.translate(
					"Unable to get user record due to database access error;" + " userId=" + userId + " stored proc="
							+ getUserDetailsProcedure.getSql(), null, e);
//		} catch (DataAccessResourceFailureException e) {
//			throw getDataAccessResourceFailureExceptionTranslator().translate(
//					"Unable to get user record;" + " userId=" + userId + " stored proc="
//							+ getUserDetailsProcedure.getSql(), e);
		} catch (DataIntegrityViolationException dve) {
			// This exception is being thrown in response to the 'no data found' exception raised by the procedure
			throw new NotFoundException(String.format("User %s not found.", userId));
		}
		return userRegistration;
	}
}
