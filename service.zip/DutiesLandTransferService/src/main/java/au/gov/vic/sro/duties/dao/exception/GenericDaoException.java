package au.gov.vic.sro.duties.dao.exception;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import oracle.sql.ARRAY;
import oracle.sql.STRUCT;

import org.apache.commons.lang3.StringUtils;

/** 
 * A copy of au.gov.vic.sro.duties.dao.exception.GenericDaoException
 *
 * @see au.gov.vic.sro.duties.dao.exception.GenericDaoException
 */
public class GenericDaoException extends RuntimeException {

	private static final long serialVersionUID = -1420211653231189685L;

	private final List<DatabaseValidationMessage> messages = new ArrayList<DatabaseValidationMessage>();

	private final Map<String, String> parameters = new HashMap<String, String>();

	private final Map<String, String> returnValues = new HashMap<String, String>();

	private final String sql;

	public GenericDaoException(Throwable cause, String message, String sql) {
		super(message, cause);
		this.sql = StringUtils.trimToNull(sql);
	}

	public GenericDaoException(String message, String sql) {
		super(message);
		this.sql = StringUtils.trimToNull(sql);
	}

	public GenericDaoException(String message, String sql, Map<String, Object> inParameters) {
		this(message, sql);
		if (inParameters != null) {
			addParameter(inParameters);
		}
	}

	public GenericDaoException(String message, String sql, Throwable cause) {
		super(message, cause);
		this.sql = StringUtils.trimToNull(sql);
	}

	public GenericDaoException(Throwable cause, String message, String sql, Map<String, Object> inParameters) {
		this(message, sql, cause);
		if (inParameters != null) {
			addParameter(inParameters);
		}
	}

	public GenericDaoException(String message, String sql, Map<String, Object> inParameters,
			Map<String, Object> outParameters) {
		this(message, sql, inParameters);
		if (outParameters != null) {
			addReturnValue(outParameters);
		}
	}

	public GenericDaoException(Throwable cause, String message, String sql, Map<String, Object> inParameters,
			Map<String, Object> outParameters) {
		this(cause, message, sql, inParameters);
		if (outParameters != null) {
			addReturnValue(outParameters);
		}
	}

	public List<DatabaseValidationMessage> getMessages() {
		return messages;
	}

	public String outputMessages() {
		StringBuilder sb = new StringBuilder();
		for (DatabaseValidationMessage message : messages) {
			sb.append(String.format("Identifier: %s, Type: %s, Message: %s%n", message.getMessageIdentifier(),
					message.getType(), message.getMessage()));
		}
		return sb.toString();
	}

	public boolean hasMessage(String messageIdentifier) {
		for (DatabaseValidationMessage message : messages) {
			if (messageIdentifier.equals(message.getMessageIdentifier())) {
				return true;
			}
		}

		return false;
	}

	@Override public String toString() {
		return outputDetail();
	}

	private String outputDetail() {
		StringBuilder sb = new StringBuilder();
		sb.append("GenericDaoException Detailed Output: START\n");
		sb.append(getMessage() + "\n");
		if (sql != null) {
			sb.append(String.format("Invoked SQL: [%s]%n", sql));
		}
		sb.append("\nInput Parameters:\n");
		for (Map.Entry<String, String> entry : parameters.entrySet()) {
			sb.append(String.format("\tParameter Name: [%s], Parameter Value: [%s]%n", entry.getKey(), entry.getValue()));
		}
		sb.append("\nReturn Values :\n");
		for (Map.Entry<String, String> entry : returnValues.entrySet()) {
			sb.append(String.format("\tReturn Value Key: [%s], Return Value: [%s]%n", entry.getKey(), entry.getValue()));
		}
		sb.append("\nMessages:\n");
		sb.append(outputMessages());
		sb.append("GenericDaoException Detailed Output: END\n");
		return sb.toString();
	}

	private void addParameter(Map<String, Object> inParameters) {
		for (Map.Entry<String, Object> entry : inParameters.entrySet()) {
			addParameter(entry.getKey(), entry.getValue());
		}
	}

	private void addParameter(String key, Object value) {
		parameters.put(key, coerceToString(value));
	}

	private void addReturnValue(Map<String, Object> outParameters) {
		for (Map.Entry<String, Object> entry : outParameters.entrySet()) {
			addReturnValue(entry.getKey(), entry.getValue());
		}
	}

	private void addReturnValue(String key, Object value) {
		returnValues.put(key, coerceToString(value));
	}

	private String coerceToString(Object value) {
		if (value == null)
			return null;
		if (value instanceof String)
			return (String) value;
		if (value instanceof STRUCT) {
			try {
				return (((STRUCT) value).dump());
			} catch (SQLException ex) {
				// Can't throw an exception
				return value.toString();
			}
		}
		if (value instanceof ARRAY) {
			try {
				return ((ARRAY) value).dump();
			} catch (SQLException ex) {
				// Can't throw an exception
				return value.toString();
			}
		}

		return value.toString();
	}
}
