package au.gov.vic.sro.duties.transfer.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Lodgement implements Serializable {

	private static final long serialVersionUID = 3238120455418935096L;

	private String id;
	private String status;
	private String lodgementCategoryCode;

	private String elnoLodgementCaseId;
	private String elnoId;
	private String caseReference;

	private List<Transaction> transactions = new ArrayList<>();

	private Date intendedSettlementDate;

	private List<Message> messages = new ArrayList<>();

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getLodgementCategoryCode() {
		return lodgementCategoryCode;
	}

	public void setLodgementCategoryCode(String lodgementCategoryCode) {
		this.lodgementCategoryCode = lodgementCategoryCode;
	}

	public String getElnoLodgementCaseId() {
		return elnoLodgementCaseId;
	}

	public void setElnoLodgementCaseId(String elnoLodgementCaseId) {
		this.elnoLodgementCaseId = elnoLodgementCaseId;
	}

	public String getCaseReference() {
		return caseReference;
	}

	public void setCaseReference(String caseReference) {
		this.caseReference = caseReference;
	}

	public String getElnoId() {
		return elnoId;
	}

	public void setElnoId(String elnoId) {
		this.elnoId = elnoId;
	}

	public List<Transaction> getTransactions() {
		return transactions;
	}

	public void setTransactions(List<Transaction> transactions) {
		this.transactions = transactions;
	}

	public Date getIntendedSettlementDate() {
		return intendedSettlementDate;
	}

	public void setIntendedSettlementDate(Date intendedSettlementDate) {
		this.intendedSettlementDate = intendedSettlementDate;
	}

	public List<Message> getMessages() {
		return messages;
	}

	public void setMessages(List<Message> messages) {
		this.messages = messages;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((caseReference == null) ? 0 : caseReference.hashCode());
		result = prime * result + ((elnoId == null) ? 0 : elnoId.hashCode());
		result = prime * result + ((elnoLodgementCaseId == null) ? 0 : elnoLodgementCaseId.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((intendedSettlementDate == null) ? 0 : intendedSettlementDate.hashCode());
		result = prime * result + ((lodgementCategoryCode == null) ? 0 : lodgementCategoryCode.hashCode());
		result = prime * result + ((messages == null) ? 0 : messages.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		result = prime * result + ((transactions == null) ? 0 : transactions.hashCode());
		return result;
	}

	@Override
	public String toString() {
		return "Lodgement [id=" + id + ", status=" + status + ", lodgementCategoryCode=" + lodgementCategoryCode
				+ ", elnoLodgementCaseId=" + elnoLodgementCaseId + ", elnoId=" + elnoId + ", caseReference="
				+ caseReference + ", transactions=" + transactions + ", intendedSettlementDate="
				+ intendedSettlementDate + "]";
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		Lodgement other = (Lodgement) obj;
		if (caseReference == null) {
			if (other.caseReference != null) return false;
		} else if (!caseReference.equals(other.caseReference)) return false;
		if (elnoId == null) {
			if (other.elnoId != null) return false;
		} else if (!elnoId.equals(other.elnoId)) return false;
		if (elnoLodgementCaseId == null) {
			if (other.elnoLodgementCaseId != null) return false;
		} else if (!elnoLodgementCaseId.equals(other.elnoLodgementCaseId)) return false;
		if (id == null) {
			if (other.id != null) return false;
		} else if (!id.equals(other.id)) return false;
		if (intendedSettlementDate == null) {
			if (other.intendedSettlementDate != null) return false;
		} else if (!intendedSettlementDate.equals(other.intendedSettlementDate)) return false;
		if (lodgementCategoryCode == null) {
			if (other.lodgementCategoryCode != null) return false;
		} else if (!lodgementCategoryCode.equals(other.lodgementCategoryCode)) return false;
		if (messages == null) {
			if (other.messages != null) return false;
		} else if (!messages.equals(other.messages)) return false;
		if (status == null) {
			if (other.status != null) return false;
		} else if (!status.equals(other.status)) return false;
		if (transactions == null) {
			if (other.transactions != null) return false;
		} else if (!transactions.equals(other.transactions)) return false;
		return true;
	}

}
