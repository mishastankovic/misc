package au.gov.vic.sro.duties.transfer.service.security;

import au.gov.vic.sro.duties.transfer.constant.Constants;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.provider.authentication.OAuth2AuthenticationDetails;
import org.springframework.stereotype.Service;

import javax.servlet.http.Cookie;

@Service
public class UserSecurityDetailsService {

    @Value("${authServer.securityDomain}")
    //@Value("${dutiesForm.server.url:https://localtest.e-business.sro.vic.gov.au}")
    private String securityDomain;

    public UserSecurity getUserSecurity() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        OAuth2AuthenticationDetails authDetails = (OAuth2AuthenticationDetails) authentication.getDetails();
        Cookie authCookie = createCookie(securityDomain, Constants.ACCESS_TOKEN, authDetails.getTokenValue());
        return new UserSecurity(authentication.getName(), authCookie);
    }

    private Cookie createCookie(String securityDomain, String name, String value) {
        Cookie cookie = new Cookie(name, value);
        cookie.setHttpOnly(true);
        cookie.setSecure(true);
        cookie.setDomain(securityDomain);
        cookie.setMaxAge(60 * 60);
        cookie.setPath("/");
        return cookie;
    }
}
