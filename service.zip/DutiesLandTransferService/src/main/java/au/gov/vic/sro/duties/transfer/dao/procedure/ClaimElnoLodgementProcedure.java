package au.gov.vic.sro.duties.transfer.dao.procedure;

import java.sql.SQLException;
import java.sql.Struct;
import java.sql.Types;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.support.SQLExceptionTranslator;

import au.gov.vic.sro.duties.dao.mapper.lodgement.LodgementMapper;
import au.gov.vic.sro.duties.dao.support.StoredProcedure;
import au.gov.vic.sro.duties.lodgement.Lodgement;
import oracle.jdbc.OracleTypes;
import oracle.sql.STRUCT;
import oracle.xdb.XMLType;

public class ClaimElnoLodgementProcedure extends StoredProcedure {

	private static final String STORED_PROC_NAME = "do_capture_pkg.claim_elno_lodgement_f";

	public ClaimElnoLodgementProcedure(JdbcTemplate jdbcTemplate, SQLExceptionTranslator sqlExceptionTranslator) {
		super(jdbcTemplate, STORED_PROC_NAME, sqlExceptionTranslator);
		setFunction(true);

		// Record type must be in upper case
		// Note for parameters: return value must be declared first, then method params in order
		declareParameter(new SqlOutParameter(LVT_LODGEMENT_REC, Types.STRUCT, DO_LODGEMENT_REC));
		declareParameter(new SqlParameter(PTI_CUSTOMER_ID, Types.VARCHAR));
		declareParameter(new SqlParameter(PTI_LODGEMENT_REC, Types.STRUCT, DO_LODGEMENT_REC));
		declareParameter(new SqlParameter(PTI_ORIGINAL_XML, OracleTypes.OPAQUE, XMLTYPE));
		declareParameter(new SqlOutParameter(PTO_MESSAGE_TAB, Types.ARRAY, DO_MESSAGE_TAB));

		compile();
	}

	public Lodgement claim(String customerId, Lodgement lodgement, String xml) {
		Map<String, Object> inParams = new LinkedHashMap<>();
		inParams.put(PTI_CUSTOMER_ID, customerId);
		inParams.put(PTI_LODGEMENT_REC, oracleStructuresFromLodgement(lodgement));
		inParams.put(PTI_ORIGINAL_XML, getXMLType(xml));

		Map<?, ?> outParams = defaultExecuteHandler(inParams, PTO_MESSAGE_TAB, LVT_LODGEMENT_REC);

		try {
			return lodgementFromOracleStructures((STRUCT) outParams.get(LVT_LODGEMENT_REC));
		} catch (Exception e) {
			throw createGenericDaoException(e, "Exception occurred during mapping", inParams, outParams);
		}
	}

	protected STRUCT oracleStructuresFromLodgement(Lodgement lodgement) {
		LodgementMapper lodgementMapper = new LodgementMapper();
		return (STRUCT) lodgementMapper.createLodgementStructToDoLodgementRec(lodgement, getOracleConnection());
	}

	protected Lodgement lodgementFromOracleStructures(Struct doLodgementRec) throws SQLException {
		LodgementMapper lodgementMapper = new LodgementMapper();
		Object[] structAsArray = doLodgementRec.getAttributes();
		return lodgementMapper.mapLodgement(structAsArray);
	}
}
