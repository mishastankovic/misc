package au.gov.vic.sro.duties.transfer.service;

import java.util.List;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;

import au.gov.vic.sro.duties.dao.exception.FormMismatchException;
import au.gov.vic.sro.duties.form.model.DutiesForm;
import au.gov.vic.sro.duties.transaction.landtransfer.Discrepancy;
import au.gov.vic.sro.duties.transaction.landtransfer.LandTransferDutyTransaction;
import au.gov.vic.sro.duties.transfer.comparator.TransactionToDutiesFormComparator;
import au.gov.vic.sro.duties.transfer.dao.TransactionDao;
import au.gov.vic.sro.duties.transfer.mapper.DutiesFormMapper;
import au.gov.vic.sro.duties.transfer.mapper.Mapper;
import au.gov.vic.sro.duties.transfer.model.Error;
import au.gov.vic.sro.duties.transfer.model.FormLink;
import au.gov.vic.sro.duties.transfer.model.MatchResult;
import au.gov.vic.sro.duties.transfer.service.security.UserSecurity;
import au.gov.vic.sro.duties.transfer.service.security.UserSecurityDetailsService;

@Service
@Transactional(propagation = Propagation.REQUIRED)
public class DutiesFormService {

	private static final String GET_FORM_URL = "/dutiesformrest/forms/form/";
	private static final String LINK_FORM_URL = "/link";
	private static final String UNLINK_FORM_URL = "/unlink";

	private static final Logger log = LoggerFactory.getLogger(DutiesFormService.class);

	@Autowired
	private UserSecurityDetailsService userSecurityDetailsService;

	@Autowired
	private DutiesFormMapper dutiesFormMapper;

	@Autowired
	private Mapper mapper;

	@Autowired
	private TransactionToDutiesFormComparator comparator;

	@Autowired
	private TransactionDao transactionDao;

	@Value("${dutiesForm.server.url}")
	private String dutiesFormUrl;

	@Value("${dutiesForm.server.ignoreSslErrors:false}")
	private String ignoreSSLErrors;

	private RestTemplate restTemplate = new RestTemplate();

	@PostConstruct
	public void init() {
		if (ignoreSSLErrors.equalsIgnoreCase("true")) {
			SSLCertitificateConfiguration.trustAllSSL();
		}
	}

	public DutiesForm getForm(Long formId) {
		final HttpEntity<Object> entity = createHttpEntity(null);
		String url = this.dutiesFormUrl + GET_FORM_URL + formId;

		// Execute the method writing your HttpEntity to the request
		ResponseEntity<DutiesForm> dutiesFormResponse =
				restTemplate.exchange(url, HttpMethod.GET, entity, DutiesForm.class);
		return dutiesFormResponse.getBody();
	}

	private HttpEntity<Object> createHttpEntity(Object body) {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		UserSecurity userSecurity = userSecurityDetailsService.getUserSecurity();
		headers.add("Cookie",
				userSecurity.getAccessTokenCookie().getName() + "=" + userSecurity.getAccessTokenCookie().getValue());
		// Create a new HttpEntity
		return new HttpEntity<>(body, headers);
	}

	public void link(Long formId, FormLink formLink) {

		List<Error> warnings = formLink.getAcknowledgedWarnings();
		final HttpEntity<Object> entity = createHttpEntity(formLink);
		String url = this.dutiesFormUrl + GET_FORM_URL + formId + LINK_FORM_URL;
		DutiesForm dutiesForm = getForm(formId);

		Long transactionId = formLink.getTransactionId();
		LandTransferDutyTransaction transaction = transactionDao.get(formLink.getTransactionId());
		Long linkedFormId = transaction.getDutiesFormId();
		if (linkedFormId != null && !formId.equals(linkedFormId)) {
			throw new IllegalStateException(
					String.format("Unable to link transaction %s to form %s as it is already linked to form %s",
							transactionId, formId, linkedFormId));
		}

		MatchResult matchResult = comparator.compareTransactionToDutiesForm(dutiesForm, mapper.fromESys(transaction));
		boolean hasNewWarnings = hasNewWarningMessages(matchResult, warnings);

		if (!CollectionUtils.isEmpty(matchResult.getErrors())
				|| ((!CollectionUtils.isEmpty(matchResult.getWarnings()) || !CollectionUtils.isEmpty(warnings))
						&& hasNewWarnings)) {
			throw new FormMismatchException(matchResult);
		}

		// update the form
		ResponseEntity<DutiesForm> dutiesFormResponse =
				restTemplate.exchange(url, HttpMethod.PUT, entity, DutiesForm.class);
		// update esys now
		Long formVersion = dutiesFormResponse.getBody().getVersion().longValue();
		Long linkedFormVersion = transaction.getDutiesFormVersion();
		// form version will be
		if (!formVersion.equals(linkedFormVersion)) {
			dutiesFormMapper.map(transaction, dutiesForm);
			if (!CollectionUtils.isEmpty(warnings)) {
				transaction.setDiscrepancyList(
						warnings.stream().map(w -> new Discrepancy(w.getErrorMsg())).collect(Collectors.toList()));
				transaction.setDiscrepancyAcceptedBy(userSecurityDetailsService.getUserSecurity().getUsername());
			}
			transaction.setDutiesFormId(formId);
			transaction.setDutiesFormVersion(formVersion);
			transactionDao.update(transaction);
			if (linkedFormVersion != null) {
				log.warn(String.format("Transaction %s updated with form %s from version %s to version %s,",
						transactionId, formId, linkedFormVersion, formVersion));
			}
		}
		// return mapper.fromESys(transaction); // Should return updated transaction
	}

	private boolean hasNewWarningMessages(MatchResult result, List<Error> warnings) {
		List<Object> newWarnings =
				(result.getWarnings().stream().map(Error::getErrorCode).collect(Collectors.toList()));
		List<Object> uiWarnings = //warnings == null ? new ArrayList<Object>() :
				(warnings.stream().map(Error::getErrorCode).collect(Collectors.toList()));
		List<Object> distinctWarnings =
				newWarnings.stream().filter(w -> !uiWarnings.contains(w)).collect(Collectors.toList());

		return !CollectionUtils.isEmpty(distinctWarnings);
	}

	public void unlink(Long formId, FormLink formLink) {

		// Note. Best inconsistent state is when form is linked even when eSys transaction is not linked.
		// Hence, should always make sure form is never unlinked unless eSys transaction has been unlinked.

		Long transactionId = formLink.getTransactionId();
		LandTransferDutyTransaction transaction = transactionDao.get(transactionId);

		Long linkedFormId = transaction.getDutiesFormId();
		if (linkedFormId == null) {
			throw new IllegalStateException(
					String.format("Unable to unlink transaction %s from form %s as the transaction is not linked.",
							transactionId, formId, linkedFormId));
		}
		if (!formId.equals(linkedFormId)) {
			throw new IllegalStateException(String.format(
					"Unable to unlink transaction %s from form %s as it is linked to form %s instead",
					transactionId, formId, linkedFormId));
		}

		Long linkedFormVersion = transaction.getDutiesFormVersion();
		if (linkedFormVersion != null) {
			transaction.setDutiesFormId(null);
			transaction.setDutiesFormVersion(null);
			// TODO Stage 2 iteration 3 need to reset to ELNO data
			transactionDao.update(transaction);
		}

		final HttpEntity<Object> entity = createHttpEntity(formLink);
		String url = this.dutiesFormUrl + GET_FORM_URL + formId + UNLINK_FORM_URL;

		// Execute the method writing your HttpEntity to the request
		restTemplate.exchange(url, HttpMethod.PUT, entity, String.class);

		// return mapper.fromESys(transaction); // Should return updated transaction.
	}
}
