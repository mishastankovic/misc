package au.gov.vic.sro.duties.transfer.dao.procedure;

import java.sql.Types;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.support.SQLExceptionTranslator;

import au.gov.vic.sro.duties.dao.mapper.refdata.ReferenceDataRecMapper;
import au.gov.vic.sro.duties.dao.support.StoredProcedure;
import au.gov.vic.sro.duties.lodgement.LodgementCategory;
import au.gov.vic.sro.duties.transfer.model.AssessingType;
import oracle.sql.ARRAY;

public class QueryRefDataProcedure extends StoredProcedure {

	private static final String STORED_PROC_NAME = ESYS_COMMON_PKG + ".QUERY_REF_DATA_F";

	private static final String LVT_REF_DATA_TAB = "lvt_rd_Tab";
	private static final String PCI_TABLE_NAME = "pci_table_name";
	private static final String PCI_DOMAIN = "pci_domain";
	private static final String PCI_FILTER = "pci_filter";
	private static final String REF_DATA_TAB = "REF_DATA_TAB";

	private static final String ELNO_LODGEMENT_CATEGORY = "DOL ELNO LODGEMENT CATEGORY";
//	private static final String MANUAL_ELNO_LODGEMENT_CATEGORY = "MANUAL";
//	private static final String SYSTEM_ELNO_LODGEMENT_CATEGORY = "SYSTEM";

	public QueryRefDataProcedure(JdbcTemplate jdbcTemplate, SQLExceptionTranslator sqlExceptionTranslator) {
		super(jdbcTemplate, STORED_PROC_NAME, sqlExceptionTranslator);
		setFunction(true);

		declareParameter(new SqlOutParameter(LVT_REF_DATA_TAB, Types.ARRAY, REF_DATA_TAB));
		declareParameter(new SqlParameter(PCI_TABLE_NAME, Types.VARCHAR));
		declareParameter(new SqlParameter(PCI_DOMAIN, Types.VARCHAR));
		declareParameter(new SqlParameter(PCI_FILTER, Types.VARCHAR));

		compile();
	}

	public List<LodgementCategory> getAllElnoLodgementCategoryList() {
		return getElnoLodgementCategoryList(null);
	}

	public List<LodgementCategory> getElnoLodgementCategoryList(AssessingType assessingType) {
		Map<String, Object> inParams = new LinkedHashMap<>();
		inParams.put(PCI_TABLE_NAME, ELNO_LODGEMENT_CATEGORY);
		inParams.put(PCI_DOMAIN, "");
		inParams.put(PCI_FILTER, assessingType);

		Map<?, ?> outParams = defaultExecuteHandler(inParams, REF_DATA_TAB);

		try {
			return new ReferenceDataRecMapper().mapRefDataToLodgmentCategory((ARRAY) outParams.get(LVT_REF_DATA_TAB));
		} catch (Exception ex) {
			throw createGenericDaoException(ex,
					"Exception occurred during mapping", inParams, outParams);
		}
	}
}
