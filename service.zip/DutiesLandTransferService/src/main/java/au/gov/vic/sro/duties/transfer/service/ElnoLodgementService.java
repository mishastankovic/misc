package au.gov.vic.sro.duties.transfer.service;

import java.util.Date;

import au.gov.vic.sro.duties.transfer.model.ElnoLodgementCase;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import au.gov.vic.sro.duties.transfer.dao.ElnoLodgementDao;
import au.gov.vic.sro.duties.transfer.model.Lodgement;

@Service
@Transactional(propagation = Propagation.REQUIRED)
public class ElnoLodgementService {

	@Autowired
	private ElnoLodgementDao elnoLodgementDao;

	@Transactional
	public Lodgement submitElnoLodgement(String elnoLodgementReference, Date intendedSettlementDate,
			String originalXml) {
		return elnoLodgementDao.submit(elnoLodgementReference, intendedSettlementDate, originalXml);
	}

	public Lodgement updateLodgement(ElnoLodgementCase elnoLodgement) {
		//return elnoLodgementDao.update(elnoLodgement);
		return null;
	}
}
