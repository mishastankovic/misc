package au.gov.vic.sro.duties.transfer.mapper;

import static au.gov.vic.sro.duties.form.model.property.LandIdentifierType.BOOK_MEMORIAL;
import static au.gov.vic.sro.duties.form.model.property.LandIdentifierType.CROWN_ALLOTMENT;
import static au.gov.vic.sro.duties.form.model.property.LandIdentifierType.LOT_PLAN;
import static au.gov.vic.sro.duties.form.model.property.LandIdentifierType.VOLUME_FOLIO;
import static au.gov.vic.sro.duties.transaction.landtransfer.LandIdentifierType.BookAndMemorialNumber;
import static au.gov.vic.sro.duties.transaction.landtransfer.LandIdentifierType.CrownAllotment;
import static au.gov.vic.sro.duties.transaction.landtransfer.LandIdentifierType.LotAndPlanNumber;
import static au.gov.vic.sro.duties.transaction.landtransfer.LandIdentifierType.VolumeAndFolio;

import java.math.BigDecimal;
import java.util.List;
import java.util.function.Function;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import au.gov.vic.sro.duties.form.model.DutiesForm;
import au.gov.vic.sro.duties.form.model.DutiesFormData;
import au.gov.vic.sro.duties.form.model.address.Address;
import au.gov.vic.sro.duties.form.model.address.CountryType;
import au.gov.vic.sro.duties.form.model.party.AbstractTransferParty;
import au.gov.vic.sro.duties.form.model.party.ForeignNationalDetails;
import au.gov.vic.sro.duties.form.model.party.ForeignOrganisation;
import au.gov.vic.sro.duties.form.model.party.NaturalPerson;
import au.gov.vic.sro.duties.form.model.party.Organisation;
import au.gov.vic.sro.duties.form.model.party.OwnershipShare;
import au.gov.vic.sro.duties.form.model.party.PartyType;
import au.gov.vic.sro.duties.form.model.party.PersonName;
import au.gov.vic.sro.duties.form.model.party.Transferee;
import au.gov.vic.sro.duties.form.model.party.TransfereeSection;
import au.gov.vic.sro.duties.form.model.party.Transferor;
import au.gov.vic.sro.duties.form.model.party.TransferorSection;
import au.gov.vic.sro.duties.form.model.property.LandIdentifier;
import au.gov.vic.sro.duties.form.model.property.LandIdentifierType;
import au.gov.vic.sro.duties.form.model.property.Property;
import au.gov.vic.sro.duties.form.model.property.PropertySection;
import au.gov.vic.sro.duties.form.model.transaction.ConsiderationAndValue;
import au.gov.vic.sro.duties.form.model.transaction.Gst;
import au.gov.vic.sro.duties.form.model.transaction.RelatedParty;
import au.gov.vic.sro.duties.form.model.transaction.Transaction;
import au.gov.vic.sro.duties.form.model.transaction.TransferDetails;
import au.gov.vic.sro.duties.transaction.AddressOther;
import au.gov.vic.sro.duties.transaction.Fraction;
import au.gov.vic.sro.duties.transaction.landtransfer.AbstractLandTransferDutyTransaction;
import au.gov.vic.sro.duties.transaction.landtransfer.AbstractTransferee;
import au.gov.vic.sro.duties.transaction.landtransfer.LegalEntity;
import au.gov.vic.sro.duties.transaction.landtransfer.LegalEntityType;
import au.gov.vic.sro.duties.transaction.landtransfer.PropertyType;
import au.gov.vic.sro.duties.transaction.landtransfer.TransferProperty;

/**
 * Adaptation from au.gov.vic.sro.duties.service.form.DutiesFormMapper from DutiesOnline
 * @author YXL0
 *
 */
@Service
public class DutiesFormMapper {

	private static final Logger log = LoggerFactory.getLogger(DutiesFormMapper.class);

	private static final BigDecimal MAX_MARKET_VALUE = new BigDecimal(9999999999l);
	private static final BigDecimal MAX_CONSIDERATION = new BigDecimal(99999999999999l);

	private static final long MAX_SHARE_NUMERATOR = 99999999L;
	private static final long MAX_SHARE_DENOMINATOR = 99999999L;

	public AbstractLandTransferDutyTransaction map(AbstractLandTransferDutyTransaction transaction, DutiesForm dutiesForm) {
		if (dutiesForm == null || dutiesForm.getDutiesFormData() == null) {
			log.error("Duties Form is null or empty");
			return transaction;
		}

		if (transaction == null) {
			log.error("Transaction is");
			return transaction;
		}

		transaction.setDutiesFormId(dutiesForm.getDutiesFormId());
		transaction.setDutiesFormVersion(toLong(dutiesForm.getVersion()));

		DutiesFormData dutiesFormData = dutiesForm.getDutiesFormData();
		mapTransactionDetails(transaction, dutiesFormData.getTransaction());
		mapProperties(transaction, dutiesFormData.getPropertySection());
		mapTransferees(transaction.getTransferees(), dutiesFormData.getTransfereeSection());
		mapTransferors(transaction.getTransferors(), dutiesFormData.getTransferorSection());
		// TODO Yuke to test.
//		complexLandTransfer.setCreationDate(DateUtil.getCurrentDate());
//		// landTransferDutyTransaction.setCreatedBy(createdBy);(transferDetails.get);
//		// landTransferDutyTransaction.setCreatedById(createdById);(transferDetails.get);

		// TODO How do we map supporting documents?
//		formspace.setSupportingDocuments(mapSupportingDocuments(getFormResponse.getDutiesFormDocuments()));

		return transaction;
	}

	private void mapProperties(AbstractLandTransferDutyTransaction transaction, PropertySection propertySection) {
		if (propertySection == null) {
			return;
		}

		List<Property> propertyList = propertySection.getPropertyList();
		List<TransferProperty> eSysPropertyList = transaction.getProperties();
		eSysPropertyList.clear();	// Remove all ELNO properties

		if (propertyList != null) {
			for (Property property : propertyList) {
				eSysPropertyList.add(mapProperty(property));
			}
		}

		transaction.setTotalInterestPassingPercentage(propertySection.getPercentInterestTransferred());
	}

	private TransferProperty mapProperty(Property property) {
		Function<LandIdentifier, au.gov.vic.sro.duties.transaction.landtransfer.LandIdentifier> mapFunction;
		TransferProperty eSysProperty = new TransferProperty();
		eSysProperty.setPropertyAddress(mapAddress(property.getPropertyAddress()));
		eSysProperty.setPropertyType(map(property.getPropertyType()));

		List<LandIdentifier> landIdentifierList = property.getLandIdentifierList();
		if (landIdentifierList != null && !landIdentifierList.isEmpty()) {
			// Note. There must be at least a volume folio land identifier
			// TODO: Yuke: Do I still need this code for stage 3?
//			if (VOLUME_FOLIO == landIdentifierList.get(0).getLandIdentifierType()) {
				eSysProperty.setLandIdentifierType(VolumeAndFolio);
				mapFunction = (LandIdentifier l) -> new au.gov.vic.sro.duties.transaction.landtransfer.LandIdentifier(
						l.getVolume(), l.getFolio());
				map(eSysProperty, landIdentifierList, VOLUME_FOLIO, mapFunction);
//			} else if (LOT_PLAN == landIdentifierList.get(0).getLandIdentifierType()) {
//				eSysProperty.setLandIdentifierType(LotAndPlanNumber);
//				mapFunction = (LandIdentifier l) -> new au.gov.vic.sro.duties.transaction.landtransfer.LandIdentifier(
//						l.getLot(), l.getPlan());
//				map(eSysProperty, landIdentifierList, LOT_PLAN, mapFunction);
//			} else if (isComplex) {
//				if (BOOK_MEMORIAL == landIdentifierList.get(0).getLandIdentifierType()) {
//					eSysProperty.setLandIdentifierType(BookAndMemorialNumber);
//					mapFunction = (LandIdentifier l) -> new au.gov.vic.sro.duties.transaction.landtransfer.LandIdentifier(
//							l.getBookNumber(), l.getMemorial());
//					map(eSysProperty, landIdentifierList, BOOK_MEMORIAL, mapFunction);
//				} else if (CROWN_ALLOTMENT == landIdentifierList.get(0).getLandIdentifierType()) {
//					eSysProperty.setLandIdentifierType(CrownAllotment);
//					mapFunction = (LandIdentifier l) -> new au.gov.vic.sro.duties.transaction.landtransfer.LandIdentifier(
//							l.getCrownAllotment(), l.getVolume(), l.getFolio(), eSysProperty.landIdentifierType);
//					map(eSysProperty, landIdentifierList, CROWN_ALLOTMENT, mapFunction);
//				}
//			}
		}

		return eSysProperty;
	}

	private void map(TransferProperty eSysProperty, List<LandIdentifier> landIdentifierList,
			LandIdentifierType landIdentifierType,
			Function<LandIdentifier, au.gov.vic.sro.duties.transaction.landtransfer.LandIdentifier> mapFunction) {
		for (LandIdentifier landIdentifier : landIdentifierList) {
			if (landIdentifierType == landIdentifier.getLandIdentifierType()) {
				eSysProperty.getLandIdentifiers().add(mapFunction.apply(landIdentifier));
			}
		}
	}

	private PropertyType map(au.gov.vic.sro.duties.form.model.property.PropertyType dfPropertyType) {
		if (dfPropertyType == null) {
			return null;
		}

		for (PropertyType propertyType : PropertyType.getList()) {
			if (propertyType.getOracleCode().equals(dfPropertyType.getCode())) {
				return propertyType;
			}
		}

		return null;
	}

	public AddressOther mapAddress(Address address) {
		if (address == null) {
			return null;
		}
		AddressOther landTransferDutyTxnAddress = new AddressOther();
		// TODO Stage 2 Iteration 5 / Stage 3A - Map structure address
		String addressAsString = address.getFormattedAddress();
		landTransferDutyTxnAddress.setAddress(addressAsString);
		return landTransferDutyTxnAddress;
	}

	private <T extends AbstractTransferee> void mapTransferees(List<T> eSysTransfereeList, TransfereeSection transfereeSection) {
		if (transfereeSection == null) {
			return;
		}
		List<Transferee> transfereeList = transfereeSection.getTransfereeList();
		if (transfereeList != null) {
			for (Transferee transferee : transfereeList) {
				AbstractTransferee eSysTransferee = getMatchingParty(eSysTransfereeList, transferee);
				if (eSysTransferee != null) {
					mapTransferee(eSysTransferee, transferee);
					eSysTransferee.calculateInterestAcquiring();
				} else {
					log.error("Unable to find matching transferee {}", transferee.getPartyId());
				}
			}
		}
	}

	private <T extends AbstractTransferee> void mapTransferee(T eSysTransferee, AbstractTransferParty party) {
		if (party == null) {
			return;
		}
		mapLegalEntity(eSysTransferee, party, true);
		eSysTransferee.setInterestOnTitle(getFraction(party.getInterestHolding()));
		eSysTransferee.setAcquiringAsTrusteeOfTrust(party.getBehalfOfTrust());
		mapForeignFields(eSysTransferee, party);
	}

	private void mapTransferors(List<au.gov.vic.sro.duties.transaction.landtransfer.Transferor> eSysTransferorList,
			TransferorSection transferorSection) {
		if (transferorSection == null) {
			return;
		}
		List<Transferor> transferorList = transferorSection.getTransferorList();
		if (transferorList != null) {
			for (Transferor transferor : transferorList) {
				au.gov.vic.sro.duties.transaction.landtransfer.Transferor eSysTransferor = getMatchingParty(eSysTransferorList, transferor);
				if (eSysTransferor == null) {
					log.error("Unable to find matching transferor {}", transferor.getPartyId());
				} else {
					mapTransferor(eSysTransferor, transferor);
				}
			}
		}
	}

	private void mapTransferor(au.gov.vic.sro.duties.transaction.landtransfer.Transferor eSysTransferor, Transferor transferor) {
		if (transferor == null) {
			return;
		}
		mapLegalEntity(eSysTransferor, transferor, true);
		if (transferor.getInterestHolding() != null) {
			eSysTransferor.setInterestOnTitle(getFraction(transferor.getInterestHolding()));
			eSysTransferor.setInterestOnTitleAsPercentage(transferor.getInterestHolding().getSharePercentage());
		}
		eSysTransferor.setRemainingOnTitle(transferor.getRemainingOnTitle());
		mapForeignFields(eSysTransferor, transferor);
	}

	private <T extends LegalEntity> T getMatchingParty(List<T> eSysPartyList, AbstractTransferParty party) {
		for (T eSysParty : eSysPartyList) {
			PartyType partyType = party.getPartyType();
			if (partyType.getCode().equals(eSysParty.getLegalEntityType().getOracleCode())) { 
				switch (partyType) {
				case INDIVIDUAL_NATURAL_PERSON:
				case INDIVIDUAL_OTHER:
					NaturalPerson naturalPerson = party.getNaturalPerson();
					PersonName personName = naturalPerson.getPersonName();
					au.gov.vic.sro.duties.transaction.PersonName eSysPersonName = eSysParty.getIndividualName();
					if (naturalPerson.getDateOfBirth().getTime() == eSysParty.getDateOfBirth().getTime() && 
							equalsIgnoreCaseAndSpace(personName.getFirstName(), eSysPersonName.getFirstName()) && 
							equalsIgnoreCaseAndSpace(personName.getSurname(), eSysPersonName.getSurname())) {
						return eSysParty;
					}
					break;
				case ASSOCIATION:
				case COMPANY:
				case ORGANISATION:
					Organisation organisation = party.getOrganisation();
					if (equalsIgnoreCaseAndSpace(organisation.getOrganisationName(), eSysParty.getCompanyName())) {
						return eSysParty;
					}
					break;
				default:
				}
			}
		}
		return null;
	}

	private <T extends LegalEntity> void mapLegalEntity(T eSysParty, AbstractTransferParty party, boolean mapAddress) {
		if (party == null) {
			return;
		}

		eSysParty.setPartyId(party.getPartyId().toString());	// Note. Party ID should not be null by this stage.
		LegalEntityType legalEntityType = getLegalEntityType(party.getPartyType());
		eSysParty.setLegalEntityType(legalEntityType);
		if (LegalEntityType.IndividualNaturalPerson.equals(legalEntityType)
				|| LegalEntityType.IndividualOther.equals(legalEntityType)) {
			NaturalPerson naturalPerson = party.getNaturalPerson();
			if (naturalPerson != null) {
				PersonName personName = naturalPerson.getPersonName();
				if (personName != null) {
					eSysParty.getIndividualName().setFirstName(personName.getFirstName());
					eSysParty.getIndividualName().setMiddleName(personName.getMiddleName());
					eSysParty.getIndividualName().setSurname(personName.getSurname());
				}
				eSysParty.setDateOfBirth(naturalPerson.getDateOfBirth());
				eSysParty.setABN(naturalPerson.getAbn());
			}
		} else {
			Organisation organisation = party.getOrganisation();
			if (organisation != null) {
				eSysParty.setCompanyName(organisation.getOrganisationName());
				if (LegalEntityType.Company.equals(legalEntityType)) {
					// Note. ACN validation (length == 9) should have been done by Duties Form
					eSysParty.setACN(organisation.getAcnArbnAbn());
				}
				// Note. ABN validation (length == 11) should have been done by Duties Form
				eSysParty.setABN(organisation.getAcnArbnAbn());
			}
		}
		if (mapAddress) {
			eSysParty.setAddressCurrent(mapAddress(party.getCurrentAddress()));
			if (Boolean.TRUE.equals(party.getSameAddress())) {
				eSysParty.setAddressOther(mapAddress(party.getCurrentAddress()));
			} else {
				eSysParty.setAddressOther(mapAddress(party.getPartyAddress()));
			}
		}
	}

	private LegalEntityType getLegalEntityType(PartyType partyType) {
		if (partyType == null) {
			return null;
		}

		for (LegalEntityType legalEntityType : LegalEntityType.values()) {
			if (legalEntityType.getOracleCode().equals(partyType.getCode())) {
				return legalEntityType;
			}
		}

		return null;
	}

	private <T extends LegalEntity> void mapForeignFields(T eSysParty, AbstractTransferParty party) {
		switch (party.getPartyType()) {
		case INDIVIDUAL_NATURAL_PERSON:
		case INDIVIDUAL_OTHER:
			mapForeignFields(eSysParty, party.getNaturalPerson());
			break;
		case ASSOCIATION:
		case COMPANY:
		case ORGANISATION:
			mapForeignFields(eSysParty, party.getOrganisation());
			break;
		default:
		}

		if (eSysParty instanceof AbstractTransferee) {
			AbstractTransferee transferee = (AbstractTransferee) eSysParty;
			transferee.setAcquiringAsTrusteeOfTrust(party.getBehalfOfTrust());
		}
	}

	private <T extends LegalEntity> void mapForeignFields(T eSysParty, NaturalPerson naturalPerson) {
		if (naturalPerson == null) {
			return;
		}

		if (eSysParty instanceof AbstractTransferee) {
			AbstractTransferee transferee = (AbstractTransferee) eSysParty;
			transferee.setForeignPurchaser(naturalPerson.getForeignNaturalPerson());
		}

		if (Boolean.TRUE.equals(naturalPerson.getForeignNaturalPerson())) {
			ForeignNationalDetails foreignNationalDetails = naturalPerson.getForeignNationalDetails();
			if (foreignNationalDetails != null) {
				eSysParty.setVisaNumber(foreignNationalDetails.getVisaNumber());
				eSysParty.setPassportNumber(foreignNationalDetails.getPassportNumber());
				eSysParty.setVisaSubclass(foreignNationalDetails.getVisaSubclass());
				eSysParty.setVisaExpiryDate(foreignNationalDetails.getVisaExpiryDate());
				eSysParty.setCountryOfCitizenshipOracleDbValue(getCountryCode(foreignNationalDetails.getNationality()));
				eSysParty.setTaxResidenceCountry(getCountryCode(foreignNationalDetails.getTaxResidenceCountry()));
				eSysParty.setOverseasEntityIdentifier(foreignNationalDetails.getOverseasEntityIdentifier());
				eSysParty.setFirbApplicationNumber(foreignNationalDetails.getFirbApplicationNumber());
			}
		}
	}	

	private <T extends LegalEntity> void mapForeignFields(T eSysParty, Organisation organisation) {
		if (organisation == null) {
			return;
		}

		if (eSysParty instanceof AbstractTransferee) {
			AbstractTransferee transferee = (AbstractTransferee) eSysParty;
			transferee.setForeignPurchaser(organisation.getForeignOrganisationInd());
		}

		if (Boolean.TRUE.equals(organisation.getForeignOrganisationInd())) {
			ForeignOrganisation foreignOrganisation = organisation.getForeignOrganisation();
			if (foreignOrganisation != null) {
				eSysParty.setCountryOfIncorporationOracleDbValue(
						getCountryCode(foreignOrganisation.getCountryOfIncorporation()));
				eSysParty.setOverseasEntityRegNumber(foreignOrganisation.getOverseasEntityRegNumber());
				eSysParty.setFirbApplicationNumber(foreignOrganisation.getFirbApplicationNumber());
			}
		}
	}

	private Fraction getFraction(OwnershipShare share) {
		if (share == null || share.getSharesOwned() == null || share.getTotalShares() == null) {
			return null;
		}

		Fraction fraction = Fraction.getReducedFraction(toInteger(share.getSharesOwned()),
				toInteger(share.getTotalShares()));

		return (fraction.getNumerator() > MAX_SHARE_NUMERATOR || fraction.getDenominator() > MAX_SHARE_DENOMINATOR)
				? null : fraction;
	}

	private String getCountryCode(CountryType country) {
		return country == null ? null : country.getCode();
	}

	private void mapTransactionDetails(AbstractLandTransferDutyTransaction transaction, Transaction transactionSection) {
		if (transactionSection == null) {
			return;
		}

		TransferDetails transferDetails = transactionSection.getTransferDetails();
		ConsiderationAndValue considerationAndValue = transactionSection.getConsiderationAndValue();
		Gst gst = transactionSection.getGst();
		RelatedParty relatedParty = transactionSection.getRelatedParty();

		if (transferDetails != null) {
			transaction.setSettlementDate(transferDetails.getSettlementDate());
			transaction.setContractDate(transferDetails.getContractDate());
			transaction.setTransferDate(transferDetails.getTransferDate());
		}

		if (considerationAndValue != null) {
			BigDecimal effectiveConsideration;
			if (gst != null && gst.determineConsiderationDoesNotIncludeGst() && gst.determineIsTransferorMakesTaxableSupplyForGst() 
					&& gst.getTotalIncGst() != null) {
				effectiveConsideration = gst.getTotalIncGst();
			} else {
				effectiveConsideration = considerationAndValue.getConsideration();
			}
			
			transaction.setConsideration(nullIfGreaterThanMax(effectiveConsideration, MAX_CONSIDERATION));
			// TODO: Stage 3A - System assessed only
			//landTransferDutyTransaction.setMarketValue(nullIfGreaterThanMax(considerationAndValue.getMarketValue(), MAX_MARKET_VALUE));
		}

		if (relatedParty != null) {
			// TODO: Stage 3A - System assessed only
			//landTransferDutyTransaction.setRelatedParties(relatedParty.getRelatedParty());
		}
	}

	private boolean equalsIgnoreCaseAndSpace(String a, String b) {
		if (a == null || b == null) {
			return false;
		}
		return a.replaceAll("\\s","").equalsIgnoreCase(b.replaceAll("\\s",""));
	}

	private BigDecimal nullIfGreaterThanMax(BigDecimal a, BigDecimal max) {
		if (a == null || a.compareTo(max) > 0) {
			log.error("BigDecimal {} exceeds maximum {}", a, max);
			return null;
		} else {
			return a;
		}
	}

	private Long toLong(Integer i) {
		return i == null ? null : i.longValue();
	}

	private Integer toInteger(Long l) {
		return l == null ? null : l.intValue();
	}
}