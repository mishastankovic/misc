package au.gov.vic.sro.duties.transfer.fixture;

import au.gov.vic.sro.duties.transfer.model.Property;
import au.gov.vic.sro.duties.transfer.model.VolumeAndFolio;

import java.util.Collections;

public class PropertyFixture {

    public static Property createProperty(String id) {
        Property property = new Property();
        property.setAddress(id + ", Exibition Street, Melbourne");
        VolumeAndFolio volumeAndFolio = new VolumeAndFolio();
        volumeAndFolio.setFolio("FOL" + id);
        volumeAndFolio.setVolume("VOL" + id);
        property.setLandIdentifierList(Collections.singletonList(volumeAndFolio));

        return property;
    }

}
