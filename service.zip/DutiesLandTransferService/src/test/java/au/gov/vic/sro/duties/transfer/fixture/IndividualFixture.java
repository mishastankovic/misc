package au.gov.vic.sro.duties.transfer.fixture;

import au.gov.vic.sro.duties.transfer.model.Individual;

public class IndividualFixture {

    public static Individual createIndividual(String firstname, String middlename, String surname) {
        Individual individual = new Individual();
        individual.setFirstName(firstname);
        individual.setMiddleName(middlename);
        individual.setSurname(surname);
        return individual;
    }

}
