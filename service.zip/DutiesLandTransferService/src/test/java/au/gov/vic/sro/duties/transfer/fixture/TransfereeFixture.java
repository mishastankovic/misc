package au.gov.vic.sro.duties.transfer.fixture;

import au.gov.vic.sro.duties.transfer.model.Transferee;

public class TransfereeFixture {
    public static Transferee createTransferee(String id) {
        Transferee transferee = new Transferee();
        transferee.setId(id);
        transferee.setElnoPartyId("elnoParty" + id);
        transferee.setPartyId("party" + id);

        return transferee;
    }


}
