package au.gov.vic.sro.duties.transfer.fixture;

import au.gov.vic.sro.duties.transfer.model.Organisation;

public class OrganisationFixture {
    public static Organisation createOrganisation(String name, String abn, String acn) {
        Organisation organisation = new Organisation();
        organisation.setOrganisationName(name);
        organisation.setAbn(abn);
        organisation.setAcn(acn);

        return organisation;
    }

}
