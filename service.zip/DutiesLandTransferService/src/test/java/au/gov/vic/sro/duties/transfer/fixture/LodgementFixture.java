package au.gov.vic.sro.duties.transfer.fixture;

import au.gov.vic.sro.duties.transfer.model.*;
import org.mockito.Mockito;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class LodgementFixture {

    public static Lodgement createLodgement(String id) {
        Lodgement lodgement = new Lodgement();

        lodgement.setId(id);
        lodgement.setLodgementCategoryCode("C" + id);
        lodgement.setStatus("status" + id);
        lodgement.setElnoId("ELN" + id);
        lodgement.setElnoLodgementCaseId("CASE" + id);
        lodgement.setCaseReference("REF" + id);



        List<Transaction> transactionList = new ArrayList<>();
        transactionList.add(createTransaction("T01"));
        transactionList.add(createTransaction("T02"));
        lodgement.setTransactions(transactionList);

        return lodgement;
    }

    public static Transaction createTransaction(String id) {
        Transaction transaction = new Transaction();
        transaction.setId(id);
        transaction.setElnoDocumentId("el02");
        transaction.setElnoId("elno" + id);
        transaction.setFormId(1L);
        transaction.setFormVersion(1);

        List<Property> propertyList = new ArrayList<>();
        propertyList.add(PropertyFixture.createProperty("P01"));
        propertyList.add(PropertyFixture.createProperty("P02"));
        transaction.setPropertyList(propertyList);

        List<Transferee> transfereeList = new ArrayList<>();
        transfereeList.add(TransfereeFixture.createTransferee("01"));
        transfereeList.add(TransfereeFixture.createTransferee("02"));
        transaction.setTransfereeList(transfereeList);

        List<Transferor> transferorList = new ArrayList<>();
        transferorList.add(TransfororFixture.createTransferor("01"));
        transferorList.add(TransfororFixture.createTransferor("02"));
        transaction.setTransferorList(transferorList);

        return transaction;
    }

}
