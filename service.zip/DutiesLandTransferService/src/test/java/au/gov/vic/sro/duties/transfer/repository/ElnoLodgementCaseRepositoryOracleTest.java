package au.gov.vic.sro.duties.transfer.repository;

import au.gov.vic.sro.duties.transfer.configuration.ElnoOracleTestConfiguration;
import au.gov.vic.sro.duties.transfer.configuration.ElnoPersistenceTestConfiguration;
import au.gov.vic.sro.duties.transfer.fixture.ElnoLodgementCaseFixture;
import au.gov.vic.sro.duties.transfer.model.ElnoLodgementCase;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

@RunWith(SpringRunner.class)
@ContextConfiguration(
        classes = { ElnoPersistenceTestConfiguration.class, ElnoOracleTestConfiguration.class},
        loader = AnnotationConfigContextLoader.class)
@Transactional
public class ElnoLodgementCaseRepositoryOracleTest {

    @Autowired
    private ElnoLodgementCaseRepository elnoLodgementCaseRepository;

    @Test
    //@Rollback(false)
    public void testFindByElnoIdAndCaseId() {

        String elnoId = "elnoId1";
        String elnoLodgementCaseId = String.valueOf(System.currentTimeMillis());

        // given
        elnoLodgementCaseRepository.save(createElnoLodgementCase(elnoId, elnoLodgementCaseId));

        // when
        List<ElnoLodgementCase> result = elnoLodgementCaseRepository.findByElnoIdAndCaseId(elnoId, elnoLodgementCaseId);

        // then
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(result.get(0).getElnoId(), elnoId);
        assertEquals(result.get(0).getElnoLodgementCaseId(), elnoLodgementCaseId);
        assertNotNull(result.get(0).getCaseReferenceId());
        assertTrue(result.get(0).getCaseReferenceId().startsWith(ElnoLodgementCase.CASE_REFERENCE_PREFIX));
        assertEquals(result.get(0).getLatestRequestXml(), ElnoLodgementCaseFixture.getXml());
    }

    @Test
    public void testCreateDelete() {

        String elnoId = "elnoId1";
        String elnoLodgementCaseId = String.valueOf(System.currentTimeMillis());

        // given
        ElnoLodgementCase elnoLodgementCase = createElnoLodgementCase(elnoId, elnoLodgementCaseId);
        elnoLodgementCaseRepository.save(elnoLodgementCase);

        // when
        List<ElnoLodgementCase> result = elnoLodgementCaseRepository.findByElnoIdAndCaseId(elnoId, elnoLodgementCaseId);

        // then
        assertNotNull(result);
        assertEquals(result.get(0).getElnoId(), elnoId);
        assertEquals(result.get(0).getElnoLodgementCaseId(), elnoLodgementCaseId);
        assertNotNull(result.get(0).getCaseReferenceId());
        assertTrue(result.get(0).getCaseReferenceId().startsWith(ElnoLodgementCase.CASE_REFERENCE_PREFIX));
        assertEquals(result.get(0).getLatestRequestXml(), ElnoLodgementCaseFixture.getXml());
        elnoLodgementCaseRepository.delete(result.get(0));

        result = elnoLodgementCaseRepository.findByElnoIdAndCaseId(elnoId, elnoLodgementCaseId);
        assertTrue(result == null || result.size() == 0);
    }

    private ElnoLodgementCase createElnoLodgementCase(String elnoId, String elnoLodgementCaseId) {
        return ElnoLodgementCaseFixture.createElnoLodgementCase(elnoId, elnoLodgementCaseId);
    }
}
