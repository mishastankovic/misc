package au.gov.vic.sro.duties.transfer.dao;

import au.gov.vic.sro.duties.transfer.dao.ReferenceDataDao;
import au.gov.vic.sro.duties.transfer.dao.configuration.PersistenceTestConfiguration;
import au.gov.vic.sro.duties.transfer.model.ClaimCategory;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static au.gov.vic.sro.duties.transfer.model.AssessingType.EXTERNAL;
import static au.gov.vic.sro.duties.transfer.model.AssessingType.INTERNAL;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

@RunWith(SpringRunner.class)
@ContextConfiguration(
		classes = { PersistenceTestConfiguration.class, ReferenceDataDao.class },
		loader = AnnotationConfigContextLoader.class)
@DirtiesContext(classMode = ClassMode.AFTER_CLASS)
@Transactional
@Rollback
public class ReferenceDataDaoTest {

	@Autowired
	private ReferenceDataDao referenceDataDao;

	@Test
	@Ignore
	public void testGetClaimCategoryList() throws Exception {
		List<ClaimCategory> allCategories = referenceDataDao.getAllClaimCategoryList();
		List<ClaimCategory> manualCategories = referenceDataDao.getClaimCategoryList(INTERNAL);
		List<ClaimCategory> systemCategories = referenceDataDao.getClaimCategoryList(EXTERNAL);

		assertTrue(allCategories.size() > 0);
		assertEquals(allCategories.size(), manualCategories.size() + systemCategories.size());
	}
}
