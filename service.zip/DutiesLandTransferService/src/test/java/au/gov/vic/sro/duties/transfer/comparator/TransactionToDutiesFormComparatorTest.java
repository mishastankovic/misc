package au.gov.vic.sro.duties.transfer.comparator;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.util.stream.Collectors;

import org.junit.Before;
import org.junit.Test;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.StaxDriver;

import au.gov.vic.sro.duties.form.model.DutiesForm;
import au.gov.vic.sro.duties.lodgement.Lodgement;
import au.gov.vic.sro.duties.transaction.landtransfer.AbstractLandTransferDutyTransaction;
import au.gov.vic.sro.duties.transfer.mapper.Mapper;
import au.gov.vic.sro.duties.transfer.model.MatchResult;

public final class TransactionToDutiesFormComparatorTest implements Serializable {

	private static final long serialVersionUID = 2574642413740909581L;

	private AbstractLandTransferDutyTransaction transaction;

	private DutiesForm dutiesForm;

	private TransactionToDutiesFormComparator comparator;

	private Mapper mapper = new Mapper();

	XStream XSTREAM = new XStream(new StaxDriver());

	@Before
	public void setUp() throws Exception {
		dutiesForm = (DutiesForm) XSTREAM
				.fromXML(ClassLoader.getSystemResourceAsStream("DutiesForm_comparator_mismatch.xml"));
		Mapper mapper = new Mapper();
		Lodgement lodgement = mapper.toESys(mapper.fromXML(
				toXML(ClassLoader.getSystemResourceAsStream("StampDutyVerificationRequest_comparator mismatch.xml"))));
		transaction = (AbstractLandTransferDutyTransaction) lodgement.getTransactions().get(0);
		comparator = new TransactionToDutiesFormComparator();
	}

	protected String toXML(InputStream inputStream) throws IOException {
		try (BufferedReader br = new BufferedReader(new InputStreamReader(inputStream))) {
			return br.lines().collect(Collectors.joining(System.lineSeparator()));
		}
	}

	@Test
	public void testCompareTransactionToDutiesFormErrorWarnings() {
		MatchResult matchResult = comparator.compareTransactionToDutiesForm(dutiesForm, mapper.fromESys(transaction));
		assertThat(matchResult.getErrors().size() == 2).isTrue();
		assertThat(matchResult.getWarnings().size() == 1).isTrue();
	}

	@Test
	public void testCompareTransactionToDutiesFormNoMismatch() {
		dutiesForm = (DutiesForm) XSTREAM.fromXML(ClassLoader.getSystemResourceAsStream("DutiesForm.xml"));
		MatchResult matchResult = new MatchResult();
		Mapper mapper = new Mapper();
		try {
			Lodgement lodgement = mapper.toESys(
					mapper.fromXML(toXML(ClassLoader.getSystemResourceAsStream("StampDutyVerificationRequest.xml"))));
			transaction = (AbstractLandTransferDutyTransaction) lodgement.getTransactions().get(0);
			matchResult = comparator.compareTransactionToDutiesForm(dutiesForm, mapper.fromESys(transaction));
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertEquals(4, matchResult.getErrors().size());
		assertEquals(0, matchResult.getWarnings().size());
	}
}