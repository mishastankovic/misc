package au.gov.vic.sro.duties.transfer.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.fail;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.stream.Collectors;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;
import org.springframework.transaction.annotation.Transactional;

import au.gov.vic.sro.duties.dao.exception.GenericDaoException;
import au.gov.vic.sro.duties.lodgement.Lodgement;
import au.gov.vic.sro.duties.transaction.AbstractDutyTransaction;
import au.gov.vic.sro.duties.transfer.dao.configuration.PersistenceTestConfiguration;
import au.gov.vic.sro.duties.transfer.mapper.Mapper;

@RunWith(SpringRunner.class)
@ContextConfiguration(
		classes = { PersistenceTestConfiguration.class, LodgementDao.class, FoundationDao.class},
		loader = AnnotationConfigContextLoader.class)
@DirtiesContext(classMode = ClassMode.AFTER_CLASS)	// https://stackoverflow.com/questions/7498202/springjunit4classrunner-does-not-close-the-application-context-at-the-end-of-jun
@Transactional
@Rollback
public class LodgementDaoTest {

	@Autowired
	private FoundationDao foundationDao;

	@Autowired
	private LodgementDao lodgementDao;

	@Before
	public void setUp() throws Exception {
		foundationDao.setUser("DAMBOU0001");
	}

	@After
	public void tearDown() throws Exception {
		foundationDao.setUser(null);
	}

	@Test(expected = GenericDaoException.class)
	public void testGetLodgement() {
		lodgementDao.getLodgement(0l);
	}

	@Test
	public void testClaimElnoLodgementWithoutCaseReference() throws IOException {
		Mapper mapper = new Mapper();
		String xml = toXML(ClassLoader.getSystemResourceAsStream("StampDutyVerificationRequest.xml"));
		Lodgement lodgement = mapper.toESys(mapper.fromXML(xml));
		lodgement.setElnoLodgementReference(null);
		try {
			lodgementDao.claimElnoLodgement("62637482", lodgement, xml);
			fail("Claiming lodgement without case reference should fail");
		} catch(GenericDaoException e) {
			assertEquals(1, e.getMessages().size());
			assertEquals("ELNO eln_lodgement_reference has not been provided.", e.getMessages().get(0).getMessage());
		}
	}

	@Test
	@Ignore	// Ignore until when we can cancel lodgement
	public void testClaimElnoLodgement() throws IOException {
		Mapper mapper = new Mapper();
		String xml = toXML(ClassLoader.getSystemResourceAsStream("StampDutyVerificationRequest.xml"));
		Lodgement lodgement = mapper.toESys(mapper.fromXML(xml));
		lodgement.setLodgementCategoryDbValue("400");	// Trust Exemptions and Concessions
		assertNull(lodgement.getIdentifier());
		for (AbstractDutyTransaction transaction : lodgement.getTransactions()) {
			assertNull(transaction.getIdentifier());
		}
		Lodgement claimedLodgement = lodgementDao.claimElnoLodgement("62637482", lodgement, xml);
		assertNotNull(claimedLodgement.getIdentifier().getIdentifier());
		assertEquals(1, claimedLodgement.getTransactions().size());
		for (AbstractDutyTransaction transaction : claimedLodgement.getTransactions()) {
			assertNotNull(transaction.getIdentifier().getIdentifier());
		}
	}

	private String toXML(InputStream inputStream) throws IOException {
		try (BufferedReader br = new BufferedReader(new InputStreamReader(inputStream))) {
			return br.lines().collect(Collectors.joining(System.lineSeparator()));
		}
	}
}
