package au.gov.vic.sro.duties.transfer.service;

import au.gov.vic.sro.duties.transfer.configuration.ElnoOracleTestConfiguration;
import au.gov.vic.sro.duties.transfer.configuration.ElnoPersistenceTestConfiguration;
import au.gov.vic.sro.duties.transfer.fixture.ElnoLodgementCaseFixture;
import au.gov.vic.sro.duties.transfer.model.ElnoLodgementCase;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;
import org.springframework.transaction.annotation.Transactional;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

@RunWith(SpringRunner.class)
@ContextConfiguration(
        classes = { ElnoPersistenceTestConfiguration.class, ElnoOracleTestConfiguration.class, ElnoLodgementCaseService.class},
        loader = AnnotationConfigContextLoader.class)
@Transactional
public class ElnoLodgementCaseServiceTest {

    @Autowired
    private ElnoLodgementCaseService elnoLodgementCaseService;

    private String elnoId = "elnoIdServiceTest1";

    @Test
    public void testSave_New() {
        String elnoLodgementCaseId = String.valueOf(System.currentTimeMillis());

        ElnoLodgementCase elnoLodgementCase = ElnoLodgementCaseFixture.createElnoLodgementCase(elnoId, elnoLodgementCaseId);
        ElnoLodgementCase saved = elnoLodgementCaseService.save(elnoLodgementCase);
        assertNotNull(saved);
        assertEquals(saved.getElnoId(), elnoId);
        assertEquals(saved.getElnoLodgementCaseId(), elnoLodgementCaseId);
        assertNotNull(saved.getCaseReferenceId());
        assertTrue(saved.getCaseReferenceId().startsWith(ElnoLodgementCase.CASE_REFERENCE_PREFIX));

        // If elnoId / elnoLodgementCaseId exists in the database, should update that record.
        ElnoLodgementCase resentCase = ElnoLodgementCaseFixture.createElnoLodgementCase(elnoId, elnoLodgementCaseId);
        ElnoLodgementCase resentSaved = elnoLodgementCaseService.save(resentCase);
        assertEquals(saved.getCaseReferenceId(), resentSaved.getCaseReferenceId());
        //assertNotEquals(saved.getLastModified().getTime(), resentSaved.getLastModified().getTime());
    }
}