package au.gov.vic.sro.duties.transfer.mapper;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;

import au.gov.vic.sro.duties.transfer.model.Lodgement;
import au.gov.vic.sro.duties.transfer.model.Property;
import au.gov.vic.sro.duties.transfer.model.Transaction;
import au.gov.vic.sro.duties.transfer.model.Transferee;
import au.gov.vic.sro.duties.transfer.model.Transferor;
import au.gov.vic.sro.duties.transfer.model.VolumeAndFolio;

public class MapperTest extends AbstractMapperTest {

	private Mapper mapper = new Mapper();

	String xml;

	@Before
	public void setUp() throws Exception {
		xml = toXML(ClassLoader.getSystemResourceAsStream("StampDutyVerificationRequest.xml"));
	}

	@Test
	public void testMapFromXML() throws Exception {
		Lodgement lodgement = mapper.fromXML(xml);
		assertEquals("3422683", lodgement.getElnoLodgementCaseId());
		assertEquals("4470170", lodgement.getCaseReference());
		assertEquals("PEXA", lodgement.getElnoId());

		assertEquals(1, lodgement.getTransactions().size());
		Transaction transaction = lodgement.getTransactions().get(0);
		assertEquals("8607621", transaction.getElnoDocumentId());

		assertEquals(1, transaction.getPropertyList().size());
		Property property = transaction.getPropertyList().get(0);
		assertEquals("150 Edens RD, Caldermeade, VIC 3894", property.getAddress());

		assertEquals(1, property.getLandIdentifierList().size());
		VolumeAndFolio volumeAndFolio = (VolumeAndFolio) property.getLandIdentifierList().get(0);
		assertEquals("6304", volumeAndFolio.getVolume());
		assertEquals("780", volumeAndFolio.getFolio());

		assertEquals(5, transaction.getTransferorList().size());
		Transferor transferor = transaction.getTransferorList().get(0);
		assertEquals("7867338", transferor.getElnoPartyId());
		assertEquals("LEONIE", transferor.getIndividual().getFirstName());
		assertEquals("JEAN", transferor.getIndividual().getMiddleName());
		assertEquals("TONKS", transferor.getIndividual().getSurname());
		assertEquals(getDate("30/11/1957").getTime(), transferor.getIndividual().getDateOfBirth().getTime());
		transferor = transaction.getTransferorList().get(1);
		assertEquals("7867336", transferor.getElnoPartyId());
		assertEquals("ALMA", transferor.getIndividual().getFirstName());
		assertEquals("JEAN", transferor.getIndividual().getMiddleName());
		assertEquals("PATULLO", transferor.getIndividual().getSurname());
		assertEquals(getDate("11/04/1930").getTime(), transferor.getIndividual().getDateOfBirth().getTime());
		transferor = transaction.getTransferorList().get(2);
		assertEquals("7869122", transferor.getElnoPartyId());
		assertEquals("RAYMOND", transferor.getIndividual().getFirstName());
		assertEquals("GEOFFREY", transferor.getIndividual().getMiddleName());
		assertEquals("PATULLO", transferor.getIndividual().getSurname());
		assertEquals(getDate("10/12/1959").getTime(), transferor.getIndividual().getDateOfBirth().getTime());
		transferor = transaction.getTransferorList().get(3);
		assertEquals("7867340", transferor.getElnoPartyId());
		assertEquals("NARELLE", transferor.getIndividual().getFirstName());
		assertEquals("MARGARET", transferor.getIndividual().getMiddleName());
		assertEquals("ANDERSON", transferor.getIndividual().getSurname());
		assertEquals(getDate("19/09/1966").getTime(), transferor.getIndividual().getDateOfBirth().getTime());
		transferor = transaction.getTransferorList().get(4);
		assertEquals("8148848", transferor.getElnoPartyId());
		assertEquals("QREOF KNOXIA PTY LTD", transferor.getOrganisation().getOrganisationName());
		assertNull(transferor.getOrganisation().getAbn());
		assertEquals("616439224", transferor.getOrganisation().getAcn());

		assertEquals(2, transaction.getTransfereeList().size());
		Transferee transferee = transaction.getTransfereeList().get(0);
		assertEquals("7869122", transferee.getElnoPartyId());
		assertEquals("RAYMOND", transferee.getIndividual().getFirstName());
		assertEquals("GEOFFREY", transferee.getIndividual().getMiddleName());
		assertEquals("PATULLO", transferee.getIndividual().getSurname());
		assertEquals(getDate("10/12/1959").getTime(), transferee.getIndividual().getDateOfBirth().getTime());

		transferee = transaction.getTransfereeList().get(1);
		assertEquals("7867336", transferee.getElnoPartyId());
		assertEquals("ALMA", transferee.getIndividual().getFirstName());
		assertEquals("JEAN", transferee.getIndividual().getMiddleName());
		assertEquals("PATULLO", transferee.getIndividual().getSurname());
		assertEquals(getDate("11/04/1930").getTime(), transferee.getIndividual().getDateOfBirth().getTime());
	}

	@Test
	public void testMapToAndFromESys() throws Exception {
		Lodgement originalLodgement = mapper.fromXML(xml);
		au.gov.vic.sro.duties.lodgement.Lodgement eSysLodgement = mapper.toESys(originalLodgement);
		Lodgement lodgement = mapper.fromESys(eSysLodgement);

		assertEquals(originalLodgement.getId(), lodgement.getId());
		assertEquals(originalLodgement.getStatus(), lodgement.getStatus());
		assertEquals(originalLodgement.getLodgementCategoryCode(), lodgement.getLodgementCategoryCode());
		assertEquals(originalLodgement.getElnoLodgementCaseId(), lodgement.getElnoLodgementCaseId());
		assertEquals(originalLodgement.getElnoId(), lodgement.getElnoId());
		assertEquals(originalLodgement.getCaseReference(), lodgement.getCaseReference());
		assertEquals(originalLodgement.getTransactions().size(), lodgement.getTransactions().size());

		Transaction originalTransaction = originalLodgement.getTransactions().get(0);
		Transaction transaction = lodgement.getTransactions().get(0);
		assertEquals(originalTransaction.getId(), transaction.getId());
		assertEquals(originalTransaction.getFormId(), transaction.getFormId());
		assertEquals(originalTransaction.getFormVersion(), transaction.getFormVersion());
		assertEquals(originalTransaction.getElnoDocumentId(), transaction.getElnoDocumentId());
		assertEquals(originalTransaction.getElnoId(), transaction.getElnoId());

		assertEquals(originalTransaction.getPropertyList().size(), transaction.getPropertyList().size());
		assertEquals(originalTransaction.getTransferorList().size(), transaction.getTransferorList().size());
		assertEquals(originalTransaction.getTransfereeList().size(), transaction.getTransfereeList().size());
	}

	private Date getDate(String date) throws ParseException {
		return new SimpleDateFormat("dd/MM/yyyy").parse(date);
	}
}
