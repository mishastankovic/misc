package au.gov.vic.sro.duties.transfer.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;
import org.springframework.transaction.annotation.Transactional;

import au.gov.vic.sro.duties.dao.exception.NotFoundException;
import au.gov.vic.sro.duties.transaction.landtransfer.LandTransferDutyTransaction;
import au.gov.vic.sro.duties.transfer.dao.configuration.PersistenceTestConfiguration;

@RunWith(SpringRunner.class)
@ContextConfiguration(
		classes = { PersistenceTestConfiguration.class, TransactionDao.class, FoundationDao.class},
		loader = AnnotationConfigContextLoader.class)
@DirtiesContext(classMode = ClassMode.AFTER_CLASS)	// https://stackoverflow.com/questions/7498202/springjunit4classrunner-does-not-close-the-application-context-at-the-end-of-jun
@Transactional
@Rollback
public class TransactionDaoTest {

	@Autowired
	private FoundationDao foundationDao;

	@Autowired
	private TransactionDao transactionDao;

	@Before
	public void setUp() throws Exception {
		foundationDao.setUser("DAMBOU0001");
	}

	@After
	public void tearDown() throws Exception {
		foundationDao.setUser(null);
	}

	@Test(expected = NotFoundException.class)
	public void testGet() {
		transactionDao.get(0l);
	}

	@Test
	@Ignore
	public void testUpdate() {
		LandTransferDutyTransaction transaction = transactionDao.get(4392616l);
		transaction.setDutiesFormId(Long.valueOf(1));
		transaction.setDutiesFormVersion(Long.valueOf(1));
		transaction = transactionDao.update(transaction);
		assertEquals(Long.valueOf(1), transaction.getDutiesFormId());
		assertEquals(Long.valueOf(1), transaction.getDutiesFormVersion());
		transaction.setDutiesFormId(null);
		transaction.setDutiesFormVersion(null);
		transaction = transactionDao.update(transaction);
		assertNull(transaction.getDutiesFormId());
		assertNull(transaction.getDutiesFormVersion());
	}
}
