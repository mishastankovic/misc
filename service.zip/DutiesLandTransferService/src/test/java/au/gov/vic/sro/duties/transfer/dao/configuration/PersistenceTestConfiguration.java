package au.gov.vic.sro.duties.transfer.dao.configuration;

import javax.sql.DataSource;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.support.AnnotationConfigContextLoader;

@Configuration
@EnableAutoConfiguration
@PropertySource("classpath:META-INF/persistence-test.properties")
@ContextConfiguration(classes = { PersistenceConfiguration.class }, loader = AnnotationConfigContextLoader.class)
public class PersistenceTestConfiguration {

	@Bean
	@ConfigurationProperties(prefix = "spring.datasource.esys-dol")
	public DataSource eSysDutiesDataSource() {
		return DataSourceBuilder.create().build();
	}

//	@Bean
//	@ConfigurationProperties(prefix = "spring.datasource.esys-elno")
//	public DataSource eSysElnoDataSource() {
//		return DataSourceBuilder.create().build();
//	}
}
