package au.gov.vic.sro.duties.transfer.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Collections;

import javax.servlet.http.Cookie;

import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import au.gov.vic.sro.duties.dao.exception.FormMismatchException;
import au.gov.vic.sro.duties.dao.exception.GenericDaoException;
import au.gov.vic.sro.duties.form.model.DutiesForm;
import au.gov.vic.sro.duties.transaction.landtransfer.LandTransferDutyTransaction;
import au.gov.vic.sro.duties.transfer.comparator.TransactionToDutiesFormComparator;
import au.gov.vic.sro.duties.transfer.dao.TransactionDao;
import au.gov.vic.sro.duties.transfer.mapper.DutiesFormMapper;
import au.gov.vic.sro.duties.transfer.mapper.Mapper;
import au.gov.vic.sro.duties.transfer.model.Error;
import au.gov.vic.sro.duties.transfer.model.FormLink;
import au.gov.vic.sro.duties.transfer.model.MatchResult;
import au.gov.vic.sro.duties.transfer.model.Transaction;
import au.gov.vic.sro.duties.transfer.service.security.UserSecurity;
import au.gov.vic.sro.duties.transfer.service.security.UserSecurityDetailsService;

public class DutiesFormServiceTest {

    @Mock
    private UserSecurityDetailsService userSecurityDetailsService;

    @Mock
    private UserSecurity userSecurity;

    @Mock
    private TransactionToDutiesFormComparator transactionToDutiesFormComparator;

    @Mock
    private TransactionDao transactionDao;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private Mapper mapper;

    @Mock
    private DutiesFormMapper dutiesFormMapper;

    @Captor
    private ArgumentCaptor<String> stringCaptor1;

    @Captor
    private ArgumentCaptor<HttpEntity<DutiesForm>> httpEntityCaptor;

    @InjectMocks
    private DutiesFormService dutiesFormService;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);

        Cookie cookie = Mockito.mock(Cookie.class);
        when(userSecurityDetailsService.getUserSecurity()).thenReturn(userSecurity);
        when(userSecurity.getAccessTokenCookie()).thenReturn(cookie);
        when(cookie.getValue()).thenReturn("cookieValue");
        when(cookie.getName()).thenReturn("cookieName");

        ReflectionTestUtils.setField(dutiesFormService, "dutiesFormUrl", "http://www.dutiesFormService.com/");
        ReflectionTestUtils.setField(dutiesFormService, "restTemplate", restTemplate);
    }

    @Test
    public void getForm() {
        Long formId = new Long(1001);

        DutiesForm dutiesForm = Mockito.mock(DutiesForm.class);
        @SuppressWarnings("unchecked")
        ResponseEntity<DutiesForm> responseEntity = Mockito.mock(ResponseEntity.class);
        when(responseEntity.getBody()).thenReturn(dutiesForm);
        when(restTemplate.exchange(stringCaptor1.capture(), eq(HttpMethod.GET), httpEntityCaptor.capture(), eq(DutiesForm.class)))
            .thenReturn(responseEntity);

        //make the call
        DutiesForm retreivedForm =  dutiesFormService.getForm(formId);

        //verify
        assertEquals(dutiesForm, retreivedForm );
        //verify url is constructed properly
        assertEquals("http://www.dutiesFormService.com//dutiesformrest/forms/form/1001", stringCaptor1.getValue());
        verifyHttpRequestHeaders();
    }

    private void verifyHttpRequestHeaders() {
        HttpEntity<DutiesForm> httpEntity = httpEntityCaptor.getValue();
        //verify access token header and content type
        assertEquals(2, httpEntity.getHeaders().size());
        assertEquals("cookieName=cookieValue", httpEntity.getHeaders().get("Cookie").get(0));
        assertEquals(MediaType.APPLICATION_JSON, httpEntity.getHeaders().getContentType());
    }

    @Test
    public void linkSuccessfully() throws Exception{
        Long formId = new Long(1001);
        FormLink formLink = new FormLink(new Long(2002), new Long(3003));
        DutiesFormService spyDutiesFormService = spy(dutiesFormService);

        //we are not testing getForm here. so stub the method.
        DutiesForm form = Mockito.mock(DutiesForm.class);
        Mockito.doReturn(form).when(spyDutiesFormService).getForm(formId);

        LandTransferDutyTransaction landTransferDutyTransaction = new LandTransferDutyTransaction();
        when(transactionDao.get(formLink.getTransactionId())).thenReturn(landTransferDutyTransaction);

        Transaction transaction = new Transaction();
        when(mapper.fromESys(landTransferDutyTransaction)).thenReturn(transaction);

        MatchResult matchResult = Mockito.mock(MatchResult.class);
        when(transactionToDutiesFormComparator.compareTransactionToDutiesForm(form, transaction)).thenReturn(matchResult);

        @SuppressWarnings("unchecked")
        ResponseEntity<DutiesForm> responseEntity = Mockito.mock(ResponseEntity.class);
        when(responseEntity.getBody()).thenReturn(form);
        when(restTemplate.exchange(any(String.class), eq(HttpMethod.PUT), any(HttpEntity.class), eq(DutiesForm.class)))
                .thenReturn(responseEntity);

        DutiesForm returnedForm = new DutiesForm();
        returnedForm.setVersion(3);
        when(responseEntity.getBody()).thenReturn(returnedForm);

        spyDutiesFormService.link(formId, formLink);

        //verify link form http call parameters.
        verify(restTemplate, times(1)).
                exchange(eq("http://www.dutiesFormService.com//dutiesformrest/forms/form/1001/link"), eq(HttpMethod.PUT) ,  httpEntityCaptor.capture(), eq(DutiesForm.class ));
        verifyHttpRequestHeaders();

        verify(mapper, times(1)).fromESys(landTransferDutyTransaction);
        verify(dutiesFormMapper).map(landTransferDutyTransaction, form);
        verify(transactionDao).update(landTransferDutyTransaction);

        assertEquals(new Long(1001), landTransferDutyTransaction.getDutiesFormId());
        assertTrue(returnedForm.getVersion().longValue() == landTransferDutyTransaction.getDutiesFormVersion());
    }

    @Test
    public void linkIsIdempotentIfFormIdIsSame() throws Exception{
        Long formId = new Long(1001);
        FormLink formLink = new FormLink(new Long(2002), new Long(3003));
        DutiesFormService spyDutiesFormService = spy(dutiesFormService);

        //we are not testing getForm here. so stub the method.
        DutiesForm form = Mockito.mock(DutiesForm.class);
        Mockito.doReturn(form).when(spyDutiesFormService).getForm(formId);

        LandTransferDutyTransaction landTransferDutyTransaction = new LandTransferDutyTransaction();
        when(transactionDao.get(formLink.getTransactionId())).thenReturn(landTransferDutyTransaction);
        landTransferDutyTransaction.setDutiesFormId(new Long(1001));

        Transaction transaction = new Transaction();
        when(mapper.fromESys(landTransferDutyTransaction)).thenReturn(transaction);

        MatchResult matchResult = Mockito.mock(MatchResult.class);
        when(transactionToDutiesFormComparator.compareTransactionToDutiesForm(form, transaction)).thenReturn(matchResult);

        @SuppressWarnings("unchecked")
        ResponseEntity<DutiesForm> responseEntity = Mockito.mock(ResponseEntity.class);
        when(responseEntity.getBody()).thenReturn(form);
        when(restTemplate.exchange(any(String.class), eq(HttpMethod.PUT), any(HttpEntity.class), eq(DutiesForm.class)))
                .thenReturn(responseEntity);

        DutiesForm returnedForm = new DutiesForm();
        returnedForm.setVersion(3);
        when(responseEntity.getBody()).thenReturn(returnedForm);

        spyDutiesFormService.link(formId, formLink);

        //verify link form http call parameters.
        verify(restTemplate, times(1)).
                exchange(eq("http://www.dutiesFormService.com//dutiesformrest/forms/form/1001/link"), eq(HttpMethod.PUT) ,  httpEntityCaptor.capture(), eq(DutiesForm.class ));
        verifyHttpRequestHeaders();

        verify(mapper, times(1)).fromESys(landTransferDutyTransaction);
        verify(dutiesFormMapper).map(landTransferDutyTransaction, form);
        verify(transactionDao).update(landTransferDutyTransaction);

        assertEquals(new Long(1001), landTransferDutyTransaction.getDutiesFormId());
        assertTrue(returnedForm.getVersion().longValue() == landTransferDutyTransaction.getDutiesFormVersion());
    }

    @Test(expected = IllegalStateException.class)
    public void linkFailsIfAlreadyLinkedToAnotherForm() throws Exception{
        Long formId = new Long(1001);
        FormLink formLink = new FormLink(new Long(2002), new Long(3003));
        DutiesFormService spyDutiesFormService = spy(dutiesFormService);

        //we are not testing getForm here. so stub the method.
        DutiesForm form = Mockito.mock(DutiesForm.class);
        Mockito.doReturn(form).when(spyDutiesFormService).getForm(formId);

        LandTransferDutyTransaction landTransferDutyTransaction = new LandTransferDutyTransaction();
        when(transactionDao.get(formLink.getTransactionId())).thenReturn(landTransferDutyTransaction);
        landTransferDutyTransaction.setDutiesFormId(new Long(1002));

        Transaction transaction = new Transaction();
        when(mapper.fromESys(landTransferDutyTransaction)).thenReturn(transaction);

        spyDutiesFormService.link(formId, formLink);
    }

    @Test
    public void linkSuccessfullyWhenWarningsPresentIfAcceptMismatchFlagSet() throws Exception{
        Long formId = new Long(1001);
        FormLink formLink = new FormLink(new Long(2002), new Long(3003));
        DutiesFormService spyDutiesFormService = spy(dutiesFormService);

        //we are not testing getForm here. so stub the method.
        DutiesForm form = Mockito.mock(DutiesForm.class);
        Mockito.doReturn(form).when(spyDutiesFormService).getForm(formId);

        LandTransferDutyTransaction landTransferDutyTransaction = new LandTransferDutyTransaction();
        when(transactionDao.get(formLink.getTransactionId())).thenReturn(landTransferDutyTransaction);

        Transaction transaction = new Transaction();
        when(mapper.fromESys(landTransferDutyTransaction)).thenReturn(transaction);

        MatchResult matchResult = Mockito.mock(MatchResult.class);
        Error warning = new Error("errorMsg", "field", "errorCode");
        when(transactionToDutiesFormComparator.compareTransactionToDutiesForm(form, transaction)).thenReturn(matchResult);
        when(matchResult.getWarnings()).thenReturn(Collections.singletonList(warning));

        @SuppressWarnings("unchecked")
        ResponseEntity<DutiesForm> responseEntity = (ResponseEntity<DutiesForm>) Mockito.mock(ResponseEntity.class);
        when(responseEntity.getBody()).thenReturn(form);
        when(restTemplate.exchange(any(String.class), eq(HttpMethod.PUT), any(HttpEntity.class), eq(DutiesForm.class)))
                .thenReturn(responseEntity);

        DutiesForm returnedForm = new DutiesForm();
        returnedForm.setVersion(3);
        when(responseEntity.getBody()).thenReturn(returnedForm);

        formLink.getAcknowledgedWarnings().add(warning);
        spyDutiesFormService.link(formId, formLink);

        //verify link form http call parameters.
        verify(restTemplate, times(1)).
                exchange(eq("http://www.dutiesFormService.com//dutiesformrest/forms/form/1001/link"), eq(HttpMethod.PUT) ,  httpEntityCaptor.capture(), eq(DutiesForm.class ));
        verifyHttpRequestHeaders();

        verify(mapper, times(1)).fromESys(landTransferDutyTransaction);
        verify(dutiesFormMapper).map(landTransferDutyTransaction, form);
        verify(transactionDao).update(landTransferDutyTransaction);

        assertEquals(new Long(1001), landTransferDutyTransaction.getDutiesFormId());
        assertTrue(returnedForm.getVersion().longValue() == landTransferDutyTransaction.getDutiesFormVersion());
    }

    @Test(expected = FormMismatchException.class)
    public void linkFailsWhenErrorsPresentEvenIfAcceptMismatchFlagSet() throws Exception{
        Long formId = new Long(1001);
        FormLink formLink = new FormLink(new Long(2002), new Long(3003));
        DutiesFormService spyDutiesFormService = spy(dutiesFormService);

        //we are not testing getForm here. so stub the method.
        DutiesForm form = Mockito.mock(DutiesForm.class);
        Mockito.doReturn(form).when(spyDutiesFormService).getForm(formId);

        LandTransferDutyTransaction landTransferDutyTransaction = new LandTransferDutyTransaction();
        when(transactionDao.get(formLink.getTransactionId())).thenReturn(landTransferDutyTransaction);

        Transaction transaction = new Transaction();
        when(mapper.fromESys(landTransferDutyTransaction)).thenReturn(transaction);

        MatchResult matchResult = Mockito.mock(MatchResult.class);
        when(transactionToDutiesFormComparator.compareTransactionToDutiesForm(form, transaction)).thenReturn(matchResult);
        when(matchResult.getErrors()).thenReturn(Collections.singletonList(new Error()));

        @SuppressWarnings("unchecked")
        ResponseEntity<DutiesForm> responseEntity = Mockito.mock(ResponseEntity.class);
        when(responseEntity.getBody()).thenReturn(form);
        when(restTemplate.exchange(any(String.class), eq(HttpMethod.PUT), any(HttpEntity.class), eq(DutiesForm.class)))
                .thenReturn(responseEntity);

        DutiesForm returnedForm = new DutiesForm();
        returnedForm.setVersion(3);
        when(responseEntity.getBody()).thenReturn(returnedForm);

        spyDutiesFormService.link(formId, formLink);
    }

    @Test(expected = FormMismatchException.class)
    public void linkFailsWhenWarningsPresentIfAcceptMismatchFlagNotSet() throws Exception{
        Long formId = new Long(1001);
        FormLink formLink = new FormLink(new Long(2002), new Long(3003));
        DutiesFormService spyDutiesFormService = spy(dutiesFormService);

        //we are not testing getForm here. so stub the method.
        DutiesForm form = Mockito.mock(DutiesForm.class);
        Mockito.doReturn(form).when(spyDutiesFormService).getForm(formId);

        LandTransferDutyTransaction landTransferDutyTransaction = new LandTransferDutyTransaction();
        when(transactionDao.get(formLink.getTransactionId())).thenReturn(landTransferDutyTransaction);

        Transaction transaction = new Transaction();
        when(mapper.fromESys(landTransferDutyTransaction)).thenReturn(transaction);

        MatchResult matchResult = Mockito.mock(MatchResult.class);
        when(transactionToDutiesFormComparator.compareTransactionToDutiesForm(form, transaction)).thenReturn(matchResult);
        when(matchResult.getWarnings()).thenReturn(Collections.singletonList(new Error()));

        @SuppressWarnings("unchecked")
        ResponseEntity<DutiesForm> responseEntity = Mockito.mock(ResponseEntity.class);
        when(responseEntity.getBody()).thenReturn(form);
        when(restTemplate.exchange(any(String.class), eq(HttpMethod.PUT), any(HttpEntity.class), eq(DutiesForm.class)))
                .thenReturn(responseEntity);

        DutiesForm returnedForm = new DutiesForm();
        returnedForm.setVersion(3);
        when(responseEntity.getBody()).thenReturn(returnedForm);

        spyDutiesFormService.link(formId, formLink);
    }

    @Test(expected = FormMismatchException.class)
    public void formMismatchThrowsException() throws Exception{
        Long formId = new Long(1001);
        FormLink formLink = new FormLink(new Long(2002), new Long(3003));
        DutiesFormService spyDutiesFormService = spy(dutiesFormService);

        //we are not testing getForm here. so stub the method.
        DutiesForm form = Mockito.mock(DutiesForm.class);
        Mockito.doReturn(form).when(spyDutiesFormService).getForm(formId);

        LandTransferDutyTransaction landTransferDutyTransaction = new LandTransferDutyTransaction();
        when(transactionDao.get(formLink.getTransactionId())).thenReturn(landTransferDutyTransaction);

        Transaction transaction = new Transaction();
        when(mapper.fromESys(landTransferDutyTransaction)).thenReturn(transaction);

        MatchResult matchResult = Mockito.mock(MatchResult.class);
        when(transactionToDutiesFormComparator.compareTransactionToDutiesForm(form, transaction)).thenReturn(matchResult);
        when(matchResult.getErrors()).thenReturn(Collections.singletonList(new Error()));

        spyDutiesFormService.link(formId, formLink);
    }

    @Test(expected = RuntimeException.class)
    public void linkThrowsRuntimeExceptionIfGetTransactionFails() throws Exception{
        Long formId = new Long(1001);
        FormLink formLink = new FormLink(new Long(2002), new Long(3003));
        DutiesFormService spyDutiesFormService = spy(dutiesFormService);

        //we are not testing getForm here. so stub the method.
        DutiesForm form = Mockito.mock(DutiesForm.class);
        Mockito.doReturn(form).when(spyDutiesFormService).getForm(formId);

        LandTransferDutyTransaction landTransferDutyTransaction = new LandTransferDutyTransaction();
        when(transactionDao.get(formLink.getTransactionId())).thenThrow(new GenericDaoException("failed", "failed"));
        landTransferDutyTransaction.setDutiesFormId(new Long(1001));

        spyDutiesFormService.link(formId, formLink);
    }

    @Test(expected = RuntimeException.class)
    public void linkThrowsRuntimeExceptionIfEsysUpdateFails() throws Exception{
        Long formId = new Long(1001);
        FormLink formLink = new FormLink(new Long(2002), new Long(3003));
        DutiesFormService spyDutiesFormService = spy(dutiesFormService);

        //we are not testing getForm here. so stub the method.
        DutiesForm form = Mockito.mock(DutiesForm.class);
        Mockito.doReturn(form).when(spyDutiesFormService).getForm(formId);

        LandTransferDutyTransaction landTransferDutyTransaction = new LandTransferDutyTransaction();
        when(transactionDao.get(formLink.getTransactionId())).thenReturn(landTransferDutyTransaction);

        Transaction transaction = new Transaction();
        when(mapper.fromESys(landTransferDutyTransaction)).thenReturn(transaction);

        MatchResult matchResult = Mockito.mock(MatchResult.class);
        when(transactionToDutiesFormComparator.compareTransactionToDutiesForm(form, transaction)).thenReturn(matchResult);

        @SuppressWarnings("unchecked")
        ResponseEntity<DutiesForm> responseEntity = Mockito.mock(ResponseEntity.class);
        when(responseEntity.getBody()).thenReturn(form);
        when(restTemplate.exchange(any(String.class), eq(HttpMethod.PUT), any(HttpEntity.class), eq(DutiesForm.class)))
                .thenReturn(responseEntity);

        DutiesForm returnedForm = new DutiesForm();
        returnedForm.setVersion(3);
        when(responseEntity.getBody()).thenReturn(returnedForm);

        when(transactionDao.update(landTransferDutyTransaction)).thenThrow(new GenericDaoException("failed","failed"));

        spyDutiesFormService.link(formId, formLink);
    }

    @Test
    public void unlinkSuccessfully() throws Exception{
        Long formId = new Long(1001);
        FormLink formLink = new FormLink(new Long(2002), new Long(3003));
        DutiesFormService spyDutiesFormService = spy(dutiesFormService);

        //we are not testing getForm here. so stub the method.
        DutiesForm form = Mockito.mock(DutiesForm.class);
        Mockito.doReturn(form).when(spyDutiesFormService).getForm(formId);

        LandTransferDutyTransaction landTransferDutyTransaction = new LandTransferDutyTransaction();
        when(transactionDao.get(formLink.getTransactionId())).thenReturn(landTransferDutyTransaction);
        landTransferDutyTransaction.setDutiesFormId(new Long(1001));
        landTransferDutyTransaction.setDutiesFormVersion(new Long(5000));

        @SuppressWarnings("unchecked")
        ResponseEntity<DutiesForm> responseEntity = Mockito.mock(ResponseEntity.class);
        when(responseEntity.getBody()).thenReturn(form);
        when(restTemplate.exchange(any(String.class), eq(HttpMethod.PUT), any(HttpEntity.class), eq(DutiesForm.class)))
                .thenReturn(responseEntity);

        DutiesForm returnedForm = new DutiesForm();
        returnedForm.setVersion(3);
        when(responseEntity.getBody()).thenReturn(returnedForm);

        spyDutiesFormService.unlink(formId, formLink);

        //verify link form http call parameters.
        verify(restTemplate, times(1)).
                exchange(eq("http://www.dutiesFormService.com//dutiesformrest/forms/form/1001/unlink"), eq(HttpMethod.PUT) ,  httpEntityCaptor.capture(), eq(String.class ));
        verifyHttpRequestHeaders();

        verify(transactionDao).update(landTransferDutyTransaction);

        assertNull(landTransferDutyTransaction.getDutiesFormId());
        assertNull(landTransferDutyTransaction.getDutiesFormVersion());
    }

    @Test(expected = IllegalStateException.class)
    public void unlinkThrowsErrorWhenFormIdInRequestDoesNotMatchToLinkedForm() throws Exception{
        Long formId = new Long(1001);
        FormLink formLink = new FormLink(new Long(2002), new Long(3003));
        DutiesFormService spyDutiesFormService = spy(dutiesFormService);

        //we are not testing getForm here. so stub the method.
        DutiesForm form = Mockito.mock(DutiesForm.class);
        Mockito.doReturn(form).when(spyDutiesFormService).getForm(formId);

        LandTransferDutyTransaction landTransferDutyTransaction = new LandTransferDutyTransaction();
        when(transactionDao.get(formLink.getTransactionId())).thenReturn(landTransferDutyTransaction);
        landTransferDutyTransaction.setDutiesFormId(new Long(1009));//this is different to the submitted formId
        landTransferDutyTransaction.setDutiesFormVersion(new Long(5000));

        spyDutiesFormService.unlink(formId, formLink);
    }

    @Test(expected = IllegalStateException.class)
    public void unlinkThrowsErrorWhenNoFormIsLinkedToTransactionInEsys() throws Exception{
        Long formId = new Long(1001);
        FormLink formLink = new FormLink(new Long(2002), new Long(3003));
        DutiesFormService spyDutiesFormService = spy(dutiesFormService);

        //we are not testing getForm here. so stub the method.
        DutiesForm form = Mockito.mock(DutiesForm.class);
        Mockito.doReturn(form).when(spyDutiesFormService).getForm(formId);

        LandTransferDutyTransaction landTransferDutyTransaction = new LandTransferDutyTransaction();
        when(transactionDao.get(formLink.getTransactionId())).thenReturn(landTransferDutyTransaction);
        landTransferDutyTransaction.setDutiesFormId(null);//set to null.

        spyDutiesFormService.unlink(formId, formLink);
    }
}
