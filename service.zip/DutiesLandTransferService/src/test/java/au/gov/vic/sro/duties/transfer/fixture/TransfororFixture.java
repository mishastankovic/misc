package au.gov.vic.sro.duties.transfer.fixture;

import au.gov.vic.sro.duties.transfer.model.Transferor;

public class TransfororFixture {

    public static Transferor createTransferor(String id) {
        Transferor transferor = new Transferor();
        transferor.setId(id);

        return transferor;
    }

}
