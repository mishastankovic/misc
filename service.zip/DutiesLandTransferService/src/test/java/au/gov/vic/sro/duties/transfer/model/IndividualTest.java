package au.gov.vic.sro.duties.transfer.model;

import au.gov.vic.sro.duties.transfer.fixture.IndividualFixture;
import org.junit.Assert;
import org.junit.Test;

/**
 * just one method, million tests,  just for fun :-). not really.
 *
 */
public class IndividualTest {

    @Test
    public void testThreeParts() {
        Individual individual = IndividualFixture.createIndividual("aa", "bb", "cc");
        Assert.assertEquals("aa bb cc", individual.getName() );
    }

    @Test
    public void testFirstPartBlank() {
        Individual individual = IndividualFixture.createIndividual("", "bb", "cc");
        Assert.assertEquals("bb cc", individual.getName() );
    }

    @Test
    public void testFirstPartNull() {
        Individual individual = IndividualFixture.createIndividual(null, "bb", "cc");
        Assert.assertEquals("bb cc", individual.getName() );
    }

    @Test
    public void testSecondPartBlank() {
        Individual individual = IndividualFixture.createIndividual("aa", "", "cc");
        Assert.assertEquals("aa cc", individual.getName() );
    }

    @Test
    public void testSecondPartNull() {
        Individual individual = IndividualFixture.createIndividual("aa", null, "cc");
        Assert.assertEquals("aa cc", individual.getName() );
    }

    @Test
    public void testThirdPartNull() {
        Individual individual = IndividualFixture.createIndividual("aa", "bb", null);
        Assert.assertEquals("aa bb", individual.getName() );
    }

    @Test
    public void testThirdPartBlank() {
        Individual individual = IndividualFixture.createIndividual("aa", "bb", "");
        Assert.assertEquals("aa bb", individual.getName() );
    }

    @Test
    public void testOnlyMiddlePart() {
        Individual individual = IndividualFixture.createIndividual("aa", "", "");
        Assert.assertEquals("aa", individual.getName() );
    }
    @Test
    public void testOnlyFirstPart() {
        Individual individual = IndividualFixture.createIndividual("", "bb", "");
        Assert.assertEquals("bb", individual.getName() );
    }
    @Test
    public void testOnlySurnamePart() {
        Individual individual = IndividualFixture.createIndividual("", "", "cc");
        Assert.assertEquals("cc", individual.getName() );
    }



}
