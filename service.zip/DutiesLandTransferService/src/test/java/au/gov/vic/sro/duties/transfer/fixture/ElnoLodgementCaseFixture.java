package au.gov.vic.sro.duties.transfer.fixture;

import au.gov.vic.sro.duties.transfer.model.ElnoLodgementCase;

import java.util.Date;

public class ElnoLodgementCaseFixture {

    public static ElnoLodgementCase createElnoLodgementCase(String elnoId, String elnoLodgementCaseId) {
        ElnoLodgementCase elnoCase = new ElnoLodgementCase();
        elnoCase.setElnoId(elnoId);
        elnoCase.setElnoLodgementCaseId(elnoLodgementCaseId);
        elnoCase.setLastModified(new Date());
        elnoCase.setLatestRequestXml(getXml());
        return elnoCase;
    }

    public static String getXml() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><request><tranferee></transferee></request>";
    }
}
