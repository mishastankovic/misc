package au.gov.vic.sro.duties.transfer.mapper;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.Before;
import org.junit.Test;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.StaxDriver;

import au.gov.vic.sro.duties.form.model.DutiesForm;
import au.gov.vic.sro.duties.lodgement.Lodgement;
import au.gov.vic.sro.duties.transaction.landtransfer.AbstractLandTransferDutyTransaction;
import au.gov.vic.sro.duties.transaction.landtransfer.AbstractTransferee;
import au.gov.vic.sro.duties.transaction.landtransfer.PropertyType;
import au.gov.vic.sro.duties.transaction.landtransfer.TransferProperty;
import au.gov.vic.sro.duties.transaction.landtransfer.Transferor;

public class DutiesFormMapperTest extends AbstractMapperTest {

	AbstractLandTransferDutyTransaction transaction;

	DutiesForm dutiesForm;

	@Before
	public void setUp() throws Exception {
		dutiesForm = (DutiesForm) new XStream(new StaxDriver())
				.fromXML(ClassLoader.getSystemResourceAsStream("DutiesForm.xml"));
		Mapper mapper = new Mapper();
		Lodgement lodgement = mapper.toESys(mapper.fromXML(
				toXML(ClassLoader.getSystemResourceAsStream("StampDutyVerificationRequest.xml"))));
		transaction = (AbstractLandTransferDutyTransaction) lodgement.getTransactions().get(0);
	}

	@Test
	public void testMap() throws Exception {
		TransferProperty property = transaction.getProperties().get(0);
		assertNull(property.getPropertyType());

		Transferor transferor = transaction.getTransferors().get(0);
		assertEquals("7867338", transferor.getElnoPartyId());
		assertNull(transferor.getPartyId());
		assertNull(transferor.getPassportNumber());
		assertNull(transferor.getTaxResidenceCountry());
		assertNull(transferor.getVisaNumber());
		assertNull(transferor.getVisaSubclass());

		transferor = transaction.getTransferors().get(3);
		assertEquals("7867340", transferor.getElnoPartyId());
		assertNull(transferor.getPartyId());
		assertNull(transferor.getPassportNumber());
		assertNull(transferor.getTaxResidenceCountry());
		assertNull(transferor.getVisaNumber());

		AbstractTransferee transferee = transaction.getTransferees().get(0);
		assertEquals("7869122", transferee.getElnoPartyId());
		assertNull(transferee.getPartyId());
		assertNull(transferee.getPassportNumber());
		assertNull(transferee.getTaxResidenceCountry());
		assertNull(transferee.getVisaNumber());

		transferee = transaction.getTransferees().get(1);
		assertEquals("7867336", transferee.getElnoPartyId());
		assertNull(transferee.getPartyId());
		assertNull(transferee.getPassportNumber());
		assertNull(transferee.getTaxResidenceCountry());
		assertNull(transferee.getVisaNumber());

		new DutiesFormMapper().map(transaction, dutiesForm);

		property = transaction.getProperties().get(0);
		assertEquals(PropertyType.ResidentialPrivateDwelling, property.getPropertyType());

		transferor = transaction.getTransferors().get(0);
		assertEquals("108652", transferor.getPartyId());
		assertEquals("LEONIE TONKS", transferor.getIndividualName().toString());
		assertEquals("LT123", transferor.getPassportNumber());
		assertEquals("ALA", transferor.getTaxResidenceCountry());
		assertEquals("LT1234", transferor.getVisaNumber());
		assertEquals("175", transferor.getVisaSubclass());

		transferor = transaction.getTransferors().get(1);
		assertNull(transferor.getPartyId());
		assertEquals("ALMA JEAN PATULLO", transferor.getIndividualName().toString());
		assertNull(transferor.getPassportNumber());
		assertNull(transferor.getTaxResidenceCountry());
		assertNull(transferor.getVisaNumber());

		transferor = transaction.getTransferors().get(2);
		assertNull(transferor.getPartyId());
		assertEquals("RAYMOND GEOFFREY PATULLO", transferor.getIndividualName().toString());
		assertNull(transferor.getPassportNumber());
		assertNull(transferor.getTaxResidenceCountry());
		assertNull(transferor.getVisaNumber());

		transferor = transaction.getTransferors().get(3);
		assertEquals("108653", transferor.getPartyId());
		assertEquals("NARELLE ANDERSON", transferor.getIndividualName().toString());
		assertEquals("NA123", transferor.getPassportNumber());
		assertEquals("ALA", transferor.getTaxResidenceCountry());
		assertEquals("NA1234", transferor.getVisaNumber());

		transferor = transaction.getTransferors().get(4);
		assertNull(transferor.getPartyId());
		assertEquals("QREOF KNOXIA PTY LTD", transferor.getCompanyName());
		assertNull(transferor.getPassportNumber());
		assertNull(transferor.getTaxResidenceCountry());
		assertNull(transferor.getVisaNumber());

		transferee = transaction.getTransferees().get(0);
		assertEquals("108703", transferee.getPartyId());
		assertEquals("Raymond Patullo", transferee.getIndividualName().toString());
		assertEquals("RP123", transferee.getPassportNumber());
		assertEquals("AZE", transferee.getTaxResidenceCountry());
		assertEquals("RP1234", transferee.getVisaNumber());

		transferee = transaction.getTransferees().get(1);
		assertEquals("108702", transferee.getPartyId());
		assertEquals("Alma Patullo", transferee.getIndividualName().toString());
		assertEquals("AP123", transferee.getPassportNumber());
		assertEquals("ASM", transferee.getTaxResidenceCountry());
		assertEquals("AP1234", transferee.getVisaNumber());
	}
}
