package au.gov.vic.sro.common.templateengine;

import com.itextpdf.text.DocumentException;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.templateresolver.ClassLoaderTemplateResolver;
import org.xhtmlrenderer.pdf.ITextRenderer;

import java.io.IOException;

import static com.itextpdf.text.pdf.BaseFont.EMBEDDED;
import static com.itextpdf.text.pdf.BaseFont.IDENTITY_H;
import static org.thymeleaf.templatemode.TemplateMode.HTML;

@Configuration
public class DocumentGeneratorConfig {
    private static final String UTF_8 = "UTF-8";


    @Bean
    public TemplateEngine templateEngine() {
        ClassLoaderTemplateResolver templateResolver = new ClassLoaderTemplateResolver();
        templateResolver.setPrefix("/");
        templateResolver.setSuffix(".html");
        templateResolver.setTemplateMode(HTML);
        templateResolver.setCharacterEncoding(UTF_8);

        TemplateEngine templateEngine = new TemplateEngine();
        templateEngine.setTemplateResolver(templateResolver);

        return templateEngine;
    }

    @Bean
    public ITextRenderer itextRenderer() {
        try {
            ITextRenderer renderer = new ITextRenderer();
            renderer.getFontResolver().addFont("Code39.ttf", IDENTITY_H, EMBEDDED);
            return renderer;
        } catch(IOException | DocumentException e) {
            throw new RuntimeException("itextRenderer initialisation error: ", e);
        }
    }
}
