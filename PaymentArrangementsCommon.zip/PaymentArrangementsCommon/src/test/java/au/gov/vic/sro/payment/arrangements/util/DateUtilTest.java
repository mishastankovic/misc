package au.gov.vic.sro.payment.arrangements.util;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Test;

public class DateUtilTest {

	@Test
	public void testIsAfter() throws Exception {
		DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSS");
		String dateString = "2018-08-15 05:24:25.694";
		Date date1 = sdf.parse(dateString);

		dateString = "2017-08-16 23:24:25.694";
		Date date2 = sdf.parse(dateString);

		assertThat(DateUtil.isAfter(date1, date2), is(true));
		assertThat(DateUtil.isAfter(date2, date1), is(false));
	}

}