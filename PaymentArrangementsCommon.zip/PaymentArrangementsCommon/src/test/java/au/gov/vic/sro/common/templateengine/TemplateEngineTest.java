package au.gov.vic.sro.common.templateengine;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;
import org.w3c.tidy.Tidy;
import org.xhtmlrenderer.pdf.ITextRenderer;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.nio.file.FileSystems;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {DocumentGeneratorConfig.class})
public class TemplateEngineTest {
    private static final String OUTPUT_FILE = "test.pdf";

    @Autowired
    private ITextRenderer renderer;

    @Autowired
    private TemplateEngine templateEngine;

    @Test
    public void test1() throws Exception {

        Data data = exampleData();

        Context context = new Context();
        context.setVariable("data", data);

        String renderedHtmlContent = templateEngine.process("template", context);
        String xHtml = TemplateEngineUtils.convertToXhtml(renderedHtmlContent);
        String baseUrl = FileSystems
                .getDefault()
                .getPath("src", "test", "resources")
                .toUri()
                .toURL()
                .toString();
        renderer.setDocumentFromString(xHtml, baseUrl);
        renderer.layout();

        // And finally, we create the PDF:
        OutputStream outputStream = new FileOutputStream(OUTPUT_FILE);
        renderer.createPDF(outputStream);
        outputStream.close();
    }


    //----------------------------
    //  Test harness
    //----------------------------
    private Data exampleData() {
        Data data = new Data();
        data.setFirstname("Misha");
        data.setLastname("Stankovic");
        data.setStreet("13 Blyth Street");
        data.setZipCode("3133");
        data.setCity("Vermont");
        return data;
    }


    static class Data {
        private String firstname;
        private String lastname;
        private String street;
        private String zipCode;
        private String city;

        public String getFirstname() {
            return firstname;
        }

        public void setFirstname(String firstname) {
            this.firstname = firstname;
        }

        public String getLastname() {
            return lastname;
        }

        public void setLastname(String lastname) {
            this.lastname = lastname;
        }

        public String getStreet() {
            return street;
        }

        public void setStreet(String street) {
            this.street = street;
        }

        public String getZipCode() {
            return zipCode;
        }

        public void setZipCode(String zipCode) {
            this.zipCode = zipCode;
        }

        public String getCity() {
            return city;
        }

        public void setCity(String city) {
            this.city = city;
        }
    }


}
