import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl, FormBuilder, Validators, AbstractControl } from '@angular/forms';
import { FormUtils } from 'sro-ngcomponent-library';
import { UIMessageService } from 'src/app/au/gov/vic/sro/dol-claim/service/ui-message.service';
import { DolClaimUIService } from 'src/app/au/gov/vic/sro/dol-claim/service/dol-claim-ui.service';
import {DolClaimService} from "../../service/dol-claim.service";
import {DolError} from "../../model/claim.interface";
import {isNullOrUndefined} from "util";
import {DolErrorHandler} from "../../service/dol-error-handler";

@Component({
    selector: 'dol-elno-lodgement-retreive',
    templateUrl: './dol-elno-lodgement-retrieve.html',
    styleUrls: ['./dol-elno-lodgement-retrieve.scss']
})
export class DolElnoLodgementRetrieve implements OnInit {

	form: FormGroup;
	elnoLodgementCaseId: FormControl;
	caseReferenceId: FormControl;
	pageErrors: string[];

	constructor(private formBuilder: FormBuilder,
				private router: Router,
				public errorHandler: DolErrorHandler,
				public uiMessageService: UIMessageService,
				private dolClaimService : DolClaimService,
				private dolClaimUIService: DolClaimUIService) { }

	ngOnInit() {
		this.buildForm();
	}

	buildForm() {
		this.elnoLodgementCaseId = new FormControl('', Validators.compose([Validators.required]));
		this.caseReferenceId = new FormControl('', Validators.compose([Validators.required, Validators.pattern('^N[0-9]{1,8}$')]));

		this.form = this.formBuilder.group({
			elnoLodgementCaseId: this.elnoLodgementCaseId,
			caseReferenceId: this.caseReferenceId
		});
	}

	onSubmit() {
		FormUtils.validate(this.form);
		if (this.form.valid) {
			this.dolClaimUIService.clear();
			this.dolClaimUIService.elnoLodgementCaseId = this.elnoLodgementCaseId.value;
			this.dolClaimUIService.caseReferenceId = this.caseReferenceId.value;
			this.pageErrors = [];
            this.dolClaimService.getLodgement(this.caseReferenceId.value, this.elnoLodgementCaseId.value).subscribe( (response: any) => {
				this.dolClaimUIService.lodgement = response.lodgement;
				if (response.lodgement.esysLodgementId) {
					this.router.navigate(['/link-forms']);
				} else {
					this.router.navigate(['/claim-lodgement']);
				}
			}, (response: any) => {
				this.pageErrors.push(this.errorHandler.getErrorMessage(response.error));
			})
		}

	}

	/*
	getErrorMessage(response: any): string {
        //alert("response" + JSON.stringify(response));
        return response && response.error && response.error.errors && response.error.errors.length > 0 &&
        		response.error.errors[0].code === 'lodgement.not.found' ?
            	this.uiMessageService.getMessage("ELNO_LODGEMENT_RETRIEVED_EMPTY") :
            	this.uiMessageService.getMessage("DOL_GENERIC_ERROR")
	}
	*/

	isNotValid(control: AbstractControl, type?: string): boolean {
		if (!control) { return; }
		return FormUtils.isNotValid(control, type);
	}

}

