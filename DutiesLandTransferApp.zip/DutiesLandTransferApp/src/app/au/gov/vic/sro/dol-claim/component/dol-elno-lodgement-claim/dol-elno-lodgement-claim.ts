import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl, FormBuilder, Validators, AbstractControl } from '@angular/forms';
import { FormUtils } from 'sro-ngcomponent-library';
import { UIMessageService } from 'src/app/au/gov/vic/sro/dol-claim/service/ui-message.service';
import { DolClaimUIService } from 'src/app/au/gov/vic/sro/dol-claim/service/dol-claim-ui-service';
import { DolClaimService } from 'src/app/au/gov/vic/sro/dol-claim/service/dol-claim.service';
import { DolCategoryService } from 'src/app/au/gov/vic/sro/dol-claim/service/dol-claim-category.service';
import { Lodgement, SubCategory, Category, Form, ClaimedForm } from 'src/app/au/gov/vic/sro/dol-claim/model/claim.interface';

@Component({
    selector: '[dol-elno-lodgement-claim]',
    templateUrl: './dol-elno-lodgement-claim.html',
    styleUrls: ['./dol-elno-lodgement-claim.scss']
})
export class DolElnoLodgementClaim implements OnInit {


	public claimForm: FormGroup;
	private category: FormControl;
	private subCategory: FormControl;
	
	private categoryList : Category[];
	private subCategoryList : Category[];
	


	constructor(private formBuilder: FormBuilder,
				private router: Router,
				private uiMessageService: UIMessageService,
				private dolClaimService: DolClaimService,
				private dolClaimUiService: DolClaimUIService,
				private dolCategoryService: DolCategoryService ) {
	}

	async ngOnInit() {

		//retreive the lodgement information
		this.dolClaimUiService.lodgement = await this.dolClaimService.getLodgement(this.dolClaimUiService.lodgementCaseId);
		await this.dolCategoryService.init();
		this.categoryList = this.dolCategoryService.getCategories();
		this.buildForm();
	}

	onSelectCategory(categoryCode: string) {
		this.subCategory.setValue('');
		this.subCategoryList = this.dolCategoryService.getSubCategories(categoryCode);
		if (this.subCategoryList && this.subCategoryList.length > 0 ) {
			this.subCategory.enable();
		} else {
			this.subCategory.disable();
		}
	}

	buildForm() {
		this.category = new FormControl('', Validators.compose([Validators.required]));
		this.subCategory = new FormControl('', Validators.compose([Validators.required]));

		this.claimForm = this.formBuilder.group({
			lodgementCaseId: this.dolClaimUiService.lodgementCaseId,
			sroReferenceId: this.dolClaimUiService.sroReferenceId,
			category : this.category,
			subCategory : this.subCategory
		});

	}

	onSubmit() {
		let url = 'https://localtest.e-business.sro.vic.gov.au/duties/faces/elno/claim.xhtml?transacti=4379480&lodgementId=1740456';

		console.log('submitting');
		FormUtils.validate(this.claimForm);
		if (this.claimForm.valid) {
			let data = this.dolClaimUiService.getClaimLodgementData();
			console.log('submitting data : ' + data);
			window.open(url, '_self');
		}
		
	}

	isNotValid(control: AbstractControl, type?: string): boolean {

		if (!control) { return; }
		return FormUtils.isNotValid(control, type);
	}




}

