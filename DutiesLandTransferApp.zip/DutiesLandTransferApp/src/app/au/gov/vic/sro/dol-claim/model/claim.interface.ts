export interface Category1 {
    id: string,
    value: string,
    subCategories: SubCategory[]
}

export interface Category {
    categoryCode: string,
    categoryName: string,
    categoryOrder: number,
    parentCategoryCode: string,
    subCategories: Category[],
    assessingType: string
}

export interface SubCategory {
    id: string,
    value: string
}

export interface Document {
    elnoDocId: string;
    elnoId: string;
    formId: number;
    formVersion: number;
    documentId: string;
    properties: Property[];
    transferees: Transferee[];
}

export interface Transferee {
    name: string;
}

export interface Form {
    property: Property;
}

export interface Lodgement {
    elnoId: string;
    elnoLodgementCaseId: string;
    caseReferenceId: string;
    esysLodgementId: string;
    category: string;
    documents : Document [];
}

export interface Property {
    address: string;
    volfol: string;
}

export interface ClaimedForm {
    formId: number,
    documentId: string
}

export interface DolError {
    errorCode: string;
    errorMsg: string;
    errorId: string;
}

export interface DolFieldError {
    errorCode: string;
    field: string;
    errorMsg: string;

}
