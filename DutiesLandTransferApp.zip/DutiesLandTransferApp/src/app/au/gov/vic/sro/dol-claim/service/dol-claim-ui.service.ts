import { Injectable } from "@angular/core";
import { Lodgement, ClaimedForm } from "../model/claim.interface";


@Injectable()
export class DolClaimUIService {

    private _elnoLodgementCaseId: string;
    private _caseReferenceId: string;
    private _lodgement : Lodgement;
    
    private claimedForms : Map<string, ClaimedForm> = new Map<string, ClaimedForm>();


    constructor () {
    }

    clear() {
        this.elnoLodgementCaseId = undefined;
        this.caseReferenceId = undefined;
        this.lodgement = undefined;
        this.claimedForms = new Map<string, ClaimedForm>();

    }

    public setClaimedForm(form: ClaimedForm) :void {
        this.claimedForms.set(form.documentId, form);
    }

    public getClaimLodgementData() {
        let data = {
            lodgementCaseId: this.elnoLodgementCaseId,
            sroReferenceId: this.caseReferenceId,
            forms: []
        }

        this.claimedForms.forEach( (claimedForm) => {
            data.forms.push(claimedForm);
        });
        return data;
    }

    get lodgement(): Lodgement {
        return this._lodgement;
    }

    set lodgement(lodgement: Lodgement) {
        this._lodgement = lodgement;
    }

    get elnoLodgementCaseId(): string {
        return this._elnoLodgementCaseId;
    }

    set elnoLodgementCaseId(val: string) {
        this._elnoLodgementCaseId = val;
    }

    get caseReferenceId(): string {
        return this._caseReferenceId;
    }

    set caseReferenceId(val: string) {
        this._caseReferenceId = val;
    }
}
