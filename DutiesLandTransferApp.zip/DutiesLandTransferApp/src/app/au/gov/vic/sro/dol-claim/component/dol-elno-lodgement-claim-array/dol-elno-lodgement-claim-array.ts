import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { FormArray, FormGroup, FormBuilder, AbstractControl, FormControl, Validators, ValidatorFn } from '@angular/forms';
import { Document, ClaimedForm } from 'src/app/au/gov/vic/sro/dol-claim/model/claim.interface';
import { DolElnoLodgementClaimRow } from '../dol-elno-lodgement-claim-row/dol-elno-lodgement-claim-row';
import { FormUtils } from 'sro-ngcomponent-library';
import { DolClaimUIService } from '../../service/dol-claim-ui.service';


@Component({
    selector: '[dol-elno-lodgement-claim-array]',
    templateUrl: './dol-elno-lodgement-claim-array.html',
    styleUrls: ['./dol-elno-lodgement-claim-array.scss']
})
export class DolElnoLodgementClaimArray implements OnInit{


	@Input()
	public claimForm : FormGroup;

	@Output()
	private formClaimedEvent : EventEmitter<ClaimedForm> = new EventEmitter<ClaimedForm>();

	@Input()
	public documentList : Document[];

	@Input()
	public claimButtonsRequired: boolean;

	async ngOnInit() {
	}


}


