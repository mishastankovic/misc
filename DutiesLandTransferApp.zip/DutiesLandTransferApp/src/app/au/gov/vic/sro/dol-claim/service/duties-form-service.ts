import { HttpClient } from '@angular/common/http';
import { Injectable, EventEmitter } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Lodgement, Form } from 'src/app/au/gov/vic/sro/dol-claim/model/claim.interface';
import { fetch } from 'node-fetch';


@Injectable()
export class DutiesFormService {
	protected basePath = environment.formApiBasePath;

	constructor(protected http: HttpClient) { }
	public async getForm(formId: string): Promise<Form> {
		const url = this.basePath + 'forms/form/' + formId;
		return this.http.get<Form>(url).toPromise();
	}

}
