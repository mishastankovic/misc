import {Injectable} from "@angular/core";
import {UIMessageService} from "./ui-message.service";
import {DolFieldError} from "../model/claim.interface";

@Injectable()
export class DolErrorHandler {


    constructor(private uiMessageService: UIMessageService) {
    }


    public getErrorMessage(error: any): string {
        return error && error.errorMsg ? error.errorMsg : this.uiMessageService.getMessage("DOL_GENERIC_ERROR")
    }

    public getErrorMessages(errors: DolFieldError[]): string[] {

        let messages: string[] = [];
        if(errors) {
            errors.map(error => {
                messages.push(error.errorMsg);
            });
        }
        return messages;
    }

}
