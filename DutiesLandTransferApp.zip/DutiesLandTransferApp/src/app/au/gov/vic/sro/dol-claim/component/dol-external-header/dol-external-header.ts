import { Component } from '@angular/core'

@Component({
    selector: 'dol-external-header',
    templateUrl: './dol-external-header.html',
    styleUrls: ['./dol-external-header.scss']
})
export class DolExternalHeader {
    public dutiesUrl = "https://localtest.e-business.sro.vic.gov.au";

    
}

