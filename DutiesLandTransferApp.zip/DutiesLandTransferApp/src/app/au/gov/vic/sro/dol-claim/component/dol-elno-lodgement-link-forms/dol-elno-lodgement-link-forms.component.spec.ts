import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DolElnoLodgementLinkFormsComponent } from './dol-elno-lodgement-link-forms.component';

describe('DolElnoLodgementLinkFormsComponent', () => {
  let component: DolElnoLodgementLinkFormsComponent;
  let fixture: ComponentFixture<DolElnoLodgementLinkFormsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DolElnoLodgementLinkFormsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DolElnoLodgementLinkFormsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
