import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {DolClaimUIService} from "../../service/dol-claim-ui.service";
import {FormUtils} from "sro-ngcomponent-library";
import {FormBuilder, FormControl, FormGroup, Validators} from "@angular/forms";
import {DolClaimService} from "../../service/dol-claim.service";
import {UIMessageService} from "../../service/ui-message.service";
import {DolError} from "../../model/claim.interface";
import {DutiesFormService} from "../../service/duties-form.service";
import {DolErrorHandler} from "../../service/dol-error-handler";

@Component({
  selector: 'app-dol-elno-lodgement-link-forms',
  templateUrl: './dol-elno-lodgement-link-forms.component.html',
  styleUrls: ['./dol-elno-lodgement-link-forms.component.css']
})
export class DolElnoLodgementLinkFormsComponent implements OnInit {

  // TODO - consilidate page errors into a common component. Currently repeaated in every component.
    private _pageErrors: string[];
    lodgementForm: FormGroup;


    @Output()
  private lodgementSubmittedEvent = new EventEmitter<string>();

  constructor( public dolClaimUIService: DolClaimUIService,
               private dolClaimService: DolClaimService,
               private dutiesFormService: DutiesFormService,
               private errorHandler: DolErrorHandler,
               public uiMessageService: UIMessageService,
               private formBuilder: FormBuilder,) { }

  ngOnInit() {
      this.buildForm();
  }

  onSubmit() {
      console.log('submitting');
      FormUtils.validate(this.lodgementForm);
      if (this.lodgementForm.valid) {
          this.dolClaimService.submitLodgement(this.dolClaimUIService.lodgement).subscribe(
              () => {
              },
              (response: any) => {
                  this._pageErrors.push(this.errorHandler.getErrorMessage(response.error));
              });


      }
  }

    buildForm() {
        this.lodgementForm = this.formBuilder.group({
            lodgementCaseId: this.dolClaimUIService.elnoLodgementCaseId,
            sroReferenceId: this.dolClaimUIService.caseReferenceId,
        });

    }


}
