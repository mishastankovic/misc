import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl, FormBuilder, Validators, AbstractControl, FormArray, ValidatorFn, ValidationErrors } from '@angular/forms';
import { FormUtils } from 'sro-ngcomponent-library';
import { UIMessageService } from 'src/app/au/gov/vic/sro/dol-claim/service/ui-message.service';
import { DolClaimUIService } from 'src/app/au/gov/vic/sro/dol-claim/service/dol-claim-ui-service';
import { DolClaimService } from 'src/app/au/gov/vic/sro/dol-claim/service/dol-claim.service';
import { DutiesFormService } from 'src/app/au/gov/vic/sro/dol-claim/service/duties-form-service';
import { DolCategoryService } from 'src/app/au/gov/vic/sro/dol-claim/service/dol-claim-category.service';

import { Lodgement, SubCategory, Category, Form, Document, ClaimedForm } from 'src/app/au/gov/vic/sro/dol-claim/model/claim.interface';

@Component({
    selector: '[dol-elno-lodgement-claim-row]',
    templateUrl: './dol-elno-lodgement-claim-row.html',
    styleUrls: ['./dol-elno-lodgement-claim-row.scss']
})
export class DolElnoLodgementClaimRow implements OnInit {

	@Input()
	public index: number;

	@Input()
	private document : Document;

	@Input()
	private claimForm: FormGroup;


	public dutiesMatchForm : FormGroup;
	private dutiesFormId : FormControl;
	private propertyAddress? : FormControl;
	private claimedDutiesFormId : FormControl;


	constructor(private formBuilder: FormBuilder, private uiMessageService: UIMessageService,
		private dolClaimService: DolClaimService, private dolClaimUiService: DolClaimUIService, private dutiesFormService: DutiesFormService) {
	}

	ngOnInit() {
		this.buildForm();
	}

	buildForm() {
		this.dutiesFormId = new FormControl('', [Validators.required, this.propertyRequired, this.claimedFormIdChanged]);
		this.propertyAddress = new FormControl('');
		this.claimedDutiesFormId = new FormControl('');
		this.dutiesMatchForm = this.formBuilder.group({
			dutiesFormId : this.dutiesFormId,
			propertyAddress: this.propertyAddress,
			claimedDutiesFormId: this.claimedDutiesFormId,
		});
		this.claimForm.addControl("document" + this.document.documentId, this.dutiesMatchForm);
	}

	async onClaim() {
		this.dutiesFormId.markAsTouched();
		FormUtils.validate(this.dutiesFormId);
		let validationErors: ValidationErrors = this.dutiesFormId.errors;
		if (validationErors && validationErors['propertyRequired'] || validationErors['claimedFormIdChanged']) {
			this.dutiesFormId.setErrors(null);
		}


		if (this.dutiesMatchForm.valid) {
			let formId: string = this.dutiesMatchForm.get('dutiesFormId').value;
			let form : Form = await this.dutiesFormService.getForm(formId);
			if (form) {
				this.propertyAddress.setValue(form.property.address);
				this.claimedDutiesFormId.setValue(formId);

				this.dolClaimUiService.setClaimedForm({formId: formId, documentId: this.document.documentId});

			}
		}
	}

	isNotValid(control: AbstractControl, type?: string): boolean {
		if (!control) { return; }
		let notValid = FormUtils.isNotValid(control, type);
		return notValid;
	}

	//make sure property is populated for parent form level validations before submission
    propertyRequired (control: AbstractControl): ValidationErrors | null {
		if (control.parent) {
			let propertyAddressValue = control.parent.get('propertyAddress').value;
			if(control.value && !propertyAddressValue) {
				return { propertyRequired: "propertyAddressrequired"}
			}
		}
		return;
	}

	//make sure that formId has not be changed after claiming a form.
	claimedFormIdChanged (control: AbstractControl): ValidationErrors | null {
		if (control.parent &&  control.parent.get('claimedDutiesFormId')) {
			let claimedFormId : string = control.parent.get('claimedDutiesFormId').value;
			let formId = control.value;
			let propertyAddressValue = control.parent.get('propertyAddress').value;
			if(propertyAddressValue && formId && claimedFormId && claimedFormId !== formId ) {
				return { claimedFormIdChanged: "claimedFormIdChanged"}
			}
		}
		return;
	}

}
