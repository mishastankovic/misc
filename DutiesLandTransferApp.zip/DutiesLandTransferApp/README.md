# DutiesLandTransferApp

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 6.0.8.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `--prod` flag for a production build.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via [Protractor](http://www.protractortest.org/).

## Stubby
npm stubby can be used to stub any http back end service during front end development.

#### Installing stubby

`npm install -g stubby`

#### Running stubby

`npm run stubby`  

This command sets the port numbers that the stubby listens to.<br>
The default settings are `9444` for `https` and `9080` for `http`.<br>
To change these setting, edit the `stubby` command in the script section of `package.json`.

## Apache HTTP server configuration
#### Pass through proxy for the local environment
Reverse proxy configuraiton on the Apache server is used in order to re-direct DDP requests to a node server running locally.
This setup enables debugging in the browser environment while still integrating with the DDP and DOL WebSphere back end.  
To configure a proxy for the DDP endpoint, make the following changes to httpd.conf file:
- Uncomment proxy modules

`LoadModule proxy_module modules/mod_proxy.so`  
`LoadModule proxy_http_module modules/mod_proxy_http.so`
- Add proxy settings to <VirtualHost *:443>:
<p><code>
 ProxyPass     /dutieslandtransfer/     http://localhost:4200/dutieslandtransfer

</code>
</p>

- Restart HTTP server

- Start the local WebSphere instance with DOL and DDP
- Start local angular app using `npm run start`
- Open DDP in a browser: `https://localtest.e-business.sro.vic.gov.au/dutieslandtransfer/`  

The DDP front end `/dutieslandtransfer` is now served from the local node server and source map is available for debugging.  
Note that the DOL front end is still served from the WebSphere.  


## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).
