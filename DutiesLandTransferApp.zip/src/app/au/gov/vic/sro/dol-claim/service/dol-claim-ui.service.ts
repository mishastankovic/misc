import { Injectable } from "@angular/core";
import { Lodgement, ClaimedForm } from "../model/claim.interface";


@Injectable()
export class DolClaimUiService {

    private _lodgementCaseId: string;
    private _caseReferenceId: string;
    private _lodgement : Lodgement;
    
    private claimedForms : Map<string, ClaimedForm> = new Map<string, ClaimedForm>();


    constructor () {
    }

    clear() {
        this.lodgementCaseId = undefined;
        this.caseReferenceId = undefined;
        this.lodgement = undefined;
        this.claimedForms = new Map<string, ClaimedForm>();

    }

    public setClaimedForm(claimedForm: ClaimedForm) :void {
        this.claimedForms.set(claimedForm.documentId, claimedForm);
    }

    public getClaimLodgementData() {
        let data = {
            lodgementCaseId: this.lodgementCaseId,
            sroReferenceId: this.caseReferenceId,
            forms: []
        }

        this.claimedForms.forEach( (claimedForm) => {
            data.forms.push(claimedForm);
        });
        return data;
    }

    get lodgement(): Lodgement {
        return this._lodgement;
    }

    set lodgement(lodgement: Lodgement) {
        this._lodgement = lodgement;
    }

    get lodgementCaseId(): string {
        return this._lodgementCaseId;
    }

    set lodgementCaseId(val: string) {
        this._lodgementCaseId = val;
    }

    get caseReferenceId(): string {
        return this._caseReferenceId;
    }

    set caseReferenceId(val: string) {
        this._caseReferenceId = val;
    }
}