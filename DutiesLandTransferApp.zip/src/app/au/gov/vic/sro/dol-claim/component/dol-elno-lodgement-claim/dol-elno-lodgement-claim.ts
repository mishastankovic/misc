import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl, FormBuilder, Validators, AbstractControl } from '@angular/forms';
import { FormUtils } from 'sro-ngcomponent-library';
import { UIMessageService } from 'src/app/au/gov/vic/sro/dol-claim/service/ui-message.service';
import { DolClaimUiService } from 'src/app/au/gov/vic/sro/dol-claim/service/dol-claim-ui.service';
import { DolClaimService } from 'src/app/au/gov/vic/sro/dol-claim/service/dol-claim.service';
import { DolCategoryService } from 'src/app/au/gov/vic/sro/dol-claim/service/dol-claim-category.service';
import { Lodgement, SubCategory, Category, Form, ClaimedForm } from 'src/app/au/gov/vic/sro/dol-claim/model/claim.interface';

@Component({
    selector: '[dol-elno-lodgement-claim]',
    templateUrl: './dol-elno-lodgement-claim.html',
    styleUrls: ['./dol-elno-lodgement-claim.scss']
})
export class DolElnoLodgementClaim implements OnInit {


	public claimForm: FormGroup;
	private category: FormControl;
	private subCategory: FormControl;
	
	private categoryList : Category[];
	public subCategoryList : Category[];
	


	constructor(private formBuilder: FormBuilder,
				private router: Router,
				private _uiMessageService: UIMessageService,
				private dolClaimService: DolClaimService,
				public dolClaimUiService: DolClaimUiService,
				private dolCategoryService: DolCategoryService ) {
	}

	async ngOnInit() {
		await this.dolCategoryService.init();
		this.categoryList = this.dolCategoryService.getCategories();
		this.buildForm();
	}

	onSelectCategory(categoryCode: string) {
		this.subCategory.setValue('');
		this.subCategoryList = this.dolCategoryService.getSubCategories(categoryCode);
		if (this.subCategoryList && this.subCategoryList.length > 0 ) {
			this.subCategory.enable();
		} else {
			this.subCategory.disable();
		}
	}

	buildForm() {
		this.category = new FormControl('', Validators.compose([Validators.required]));
		this.subCategory = new FormControl('', Validators.compose([Validators.required]));

		this.claimForm = this.formBuilder.group({
			lodgementCaseId: this.dolClaimUiService.lodgementCaseId,
			sroReferenceId: this.dolClaimUiService.caseReferenceId,
			category : this.category,
			subCategory : this.subCategory
		});

	}

	onSubmit() {
		let url = 'https://localtest.e-business.sro.vic.gov.au/duties/faces/elno/claim.xhtml?transacti=4379480&lodgementId=1740456';

		console.log('submitting');
		FormUtils.validate(this.claimForm);
		if (this.claimForm.valid) {
			let data = this.dolClaimUiService.getClaimLodgementData();
			console.log('submitting data : ' + data);
			window.open(url, '_self');
		}
		
	}

	isNotValid(control: AbstractControl, type?: string): boolean {

		if (!control) { return; }
		return FormUtils.isNotValid(control, type);
	}

	get uiMessageService(): UIMessageService {
		return this._uiMessageService;
	}


}

