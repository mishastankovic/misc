import { HttpClient } from '@angular/common/http';
import { Injectable, EventEmitter, OnInit } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Lodgement, SubCategory, Category } from 'src/app/au/gov/vic/sro/dol-claim/model/claim.interface';



@Injectable()
export class DolCategoryService{
	protected basePath = environment.apiBasePath;
	private categoryList : Category[];

	constructor(protected http: HttpClient) {
	 }

	public async init() {
		if (!this.categoryList) {
			this.categoryList = await this.retreiveCategories();
		}
	}

	private async retreiveCategories(): Promise<Category[]> {
		const url = this.basePath + 'categories';
		return this.http.get<Category[]>(url).toPromise();
	}

	public getCategories(): Category[] {
		return this.categoryList;
	}

	public getSubCategories(categoryCode: string) : Category[] {
		let subCategories : Category[];
		if (this.categoryList) {
			this.categoryList.forEach(category => {
				if (category.categoryCode === categoryCode) {
					subCategories = category.subCategories;
				}
			})
		}
		return subCategories;
	}


}
