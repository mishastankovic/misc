export const environment = {
	production: false,
	//apiBasePath: '/dol/claim/',
	apiBasePath: '/dutiesservice/dol/claim/',
	formApiBasePath: '/dutiesformrest/',
	dolApiBasePath: '/duties/',
	serviceHostname: ''
};
