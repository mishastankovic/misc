package au.gov.vic.sro.autopay.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class FileUtil {

	public String resourceToString(String resourceLocation) throws IOException {

		try (InputStream is = FileUtil.class.getClassLoader().getResourceAsStream(resourceLocation)) {
			StringBuilder sb = new StringBuilder(1024);

			if (is == null) {
				throw new RuntimeException(String.format(
						"Unable to find the resource from class path; resourceLocation=[%s]", resourceLocation));
			}

			InputStreamReader isr = new InputStreamReader(is);
			int c;
			while ((c = isr.read()) > 0) {
				sb.append((char) c);
			}
			return sb.toString();

		} catch (IOException ioe) {
			throw new IOException(String.format("Failed to read from resource; resourceLocation=[%s] IOException=[%s]",
					resourceLocation, ioe));
		}
	}

}
