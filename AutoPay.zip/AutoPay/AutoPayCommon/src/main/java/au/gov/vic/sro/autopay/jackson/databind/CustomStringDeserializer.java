package au.gov.vic.sro.autopay.jackson.databind;

import java.io.IOException;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;

public class CustomStringDeserializer extends JsonDeserializer<String> {

	// Default no-arg constructor required by server
	public CustomStringDeserializer() {
		// Server complains if the non argument constructor is not present.
	}

	@Override
	public String deserialize(JsonParser jsonparser, DeserializationContext context) throws IOException {
		return StringUtils.trimToNull(jsonparser.getText());
	}

}