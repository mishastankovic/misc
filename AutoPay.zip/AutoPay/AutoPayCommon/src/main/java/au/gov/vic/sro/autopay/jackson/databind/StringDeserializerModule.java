package au.gov.vic.sro.autopay.jackson.databind;

import com.fasterxml.jackson.core.Version;
import com.fasterxml.jackson.databind.module.SimpleModule;

public class StringDeserializerModule extends SimpleModule {

	private static final long serialVersionUID = -3407522971531464929L;

	public StringDeserializerModule() {
		super("SimpleModule", new Version(1, 0, 0, null, "SRO.Common", "JsonModule"));
		this.addDeserializer(String.class, new CustomStringDeserializer());
	}

}
