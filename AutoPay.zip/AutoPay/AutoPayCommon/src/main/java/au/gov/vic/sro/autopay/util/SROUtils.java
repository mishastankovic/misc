package au.gov.vic.sro.autopay.util;

import org.apache.commons.lang3.StringUtils;

public class SROUtils {

	private SROUtils() {
		// does not require instantiation
	}

	public static String nullSafeAdd(String... str) {
		StringBuilder sb = new StringBuilder();
		for (String s : str) {
			nullSafeAppend(sb, s);
		}
		return sb.toString();
	}

	public static StringBuilder nullSafeAppend(StringBuilder sb, String str) {
		if ((str != null) && (str.trim().length() > 0)) {
			if (sb.length() > 0) {
				sb.append(' ');
			}
			sb.append(str);
		}
		return sb;
	}

	/**
	 * This method is to be used for validating SRO IDs as requested by the State Revenue Office.<br>
	 * It implements the SRO provided algorithm for determining if an ID is correct and returns true if so otherwise
	 * false.
	 * 
	 * @param identifier the id in string form.
	 * @param offset this is added to the final result to get the check digit
	 * 
	 * @return true if the id is valid, otherwise false.
	 */
	public static boolean validateCustomerIdentifier(String identifier) {
		return validateIdentifier(identifier, 1);
	}

	public static boolean validateCorrespondenceIdentifier(String identifier) {
		return validateIdentifier(identifier, 0);
	}

	public static boolean validateAssessmentIdentifier(String identifier) {
		return validateAssessmentIdentifier(identifier, 0) || validateAssessmentIdentifier(identifier, 2);
	}

	private static boolean validateIdentifier(String identifier, int offset) {

		final int minLength = 1;

		// remove any leading/trailing spaces
		String formattedIdentifier = StringUtils.trimToNull(identifier);
		if (formattedIdentifier == null || formattedIdentifier.length() < minLength
				|| !StringUtils.isNumeric(formattedIdentifier))
			return false;

		int result = 0;
		int expectedResult = Character.getNumericValue(formattedIdentifier.charAt(formattedIdentifier.length() - 1));

		// Step 1 - Take the id and multiply digits from second right most digit to left most digit by 2
		// incrementing multiply factor by one for next digit.

		// Step 2 - Sum up the products of step one.
		for (int index = (formattedIdentifier.length() - 2), multiplyFactor =
				2; index >= 0; index--, multiplyFactor++) {
			result += (Character.getNumericValue(formattedIdentifier.charAt(index)) * multiplyFactor);
		}

		final int checkDigit = (((10 - (result % 10)) % 10) + offset) % 10;

		return checkDigit == expectedResult;
	}

	/**
	 * This method is to be used for validating SRO Assessment IDs as requested by the State Revenue Office.<br>
	 * It implements the SRO provided algorithm for determining if an assessment ID is correct and returns true if so
	 * otherwise false.
	 * 
	 * @param identifier the id in string form.
	 * @param addTo this is added to the final result to get the check digit
	 * 
	 * @return true if the id is valid, otherwise false.
	 */
	private static boolean validateAssessmentIdentifier(String identifier, int offset) {

		final int numberOfDigits = 8;

		String formattedIdentifier = StringUtils.trimToNull(identifier);
		if (formattedIdentifier == null || !StringUtils.isNumeric(formattedIdentifier)
				|| formattedIdentifier.length() > numberOfDigits)
			return false;

		// strip off check digit
		final String paddedIdentifier = StringUtils
				.leftPad(formattedIdentifier.substring(0, formattedIdentifier.length() - 1), numberOfDigits, "0");

		int result = 0;
		int expectedResult = Character.getNumericValue(identifier.charAt(identifier.length() - 1));

		for (int index = 0, digit = 1, multiplier =
				10 - numberOfDigits; index < numberOfDigits; index++, digit++, multiplier++) {
			result += (multiplier
					* Character.getNumericValue(paddedIdentifier.charAt(paddedIdentifier.length() - digit)));
		}

		final int checkDigit = (((10 - (result % 10)) % 10) + offset) % 10;

		return checkDigit == expectedResult;
	}
}
