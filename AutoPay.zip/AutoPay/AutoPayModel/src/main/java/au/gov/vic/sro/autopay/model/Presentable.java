package au.gov.vic.sro.autopay.model;

/**
 * A presentable object has a label for presentation.
 */
public interface Presentable {

	String getLabel();

}
