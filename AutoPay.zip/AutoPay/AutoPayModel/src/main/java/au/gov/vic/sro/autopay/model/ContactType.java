package au.gov.vic.sro.autopay.model;

import java.util.HashMap;
import java.util.Map;

/**
 * A contact has a type.
 */
public enum ContactType implements Presentable, Codified {
	CUSTOMER("C", "Customer"),
	CUSTOMER_REP("R", "Customer representative");

	private static final Map<String, ContactType> codeMap;

	private String code;
	private String label;

	static {
		codeMap = new HashMap<String, ContactType>();
		for (ContactType value : values()) {
			codeMap.put(value.getCode(), value);
		}
	}

	private ContactType(String code, String label) {
		this.code = code;
		this.label = label;
	}

	@Override
	public String getCode() {
		return code;
	}

	@Override
	public String getLabel() {
		return label;
	}

	public static ContactType fromCode(String code) {
		return codeMap.get(code);
	}

	public static String toCode(ContactType value) {
		return value == null ? null : value.getCode();
	}

}
