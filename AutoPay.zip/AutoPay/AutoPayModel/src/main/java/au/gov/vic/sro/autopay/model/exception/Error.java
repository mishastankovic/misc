package au.gov.vic.sro.autopay.model.exception;

import java.util.Objects;

import io.swagger.annotations.ApiModelProperty;

public class Error {

	private String errorCode = null;
	private String errorText = null;
	private String errorLocation = null;

	public Error errorCode(String errorCode) {
		this.errorCode = errorCode;
		return this;
	}

	@ApiModelProperty(value = "")
	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public Error errorText(String errorText) {
		this.errorText = errorText;
		return this;
	}

	@ApiModelProperty(value = "")
	public String getErrorText() {
		return errorText;
	}

	public void setErrorText(String errorText) {
		this.errorText = errorText;
	}

	public Error errorLocation(String errorLocation) {
		this.errorLocation = errorLocation;
		return this;
	}

	@ApiModelProperty(value = "")
	public String getErrorLocation() {
		return errorLocation;
	}

	public void setErrorLocation(String errorLocation) {
		this.errorLocation = errorLocation;
	}

	@Override
	public boolean equals(java.lang.Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		Error error = (Error) o;
		return Objects.equals(errorCode, error.errorCode) && Objects.equals(errorText, error.errorText)
				&& Objects.equals(errorLocation, error.errorLocation);
	}

	@Override
	public int hashCode() {
		return Objects.hash(errorCode, errorText, errorLocation);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class Error {\n");

		sb.append("    errorCode: ").append(toIndentedString(errorCode)).append("\n");
		sb.append("    errorText: ").append(toIndentedString(errorText)).append("\n");
		sb.append("    errorLocation: ").append(toIndentedString(errorLocation)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}
}
