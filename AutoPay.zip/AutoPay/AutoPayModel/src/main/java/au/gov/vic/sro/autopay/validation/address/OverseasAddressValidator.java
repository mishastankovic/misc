package au.gov.vic.sro.autopay.validation.address;

import static au.gov.vic.sro.autopay.validation.util.ValidationHelper.extractValidationError;

import org.apache.commons.lang3.StringUtils;

import com.baidu.unbiz.fluentvalidator.Validator;
import com.baidu.unbiz.fluentvalidator.ValidatorContext;
import com.baidu.unbiz.fluentvalidator.ValidatorHandler;

import au.gov.vic.sro.autopay.model.address.Address;

public class OverseasAddressValidator extends ValidatorHandler<Address> implements Validator<Address> {

	public static final String AUSTRALIA_CODE = "AUS";

	@Override
	public boolean validate(ValidatorContext context, Address address) {
		boolean isValid = true;

		if (!address.determineIsOverseasAddress()) return isValid;

		if (!validateOverseasAddress(context, address)) {
			isValid = false;
		}
		return isValid;
	}

	private boolean validateOverseasAddress(ValidatorContext context, Address address) {
		boolean isValid = true;

		String overseasAddressLine1 = StringUtils.trimToNull(address.getOverseasAddressLine1());
		if (overseasAddressLine1 == null) {
			context.addError(extractValidationError("overseasAddressLine1", "overseasAddressLine1.mandatory"));
			isValid = false;
		}

		if (address.getCountry() == null) {
			context.addError(extractValidationError("country", "country.mandatory"));
			isValid = false;
		}

		if (address.getCountry() != null && address.getCountry().equals(AUSTRALIA_CODE)) {
			context.addError(extractValidationError("country", "country.invalid"));
			isValid = false;
		}

		return isValid;
	}

}
