package au.gov.vic.sro.autopay.validation.identity;

import static org.apache.commons.lang3.StringUtils.isAllEmpty;
import static org.apache.commons.lang3.StringUtils.isNotBlank;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.baidu.unbiz.fluentvalidator.ValidationError;
import com.baidu.unbiz.fluentvalidator.Validator;
import com.baidu.unbiz.fluentvalidator.ValidatorContext;
import com.baidu.unbiz.fluentvalidator.ValidatorHandler;

import au.gov.vic.sro.autopay.model.identity.CustomerIdentity;
import au.gov.vic.sro.autopay.util.SROUtils;

public class CustomerIdentityValidator extends ValidatorHandler<CustomerIdentity>
		implements Validator<CustomerIdentity> {

	private static final Logger log = LoggerFactory.getLogger(CustomerIdentityValidator.class);

	@Override
	public boolean validate(ValidatorContext context, CustomerIdentity customerIdentity) {
		return validateCustomerIdentity(context, customerIdentity);
	}

	private boolean validateCustomerIdentity(ValidatorContext context, CustomerIdentity customerIdentity) {
		boolean isValid = true;
		StringBuilder logMessage = new StringBuilder("Customer identity validation failed; ");

		if (customerIdentity == null || isAllEmpty(customerIdentity.getCorrespondenceId(),
				customerIdentity.getCustomerId(), customerIdentity.getLtxAssessmentId(),
				customerIdentity.getPreviousReceiptNumber(), customerIdentity.getAssessmentId())) {
			isValid = false;
			logMessage.append(
					"Correspondence number, Customer number, Reference ID, Vacant residential land tax assessment number, Land tax assessment number not provided.");
		}

		if (isValid && isNotBlank(customerIdentity.getCorrespondenceId())) {
			isValid = SROUtils.validateCorrespondenceIdentifier(customerIdentity.getCorrespondenceId());			
			if (!isValid) appendLogMessage(logMessage, "Correspondence number", customerIdentity.getCorrespondenceId());
		}

		if (isValid && isNotBlank(customerIdentity.getCustomerId())) {
			isValid = SROUtils.validateCustomerIdentifier(customerIdentity.getCustomerId());
			if (!isValid) appendLogMessage(logMessage, "Customer number", customerIdentity.getCustomerId());
		}

		if (isValid && isNotBlank(customerIdentity.getLtxAssessmentId())) {
			isValid = SROUtils.validateAssessmentIdentifier(customerIdentity.getLtxAssessmentId());
			if (!isValid) appendLogMessage(logMessage, "VLT assessment number", customerIdentity.getLtxAssessmentId());
		}

		if (isValid && isNotBlank(customerIdentity.getPreviousReceiptNumber())) {
			isValid = validateReceiptNumber(customerIdentity.getPreviousReceiptNumber(),20);
			if (!isValid) appendLogMessage(logMessage, "Reference ID", customerIdentity.getPreviousReceiptNumber());
		}

		if (isValid && isNotBlank(customerIdentity.getAssessmentId())) {
			isValid = SROUtils.validateAssessmentIdentifier(customerIdentity.getAssessmentId());
			if (!isValid) appendLogMessage(logMessage, "Assessment number", customerIdentity.getAssessmentId());
		}

		if (!isValid) {
			ValidationError error = new ValidationError();
			if (log.isDebugEnabled()) log.debug(logMessage.toString());
			error.setErrorMsg(logMessage.toString());
			context.addError(error);
		}

		return isValid;
	}

	private void appendLogMessage(StringBuilder sb, String identifierType, String identifier) {
		sb.append(identifierType).append(" [").append(identifier).append("] in not valid");
	}
	
	private boolean validateReceiptNumber(String identifier, int maxLength ){
		String formattedIdentifier = StringUtils.trimToNull(identifier);
		if (formattedIdentifier == null || !StringUtils.isNumeric(formattedIdentifier)
				|| formattedIdentifier.length() > maxLength)
			return false;
		return true;
	}
}