package au.gov.vic.sro.autopay.model;

import static au.gov.vic.sro.builder.ToStringStyleFactory.getToStringStyle;

import java.io.Serializable;
import java.util.Collection;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

/**
 * An arrangement has contact details.
 */
public class Contact implements Serializable {
	private static final long serialVersionUID = -2479478185326513035L;
	public static final Contact[] EMPTY_CONTACT_ARRAY = {};

	private ContactType type;
	private String personName;
	private String emailAddress;
	private String mobilePhone;
	private String reminderEmails;
	// Parent.
	private Arrangement arrangement;

	public Contact() {

	}

	public Contact(Contact contact) {
		if (contact != null) {
			type = contact.getType();
			personName = contact.getPersonName();
			emailAddress = contact.getEmailAddress();
			mobilePhone = contact.getMobilePhone();
			arrangement = contact.getArrangement();
			reminderEmails = contact.getReminderEmails();
		}
	}

	public static Contact[] toArray(Collection<Contact> contacts) {
		if (contacts == null) {
			return null;
		}
		if (contacts.isEmpty()) {
			return EMPTY_CONTACT_ARRAY;
		}
		return contacts.toArray(new Contact[contacts.size()]);
	}

	public static Contact[] toArray(Collection<Contact> contacts, boolean nullToEmpty) {
		Contact[] arr = toArray(contacts);
		return arr == null && nullToEmpty ? EMPTY_CONTACT_ARRAY : arr;
	}

	public ContactType getType() {
		return type;
	}

	public void setType(ContactType type) {
		this.type = type;
	}

	public String getPersonName() {
		return personName;
	}

	public void setPersonName(String personName) {
		this.personName = personName;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getMobilePhone() {
		return mobilePhone;
	}

	public void setMobilePhone(String mobilePhone) {
		this.mobilePhone = mobilePhone;
	}

	public Arrangement getArrangement() {
		return arrangement;
	}

	public void setArrangement(Arrangement arrangement) {
		this.arrangement = arrangement;
	}

	public String getReminderEmails() {
		return reminderEmails;
	}

	public void setReminderEmails(String reminderEmails) {
		this.reminderEmails = reminderEmails;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, getToStringStyle());
	}

}
