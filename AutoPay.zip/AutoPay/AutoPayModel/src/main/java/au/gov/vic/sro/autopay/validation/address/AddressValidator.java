package au.gov.vic.sro.autopay.validation.address;

import static au.gov.vic.sro.autopay.validation.util.ValidationHelper.extractValidationError;
import static org.apache.commons.lang3.StringUtils.isBlank;
import static org.apache.commons.lang3.StringUtils.trimToNull;

import com.baidu.unbiz.fluentvalidator.Validator;
import com.baidu.unbiz.fluentvalidator.ValidatorContext;
import com.baidu.unbiz.fluentvalidator.ValidatorHandler;

import au.gov.vic.sro.autopay.model.address.Address;

public class AddressValidator extends ValidatorHandler<Address> implements Validator<Address> {

	@Override
	public boolean validate(ValidatorContext context, Address address) {
		boolean isValid = true;

		if (!address.determineIsFreeTextAddress()) return isValid;

		if (!validateAddress(context, address)) {
			isValid = false;
		}

		return isValid;
	}

	private boolean validateAddress(ValidatorContext context, Address address) {
		boolean isValid = true;

		String lineAddress = trimToNull(address.getAddressLine());
		if (lineAddress == null) {
			context.addError(extractValidationError("addressLine", "addressLine.mandatory"));
			isValid = false;
		}

		if (isBlank(address.getRoadNumberFrom()) || isBlank(address.getRoadName()) || isBlank(address.getLocalityName())
				|| isBlank(address.getPostcode()) || isBlank(address.getStateTerritory())) {
			context.addError(extractValidationError("addressLine", "addressLine.invalid"));
			isValid = false;
		}

		return isValid;
	}

}
