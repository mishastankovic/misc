package au.gov.vic.sro.autopay.model;

import java.util.HashMap;
import java.util.Map;

/**
 * A message has a type.
 */
public enum MessageType implements Presentable, Codified {
	INFO("I", "INFO"),
	ERROR("E", "ERROR");

	private static final Map<String, MessageType> codeMap;

	private String code;
	private String label;

	static {
		codeMap = new HashMap<String, MessageType>();
		for (MessageType value : values()) {
			codeMap.put(value.getCode(), value);
		}
	}

	private MessageType(String code, String label) {
		this.code = code;
		this.label = label;
	}

	@Override
	public String getCode() {
		return code;
	}

	@Override
	public String getLabel() {
		return label;
	}

	public static MessageType fromCode(String code) {
		return codeMap.get(code);
	}

	public static String toCode(MessageType value) {
		return value == null ? null : value.getCode();
	}

}
