package au.gov.vic.sro.autopay.validation.address;

import static au.gov.vic.sro.autopay.validation.util.ValidationHelper.extractValidationError;

import org.apache.commons.lang3.StringUtils;

import com.baidu.unbiz.fluentvalidator.Validator;
import com.baidu.unbiz.fluentvalidator.ValidatorContext;
import com.baidu.unbiz.fluentvalidator.ValidatorHandler;

import au.gov.vic.sro.autopay.model.address.Address;

public class PostalAddressValidator extends ValidatorHandler<Address> implements Validator<Address> {

	@Override
	public boolean validate(ValidatorContext context, Address address) {
		boolean isValid = true;

		if (!address.determineIsPostalAddress()) return isValid;

		if (!validatePostalAddress(context, address)) {
			isValid = false;
		}
		return isValid;
	}

	private boolean validatePostalAddress(ValidatorContext context, Address address) {
		boolean isValid = true;

		String postalDeliveryType = StringUtils.trimToNull(address.getPostalDeliveryType());
		if (postalDeliveryType == null) {
			context.addError(extractValidationError("postalDeliveryType", "postalDeliveryType.mandatory"));
			isValid = false;
		}

		String postalDeliveryNumber = StringUtils.trimToNull(address.getPostalDeliveryNumber());
		if (postalDeliveryNumber == null) {
			context.addError(extractValidationError("postalDeliveryNumber", "postalDeliveryNumber.mandatory"));
			isValid = false;
		}

		String localityName = StringUtils.trimToNull(address.getLocalityName());
		if (localityName == null) {
			context.addError(extractValidationError("localityName", "localityName.mandatory"));
			isValid = false;
		}

		String postcode = StringUtils.trimToNull(address.getPostcode());
		if (postcode == null) {
			context.addError(extractValidationError("postcode", "postcode.mandatory"));
			isValid = false;
		}

		if (address.getStateTerritory() == null) {
			context.addError(extractValidationError("stateTerritoryCode", "stateTerritoryCode.mandatory"));
			isValid = false;
		}

		return isValid;
	}

}
