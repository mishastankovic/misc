package au.gov.vic.sro.autopay.validation.constraint;

import java.io.Serializable;
import java.util.regex.Pattern;

public class EmailChecker implements Serializable {

	private static final long serialVersionUID = 605860420241399361L;

	private static final String LOCAL_ATOM = "[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]";
	private static final String DOMAIN_ATOM = "[a-zA-Z0-9-]";
	private static final String DOMAIN = "(" + DOMAIN_ATOM + "+(\\." + DOMAIN_ATOM + "+)*";
	private static final String IP_DOMAIN = "\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\]";
	private static final Pattern EMAIL_PATTERN =
			Pattern.compile("^" + LOCAL_ATOM + "+(\\." + LOCAL_ATOM + "+)*@" + DOMAIN + "|" + IP_DOMAIN + ")$");

	private static String atSymbol = "@";
	private static String period = ".";

	public static boolean isValid(String emailAddress) {
		return emailAddress != null && EMAIL_PATTERN.matcher(emailAddress).matches()
				&& checkADotIsInDomainName(emailAddress);
	}

	private static boolean checkADotIsInDomainName(String emailAddress) {
		if (emailAddress == null) {
			return false;
		}

		StringBuilder address = new StringBuilder(emailAddress);

		int lastPositionOfAt = address.lastIndexOf(atSymbol);
		int firstPositionOfAt = address.indexOf(atSymbol);

		if (lastPositionOfAt != firstPositionOfAt) {
			return false;
		}

		String domainName = address.substring(firstPositionOfAt);

		int dotPosition = domainName.indexOf(period);

		return dotPosition == -1 ? false : true;
	}

}
