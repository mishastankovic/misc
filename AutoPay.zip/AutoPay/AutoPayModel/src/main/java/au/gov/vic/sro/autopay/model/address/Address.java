package au.gov.vic.sro.autopay.model.address;

import static au.gov.vic.sro.autopay.model.address.AddressFormatType.FREETEXT;
import static au.gov.vic.sro.autopay.model.address.AddressFormatType.HOUSE_BUILDING_SHOP;
import static au.gov.vic.sro.autopay.model.address.AddressFormatType.LOT;
import static au.gov.vic.sro.autopay.model.address.AddressFormatType.OVERSEAS;
import static au.gov.vic.sro.autopay.model.address.AddressFormatType.POSTAL_BOX;

import java.io.Serializable;
import java.util.Objects;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;

import au.gov.vic.sro.model.address.Addressable;
import io.swagger.annotations.ApiModelProperty;

public class Address implements Addressable, Serializable {

	private static final long serialVersionUID = -6534365145055884601L;

	@NotNull(message = "{addressFormatType.mandatory}")
	@Length(max = 100)
	private String addressFormatType;

	@Length(max = 120, message = "{addressLine.length}")
	private String addressLine;

	private String flatUnitType;

	@Length(max = 7, message = "{flatUnitNumber.length}")
	private String flatUnitNumber;

	private String floorLevelType;

	@Length(max = 5, message = "{floorLevelNumber.length}")
	private String floorLevelNumber;

	@Length(max = 30, message = "{buildingName.length}")
	private String buildingName;

	@Length(max = 6, message = "{lotNumber.length}")
	private String lotNumber;

	@Length(max = 6, message = "{roadNumberFrom.length}")
	@Pattern(regexp = "^[0-9]{1,5}[a-zA-Z]?$", message = "{roadNumberFrom.pattern}")
	private String roadNumberFrom;

	private String roadNumberFromSuffix;

	@Length(max = 6, message = "{roadNumberTo.length}")
	@Pattern(regexp = "^[0-9]{1,5}[a-zA-Z]?$", message = "{roadNumberTo.pattern}")
	private String roadNumberTo;

	private String roadNumberToSuffix;

	@Length(max = 30, message = "{roadName.length}")
	private String roadName;

	@Length(max = 4, message = "{roadType.length}")
	private String roadType;

	@Length(max = 2, message = "{roadSuffixType.length}")
	private String roadSuffixType;

	@Length(max = 100, message = "{postalDeliveryType.length}")
	private String postalDeliveryType;

	@Length(max = 3, message = "{deliveryPrefix.length}")
	private String postalDeliveryPrefix;

	@Length(max = 5, message = "{deliveryNumber.length}")
	private String postalDeliveryNumber;

	@Length(max = 3, message = "{deliverySuffix.length}")
	private String postalDeliverySuffix;

	@Length(max = 46, message = "{localityName.length}")
	private String localityName;

	@Pattern(regexp = "[0-9]{4}", message = "{postcode.pattern}")
	@Length(max = 4, message = "{postcode.length}")
	private String postcode;

	@Length(max = 100, message = "{stateTerritory.length}")
	private String stateTerritory;

	@Length(max = 60, message = "{overseasAddressLine1.length}")
	private String overseasAddressLine1;

	@Length(max = 60, message = "{overseasAddressLine2.length}")
	private String overseasAddressLine2;

	@Length(max = 60, message = "{overseasAddressLine3.length}")
	private String overseasAddressLine3;

	@Length(max = 100, message = "{country.length}")
	private String country;

	public Address addressFormatType(String addressFormatType) {
		this.addressFormatType = addressFormatType;
		return this;
	}

	@ApiModelProperty(example = "STREET / LOT / POSTAL / OVERSEAS", value = "")
	public String getAddressFormatType() {
		return addressFormatType;
	}

	public void setAddressFormatType(String addressFormatType) {
		this.addressFormatType = addressFormatType;
	}

	public Address addressLine(String addressLine) {
		this.addressLine = addressLine;
		return this;
	}

	@ApiModelProperty(example = "2 Smith Street Fitzroy VIC 3065", value = "")
	public String getAddressLine() {
		return addressLine;
	}

	public void setAddressLine(String addressLine) {
		this.addressLine = addressLine;
	}

	public Address flatUnitType(String flatUnitType) {
		this.flatUnitType = flatUnitType;
		return this;
	}

	@ApiModelProperty(example = "FL (Flat)", value = "")
	public String getFlatUnitType() {
		return flatUnitType;
	}

	public void setFlatUnitType(String flatUnitType) {
		this.flatUnitType = flatUnitType;
	}

	public Address flatUnitNumber(String flatUnitNumber) {
		this.flatUnitNumber = flatUnitNumber;
		return this;
	}

	@ApiModelProperty(example = "12 (eg Flat 12)", value = "")
	public String getFlatUnitNumber() {
		return flatUnitNumber;
	}

	public void setFlatUnitNumber(String flatUnitNumber) {
		this.flatUnitNumber = flatUnitNumber;
	}

	public Address floorLevelType(String floorLevelType) {
		this.floorLevelType = floorLevelType;
		return this;
	}

	@ApiModelProperty(example = "F (Floor)", value = "")
	public String getFloorLevelType() {
		return floorLevelType;
	}

	public void setFloorLevelType(String floorLevelType) {
		this.floorLevelType = floorLevelType;
	}

	public Address floorLevelNumber(String floorLevelNumber) {
		this.floorLevelNumber = floorLevelNumber;
		return this;
	}

	@ApiModelProperty(example = "1 (eg Floor 1)", value = "")
	public String getFloorLevelNumber() {
		return floorLevelNumber;
	}

	public void setFloorLevelNumber(String floorLevelNumber) {
		this.floorLevelNumber = floorLevelNumber;
	}

	public Address buildingName(String buildingName) {
		this.buildingName = buildingName;
		return this;
	}

	@ApiModelProperty(example = "Efron Towers", value = "")
	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public Address lotNumber(String lotNumber) {
		this.lotNumber = lotNumber;
		return this;
	}

	@ApiModelProperty(example = "40 (Lot", value = "")
	public String getLotNumber() {
		return lotNumber;
	}

	public void setLotNumber(String lotNumber) {
		this.lotNumber = lotNumber;
	}

	public Address roadNumberFrom(String roadNumberFrom) {
		this.roadNumberFrom = roadNumberFrom;
		return this;
	}

	@ApiModelProperty(example = "7A", value = "")
	public String getRoadNumberFrom() {
		return roadNumberFrom;
	}

	public void setRoadNumberFrom(String roadNumberFrom) {
		this.roadNumberFrom = roadNumberFrom;
	}

	public Address roadNumberFromSuffix(String roadNumberFromSuffix) {
		this.roadNumberFromSuffix = roadNumberFromSuffix;
		return this;
	}

	@ApiModelProperty(example = "A", value = "")
	public String getRoadNumberFromSuffix() {
		return roadNumberFromSuffix;
	}

	public void setRoadNumberFromSuffix(String roadNumberFromSuffix) {
		this.roadNumberFromSuffix = roadNumberFromSuffix;
	}

	public Address roadNumberTo(String roadNumberTo) {
		this.roadNumberTo = roadNumberTo;
		return this;
	}

	@ApiModelProperty(example = "16B", value = "")
	public String getRoadNumberTo() {
		return roadNumberTo;
	}

	public void setRoadNumberTo(String roadNumberTo) {
		this.roadNumberTo = roadNumberTo;
	}

	public Address roadNumberToSuffix(String roadNumberToSuffix) {
		this.roadNumberToSuffix = roadNumberToSuffix;
		return this;
	}

	@ApiModelProperty(example = "16B", value = "")
	public String getRoadNumberToSuffix() {
		return roadNumberToSuffix;
	}

	public void setRoadNumberToSuffix(String roadNumberToSuffix) {
		this.roadNumberToSuffix = roadNumberToSuffix;
	}

	public Address roadName(String roadName) {
		this.roadName = roadName;
		return this;
	}

	@ApiModelProperty(example = "Smith eg. (Smith St Fitzroy)", value = "")
	public String getRoadName() {
		return roadName;
	}

	public void setRoadName(String roadName) {
		this.roadName = roadName;
	}

	public Address roadType(String roadType) {
		this.roadType = roadType;
		return this;
	}

	@ApiModelProperty(example = "ST eg. (Street)", value = "")
	public String getRoadType() {
		return roadType;
	}

	public void setRoadType(String roadType) {
		this.roadType = roadType;
	}

	public Address roadSuffixType(String roadSuffixType) {
		this.roadSuffixType = roadSuffixType;
		return this;
	}

	@ApiModelProperty(example = "S (South)", value = "")
	public String getRoadSuffixType() {
		return roadSuffixType;
	}

	public void setRoadSuffixType(String roadSuffixType) {
		this.roadSuffixType = roadSuffixType;
	}

	public Address postalDeliveryType(String postalDeliveryType) {
		this.postalDeliveryType = postalDeliveryType;
		return this;
	}

	@ApiModelProperty(example = "PO BOX", value = "")
	public String getPostalDeliveryType() {
		return postalDeliveryType;
	}

	public void setPostalDeliveryType(String postalDeliveryType) {
		this.postalDeliveryType = postalDeliveryType;
	}

	public Address postalDeliveryPrefix(String postalDeliveryPrefix) {
		this.postalDeliveryPrefix = postalDeliveryPrefix;
		return this;
	}

	@ApiModelProperty(value = "")
	public String getPostalDeliveryPrefix() {
		return postalDeliveryPrefix;
	}

	public void setPostalDeliveryPrefix(String postalDeliveryPrefix) {
		this.postalDeliveryPrefix = postalDeliveryPrefix;
	}

	public Address postalDeliveryNumber(String postalDeliveryNumber) {
		this.postalDeliveryNumber = postalDeliveryNumber;
		return this;
	}

	@ApiModelProperty(value = "")
	public String getPostalDeliveryNumber() {
		return postalDeliveryNumber;
	}

	public void setPostalDeliveryNumber(String postalDeliveryNumber) {
		this.postalDeliveryNumber = postalDeliveryNumber;
	}

	public Address postalDeliverySuffix(String postalDeliverySuffix) {
		this.postalDeliverySuffix = postalDeliverySuffix;
		return this;
	}

	@ApiModelProperty(value = "")
	public String getPostalDeliverySuffix() {
		return postalDeliverySuffix;
	}

	public void setPostalDeliverySuffix(String postalDeliverySuffix) {
		this.postalDeliverySuffix = postalDeliverySuffix;
	}

	public Address localityName(String localityName) {
		this.localityName = localityName;
		return this;
	}

	@ApiModelProperty(example = "Melbourne", value = "")
	public String getLocalityName() {
		return localityName;
	}

	public void setLocalityName(String localityName) {
		this.localityName = localityName;
	}

	public Address postcode(String postcode) {
		this.postcode = postcode;
		return this;
	}

	@ApiModelProperty(example = "3000", value = "")
	public String getPostcode() {
		return postcode;
	}

	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}

	public Address stateTerritory(String stateTerritory) {
		this.stateTerritory = stateTerritory;
		return this;
	}

	@ApiModelProperty(example = "VIC", value = "")
	public String getStateTerritory() {
		return stateTerritory;
	}

	public void setStateTerritory(String stateTerritory) {
		this.stateTerritory = stateTerritory;
	}

	public Address overseasAddressLine1(String overseasAddressLine1) {
		this.overseasAddressLine1 = overseasAddressLine1;
		return this;
	}

	@ApiModelProperty(value = "")
	public String getOverseasAddressLine1() {
		return overseasAddressLine1;
	}

	public void setOverseasAddressLine1(String overseasAddressLine1) {
		this.overseasAddressLine1 = overseasAddressLine1;
	}

	public Address overseasAddressLine2(String overseasAddressLine2) {
		this.overseasAddressLine2 = overseasAddressLine2;
		return this;
	}

	@ApiModelProperty(value = "")
	public String getOverseasAddressLine2() {
		return overseasAddressLine2;
	}

	public void setOverseasAddressLine2(String overseasAddressLine2) {
		this.overseasAddressLine2 = overseasAddressLine2;
	}

	public Address overseasAddressLine3(String overseasAddressLine3) {
		this.overseasAddressLine3 = overseasAddressLine3;
		return this;
	}

	@ApiModelProperty(value = "")
	public String getOverseasAddressLine3() {
		return overseasAddressLine3;
	}

	public void setOverseasAddressLine3(String overseasAddressLine3) {
		this.overseasAddressLine3 = overseasAddressLine3;
	}

	public Address country(String country) {
		this.country = country;
		return this;
	}

	@ApiModelProperty(example = "Australia", value = "")
	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public boolean determineIsFreeTextAddress() {
		return FREETEXT.getCode().equals(getAddressFormatType());
	}

	public boolean determineIsStreetAddress() {
		return HOUSE_BUILDING_SHOP.getCode().equals(getAddressFormatType());
	}

	public boolean determineIsLotAddress() {
		return LOT.getCode().equals(getAddressFormatType());
	}

	public boolean determineIsPostalAddress() {
		return POSTAL_BOX.getCode().equals(getAddressFormatType());
	}

	public boolean determineIsOverseasAddress() {
		return OVERSEAS.getCode().equals(getAddressFormatType());
	}

	public boolean determineIsStructuredAddress() {
		return AddressFormatType.isStructuredAddress(getAddressFormatType());
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}

		if (o == null || getClass() != o.getClass()) {
			return false;
		}

		Address address = (Address) o;
		// @formatter:off
		return Objects.equals(addressFormatType, address.addressFormatType)
				&& Objects.equals(addressLine, address.addressLine)
				&& Objects.equals(flatUnitType, address.flatUnitType)
				&& Objects.equals(flatUnitNumber, address.flatUnitNumber)
				&& Objects.equals(floorLevelType, address.floorLevelType)
				&& Objects.equals(floorLevelNumber, address.floorLevelNumber)
				&& Objects.equals(buildingName, address.buildingName) && Objects.equals(lotNumber, address.lotNumber)
				&& Objects.equals(roadNumberFrom, address.roadNumberFrom)
				&& Objects.equals(roadNumberFromSuffix, address.roadNumberFromSuffix)
				&& Objects.equals(roadNumberTo, address.roadNumberTo)
				&& Objects.equals(roadNumberToSuffix, address.roadNumberToSuffix)
				&& Objects.equals(roadName, address.roadName) && Objects.equals(roadType, address.roadType)
				&& Objects.equals(roadSuffixType, address.roadSuffixType)
				&& Objects.equals(postalDeliveryType, address.postalDeliveryType)
				&& Objects.equals(postalDeliveryPrefix, address.postalDeliveryPrefix)
				&& Objects.equals(postalDeliveryNumber, address.postalDeliveryNumber)
				&& Objects.equals(postalDeliverySuffix, address.postalDeliverySuffix)
				&& Objects.equals(localityName, address.localityName) && Objects.equals(postcode, address.postcode)
				&& Objects.equals(stateTerritory, address.stateTerritory)
				&& Objects.equals(overseasAddressLine1, address.overseasAddressLine1)
				&& Objects.equals(overseasAddressLine2, address.overseasAddressLine2)
				&& Objects.equals(overseasAddressLine3, address.overseasAddressLine3)
				&& Objects.equals(country, address.country);
		// @formatter:on
	}

	@Override
	public int hashCode() {
		// @formatter:off
		return Objects.hash(addressFormatType, addressLine, flatUnitType, flatUnitNumber, floorLevelType,
				floorLevelNumber, buildingName, lotNumber, roadNumberFrom, roadNumberFromSuffix, roadNumberTo,
				roadNumberToSuffix, roadName, roadType, roadSuffixType, postalDeliveryType, postalDeliveryPrefix,
				postalDeliveryNumber, postalDeliverySuffix, localityName, postcode, stateTerritory,
				overseasAddressLine1, overseasAddressLine2, overseasAddressLine3, country);
		// @formatter:on
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class Address {\n");

		sb.append("    addressFormatType: ").append(toIndentedString(addressFormatType)).append("\n");
		sb.append("    addressLine: ").append(toIndentedString(addressLine)).append("\n");
		sb.append("    flatUnitType: ").append(toIndentedString(flatUnitType)).append("\n");
		sb.append("    flatUnitNumber: ").append(toIndentedString(flatUnitNumber)).append("\n");
		sb.append("    floorLevelType: ").append(toIndentedString(floorLevelType)).append("\n");
		sb.append("    floorLevelNumber: ").append(toIndentedString(floorLevelNumber)).append("\n");
		sb.append("    buildingName: ").append(toIndentedString(buildingName)).append("\n");
		sb.append("    lotNumber: ").append(toIndentedString(lotNumber)).append("\n");
		sb.append("    roadNumberFrom: ").append(toIndentedString(roadNumberFrom)).append("\n");
		sb.append("    roadNumberFromSuffix: ").append(toIndentedString(roadNumberFromSuffix)).append("\n");
		sb.append("    roadNumberTo: ").append(toIndentedString(roadNumberTo)).append("\n");
		sb.append("    roadNumberToSuffix: ").append(toIndentedString(roadNumberToSuffix)).append("\n");
		sb.append("    roadName: ").append(toIndentedString(roadName)).append("\n");
		sb.append("    roadType: ").append(toIndentedString(roadType)).append("\n");
		sb.append("    roadSuffixType: ").append(toIndentedString(roadSuffixType)).append("\n");
		sb.append("    postalDeliveryType: ").append(toIndentedString(postalDeliveryType)).append("\n");
		sb.append("    postalDeliveryPrefix: ").append(toIndentedString(postalDeliveryPrefix)).append("\n");
		sb.append("    postalDeliveryNumber: ").append(toIndentedString(postalDeliveryNumber)).append("\n");
		sb.append("    postalDeliverySuffix: ").append(toIndentedString(postalDeliverySuffix)).append("\n");
		sb.append("    localityName: ").append(toIndentedString(localityName)).append("\n");
		sb.append("    postcode: ").append(toIndentedString(postcode)).append("\n");
		sb.append("    stateTerritory: ").append(toIndentedString(stateTerritory)).append("\n");
		sb.append("    overseasAddressLine1: ").append(toIndentedString(overseasAddressLine1)).append("\n");
		sb.append("    overseasAddressLine2: ").append(toIndentedString(overseasAddressLine2)).append("\n");
		sb.append("    overseasAddressLine3: ").append(toIndentedString(overseasAddressLine3)).append("\n");
		sb.append("    country: ").append(toIndentedString(country)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces (except the first line).
	 */
	private String toIndentedString(Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}
}
