package au.gov.vic.sro.autopay.validation.constraint;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;

public class PhoneNumberChecker {

	private static final String PHONE_NUMBER_PATTERN = "^(\\+ ?)?(?:[0-9()] ?){1,16}[0-9]$";

	private PhoneNumberChecker() {
		// not required
	}

	public static boolean isValid(String mobileNumber, String landLineNumber) {
		return (StringUtils.trimToNull(mobileNumber) != null || StringUtils.trimToNull(landLineNumber) != null);
	}

	public static boolean isValid(String phoneNumber) {
		Pattern pattern = Pattern.compile(PHONE_NUMBER_PATTERN);
		Matcher matcher = pattern.matcher(phoneNumber);
		boolean matched = matcher.matches();
		if (matched) {
			String numberArray[] = phoneNumber.split("[\\(\\)]");
			if (numberArray.length > 2) {
				return numberArray[1].length() > 0;
			}
		}
		return matched;
	}
}
