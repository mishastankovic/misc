package au.gov.vic.sro.autopay.validation.util;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Validation;

import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.baidu.unbiz.fluentvalidator.ComplexResult;
import com.baidu.unbiz.fluentvalidator.FluentValidator;
import com.baidu.unbiz.fluentvalidator.ResultCollectors;
import com.baidu.unbiz.fluentvalidator.ValidationError;
import com.baidu.unbiz.fluentvalidator.Validator;
import com.baidu.unbiz.fluentvalidator.jsr303.HibernateSupportedValidator;

public final class ValidationHelper {

	private static final Logger log = LoggerFactory.getLogger(ValidationHelper.class);

	private ValidationHelper() {
		// not necessary
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static <T extends Serializable> boolean validate(final List<ValidationRequest> requests) {
		boolean result = true;
		for (final ValidationRequest<T> request : requests) {
			result = result && validate(request);
		}
		return result;
	}

	@SuppressWarnings("unchecked")
	public static <T extends Serializable> boolean validate(final ValidationRequest<T> request) {

		final ComplexResult result =
				validate(request.getObjectToBeValidated(), request.getContextObjects(), request.getPropertyPath(),
						request.getValidators().toArray(new Validator[request.getValidators().size()]));

		List<ValidationError> errors = result.getErrors();

		boolean isValid = CollectionUtils.isEmpty(errors);

		if (!isValid) printErrors(request.getObjectToBeValidated(), request.getPropertyPath(), errors);

		return isValid;
	}

	public static ValidationError extractValidationError(String fieldId, String errorMessage) {
		ValidationError error = new ValidationError();
		error.setField(fieldId);
		error.setErrorMsg(errorMessage);
		return error;
	}

	@SuppressWarnings("unchecked")
	public static <T> ComplexResult validate(final T object, final Validator<T>... validators) {
		return validate(object, null, null, validators);
	}

	@SuppressWarnings({ "unchecked" })
	public static <T> ComplexResult validate(final T object, final Object[] objectsToAddToContext,
			final String propertyPath, final Validator<T>... validators) {
		javax.validation.Validator validator = Validation.buildDefaultValidatorFactory().getValidator();

		FluentValidator fluentValidator = FluentValidator.checkAll().on(object,
				new HibernateSupportedValidator<T>().setHiberanteValidator(validator));

		if (validators != null && validators.length > 0) {
			for (final Validator<T> v : validators) {
				fluentValidator = fluentValidator.on(object, v);
			}
		}

		if (objectsToAddToContext != null && objectsToAddToContext.length > 0) {
			for (Object contextObj : objectsToAddToContext) {
				if (contextObj != null) {
					fluentValidator.putAttribute2Context(contextObj.getClass().getSimpleName().toLowerCase(),
							contextObj);
				}
			}
		}

		ComplexResult result = fluentValidator.failOver().doValidate().result(ResultCollectors.toComplex());
		if (result.getErrors() == null) {
			result.setErrors(new ArrayList<ValidationError>());
		}

		if (propertyPath != null) {
			for (ValidationError error : result.getErrors()) {
				error.setField(propertyPath + "." + error.getField());
			}
		}
		return result;
	}

	private static <T> void printErrors(T objectToBeValidated, String propertyPath, List<ValidationError> errors) {
		for (ValidationError error : errors) {
			log.error(String.format(
					"Validation errors; objectToBeValidated[%s] propertyPath=[%s] errorCode=[%s] errorMessage=[%s]",
					objectToBeValidated, propertyPath, error.getErrorCode(), error.getErrorMsg()));
		}
	}

}
