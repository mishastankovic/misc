package au.gov.vic.sro.autopay.model;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonValue;

/**
 * A liability has a revenue line.
 */
public enum RevenueLine implements Presentable, Codified {
	LAND_TAX("LTX", "Land tax"),
	VACANT_LAND_TAX("VLT", "Vacant residential land tax");

	private static final Map<String, RevenueLine> codeMap;

	private String code;
	private String label;

	static {
		codeMap = new HashMap<String, RevenueLine>();
		for (RevenueLine value : values()) {
			codeMap.put(value.getCode(), value);
		}
	}

	private RevenueLine(String code, String label) {
		this.code = code;
		this.label = label;
	}

	@Override
	@JsonValue
	public String getCode() {
		return code;
	}

	@Override
	public String getLabel() {
		return label;
	}

	@JsonCreator
	public static RevenueLine fromCode(String code) {
		return codeMap.get(code);
	}

	public static String toCode(RevenueLine value) {
		return value == null ? null : value.getCode();
	}

}
