package au.gov.vic.sro.autopay.model;

import static au.gov.vic.sro.builder.ToStringStyleFactory.getToStringStyle;

import java.io.Serializable;
import java.math.BigInteger;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

/**
 * A payment arrangement event.
 */
public class Event implements Serializable {
	private static final long serialVersionUID = -7188729445981578766L;
	private BigInteger id;
	private EventType type;
	private EventStatus status;
	private BigInteger arrangementId;
	private Integer arrangementVersion;

	public BigInteger getId() {
		return id;
	}

	public void setId(BigInteger id) {
		this.id = id;
	}

	public EventType getType() {
		return type;
	}

	public void setType(EventType type) {
		this.type = type;
	}

	public EventStatus getStatus() {
		return status;
	}

	public void setStatus(EventStatus status) {
		this.status = status;
	}

	public BigInteger getArrangementId() {
		return arrangementId;
	}

	public void setArrangementId(BigInteger arrangementId) {
		this.arrangementId = arrangementId;
	}

	public Integer getArrangementVersion() {
		return arrangementVersion;
	}

	public void setArrangementVersion(Integer arrangementVersion) {
		this.arrangementVersion = arrangementVersion;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, getToStringStyle());
	}

}
