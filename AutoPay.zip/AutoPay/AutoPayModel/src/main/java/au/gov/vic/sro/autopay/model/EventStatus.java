package au.gov.vic.sro.autopay.model;

import java.util.HashMap;
import java.util.Map;

/**
 * An event has a status.
 */
public enum EventStatus implements Presentable, Codified {
	REQUESTED("R", "Event notification requested"),
	SUCCESSFUL("S", "Event notification request was successful"),
	FAILED("F", "Event notification request failed");

	private static final Map<String, EventStatus> codeMap;

	private String code;
	private String label;

	static {
		codeMap = new HashMap<String, EventStatus>();
		for (EventStatus value : values()) {
			codeMap.put(value.getCode(), value);
		}
	}

	private EventStatus(String code, String label) {
		this.code = code;
		this.label = label;
	}

	@Override
	public String getCode() {
		return code;
	}

	@Override
	public String getLabel() {
		return label;
	}

	public static EventStatus fromCode(String code) {
		return codeMap.get(code);
	}

	public static String toCode(EventStatus value) {
		return value == null ? null : value.getCode();
	}

}
