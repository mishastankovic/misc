package au.gov.vic.sro.autopay.validation.constraint;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.apache.commons.lang3.StringUtils;

public class BeforeTodayValidatorForString implements ConstraintValidator<BeforeToday, String> {

	private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

	public void initialize(BeforeToday constraintAnnotation) {
		// required for use by javax.validation
	}

	@Override
	public boolean isValid(String dateString, ConstraintValidatorContext context) {
		if (StringUtils.trimToNull(dateString) == null) {
			return true;
		}
		LocalDate dateOfBirthLocalDate = getDateOfBirthLocalDate(dateString);
		if (dateOfBirthLocalDate == null) {
			return false;
		}
		return dateOfBirthLocalDate.isBefore(LocalDate.now());
	}

	public LocalDate getDateOfBirthLocalDate(String dateString) {
		LocalDate issueDate = null;
		try {
			issueDate = LocalDate.parse(dateString, formatter);
		} catch (DateTimeParseException e) {
			// ignore
		}

		return issueDate;
	}

}
