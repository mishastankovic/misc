package au.gov.vic.sro.autopay.model;

import java.util.HashMap;
import java.util.Map;

/**
 * Indicates whether instalment has been sent to payment request file.
 */
public enum InstalmentRequestSent implements Presentable, Codified {
	SENT("S", "Sent");

	private static final Map<String, InstalmentRequestSent> codeMap;

	private String code;
	private String label;

	static {
		codeMap = new HashMap<String, InstalmentRequestSent>();
		for (InstalmentRequestSent value : values()) {
			codeMap.put(value.getCode(), value);
		}
	}

	private InstalmentRequestSent(String code, String label) {
		this.code = code;
		this.label = label;
	}

	@Override
	public String getCode() {
		return code;
	}

	@Override
	public String getLabel() {
		return label;
	}

	public static InstalmentRequestSent fromCode(String code) {
		return codeMap.get(code);
	}

	public static String toCode(InstalmentRequestSent value) {
		return value == null ? null : value.getCode();
	}

}
