package au.gov.vic.sro.autopay.model;

import java.util.HashMap;
import java.util.Map;

/**
 * An event has a type.
 */
public enum EventType implements Presentable, Codified {
	ACTIVE("PASS", "Confirmation of payment arrangement successful setup"),
	CANCELLED_ASSESSMENT_WITHDRAWN("XAW",
			"Confirmation of payment arrangement cancelled because assessment has been withdrawn / cancelled"),
	CANCELLED_ESYS_SYSTEM("XCS", "Confirmation of payment arrangement cancelled by e-Sys system"),
	CANCELLED_EXTERNAL_USER("XEU", "Confirmation of payment arrangement cancelled by external user"),
	CANCELLED_INTERNAL_USER("XIU", "Confirmation of payment arrangement cancelled by internal user"),
	CANCELLED_LIABILITY_RECALCULATED("XLR",
			"Confirmation of payment arrangement cancelled because liability has been recalculated"),
	CANCELLED_PAYMENT_NOT_RECEIVED("XPN",
			"Confirmation of payment arrangement cancelled because payment has not been received"),
	REMINDER_CARD_EXPIRING("EXPC", "Reminder notice on expiring credit card"),
	REMINDER_PAYMENT("DUEP", "Reminder notice on scheduled payment due in x days");

	private static final Map<String, EventType> codeMap;

	private String code;
	private String label;

	static {
		codeMap = new HashMap<String, EventType>();
		for (EventType value : values()) {
			codeMap.put(value.getCode(), value);
		}
	}

	private EventType(String code, String label) {
		this.code = code;
		this.label = label;
	}

	@Override
	public String getCode() {
		return code;
	}

	@Override
	public String getLabel() {
		return label;
	}

	public static EventType fromCode(String code) {
		return codeMap.get(code);
	}

	public static String toCode(EventType value) {
		return value == null ? null : value.getCode();
	}

}
