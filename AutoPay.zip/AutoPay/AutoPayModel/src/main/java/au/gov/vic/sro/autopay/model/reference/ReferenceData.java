package au.gov.vic.sro.autopay.model.reference;

import java.io.Serializable;
import java.util.Objects;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "A representation of reference data.")
public class ReferenceData implements Serializable {

	private static final long serialVersionUID = -953463307296055250L;

	private String type;

	private String code;

	private String label;

	private String shortLabel;

	public ReferenceData() {
	}

	public ReferenceData(String type, String code, String label) {
		this.type = type;
		this.code = code;
		this.label = label;
	}

	/**
	 * The type of reference data item
	 **/
	public ReferenceData type(String type) {
		this.type = type;
		return this;
	}

	@ApiModelProperty(example = "STREET_TYPE", required = true, value = "The type of reference data item")
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	/**
	 * eSys code of reference data item
	 **/
	public ReferenceData code(String code) {
		this.code = code;
		return this;
	}

	@ApiModelProperty(example = "ST (Street)", required = true, value = "eSys code of reference data item")
	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * eSys description of reference data item
	 **/
	public ReferenceData label(String label) {
		this.label = label;
		return this;
	}

	@ApiModelProperty(name = "label", example = "Street", required = true,
			value = "eSys description of reference data item")
	public String getDescription() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	/**
	 * Short label of reference data item
	 **/
	public ReferenceData shortLabel(String shortLabel) {
		this.shortLabel = shortLabel;
		return this;
	}

	@ApiModelProperty(example = "Individual", value = "Short label of reference data item")
	public String getShortLabel() {
		return shortLabel;
	}

	public void setShortLabel(String shortLabel) {
		this.shortLabel = shortLabel;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}

		if (o == null || getClass() != o.getClass()) {
			return false;
		}

		ReferenceData referenceDataList = (ReferenceData) o;
		// @formatter:off
		return Objects.equals(type, referenceDataList.type)
				&& Objects.equals(code, referenceDataList.code)
				&& Objects.equals(label, referenceDataList.label)
				&& Objects.equals(shortLabel, referenceDataList.shortLabel);
		// @formatter:on
	}

	@Override
	public int hashCode() {
		// @formatter:off
		return Objects.hash(
				type,
				code,
				label,
				shortLabel);
		// @formatter:on
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}
