package au.gov.vic.sro.autopay.model.address;

public enum IntechAddressFormatType {

	INTECH_STREET("STREET"),
	INTECH_LOT("LOT"),
	INTECH_POSTAL("POSTAL_BOX"),
	INTECH_OVERSEAS("OVERSEAS");

	private String code;

	private IntechAddressFormatType(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static IntechAddressFormatType getAddressFormatType(String code) {
		for (IntechAddressFormatType type : IntechAddressFormatType.values()) {
			if (type.getCode().equals(code)) {
				return type;
			}
		}

		return null;
	}

	public static boolean isStructuredAddress(String addressFormat) {
		IntechAddressFormatType addressFormatType = getAddressFormatType(addressFormat);
		return addressFormatType != null && (addressFormatType == INTECH_STREET || addressFormatType == INTECH_LOT
				|| addressFormatType == INTECH_POSTAL);
	}
}
