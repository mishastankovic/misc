package au.gov.vic.sro.autopay.model;

import java.util.HashMap;
import java.util.Map;

/**
 * An instalment has a status.
 */
public enum InstalmentStatus implements Presentable, Codified {
	DECLINED("C", "Declined"),
	DISHONOURED("D", "Dishonoured"),
	ERROR("E", "Error"),
	PAID("P", "Paid"),
	REJECTED("R", "Rejected"),
	UNPAID("U", "Unpaid");

	private static final Map<String, InstalmentStatus> codeMap;

	private String code;
	private String label;

	static {
		codeMap = new HashMap<String, InstalmentStatus>();
		for (InstalmentStatus value : values()) {
			codeMap.put(value.getCode(), value);
		}
	}

	private InstalmentStatus(String code, String label) {
		this.code = code;
		this.label = label;
	}

	@Override
	public String getCode() {
		return code;
	}

	@Override
	public String getLabel() {
		return label;
	}

	public static InstalmentStatus fromCode(String code) {
		return codeMap.get(code);
	}

	public static String toCode(InstalmentStatus value) {
		return value == null ? null : value.getCode();
	}

}
