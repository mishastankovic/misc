package au.gov.vic.sro.autopay.validation;

import java.io.Serializable;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import au.gov.vic.sro.autopay.validation.constraint.PhoneNumber;
import au.gov.vic.sro.autopay.validation.constraint.PhoneNumberChecker; 

public class PhoneNumberValidator implements ConstraintValidator<PhoneNumber, String>, Serializable {

	private static final long serialVersionUID = 605860420241399361L;

	@Override
	public void initialize(PhoneNumber constraintAnnotation) {
		// required for use by javax.validation
	}

	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
		if (value == null) {
			return true;
		}

		return PhoneNumberChecker.isValid(value);
	}

}