package au.gov.vic.sro.autopay.model;

import java.util.HashMap;
import java.util.Map;

/**
 * An arrangement has a payment method.
 */
public enum PaymentMethod implements Presentable, Codified {
	CREDIT_CARD("C", "Visa or Mastercard", "CREDIT_CARD"),
	DIRECT_DEBIT("D", "Direct debit", "DIRECT_DEBIT");

	private static final Map<String, PaymentMethod> codeMap;

	private String code;
	private String label;
	private String quickVaultCode;

	static {
		codeMap = new HashMap<String, PaymentMethod>();
		for (PaymentMethod value : values()) {
			codeMap.put(value.getCode(), value);
		}
	}

	private PaymentMethod(String code, String label, String quickVaultCode) {
		this.code = code;
		this.label = label;
		this.quickVaultCode = quickVaultCode;
	}

	@Override
	public String getCode() {
		return code;
	}

	@Override
	public String getLabel() {
		return label;
	}

	public String getQuickVaultCode() {
		return quickVaultCode;
	}

	public static PaymentMethod fromCode(String code) {
		return codeMap.get(code);
	}

	public static String toCode(PaymentMethod value) {
		return value == null ? null : value.getCode();
	}

}
