package au.gov.vic.sro.autopay.model.address;

public enum AddressFormatType {

	FREETEXT("F"),
	HOUSE_BUILDING_SHOP("B"),
	LOT("L"),
	POSTAL_BOX("P"),
	OVERSEAS("O");

	private String code;

	private AddressFormatType(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public static AddressFormatType getAddressFormatType(String code) {
		for (AddressFormatType type : AddressFormatType.values()) {
			if (type.getCode().equals(code)) {
				return type;
			}
		}

		return null;
	}

	public static boolean isStructuredAddress(String addressFormat) {
		AddressFormatType addressFormatType = getAddressFormatType(addressFormat);
		return addressFormatType != null && (addressFormatType == HOUSE_BUILDING_SHOP || addressFormatType == LOT
				|| addressFormatType == POSTAL_BOX);
	}
}
