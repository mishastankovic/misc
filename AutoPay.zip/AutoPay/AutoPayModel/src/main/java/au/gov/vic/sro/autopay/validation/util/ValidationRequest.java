package au.gov.vic.sro.autopay.validation.util;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.baidu.unbiz.fluentvalidator.Validator;

public class ValidationRequest<T extends Serializable> implements Serializable {

	private static final long serialVersionUID = -2339582101545751788L;

	private T objectToBeValidated;
	private transient List<Validator<T>> validators = new ArrayList<>();
	private String propertyPath;
	private transient List<Object> contextObjects = new ArrayList<>();

	public ValidationRequest() {
	}

	public ValidationRequest(String propertyPath) {
		this.propertyPath = propertyPath;
	}

	public ValidationRequest<T> objectToBeValidated(final T objectToBeValidated) {
		this.objectToBeValidated = objectToBeValidated;
		return this;
	}

	public ValidationRequest<T> addValidator(final Validator<T> validator) {
		validators.add(validator);
		return this;
	}

	public T getObjectToBeValidated() {
		return objectToBeValidated;
	}

	public void setObjectToBeValidated(T objectToBeValidated) {
		this.objectToBeValidated = objectToBeValidated;
	}

	public List<Validator<T>> getValidators() {
		return validators;
	}

	public void setValidators(List<Validator<T>> validators) {
		this.validators = validators;
	}

	public String getPropertyPath() {
		return propertyPath;
	}

	public void setPropertyPath(String propertyPath) {
		this.propertyPath = propertyPath;
	}

	public ValidationRequest<T> addContextObject(Object contextObject) {
		this.contextObjects.add(contextObject);
		return this;
	}

	public Object[] getContextObjects() {
		return this.contextObjects.toArray();
	}

	@Override
	public String toString() {
		return "ValidationRequest{" + "objectToBeValidated=" + objectToBeValidated + ", validators=" + validators
				+ "; propertyPath=" + propertyPath + "}";
	}

}
