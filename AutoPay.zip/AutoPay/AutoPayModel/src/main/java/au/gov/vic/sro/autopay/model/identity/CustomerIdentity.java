package au.gov.vic.sro.autopay.model.identity;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonIgnore;

import au.gov.vic.sro.autopay.validation.constraint.BeforeToday;
import io.swagger.annotations.ApiModelProperty;

public class CustomerIdentity implements Serializable {

	private static final long serialVersionUID = 7954035181530688225L;

	private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

	private Boolean isExistingCustomer;
	private Boolean hasReceivedCorrespondence;
	private String customerId;
	private String assessmentId;
	private String correspondenceId;
	private String previousReceiptNumber;
	private String ltxAssessmentId;

	@BeforeToday(message = "{issueDate.past}")
	private String issueDate;

	private String authenticationLevel;

	public CustomerIdentity isExistingCustomer(Boolean isExistingCustomer) {
		this.isExistingCustomer = isExistingCustomer;
		return this;
	}

	@ApiModelProperty(example = "null", value = "")
	public Boolean getIsExistingCustomer() {
		return isExistingCustomer;
	}

	public void setIsExistingCustomer(Boolean isExistingCustomer) {
		this.isExistingCustomer = isExistingCustomer;
	}

	public CustomerIdentity hasReceivedCorrespondence(Boolean hasReceivedCorrespondence) {
		this.hasReceivedCorrespondence = hasReceivedCorrespondence;
		return this;
	}

	@ApiModelProperty(example = "null", value = "")
	public Boolean getHasReceivedCorrespondence() {
		return hasReceivedCorrespondence;
	}

	public void setHasReceivedCorrespondence(Boolean hasReceivedCorrespondence) {
		this.hasReceivedCorrespondence = hasReceivedCorrespondence;
	}

	public CustomerIdentity customerId(String customerId) {
		this.customerId = customerId;
		return this;
	}

	@ApiModelProperty(example = "null", value = "")
	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public CustomerIdentity assessmentId(String assessmentId) {
		this.assessmentId = assessmentId;
		return this;
	}

	@ApiModelProperty(example = "null", value = "")
	public String getAssessmentId() {
		return assessmentId;
	}

	public void setAssessmentId(String assessmentId) {
		this.assessmentId = assessmentId;
	}

	public CustomerIdentity correspondenceId(String correspondenceId) {
		this.correspondenceId = correspondenceId;
		return this;
	}

	@ApiModelProperty(example = "null", value = "")
	public String getCorrespondenceId() {
		return correspondenceId;
	}

	public void setCorrespondenceId(String correspondenceId) {
		this.correspondenceId = correspondenceId;
	}

	public CustomerIdentity previousReceiptNumber(String previousReceiptNumber) {
		this.previousReceiptNumber = previousReceiptNumber;
		return this;
	}

	@ApiModelProperty(example = "null", value = "")
	public String getPreviousReceiptNumber() {
		return previousReceiptNumber;
	}

	public void setPreviousReceiptNumber(String previousReceiptNumber) {
		this.previousReceiptNumber = previousReceiptNumber;
	}

	public CustomerIdentity ltxAssessmentId(String ltxAssessmentId) {
		this.ltxAssessmentId = ltxAssessmentId;
		return this;
	}

	@ApiModelProperty(example = "null", value = "")
	public String getLtxAssessmentId() {
		return ltxAssessmentId;
	}

	public void setLtxAssessmentId(String ltxAssessmentId) {
		this.ltxAssessmentId = ltxAssessmentId;
	}

	public CustomerIdentity issueDate(String issueDate) {
		this.issueDate = issueDate;
		return this;
	}

	@ApiModelProperty(example = "null", value = "")
	public String getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(String issueDate) {
		this.issueDate = issueDate;
	}

	@JsonIgnore
	public String getAuthenticationLevel() {
		return authenticationLevel;
	}

	public void setAuthenticationLevel(String authenticationLevel) {
		this.authenticationLevel = authenticationLevel;
	}

	public LocalDate getIssueLocalDate() {
		LocalDate issueLocalDate = null;
		if (getIssueDate() != null) {
			issueLocalDate = LocalDate.parse(getIssueDate(), formatter);
		}
		return issueLocalDate;
	}

	public void setIssueLocalDate(LocalDate issueLocalDate) {
		if (issueLocalDate != null) {
			setIssueDate(issueLocalDate.format(formatter));
		}
	}

	public boolean determineIsFullOrPartialAuthentication() {
		return "F".equals(authenticationLevel) || "P".equals(authenticationLevel);
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		CustomerIdentity customerIdentity = (CustomerIdentity) o;
		return Objects.equals(isExistingCustomer, customerIdentity.isExistingCustomer)
				&& Objects.equals(hasReceivedCorrespondence, customerIdentity.hasReceivedCorrespondence)
				&& Objects.equals(customerId, customerIdentity.customerId)
				&& Objects.equals(assessmentId, customerIdentity.assessmentId)
				&& Objects.equals(correspondenceId, customerIdentity.correspondenceId)
				&& Objects.equals(previousReceiptNumber, customerIdentity.previousReceiptNumber)
				&& Objects.equals(ltxAssessmentId, customerIdentity.ltxAssessmentId)
				&& Objects.equals(issueDate, customerIdentity.issueDate);
	}

	@Override
	public int hashCode() {
		return Objects.hash(isExistingCustomer, hasReceivedCorrespondence, customerId, assessmentId, correspondenceId,
				previousReceiptNumber, ltxAssessmentId, issueDate);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class CustomerIdentity {\n");

		sb.append("    isExistingCustomer: ").append(toIndentedString(isExistingCustomer)).append("\n");
		sb.append("    hasReceivedCorrespondence: ").append(toIndentedString(hasReceivedCorrespondence)).append("\n");
		sb.append("    customerId: ").append(toIndentedString(customerId)).append("\n");
		sb.append("    assessmentId: ").append(toIndentedString(assessmentId)).append("\n");
		sb.append("    correspondenceId: ").append(toIndentedString(correspondenceId)).append("\n");
		sb.append("    previousReceiptNumber: ").append(toIndentedString(previousReceiptNumber)).append("\n");
		sb.append("    ltxAssessmentId: ").append(toIndentedString(ltxAssessmentId)).append("\n");
		sb.append("    issueDate: ").append(toIndentedString(issueDate)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces (except the first line).
	 */
	private String toIndentedString(Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}
}
