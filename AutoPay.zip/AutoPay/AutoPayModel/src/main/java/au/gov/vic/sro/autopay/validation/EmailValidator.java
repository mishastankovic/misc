package au.gov.vic.sro.autopay.validation;

import java.io.Serializable;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import au.gov.vic.sro.autopay.validation.constraint.Email;
import au.gov.vic.sro.autopay.validation.constraint.EmailChecker;

public class EmailValidator implements ConstraintValidator<Email, String>, Serializable {

	private static final long serialVersionUID = 605860420241399361L;

	@Override
	public void initialize(Email constraintAnnotation) {
		// required for use by javax.validation
	}

	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
		if (value == null) {
			return true;
		}

		return EmailChecker.isValid(value);
	}

}
