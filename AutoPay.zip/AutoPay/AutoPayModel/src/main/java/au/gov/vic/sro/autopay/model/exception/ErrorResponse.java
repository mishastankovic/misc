package au.gov.vic.sro.autopay.model.exception;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModelProperty;

public class ErrorResponse {

	private List<Error> errors = new ArrayList<>();
	private String message = null;

	public ErrorResponse errors(List<Error> errors) {
		this.errors = errors;
		return this;
	}

	@ApiModelProperty(value = "")
	public List<Error> getErrors() {
		return errors;
	}

	public void setErrors(List<Error> errors) {
		this.errors = errors;
	}

	public ErrorResponse message(String message) {
		this.message = message;
		return this;
	}

	@ApiModelProperty(value = "")
	@Size(max = 500)
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public boolean equals(java.lang.Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		ErrorResponse errorResponse = (ErrorResponse) o;
		return Objects.equals(errors, errorResponse.errors) && Objects.equals(message, errorResponse.message);
	}

	@Override
	public int hashCode() {
		return Objects.hash(errors, message);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class ErrorResponse {\n");

		sb.append("    errors: ").append(toIndentedString(errors)).append("\n");
		sb.append("    message: ").append(toIndentedString(message)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}
}
