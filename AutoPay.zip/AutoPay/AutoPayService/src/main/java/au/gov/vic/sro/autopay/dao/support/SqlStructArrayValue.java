package au.gov.vic.sro.autopay.dao.support;

import static au.gov.vic.sro.autopay.dao.support.OracleUtil.unwrap;

import java.sql.Connection;
import java.sql.SQLException;

import org.springframework.data.jdbc.support.oracle.StructMapper;

public class SqlStructArrayValue<T> extends org.springframework.data.jdbc.support.oracle.SqlStructArrayValue<T> {

	public SqlStructArrayValue(T[] values, StructMapper<T> mapper, String structTypeName, String arrayTypeName) {
		super(values, mapper, structTypeName, arrayTypeName);
	}

	public SqlStructArrayValue(T[] values, StructMapper<T> mapper, String structTypeName) {
		super(values, mapper, structTypeName);
	}

	@Override
	protected Object createTypeValue(Connection connection, int sqlType, String typeName) throws SQLException {
		return super.createTypeValue(unwrap(connection), sqlType, typeName);
	}

}
