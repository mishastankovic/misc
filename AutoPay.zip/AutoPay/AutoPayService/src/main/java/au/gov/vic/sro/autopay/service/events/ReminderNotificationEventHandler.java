package au.gov.vic.sro.autopay.service.events;

import static au.gov.vic.sro.autopay.model.EventStatus.SUCCESSFUL;
import static au.gov.vic.sro.util.CollectionUtil.getFirst;
import static org.apache.commons.lang3.StringUtils.defaultIfBlank;
import static org.apache.commons.lang3.StringUtils.isBlank;

import java.text.MessageFormat;
import java.util.Date;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.log4j.Logger;

import au.gov.vic.sro.autopay.model.Arrangement;
import au.gov.vic.sro.autopay.model.Contact;
import au.gov.vic.sro.autopay.model.Event;
import au.gov.vic.sro.autopay.model.Instalment;

public class ReminderNotificationEventHandler extends NotificationEventHandler implements EventHandler {
	private static final Logger log = Logger.getLogger(ReminderNotificationEventHandler.class);

	@Override
	public void handle(Event event) {
		Arrangement arrangement = getArrangement(event);
		Date nextScheduledPaymentDate = getNextScheduledPaymentDate(arrangement);
		Contact contact = getFirst(arrangement.getContacts());
		if (contact == null || isBlank(contact.getEmailAddress())) {
			log.warn(String.format("No contact email address found. event=%s", event));
		} else {
			String subject = getProperties().getProperty("email.reminder.subject");
			String arrangementRef = String.format("%s-%s", arrangement.getId(), arrangement.getVersion());
			String body = MessageFormat.format(getEmailTemplate(), defaultIfBlank(contact.getPersonName(), "Customer"),
					DateFormatUtils.format(nextScheduledPaymentDate, "dd/MMM/yyyy"), arrangementRef,
					getProperties().getProperty("email.important.notice"),
					getProperties().getProperty("email.further.information"),
					getProperties().getProperty("email.sro.logo.link"),
					getProperties().getProperty("email.disclaimer"));
			sendEmail(getProperties().getProperty("email.from.name"), getProperties().getProperty("email.from.address"),
					contact.getEmailAddress(), subject, body);
		}
		event.setStatus(SUCCESSFUL);
	}

	private Date getNextScheduledPaymentDate(Arrangement arrangement) {
		Date currentDate = new Date();
		for (Instalment instalment : arrangement.getInstalments()) {
			if (currentDate.before(instalment.getDueDate())) return instalment.getDueDate();
		}
		return arrangement.getEndDate();
	}

}
