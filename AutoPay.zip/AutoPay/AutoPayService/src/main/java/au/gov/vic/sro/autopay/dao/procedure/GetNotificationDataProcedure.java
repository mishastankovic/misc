package au.gov.vic.sro.autopay.dao.procedure;

import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.IN_ARRANGEMENT_ID;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.IN_ARRANGEMENT_VERSION;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.IN_DATE_TYPE;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.OUT_MESSAGES;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.OUT_VALUE;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.PACKAGE_PAYMENT_ARRANGEMENTS_SERVICES;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.PROCEDURE_GET_NOTIFICATION_DATA;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.TYPE_MESSAGES;
import static au.gov.vic.sro.util.NumberUtil.toBigDecimal;
import static java.sql.Types.ARRAY;
import static java.sql.Types.NUMERIC;
import static java.sql.Types.TIMESTAMP;
import static java.sql.Types.VARCHAR;
import static org.apache.commons.collections4.MapUtils.emptyIfNull;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.data.jdbc.support.oracle.SqlReturnStructArray;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import au.gov.vic.sro.autopay.dao.mapper.MessageMapper;
import au.gov.vic.sro.autopay.dto.CancelEmailResponse;
import au.gov.vic.sro.autopay.model.Message;
import au.gov.vic.sro.util.DateUtil;

public class GetNotificationDataProcedure extends StoredProcedure {

	public GetNotificationDataProcedure(JdbcTemplate jdbcTemplate) {
		super(jdbcTemplate, PACKAGE_PAYMENT_ARRANGEMENTS_SERVICES + "." + PROCEDURE_GET_NOTIFICATION_DATA);
		declareParameter(new SqlParameter(IN_ARRANGEMENT_ID, NUMERIC));
		declareParameter(new SqlParameter(IN_ARRANGEMENT_VERSION, NUMERIC));
		declareParameter(new SqlParameter(IN_DATE_TYPE, VARCHAR));
		declareParameter(new SqlOutParameter(OUT_VALUE, TIMESTAMP));
		declareParameter(new SqlOutParameter(OUT_MESSAGES, ARRAY, TYPE_MESSAGES,
				new SqlReturnStructArray<Message>(new MessageMapper())));
		compile();
	}

	public CancelEmailResponse execute(BigInteger arrangementId, Integer arrangementVer, String dateType) {
		Map<String, Object> in = new LinkedHashMap<String, Object>();
		in.put(IN_ARRANGEMENT_ID, toBigDecimal(arrangementId));
		in.put(IN_ARRANGEMENT_VERSION, toBigDecimal(arrangementVer));
		in.put(IN_DATE_TYPE, dateType);

		Map<String, Object> out = emptyIfNull(execute(in));

		CancelEmailResponse response = new CancelEmailResponse();
		response.setReturnDate(DateUtil.toDate((Timestamp) out.get(OUT_VALUE)));
		response.setMessages((Object[]) out.get(OUT_MESSAGES));

		return response;
	}
}
