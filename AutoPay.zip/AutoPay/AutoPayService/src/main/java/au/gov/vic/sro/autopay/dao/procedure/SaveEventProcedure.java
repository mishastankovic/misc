package au.gov.vic.sro.autopay.dao.procedure;

import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.IN_EVENT_ID;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.IN_STATUS;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.PACKAGE_PAYMENT_ARRANGEMENTS_EVENTS;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.PROCEDURE_SAVE_EVENT;
import static au.gov.vic.sro.util.NumberUtil.toBigDecimal;
import static java.sql.Types.NUMERIC;
import static java.sql.Types.VARCHAR;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import au.gov.vic.sro.autopay.model.Event;
import au.gov.vic.sro.autopay.model.EventStatus;

public class SaveEventProcedure extends StoredProcedure {

	public SaveEventProcedure(JdbcTemplate jdbcTemplate) {
		super(jdbcTemplate, PACKAGE_PAYMENT_ARRANGEMENTS_EVENTS + "." + PROCEDURE_SAVE_EVENT);
		declareParameter(new SqlParameter(IN_EVENT_ID, NUMERIC));
		declareParameter(new SqlParameter(IN_STATUS, VARCHAR));
		compile();
	}

	public void execute(Event event) {
		Map<String, Object> in = new LinkedHashMap<String, Object>();
		in.put(IN_EVENT_ID, event == null ? null : toBigDecimal(event.getId()));
		in.put(IN_STATUS, event == null ? null : EventStatus.toCode(event.getStatus()));

		execute(in);
	}

}
