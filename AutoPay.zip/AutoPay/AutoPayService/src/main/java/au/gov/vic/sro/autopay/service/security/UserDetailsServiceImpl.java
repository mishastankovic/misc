package au.gov.vic.sro.autopay.service.security;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;

import au.gov.vic.sro.autopay.dao.AutoPayDao;
import au.gov.vic.sro.autopay.dto.AuthenticateResponse;
import au.gov.vic.sro.autopay.model.RevenueLine;
import au.gov.vic.sro.autopay.util.LogUtil;
import org.springframework.stereotype.Service;

@Service("userDetailsService")
public class UserDetailsServiceImpl implements UserDetailsService {

	private static final Logger log = Logger.getLogger(UserDetailsServiceImpl.class);

	@Autowired
	private AutoPayDao autoPayDao;

	private List<GrantedAuthority> userAuthorities;
	private ObjectReader objectReader;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

		UserDetailsImpl user = parseUsername(username);
		LogUtil.putCustomerId(user.getCustomerId());
		AuthenticateResponse result = getAutoPayDao().authenticate(user.getCustomerId(),
				user.getRevenueLine(), user.getLiabilityType(), user.getLiabilityId());

		if (BooleanUtils.isNotTrue(result.getAuthenticated())) {
			log.info(String.format("Login failed. messages=%s", result.getMessages()));
			throw new UsernameNotFoundException("Username was not found.");
		}
		user.setCustomerId(result.getCustomerId());
		user.setRevenueLine(RevenueLine.fromCode(result.getRevenueLineCode()));
		user.setAuthorities(Arrays.asList(new GrantedAuthority[] {AutoPayRole.Customer}));

		log.info("Login successful.");
		return user;

	}

	public AutoPayDao getAutoPayDao() {
		return autoPayDao;
	}

	public void setAutoPayDao(AutoPayDao autoPayDao) {
		this.autoPayDao = autoPayDao;
	}

	public List<GrantedAuthority> getUserAuthorities() {
		return userAuthorities;
	}

	public void setUserAuthorities(List<GrantedAuthority> userAuthorities) {
		this.userAuthorities = userAuthorities;
	}

	protected ObjectReader getObjectReader() {
		if (objectReader == null) {
			objectReader = new ObjectMapper().reader(UserDetailsImpl.class);
		}
		return objectReader;
	}

	protected UserDetailsImpl parseUsername(String username) {
		UserDetailsImpl user;
		try {
			user = getObjectReader().readValue(username);
		} catch (Exception e) {
			throw new IllegalArgumentException(String.format("username=%s", username), e);
		}
		if (user == null || StringUtils.isBlank(user.getCustomerId()) || user.getRevenueLine() == null
				|| user.getLiabilityType() == null || StringUtils.isBlank(user.getLiabilityId())) {
			throw new IllegalArgumentException(String.format("username=%s", username));
		}
		return user;
	}

}
