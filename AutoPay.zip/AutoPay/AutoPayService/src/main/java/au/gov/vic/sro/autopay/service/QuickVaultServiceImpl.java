package au.gov.vic.sro.autopay.service;

import static au.gov.vic.sro.autopay.model.PaymentMethod.CREDIT_CARD;
import static au.gov.vic.sro.autopay.model.PaymentMethod.DIRECT_DEBIT;
import static au.gov.vic.sro.payment.quickstream3.QuickstreamConstants.CUSTOM_PARAM_PREFIX;
import static au.gov.vic.sro.payment.quickstream3.QuickstreamConstants.PARAM_ACCOUNT_NUMBER;
import static au.gov.vic.sro.payment.quickstream3.QuickstreamConstants.PARAM_ACCOUNT_TYPE;
import static au.gov.vic.sro.payment.quickstream3.QuickstreamConstants.PARAM_BSB;
import static au.gov.vic.sro.payment.quickstream3.QuickstreamConstants.PARAM_CANCEL_URL;
import static au.gov.vic.sro.payment.quickstream3.QuickstreamConstants.PARAM_COMMUNITY_CODE;
import static au.gov.vic.sro.payment.quickstream3.QuickstreamConstants.PARAM_CUSTOMER_REFERENCE_NUMBER;
import static au.gov.vic.sro.payment.quickstream3.QuickstreamConstants.PARAM_ERROR_EMAIL_TO_ADDRESS;
import static au.gov.vic.sro.payment.quickstream3.QuickstreamConstants.PARAM_EXPIRY_DATE_MONTH;
import static au.gov.vic.sro.payment.quickstream3.QuickstreamConstants.PARAM_EXPIRY_DATE_YEAR;
import static au.gov.vic.sro.payment.quickstream3.QuickstreamConstants.PARAM_MASKED_CARD_NUMBER;
import static au.gov.vic.sro.payment.quickstream3.QuickstreamConstants.PARAM_PASSWORD;
import static au.gov.vic.sro.payment.quickstream3.QuickstreamConstants.PARAM_PREREGISTRATION_CODE;
import static au.gov.vic.sro.payment.quickstream3.QuickstreamConstants.PARAM_PRODUCT;
import static au.gov.vic.sro.payment.quickstream3.QuickstreamConstants.PARAM_RETURN_URL;
import static au.gov.vic.sro.payment.quickstream3.QuickstreamConstants.PARAM_SERVER_RETURN_URL;
import static au.gov.vic.sro.payment.quickstream3.QuickstreamConstants.PARAM_SUPPLIER_BUSINESS_CODE;
import static au.gov.vic.sro.payment.quickstream3.QuickstreamConstants.PARAM_TOKEN;
import static au.gov.vic.sro.payment.quickstream3.QuickstreamConstants.PARAM_USERNAME;
import static au.gov.vic.sro.payment.quickstream3.QuickstreamConstants.PRODUCT_QUICKVAULT;

import java.io.IOException;
import java.math.BigInteger;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.client.ClientProtocolException;
import org.apache.log4j.Logger;

import au.gov.vic.sro.autopay.dto.SaveAccountRequest;
import au.gov.vic.sro.autopay.model.PaymentMethod;
import au.gov.vic.sro.autopay.model.RevenueLine;
import au.gov.vic.sro.autopay.util.LogUtil;
import au.gov.vic.sro.payment.quickstream3.QuickstreamUtil;

public class QuickVaultServiceImpl implements QuickVaultService {
	private static final Logger log = Logger.getLogger(QuickVaultServiceImpl.class);
	public static final String PROP_PREFIX = "quickVault.";
	public static final String PARAM_CUSTOM_CUSTOMER_ID = "customCustomerId";
	public static final String PARAM_CHECKSUM = "Checksum";
	private static final String INVALID_MESSAGE = "Invalid or missing value for %s. parameters=%s";
	private static final String NULL = "<null>";
	private static final Pattern CUSTOMER_REFERENCE_NUMBER_PATTERN = Pattern.compile("(\\d+)-(\\d+)");
	private QuickstreamUtil quickstreamUtil = new QuickstreamUtil();
	private Properties properties;
	private String securityTokenRequestBaseUrl;
	private String browserRedirectBaseUrl;

	@Override
	public String getSecurityToken(String customerId, BigInteger arrangementId, Integer arrangementVersion,
			RevenueLine revenueLine, PaymentMethod paymentMethod, String checksum)
			throws ClientProtocolException, IOException {
		if (customerId == null || arrangementId == null || arrangementVersion == null || paymentMethod == null
				|| revenueLine == null) {
			throw new IllegalArgumentException(String.format(
					"customerId=%s, arrangementId=%s, arrangementVersion=%s, revenueLine=%s, paymentMethod=%s",
					customerId, arrangementId, arrangementVersion, revenueLine, paymentMethod));
		}
		Map<String, String> parameters = new LinkedHashMap<String, String>();
		parameters.put(PARAM_PRODUCT, PRODUCT_QUICKVAULT);
		parameters.put(PARAM_USERNAME, properties.getProperty(PROP_PREFIX + PARAM_USERNAME));
		parameters.put(PARAM_PASSWORD, properties.getProperty(PROP_PREFIX + PARAM_PASSWORD));
		parameters.put(PARAM_SUPPLIER_BUSINESS_CODE, properties
				.getProperty(PROP_PREFIX + PARAM_SUPPLIER_BUSINESS_CODE + "." + RevenueLine.LAND_TAX.getCode().toLowerCase()));
		parameters.put(PARAM_CUSTOMER_REFERENCE_NUMBER, arrangementId + "-" + arrangementVersion);
		parameters.put(PARAM_ACCOUNT_TYPE, paymentMethod.getQuickVaultCode());
		parameters.put(PARAM_RETURN_URL, properties.getProperty(PROP_PREFIX + PARAM_RETURN_URL));
		parameters.put(PARAM_CANCEL_URL, properties.getProperty(PROP_PREFIX + PARAM_CANCEL_URL));
		parameters.put(PARAM_SERVER_RETURN_URL, properties.getProperty(PROP_PREFIX + PARAM_SERVER_RETURN_URL));
		parameters.put(PARAM_ERROR_EMAIL_TO_ADDRESS,
				properties.getProperty(PROP_PREFIX + PARAM_ERROR_EMAIL_TO_ADDRESS));
		parameters.put(PARAM_CUSTOM_CUSTOMER_ID, customerId);
		parameters.put(CUSTOM_PARAM_PREFIX + PARAM_CHECKSUM, checksum);

		return getQuickstreamUtil().getSecurityToken(securityTokenRequestBaseUrl, parameters);
	}

	@Override
	public String getBrowserRedirectUrl(String securityToken) {
		if (securityToken == null) {
			throw new IllegalArgumentException(String.format("securityToken=%s", securityToken));
		}
		Map<String, String> parameters = new LinkedHashMap<String, String>();
		parameters.put(PARAM_COMMUNITY_CODE, properties.getProperty(PROP_PREFIX + PARAM_COMMUNITY_CODE));
		parameters.put(PARAM_TOKEN, securityToken);

		return getQuickstreamUtil().getBrowserRedirectUrl(browserRedirectBaseUrl, parameters);
	}

	@Override
	public SaveAccountRequest getSaveAccountRequest(Map<String, String[]> parameters) {
		if (parameters == null) {
			throw new IllegalArgumentException(String.format("parameters=%s", toString(parameters)));
		}
		if (log.isDebugEnabled()) {
			log.debug(String.format("parameters=%s", toString(parameters)));
		}
		SaveAccountRequest request = new SaveAccountRequest();

		LogUtil.putCustomerId(getParameter(parameters, PARAM_CUSTOM_CUSTOMER_ID));

		String product = getParameter(parameters, PARAM_PRODUCT);
		if (!StringUtils.equals(product, PRODUCT_QUICKVAULT)) {
			throw new IllegalArgumentException(String.format(INVALID_MESSAGE, PARAM_PRODUCT, toString(parameters)));
		}

		String communityCode = getParameter(parameters, PARAM_COMMUNITY_CODE);
		if (!StringUtils.equals(communityCode, properties.getProperty(PROP_PREFIX + PARAM_COMMUNITY_CODE))) {
			throw new IllegalArgumentException(
					String.format(INVALID_MESSAGE, PARAM_COMMUNITY_CODE, toString(parameters)));
		}

		String checksum = getParameter(parameters, CUSTOM_PARAM_PREFIX + PARAM_CHECKSUM);
		if (checksum == null) {
			throw new IllegalArgumentException(
					String.format(INVALID_MESSAGE, CUSTOM_PARAM_PREFIX + PARAM_CHECKSUM, toString(parameters)));
		}
		request.setChecksum(checksum);

		Matcher customerReferenceNumberMatcher = CUSTOMER_REFERENCE_NUMBER_PATTERN
				.matcher(StringUtils.defaultString(getParameter(parameters, PARAM_CUSTOMER_REFERENCE_NUMBER)));
		if (!customerReferenceNumberMatcher.matches()) {
			throw new IllegalArgumentException(
					String.format(INVALID_MESSAGE, PARAM_CUSTOMER_REFERENCE_NUMBER, toString(parameters)));
		}
		request.setArrangementId(new BigInteger(customerReferenceNumberMatcher.group(1)));
		request.setArrangementVersion(Integer.valueOf(customerReferenceNumberMatcher.group(2)));

		String preregistrationCode = getParameter(parameters, PARAM_PREREGISTRATION_CODE);
		if (preregistrationCode == null) {
			throw new IllegalArgumentException(
					String.format(INVALID_MESSAGE, PARAM_PREREGISTRATION_CODE, toString(parameters)));
		}
		request.setAccountToken(preregistrationCode);

		if (parameters.containsKey(PARAM_MASKED_CARD_NUMBER)) {

			request.setPaymentMethod(CREDIT_CARD);

			String maskedCardNumber = getParameter(parameters, PARAM_MASKED_CARD_NUMBER);
			if (maskedCardNumber == null) {
				throw new IllegalArgumentException(
						String.format(INVALID_MESSAGE, PARAM_MASKED_CARD_NUMBER, toString(parameters)));
			}
			request.setCardNumber(maskedCardNumber);

			String expiryDateMonth = getParameter(parameters, PARAM_EXPIRY_DATE_MONTH);
			if (expiryDateMonth == null) {
				throw new IllegalArgumentException(
						String.format(INVALID_MESSAGE, PARAM_EXPIRY_DATE_MONTH, toString(parameters)));
			}
			request.setCardExpiryMonth(expiryDateMonth);

			String expiryDateYear = getParameter(parameters, PARAM_EXPIRY_DATE_YEAR);
			if (expiryDateYear == null) {
				throw new IllegalArgumentException(
						String.format(INVALID_MESSAGE, PARAM_EXPIRY_DATE_YEAR, toString(parameters)));
			}
			request.setCardExpiryYear(expiryDateYear);

		} else if (parameters.containsKey(PARAM_ACCOUNT_NUMBER)) {

			request.setPaymentMethod(DIRECT_DEBIT);

			String bsb = getParameter(parameters, PARAM_BSB);
			if (bsb == null) {
				throw new IllegalArgumentException(String.format(INVALID_MESSAGE, PARAM_BSB, toString(parameters)));
			}
			request.setBankBsb(bsb);

			String accountNumber = getParameter(parameters, PARAM_ACCOUNT_NUMBER);
			if (accountNumber == null) {
				throw new IllegalArgumentException(
						String.format(INVALID_MESSAGE, PARAM_ACCOUNT_NUMBER, toString(parameters)));
			}
			request.setBankAccountNumber(accountNumber);

		} else {
			throw new IllegalArgumentException(
					String.format("Unable to determine payment method. Parameters: %s", toString(parameters)));
		}

		return request;
	}

	protected String getParameter(Map<String, String[]> parameters, String key) {
		String[] value = parameters.get(key);
		return ArrayUtils.isEmpty(value) ? null : StringUtils.trimToNull(value[0]);
	}

	protected String toString(Map<String, String[]> parameters) {
		if (parameters == null) {
			return NULL;
		}
		Map<String, String> map = new LinkedHashMap<String, String>();
		for (Entry<String, String[]> entry : parameters.entrySet()) {
			map.put(entry.getKey(), ArrayUtils.toString(entry.getValue(), NULL));
		}
		return map.toString();
	}

	protected QuickstreamUtil getQuickstreamUtil() {
		return quickstreamUtil;
	}

	public Properties getProperties() {
		return properties;
	}

	public void setProperties(Properties properties) {
		this.properties = properties;
	}

	public String getSecurityTokenRequestBaseUrl() {
		return securityTokenRequestBaseUrl;
	}

	public void setSecurityTokenRequestBaseUrl(String securityTokenRequestBaseUrl) {
		this.securityTokenRequestBaseUrl = securityTokenRequestBaseUrl;
	}

	public String getBrowserRedirectBaseUrl() {
		return browserRedirectBaseUrl;
	}

	public void setBrowserRedirectBaseUrl(String browserRedirectBaseUrl) {
		this.browserRedirectBaseUrl = browserRedirectBaseUrl;
	}

}
