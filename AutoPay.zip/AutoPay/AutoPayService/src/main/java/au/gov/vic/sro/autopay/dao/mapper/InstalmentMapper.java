package au.gov.vic.sro.autopay.dao.mapper;

import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.TYPE_INSTALMENT;
import static au.gov.vic.sro.autopay.dao.support.OracleUtil.createStruct;
import static au.gov.vic.sro.autopay.dao.support.OracleUtil.getValues;
import static au.gov.vic.sro.util.DateUtil.toDate;
import static au.gov.vic.sro.util.DateUtil.toSqlTimestamp;
import static au.gov.vic.sro.util.NumberUtil.toBigDecimal;
import static au.gov.vic.sro.util.NumberUtil.toIntegerExact;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.regex.Pattern;

import org.springframework.data.jdbc.support.oracle.StructMapper;

import au.gov.vic.sro.autopay.model.Arrangement;
import au.gov.vic.sro.autopay.model.Instalment;
import au.gov.vic.sro.autopay.model.InstalmentRequestSent;
import au.gov.vic.sro.autopay.model.InstalmentStatus;
import oracle.sql.STRUCT;

public class InstalmentMapper implements StructMapper<Instalment> {

	private enum RecField {
		INSTALLMENT_NO,
		PAYMENT_ARRANGEMENT_ID,
		PAYMENT_ARRANGEMENT_VERSION,
		INSTALLMENT_STATUS,
		DUE_DATE,
		AMOUNT,
		SURCHARGE,
		TOTAL_AMOUNT,
		REQUEST_SENT_CODE,
		DATE_REQUEST_SENT,
		PAO_TRANSACTION_NUMBER,
		QUICKBATCH_SUMMARY_CODE,
		QUICKBATCH_RESPONSE_CODE;
	}

	private static final Pattern TYPE_NAME_PATTERN = Pattern.compile("(.+\\.)*" + TYPE_INSTALMENT);
	private static final int TYPE_LENGTH = RecField.values().length;

	@Override
	public STRUCT toStruct(Instalment source, Connection connection, String typeName) throws SQLException {
		return createStruct(typeName, connection, toRec(source));
	}

	protected Object[] toRec(Instalment source) {
		if (source == null) {
			throw new IllegalArgumentException(String.format("source=%s", source));
		}
		Object[] rec = new Object[TYPE_LENGTH];
		rec[RecField.INSTALLMENT_NO.ordinal()] = toBigDecimal(source.getId());
		rec[RecField.INSTALLMENT_STATUS.ordinal()] = InstalmentStatus.toCode(source.getStatus());
		rec[RecField.DUE_DATE.ordinal()] = toSqlTimestamp(source.getDueDate());
		rec[RecField.AMOUNT.ordinal()] = toBigDecimal(source.getAmountDollars());
		rec[RecField.SURCHARGE.ordinal()] = toBigDecimal(source.getSurchargeDollars());
		rec[RecField.TOTAL_AMOUNT.ordinal()] = toBigDecimal(source.getTotalAmountDollars());
		rec[RecField.REQUEST_SENT_CODE.ordinal()] = InstalmentRequestSent.toCode(source.getRequestSent());
		rec[RecField.DATE_REQUEST_SENT.ordinal()] = toSqlTimestamp(source.getRequestSentDate());
		rec[RecField.PAO_TRANSACTION_NUMBER.ordinal()] = source.getTransactionNumber();
		rec[RecField.QUICKBATCH_SUMMARY_CODE.ordinal()] = source.getQuickBatchSummaryCode();
		rec[RecField.QUICKBATCH_RESPONSE_CODE.ordinal()] = source.getQuickBatchResponseCode();
		Arrangement arrangement = source.getArrangement();
		if (arrangement != null) {
			rec[RecField.PAYMENT_ARRANGEMENT_ID.ordinal()] = toBigDecimal(arrangement.getId());
			rec[RecField.PAYMENT_ARRANGEMENT_VERSION.ordinal()] = toBigDecimal(arrangement.getVersion());
		}
		return rec;
	}

	@Override
	public Instalment fromStruct(STRUCT struct) throws SQLException {
		Object[] rec = getValues(struct, TYPE_NAME_PATTERN, TYPE_LENGTH);
		Instalment target = new Instalment();
		target.setId(toIntegerExact((BigDecimal) rec[RecField.INSTALLMENT_NO.ordinal()]));
		target.setStatus(InstalmentStatus.fromCode((String) rec[RecField.INSTALLMENT_STATUS.ordinal()]));
		target.setDueDate(toDate((Timestamp) rec[RecField.DUE_DATE.ordinal()]));
		target.setAmountDollars((BigDecimal) rec[RecField.AMOUNT.ordinal()]);
		target.setSurchargeDollars((BigDecimal) rec[RecField.SURCHARGE.ordinal()]);
		target.setTotalAmountDollars((BigDecimal) rec[RecField.TOTAL_AMOUNT.ordinal()]);
		target.setRequestSent(InstalmentRequestSent.fromCode((String) rec[RecField.REQUEST_SENT_CODE.ordinal()]));
		target.setRequestSentDate(toDate((Timestamp) rec[RecField.DATE_REQUEST_SENT.ordinal()]));
		target.setTransactionNumber((String) rec[RecField.PAO_TRANSACTION_NUMBER.ordinal()]);
		target.setQuickBatchSummaryCode((String) rec[RecField.QUICKBATCH_SUMMARY_CODE.ordinal()]);
		target.setQuickBatchResponseCode((String) rec[RecField.QUICKBATCH_RESPONSE_CODE.ordinal()]);
		return target;
	}

}
