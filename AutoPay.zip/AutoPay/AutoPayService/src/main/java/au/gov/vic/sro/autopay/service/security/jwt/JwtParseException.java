package au.gov.vic.sro.autopay.service.security.jwt;


public class JwtParseException extends RuntimeException {

    public JwtParseException(String msg, Throwable t) {
        super(msg, t);
    }

}
