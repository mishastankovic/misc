package au.gov.vic.sro.autopay.dao.procedure;

import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.PACKAGE_AUTOPAY;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.PROCEDURE_GET_REFERENCE_DATA;
import static org.apache.commons.collections4.MapUtils.emptyIfNull;

import java.util.LinkedHashMap;
import java.util.Map;

import javax.sql.DataSource;
import org.springframework.jdbc.object.StoredProcedure;
import au.gov.vic.sro.autopay.dto.GetReferenceDataResponse;

public class GetReferenceDataProcedure extends StoredProcedure {

	public GetReferenceDataProcedure(DataSource dataSource) {
		super(dataSource, PACKAGE_AUTOPAY + "." + PROCEDURE_GET_REFERENCE_DATA);

		setFunction(true);
		compile();
	}

	public GetReferenceDataResponse execute(String referenceDataType) {
		Map<String, Object> in = new LinkedHashMap<>();

		Map<String, Object> out = emptyIfNull(execute(in));

		GetReferenceDataResponse response = new GetReferenceDataResponse();
		return response;
	}

}
