package au.gov.vic.sro.autopay.dao.procedure;

import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.PACKAGE_AUTOPAY;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.PROCEDURE_VALIDATE_INPUT_DATA;
import static org.apache.commons.collections4.MapUtils.emptyIfNull;

import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.object.StoredProcedure;

import au.gov.vic.sro.autopay.dto.AuthenticateUserDataResponse;

public class AuthenticateUserDataProcedure extends StoredProcedure {

	public AuthenticateUserDataProcedure(DataSource dataSource) {
		super(dataSource, PACKAGE_AUTOPAY + "." + PROCEDURE_VALIDATE_INPUT_DATA);	

		compile();
	}

	/**
	 * Partial authentication
	 */
	public AuthenticateUserDataResponse execute(String correspondenceId, LocalDate issueDate) {
		return execute(correspondenceId, issueDate, null, null, null, null, null);
	}

	/**
	 * Full authentication
	 */
	public AuthenticateUserDataResponse execute(String customerId, String assessmentId, String correspondenceId,
			String previousReceiptNumber, String ltxAssessmentId) {

		return execute(null, null, customerId, assessmentId, correspondenceId, previousReceiptNumber, ltxAssessmentId);
	}

	private AuthenticateUserDataResponse execute(String mailOutCorrespondenceId, LocalDate issueDate, String customerId,
			String assessmentId, String correspondenceId, String previousReceiptNumber, String ltxAssessmentId) {

		Map<String, Object> in = new LinkedHashMap<>();

		Map<String, Object> out = emptyIfNull(execute(in));

		AuthenticateUserDataResponse response = new AuthenticateUserDataResponse();

		return response;
	}

}