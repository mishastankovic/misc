package au.gov.vic.sro.autopay.configuration;

import au.gov.vic.sro.autopay.dao.AutoPayDao;
import au.gov.vic.sro.autopay.dao.AutoPayDaoImpl;
import au.gov.vic.sro.autopay.dao.support.WebSphereNativeJdbcExtractor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jndi.JndiTemplate;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.TransactionManagementConfigurer;
import org.springframework.transaction.jta.WebSphereUowTransactionManager;

import javax.naming.NamingException;
import javax.sql.DataSource;

@Configuration
@ComponentScan(basePackages = { "au.gov.vic.sro.autopay.dao" })
public class PersistenceConfiguration implements TransactionManagementConfigurer {

	private static final Logger log = LoggerFactory.getLogger(PersistenceConfiguration.class);

	@Autowired
	private JndiTemplate jndiTemplate;

	@Bean
	public PlatformTransactionManager transactionManager() {
		if (log.isDebugEnabled()) log.debug("Configured transaction manager; bean=[transactionManager]");
		return new WebSphereUowTransactionManager();
	}

	@Override
	public PlatformTransactionManager annotationDrivenTransactionManager() {
		return transactionManager();
	}

	@Bean
	public DataSource eBizDataSource() throws NamingException {
		return jndiTemplate.lookup("java:comp/env/jdbc/OraDataSource", DataSource.class);
	}

	@Bean
	public DataSource eSysDataSource() throws NamingException {
		return jndiTemplate.lookup("java:comp/env/jdbc/eSysDS_PAO", DataSource.class);
	}

	@Bean
	public JdbcTemplate eSysJdbcTemplate() throws NamingException {
		JdbcTemplate t = new JdbcTemplate();
		t.setDataSource(eSysDataSource());
		t.setNativeJdbcExtractor(nativeJdbcExtractor());

		return t;
	}

	@Bean
	WebSphereNativeJdbcExtractor nativeJdbcExtractor() {
		return new WebSphereNativeJdbcExtractor();
	}

	@Bean
	public AutoPayDao autoPayDao() throws NamingException {
		AutoPayDao dao = new AutoPayDaoImpl();
		((AutoPayDaoImpl) dao).setJdbcTemplate(eSysJdbcTemplate());

		return dao;
	}
}
