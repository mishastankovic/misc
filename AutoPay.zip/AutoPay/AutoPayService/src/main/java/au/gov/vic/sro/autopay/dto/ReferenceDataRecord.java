package au.gov.vic.sro.autopay.dto;

import java.io.Serializable;
import java.util.Objects;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

public class ReferenceDataRecord implements Serializable {

	private static final long serialVersionUID = -953463307296055250L;

	private String code;

	private String description;

	private String otherValue1;

	private String otherValue2;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getOtherValue1() {
		return otherValue1;
	}

	public void setOtherValue1(String otherValue1) {
		this.otherValue1 = otherValue1;
	}

	public String getOtherValue2() {
		return otherValue2;
	}

	public void setOtherValue2(String otherValue2) {
		this.otherValue2 = otherValue2;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}

		if (o == null || getClass() != o.getClass()) {
			return false;
		}

		ReferenceDataRecord referenceData = (ReferenceDataRecord) o;
		// @formatter:off
			return Objects.equals(code, referenceData.code)
					&& Objects.equals(description, referenceData.description)
					&& Objects.equals(otherValue1, referenceData.otherValue1)
					&& Objects.equals(otherValue2, referenceData.otherValue2);
			// @formatter:on
	}

	@Override
	public int hashCode() {
		// @formatter:off
			return Objects.hash(
					code,
					description,
					otherValue1,
					otherValue2);
			// @formatter:on
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}