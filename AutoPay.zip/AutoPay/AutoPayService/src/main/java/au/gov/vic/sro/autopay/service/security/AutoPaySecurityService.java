package au.gov.vic.sro.autopay.service.security;

import com.fasterxml.jackson.core.JsonProcessingException;

public interface AutoPaySecurityService {

    /**
     *
     * @param userIdentity
     * @return security token if authorisation passes or null
     * @throws JsonProcessingException
     */
    String login(UserIdentity userIdentity) throws JsonProcessingException;
}
