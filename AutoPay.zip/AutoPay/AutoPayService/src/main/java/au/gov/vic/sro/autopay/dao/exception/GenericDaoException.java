package au.gov.vic.sro.autopay.dao.exception;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import au.gov.vic.sro.autopay.dao.support.DatabaseValidationMessage;
import oracle.sql.ARRAY;
import oracle.sql.STRUCT;

public class GenericDaoException extends Exception {

	private static final long serialVersionUID = -6446938284656549513L;

	private static final Logger log = LoggerFactory.getLogger(GenericDaoException.class);

	private final List<DatabaseValidationMessage> messages = new ArrayList<>();
	private final Map<String, String> parameters = new HashMap<>();
	private final Map<String, String> returnValues = new HashMap<>();
	private final String sql;

	public GenericDaoException(Throwable cause, String message, String sql) {
		super(message, cause);
		this.sql = StringUtils.trimToNull(sql);
	}

	public GenericDaoException(String message, String sql) {
		super(message);
		this.sql = StringUtils.trimToNull(sql);
	}

	public GenericDaoException(String message, String sql, Map<String, Object> inParameters) {
		this(message, sql);
		if (inParameters == null) {
			return;
		}

		for (Map.Entry<String, Object> entrySet : inParameters.entrySet()) {
			addParameter(entrySet.getKey(), entrySet);
		}
	}

	public GenericDaoException(String message, String sql, Throwable cause) {
		super(message, cause);
		this.sql = StringUtils.trimToNull(sql);
	}

	public GenericDaoException(Throwable cause, String message, String sql, Map<String, Object> inParameters) {
		this(message, sql, cause);
		if (inParameters == null) {
			return;
		}

		for (Map.Entry<String, Object> entrySet : inParameters.entrySet()) {
			addParameter(entrySet.getKey(), entrySet);
		}
	}

	public GenericDaoException(String message, String sql, Map<String, Object> inParameters,
			Map<String, Object> outParameters) {
		this(message, sql, inParameters);

		if (outParameters == null) {
			return;
		}

		for (Map.Entry<String, Object> entrySet : outParameters.entrySet()) {
			addReturnValue(entrySet.getKey(), entrySet);
		}

	}

	public GenericDaoException(Throwable cause, String message, String sql, Map<String, Object> inParameters,
			Map<String, Object> outParameters) {
		this(cause, message, sql, inParameters);

		if (outParameters == null) {
			return;
		}

		for (Map.Entry<String, Object> entrySet : outParameters.entrySet()) {
			addReturnValue(entrySet.getKey(), entrySet);
		}
	}

	public void addParameter(String key, Object value) {
		parameters.put(key, coerceToString(value));
	}

	private String coerceToString(Object value) {
		if (value == null) {
			return null;
		}

		if (value instanceof String) {
			return (String) value;
		}

		if (value instanceof STRUCT) {
			try {
				return (((STRUCT) value).dump());
			} catch (SQLException ex) {
				log.debug(ex.getMessage(), ex);
				// Can't throw an exception
				return value.toString();
			}
		}

		if (value instanceof ARRAY) {
			try {
				return ((ARRAY) value).dump();
			} catch (SQLException ex) {
				log.debug(ex.getMessage(), ex);
				// Can't throw an exception
				return value.toString();
			}
		}

		return value.toString();
	}

	public void addReturnValue(String key, Object value) {
		returnValues.put(key, coerceToString(value));
	}

	public List<DatabaseValidationMessage> getMessages() {
		return messages;
	}

	public String outputMessages() {
		StringBuilder buffer = new StringBuilder();
		for (DatabaseValidationMessage message : messages) {
			buffer.append(String.format("Identifier: %s, Type: %s, Message: %s%n", message.getMessageIdentifier(),
					message.getType(), message.getMessage()));
		}
		return buffer.toString();
	}

	public String outputDetail() {
		StringBuilder buffer = new StringBuilder();
		buffer.append("GenericDaoException Detailed Output: START\n");
		buffer.append(getMessage() + "\n");

		if (sql != null) {
			buffer.append(String.format("Invoked SQL: [%s]%n", sql));
		}

		buffer.append("\nInput Parameters:\n");

		for (Map.Entry<String, String> entrySet : parameters.entrySet()) {
			buffer.append(
					String.format("\tParameter Name: [%s], Parameter Value: [%s]%n", entrySet.getKey(), entrySet));
		}

		buffer.append("\nReturn Values :\n");
		for (Map.Entry<String, String> entrySet : returnValues.entrySet()) {
			buffer.append(String.format("\tReturn Value Key: [%s], Return Value: [%s]%n", entrySet.getKey(), entrySet));
		}

		buffer.append("\nMessages:\n");
		buffer.append(outputMessages());
		buffer.append("GenericDaoException Detailed Output: END\n");
		return buffer.toString();
	}

	public boolean hasMessage(String messageIdentifier) {
		boolean found = false;
		for (DatabaseValidationMessage message : messages) {
			if (messageIdentifier.equals(message.getMessageIdentifier())) {
				found = true;
				break;
			}
		}

		return found;
	}

	@Override
	public String toString() {
		return outputDetail();
	}

}
