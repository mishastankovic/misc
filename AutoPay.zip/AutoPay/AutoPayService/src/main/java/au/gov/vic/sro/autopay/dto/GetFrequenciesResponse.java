package au.gov.vic.sro.autopay.dto;

import static au.gov.vic.sro.builder.ToStringStyleFactory.getToStringStyle;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import au.gov.vic.sro.autopay.model.PaymentFrequency;

public class GetFrequenciesResponse extends MessageResponse implements Serializable {
	private static final long serialVersionUID = 6562913724022918303L;
	private List<PaymentFrequency> paymentFrequencies = new ArrayList<PaymentFrequency>();

	public List<PaymentFrequency> getPaymentFrequencies() {
		return paymentFrequencies;
	}

	public void setPaymentFrequencies(List<PaymentFrequency> paymentFrequencies) {
		this.paymentFrequencies.clear();
		if (CollectionUtils.isNotEmpty(paymentFrequencies)) {
			this.paymentFrequencies.addAll(paymentFrequencies);
		}
	}

	public void setPaymentFrequencies(Object[] paymentFrequencies) {
		this.paymentFrequencies.clear();
		if (ArrayUtils.isNotEmpty(paymentFrequencies)) {
			for (Object paymentFrequency : paymentFrequencies) {
				this.paymentFrequencies.add((PaymentFrequency) paymentFrequency);
			}
		}
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, getToStringStyle());
	}

}
