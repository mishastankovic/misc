package au.gov.vic.sro.autopay.dto;

import static au.gov.vic.sro.builder.ToStringStyleFactory.getToStringStyle;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import au.gov.vic.sro.autopay.model.Arrangement;

public class FindArrangementResponse extends MessageResponse implements Serializable {
	private static final long serialVersionUID = -2783870859719309382L;
	private Arrangement arrangement;

	public Arrangement getArrangement() {
		return arrangement;
	}

	public void setArrangement(Arrangement arrangement) {
		this.arrangement = arrangement;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, getToStringStyle());
	}

}
