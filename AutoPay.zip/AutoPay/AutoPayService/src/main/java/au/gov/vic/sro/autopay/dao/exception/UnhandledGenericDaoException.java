package au.gov.vic.sro.autopay.dao.exception;

public class UnhandledGenericDaoException extends RuntimeException {

	private static final long serialVersionUID = 458881788287515738L;

	public UnhandledGenericDaoException(GenericDaoException exception) {
		super(exception);
	}

}
