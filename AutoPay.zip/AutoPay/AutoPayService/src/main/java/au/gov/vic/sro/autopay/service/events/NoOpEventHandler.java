package au.gov.vic.sro.autopay.service.events;

import static au.gov.vic.sro.autopay.model.EventStatus.SUCCESSFUL;

import au.gov.vic.sro.autopay.model.Event;

public class NoOpEventHandler implements EventHandler {

	@Override
	public void handle(Event event) {
		event.setStatus(SUCCESSFUL);
	}

}
