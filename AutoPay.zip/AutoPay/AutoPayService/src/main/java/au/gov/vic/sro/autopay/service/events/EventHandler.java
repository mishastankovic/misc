package au.gov.vic.sro.autopay.service.events;

import au.gov.vic.sro.autopay.model.Event;

public interface EventHandler {

	void handle(Event event);

}
