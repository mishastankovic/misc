package au.gov.vic.sro.autopay.service.security;

import au.gov.vic.sro.autopay.model.LiabilityType;
import au.gov.vic.sro.autopay.model.RevenueLine;
import au.gov.vic.sro.autopay.service.security.jwt.JwtTokenProvider;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

@Service("autoPaySecurityService")
public class AutoPaySecurityServiceImpl implements AutoPaySecurityService {

    public static final String TOKEN_CLAIM_REVENUE_LINE = "revenueLine";
    public static final String TOKEN_CLAIM_AUTHORISATIONS = "auth";
    public static final String TOKEN_CLAIM_CUSTOMER_ID = "customerId";
    public static final String TOKEN_CLAIM_USERNAME = "username";


    @Autowired
    private UserDetailsService userDetailsService;

    @Autowired
    private ObjectMapper jsonMapper;

    @Autowired
    private JwtTokenProvider jwtTokenProvider;


    public String login(UserIdentity userIdentity) throws JsonProcessingException {
        String userDetailsJson = getUserDetails(userIdentity);
        UserDetailsImpl userDetails = (UserDetailsImpl)userDetailsService.loadUserByUsername(userDetailsJson);
        Map<String, Object> claims = getUserClaims(userDetails);

        return jwtTokenProvider.createToken(userIdentity.getUsername(), claims);

    }

    /**
     *
     * @param userIdentity
     * @return
     * @throws JsonProcessingException
     */
    private String getUserDetails(UserIdentity userIdentity) throws JsonProcessingException {

        // Construct UserDetails
        UserDetailsImpl userDetails = new UserDetailsImpl();
        userDetails.setCustomerId(userIdentity.getCustomerId());
        userDetails.setUsername(userIdentity.getUsername());
        userDetails.setPassword(userIdentity.getPassword());
        userDetails.setRevenueLine(RevenueLine.fromCode(userIdentity.getRevenueLine()));
        userDetails.setLiabilityId(userIdentity.getLiabilityId());
        userDetails.setLiabilityType(LiabilityType.ASSESSMENT);

        return jsonMapper.writeValueAsString(userDetails);
    }

    private Map<String, Object> getUserClaims(UserDetailsImpl userDetails) {
        Map<String, Object> claims = new HashMap<String, Object>();
        claims.put(TOKEN_CLAIM_REVENUE_LINE, userDetails.getRevenueLine().getCode());
        claims.put(TOKEN_CLAIM_AUTHORISATIONS, userDetails.getAuthorities()
                .stream().map(c -> c.toString())
                .collect(Collectors.joining(",")));
        claims.put(TOKEN_CLAIM_CUSTOMER_ID, userDetails.getCustomerId());
        claims.put(TOKEN_CLAIM_USERNAME, userDetails.getUsername());

        return claims;
    }
}
