package au.gov.vic.sro.autopay.dto;

import static au.gov.vic.sro.builder.ToStringStyleFactory.getToStringStyle;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

public class CancelArrangementResponse extends MessageResponse implements Serializable {
	private static final long serialVersionUID = -819254224268261568L;
	private Boolean cancelled;

	public Boolean getCancelled() {
		return cancelled;
	}

	public void setCancelled(Boolean cancelled) {
		this.cancelled = cancelled;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, getToStringStyle());
	}

}
