package au.gov.vic.sro.autopay.service;

import java.math.BigInteger;
import java.util.Date;
import java.util.List;

import au.gov.vic.sro.autopay.dto.CalculateScheduleResponse;
import au.gov.vic.sro.autopay.dto.CancelArrangementResponse;
import au.gov.vic.sro.autopay.dto.FindArrangementResponse;
import au.gov.vic.sro.autopay.dto.GetConfirmCancelTextResponse;
import au.gov.vic.sro.autopay.dto.GetDefaultDatesResponse;
import au.gov.vic.sro.autopay.dto.GetEventsResponse;
import au.gov.vic.sro.autopay.dto.GetFrequenciesResponse;
import au.gov.vic.sro.autopay.dto.NextEventResponse;
import au.gov.vic.sro.autopay.dto.SaveAccountRequest;
import au.gov.vic.sro.autopay.dto.SaveAccountResponse;
import au.gov.vic.sro.autopay.dto.SaveArrangementResponse;
import au.gov.vic.sro.autopay.dto.SaveContactsResponse;
import au.gov.vic.sro.autopay.model.Arrangement;
import au.gov.vic.sro.autopay.model.Contact;
import au.gov.vic.sro.autopay.model.Event;
import au.gov.vic.sro.autopay.model.LiabilityType;
import au.gov.vic.sro.autopay.model.PaymentFrequency;
import au.gov.vic.sro.autopay.model.PaymentMethod;
import au.gov.vic.sro.autopay.model.RevenueLine;

public interface AutoPayService {

	FindArrangementResponse findArrangement(String customerId, RevenueLine revenueLine, LiabilityType liabilityType,
			String liabilityId);

	FindArrangementResponse findArrangement(BigInteger arrangementId, Integer arrangementVersion);

	GetDefaultDatesResponse getDefaultDates(String customerId, RevenueLine revenueLine, LiabilityType liabilityType,
			String liabilityId);

	GetFrequenciesResponse getFrequencies(String customerId, RevenueLine revenueLine, LiabilityType liabilityType,
			String liabilityId, Date arrangementStartDate, Date arrangementEndDate);

	CalculateScheduleResponse calculateSchedule(String customerId, RevenueLine revenueLine, LiabilityType liabilityType,
			String liabilityId, Date arrangementStartDate, Date arrangementEndDate, PaymentFrequency paymentFrequency,
			PaymentMethod paymentMethod);

	SaveArrangementResponse saveArrangement(Arrangement arrangement);

	SaveAccountResponse saveAccount(SaveAccountRequest request);

	SaveContactsResponse saveContacts(List<Contact> contacts, String checksum);

	GetConfirmCancelTextResponse getConfirmCancelText(BigInteger arrangementId, Integer arrangementVersion);

	CancelArrangementResponse cancelArrangement(BigInteger arrangementId, Integer arrangementVersion);

	NextEventResponse nextEvent();

	void saveEvent(Event event);

	GetEventsResponse getEvents(List<BigInteger> eventIds);

}
