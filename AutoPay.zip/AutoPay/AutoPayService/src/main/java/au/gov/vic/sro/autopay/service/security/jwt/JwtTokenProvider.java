package au.gov.vic.sro.autopay.service.security.jwt;

import java.util.Base64;
import java.util.Date;
import java.util.Map;
import java.util.Optional;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.apache.http.HttpHeaders;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

@Component
public class JwtTokenProvider {
  public static final String BEARER_HEADER = "Bearer ";

  @Value("${security.jwt.token.secret-key:secret-key}")
  private String secretKey;

  @Value("${security.jwt.token.expire-length:3600000}")
  private long validityInMilliseconds = 3600000; // 1h


  @PostConstruct
  protected void init() {
    secretKey = Base64.getEncoder().encodeToString(secretKey.getBytes());
  }

  public String createToken(String username, Map<String, Object> claims) {

    Claims tokenClaims = Jwts.claims().setSubject(username);
    tokenClaims.putAll(claims);

    Date now = new Date();
    Date validity = new Date(System.currentTimeMillis() + validityInMilliseconds);

    return Jwts.builder()
        .setClaims(tokenClaims)
        .setIssuedAt(now)
        .setExpiration(validity)
        .signWith(SignatureAlgorithm.HS256, secretKey)
        .compact();
  }

  public Authentication getAuthentication(String token) {
    Claims claims = getClaims(token).getBody();
    return new UsernamePasswordAuthenticationToken(claims.getSubject(), claims);
  }

  public String getUsername(String token) {
    return Jwts.parser().setSigningKey(secretKey).parseClaimsJws(token).getBody().getSubject();
  }

  public String resolveToken(HttpServletRequest req) {
    return Optional.ofNullable(req.getHeader(HttpHeaders.AUTHORIZATION))
            .filter(s -> s.startsWith(BEARER_HEADER))
            .map(s -> s.substring(BEARER_HEADER.length()))
            .orElseGet(() -> null);
  }

  /**
   *
   * @param token
   * @return
   */
  public boolean validateToken(String token) {
    try {
      getClaims(token);
      return true;
    } catch (JwtException | IllegalArgumentException e) {
      throw new JwtParseException("Expired or invalid JWT token", e);
    }
  }

  /**
   * Decodes a token and returns the claims it contains.
   * @param token - encoded token string
   * @return Claims contained in the token
   */
  public Jws<Claims> getClaims(String token) {
    return Jwts.parser()
            .setSigningKey(secretKey)
            .parseClaimsJws(token);
  }

}
