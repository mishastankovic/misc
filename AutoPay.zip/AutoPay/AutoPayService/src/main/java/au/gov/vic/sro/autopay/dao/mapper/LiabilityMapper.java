package au.gov.vic.sro.autopay.dao.mapper;

import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.TYPE_LIABILITY;
import static au.gov.vic.sro.autopay.dao.support.OracleUtil.createStruct;
import static au.gov.vic.sro.autopay.dao.support.OracleUtil.getValues;
import static au.gov.vic.sro.util.DateUtil.toDate;
import static au.gov.vic.sro.util.DateUtil.toSqlTimestamp;
import static au.gov.vic.sro.util.NumberUtil.toBigDecimal;
import static au.gov.vic.sro.util.NumberUtil.toIntegerExact;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.regex.Pattern;

import org.springframework.data.jdbc.support.oracle.StructMapper;

import au.gov.vic.sro.autopay.model.Arrangement;
import au.gov.vic.sro.autopay.model.Liability;
import au.gov.vic.sro.autopay.model.LiabilityType;
import au.gov.vic.sro.autopay.model.RevenueLine;
import oracle.sql.STRUCT;

public class LiabilityMapper implements StructMapper<Liability> {

	private enum RecField {
		PAO_LIABILITY_REFERENCE_TYPE,
		LIABILITY_REFERENCE_ID,
		LIABILITY_REFERENCE_VERSION,
		LIABILITY_YEAR,
		LIABILITY_ISSUE_DATE,
		REVENUE_TYPE,
		PAYMENT_ARRANGEMENT_ID,
		PAYMENT_ARRANGEMENT_VERSION,
		OUTSTANDING_LIABILITY_AMOUNT;
	}

	private static final Pattern TYPE_NAME_PATTERN = Pattern.compile("(.+\\.)*" + TYPE_LIABILITY);
	private static final int TYPE_LENGTH = RecField.values().length;

	@Override
	public STRUCT toStruct(Liability source, Connection connection, String typeName) throws SQLException {
		return createStruct(typeName, connection, toRec(source));
	}

	protected Object[] toRec(Liability source) {
		if (source == null) {
			throw new IllegalArgumentException(String.format("source=%s", source));
		}
		Object[] rec = new Object[TYPE_LENGTH];
		rec[RecField.REVENUE_TYPE.ordinal()] = RevenueLine.toCode(source.getRevenueLine());
		rec[RecField.PAO_LIABILITY_REFERENCE_TYPE.ordinal()] = LiabilityType.toCode(source.getType());
		rec[RecField.LIABILITY_REFERENCE_ID.ordinal()] = source.getId();
		rec[RecField.LIABILITY_REFERENCE_VERSION.ordinal()] = toBigDecimal(source.getVersion());
		rec[RecField.LIABILITY_ISSUE_DATE.ordinal()] = toSqlTimestamp(source.getIssueDate());
		rec[RecField.LIABILITY_YEAR.ordinal()] = toBigDecimal(source.getYear());
		rec[RecField.OUTSTANDING_LIABILITY_AMOUNT.ordinal()] =
				toBigDecimal(source.getOutstandingLiabilityAmountDollars());
		Arrangement arrangement = source.getArrangement();
		if (arrangement != null) {
			rec[RecField.PAYMENT_ARRANGEMENT_ID.ordinal()] = toBigDecimal(arrangement.getId());
			rec[RecField.PAYMENT_ARRANGEMENT_VERSION.ordinal()] = toBigDecimal(arrangement.getVersion());
		}
		return rec;
	}

	@Override
	public Liability fromStruct(STRUCT struct) throws SQLException {
		Object[] rec = getValues(struct, TYPE_NAME_PATTERN, TYPE_LENGTH);
		Liability target = new Liability();
		target.setRevenueLine(RevenueLine.fromCode((String) rec[RecField.REVENUE_TYPE.ordinal()]));
		target.setType(LiabilityType.fromCode((String) rec[RecField.PAO_LIABILITY_REFERENCE_TYPE.ordinal()]));
		target.setId((String) rec[RecField.LIABILITY_REFERENCE_ID.ordinal()]);
		target.setVersion(toIntegerExact((BigDecimal) rec[RecField.LIABILITY_REFERENCE_VERSION.ordinal()]));
		target.setIssueDate(toDate((Timestamp) rec[RecField.LIABILITY_ISSUE_DATE.ordinal()]));
		target.setYear(toIntegerExact((BigDecimal) rec[RecField.LIABILITY_YEAR.ordinal()]));
		target.setOutstandingLiabilityAmountDollars((BigDecimal) rec[RecField.OUTSTANDING_LIABILITY_AMOUNT.ordinal()]);
		return target;
	}

}
