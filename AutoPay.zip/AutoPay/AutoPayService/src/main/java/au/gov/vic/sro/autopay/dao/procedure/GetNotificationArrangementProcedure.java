package au.gov.vic.sro.autopay.dao.procedure;

import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.IN_ARRANGEMENT_ID;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.IN_ARRANGEMENT_VERSION;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.OUT_CONTACTS;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.OUT_INSTALMENTS;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.OUT_LIABILITIES;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.OUT_MESSAGES;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.OUT_PAYMENT_ARRANGEMENT;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.PACKAGE_PAYMENT_ARRANGEMENTS_SERVICES;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.PROCEDURE_GET_NOTIFICATION_ARRANGEMENT;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.TYPE_CONTACTS;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.TYPE_INSTALMENTS;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.TYPE_LIABILITIES;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.TYPE_MESSAGES;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.TYPE_PAYMENT_ARRANGEMENT;
import static au.gov.vic.sro.util.NumberUtil.toBigDecimal;
import static java.sql.Types.ARRAY;
import static java.sql.Types.NUMERIC;
import static java.sql.Types.STRUCT;
import static org.apache.commons.collections4.MapUtils.emptyIfNull;

import java.math.BigInteger;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.data.jdbc.support.oracle.SqlReturnStruct;
import org.springframework.data.jdbc.support.oracle.SqlReturnStructArray;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import au.gov.vic.sro.autopay.dao.mapper.ArrangementMapper;
import au.gov.vic.sro.autopay.dao.mapper.ContactMapper;
import au.gov.vic.sro.autopay.dao.mapper.InstalmentMapper;
import au.gov.vic.sro.autopay.dao.mapper.LiabilityMapper;
import au.gov.vic.sro.autopay.dao.mapper.MessageMapper;
import au.gov.vic.sro.autopay.dto.FindArrangementResponse;
import au.gov.vic.sro.autopay.model.Arrangement;
import au.gov.vic.sro.autopay.model.Contact;
import au.gov.vic.sro.autopay.model.Instalment;
import au.gov.vic.sro.autopay.model.Liability;
import au.gov.vic.sro.autopay.model.Message;

public class GetNotificationArrangementProcedure extends StoredProcedure {
	public GetNotificationArrangementProcedure(JdbcTemplate jdbcTemplate) {
		super(jdbcTemplate, PACKAGE_PAYMENT_ARRANGEMENTS_SERVICES + "." + PROCEDURE_GET_NOTIFICATION_ARRANGEMENT);
		declareParameter(new SqlParameter(IN_ARRANGEMENT_ID, NUMERIC));
		declareParameter(new SqlParameter(IN_ARRANGEMENT_VERSION, NUMERIC));
		declareParameter(new SqlOutParameter(OUT_PAYMENT_ARRANGEMENT, STRUCT, TYPE_PAYMENT_ARRANGEMENT,
				new SqlReturnStruct(new ArrangementMapper())));
		declareParameter(new SqlOutParameter(OUT_LIABILITIES, ARRAY, TYPE_LIABILITIES,
				new SqlReturnStructArray<Liability>(new LiabilityMapper())));
		declareParameter(new SqlOutParameter(OUT_INSTALMENTS, ARRAY, TYPE_INSTALMENTS,
				new SqlReturnStructArray<Instalment>(new InstalmentMapper())));
		declareParameter(new SqlOutParameter(OUT_CONTACTS, ARRAY, TYPE_CONTACTS, new SqlReturnStructArray<Contact>(
				new ContactMapper())));
		declareParameter(new SqlOutParameter(OUT_MESSAGES, ARRAY, TYPE_MESSAGES, new SqlReturnStructArray<Message>(
				new MessageMapper())));
		compile();
	}

	public FindArrangementResponse execute(BigInteger arrangementId, Integer arrangementVersion) {
		Map<String, Object> in = new LinkedHashMap<String, Object>();
		in.put(IN_ARRANGEMENT_ID, toBigDecimal(arrangementId));
		in.put(IN_ARRANGEMENT_VERSION, toBigDecimal(arrangementVersion));

		Map<String, Object> out = emptyIfNull(execute(in));
		FindArrangementResponse response = new FindArrangementResponse();
		Arrangement arrangement = (Arrangement) out.get(OUT_PAYMENT_ARRANGEMENT);
		if (arrangement == null) {
			arrangement = new Arrangement();
		}
		arrangement.setLiabilities((Object[]) out.get(OUT_LIABILITIES));
		arrangement.setInstalments((Object[]) out.get(OUT_INSTALMENTS));
		arrangement.setContacts((Object[]) out.get(OUT_CONTACTS));
		response.setArrangement(arrangement);
		response.setMessages((Object[]) out.get(OUT_MESSAGES));
		return response;
	}

}
