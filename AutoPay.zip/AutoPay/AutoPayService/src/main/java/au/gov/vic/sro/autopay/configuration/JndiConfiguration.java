package au.gov.vic.sro.autopay.configuration;

import java.util.Properties;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jndi.JndiTemplate;

@Configuration
public class JndiConfiguration {

	@Bean
	public JndiTemplate jndiTemplate() {
		Properties properties = new Properties();
		properties.put("java.naming.factory.initial", "com.ibm.websphere.naming.WsnInitialContextFactory");
		return new JndiTemplate(properties);
	}

}
