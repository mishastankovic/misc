package au.gov.vic.sro.autopay.dao.mapper;

import java.sql.CallableStatement;
import java.sql.SQLException;

import org.springframework.jdbc.core.SqlReturnType;

import au.gov.vic.sro.util.BooleanUtil;

public class BooleanReturnType implements SqlReturnType {

	@Override
	public Object getTypeValue(CallableStatement cs, int paramIndex, int sqlType, String typeName) throws SQLException {
		return BooleanUtil.toBoolean(cs.getString(paramIndex));
	}

}
