package au.gov.vic.sro.autopay.dto;

import static au.gov.vic.sro.builder.ToStringStyleFactory.getToStringStyle;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import au.gov.vic.sro.autopay.model.reference.ReferenceData;

public class GetReferenceDataResponse implements Serializable {

	private static final long serialVersionUID = 324112392103669137L;

	private List<ReferenceData> referenceData = new ArrayList<>();

	public List<ReferenceData> getReferenceData() {
		return referenceData;
	}

	public void setReferenceData(List<ReferenceData> referenceData) {
		this.referenceData.clear();

		if (CollectionUtils.isNotEmpty(referenceData)) {
			this.referenceData.addAll(referenceData);
		}
	}

	public void setReferenceData(String referenceDataType, Object[] referenceDataRecords) {
		this.referenceData.clear();

		if (ArrayUtils.isNotEmpty(referenceDataRecords)) {
			for (Object referenceDataRecord : referenceDataRecords) {
				this.referenceData.add(mapReferenceData(referenceDataType, (ReferenceDataRecord) referenceDataRecord));
			}
		}
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, getToStringStyle());
	}

	private ReferenceData mapReferenceData(String referenceDataType, ReferenceDataRecord referenceDataRecord) {
		ReferenceData refData = new ReferenceData();

		refData.setType(referenceDataType);
		refData.setCode(referenceDataRecord.getCode());
		refData.setLabel(referenceDataRecord.getDescription());
		return refData;
	}

}
