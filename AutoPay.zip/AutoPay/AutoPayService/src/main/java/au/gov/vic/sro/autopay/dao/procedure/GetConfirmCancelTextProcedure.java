package au.gov.vic.sro.autopay.dao.procedure;

import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.IN_ARRANGEMENT_ID;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.IN_ARRANGEMENT_VERSION;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.OUT_MESSAGES;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.OUT_MESSAGE_TEXT;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.PACKAGE_PAYMENT_ARRANGEMENTS_SERVICES;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.PROCEDURE_GET_CONFIRM_CANCEL_TEXT;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.TYPE_MESSAGES;
import static au.gov.vic.sro.util.NumberUtil.toBigDecimal;
import static java.sql.Types.ARRAY;
import static java.sql.Types.NUMERIC;
import static java.sql.Types.VARCHAR;
import static org.apache.commons.collections4.MapUtils.emptyIfNull;

import java.math.BigInteger;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.data.jdbc.support.oracle.SqlReturnStructArray;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import au.gov.vic.sro.autopay.dao.mapper.MessageMapper;
import au.gov.vic.sro.autopay.dto.GetConfirmCancelTextResponse;
import au.gov.vic.sro.autopay.model.Message;

public class GetConfirmCancelTextProcedure extends StoredProcedure {

	public GetConfirmCancelTextProcedure(JdbcTemplate jdbcTemplate) {
		super(jdbcTemplate, PACKAGE_PAYMENT_ARRANGEMENTS_SERVICES + "." + PROCEDURE_GET_CONFIRM_CANCEL_TEXT);
		declareParameter(new SqlParameter(IN_ARRANGEMENT_ID, NUMERIC));
		declareParameter(new SqlParameter(IN_ARRANGEMENT_VERSION, NUMERIC));
		declareParameter(new SqlOutParameter(OUT_MESSAGE_TEXT, VARCHAR));
		declareParameter(new SqlOutParameter(OUT_MESSAGES, ARRAY, TYPE_MESSAGES, new SqlReturnStructArray<Message>(
				new MessageMapper())));
		compile();
	}

	public GetConfirmCancelTextResponse execute(BigInteger arrangementId, Integer arrangementVersion) {
		Map<String, Object> in = new LinkedHashMap<String, Object>();
		in.put(IN_ARRANGEMENT_ID, toBigDecimal(arrangementId));
		in.put(IN_ARRANGEMENT_VERSION, toBigDecimal(arrangementVersion));

		Map<String, Object> out = emptyIfNull(execute(in));

		GetConfirmCancelTextResponse response = new GetConfirmCancelTextResponse();
		response.setText((String) out.get(OUT_MESSAGE_TEXT));
		response.setMessages((Object[]) out.get(OUT_MESSAGES));
		return response;
	}

}
