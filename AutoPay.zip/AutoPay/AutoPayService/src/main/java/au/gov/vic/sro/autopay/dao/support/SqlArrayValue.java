package au.gov.vic.sro.autopay.dao.support;

import static au.gov.vic.sro.autopay.dao.support.OracleUtil.unwrap;

import java.sql.Connection;
import java.sql.SQLException;

public class SqlArrayValue<T> extends org.springframework.data.jdbc.support.oracle.SqlArrayValue<T> {

	public SqlArrayValue(T[] values, String defaultTypeName) {
		super(values, defaultTypeName);
	}

	public SqlArrayValue(T[] values) {
		super(values);
	}

	@Override
	protected Object createTypeValue(Connection connection, int sqlType, String typeName) throws SQLException {
		return super.createTypeValue(unwrap(connection), sqlType, typeName);
	}

}
