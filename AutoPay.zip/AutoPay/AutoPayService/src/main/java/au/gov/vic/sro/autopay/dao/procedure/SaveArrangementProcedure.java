package au.gov.vic.sro.autopay.dao.procedure;

import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.IN_CONTACTS;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.IN_INSTALMENTS;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.IN_LIABILITIES;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.IN_OUT_CHECKSUM;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.IN_PAYMENT_ARRANGEMENT;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.OUT_ARRANGEMENT_ID;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.OUT_ARRANGEMENT_VERSION;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.OUT_MESSAGES;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.PACKAGE_PAYMENT_ARRANGEMENTS_SERVICES;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.PROCEDURE_SAVE_ARRANGEMENT;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.TYPE_CONTACT;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.TYPE_CONTACTS;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.TYPE_INSTALMENT;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.TYPE_INSTALMENTS;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.TYPE_LIABILITIES;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.TYPE_LIABILITY;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.TYPE_MESSAGES;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.TYPE_PAYMENT_ARRANGEMENT;
import static au.gov.vic.sro.util.NumberUtil.toBigInteger;
import static au.gov.vic.sro.util.NumberUtil.toIntegerExact;
import static java.sql.Types.ARRAY;
import static java.sql.Types.NUMERIC;
import static java.sql.Types.STRUCT;
import static java.sql.Types.VARCHAR;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.commons.collections4.MapUtils;
import org.springframework.data.jdbc.support.oracle.SqlReturnStructArray;
import org.springframework.data.jdbc.support.oracle.SqlStructValue;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlInOutParameter;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import au.gov.vic.sro.autopay.dao.mapper.ArrangementMapper;
import au.gov.vic.sro.autopay.dao.mapper.ContactMapper;
import au.gov.vic.sro.autopay.dao.mapper.InstalmentMapper;
import au.gov.vic.sro.autopay.dao.mapper.LiabilityMapper;
import au.gov.vic.sro.autopay.dao.mapper.MessageMapper;
import au.gov.vic.sro.autopay.dao.support.SqlStructArrayValue;
import au.gov.vic.sro.autopay.dto.SaveArrangementResponse;
import au.gov.vic.sro.autopay.model.Arrangement;
import au.gov.vic.sro.autopay.model.Contact;
import au.gov.vic.sro.autopay.model.Instalment;
import au.gov.vic.sro.autopay.model.Liability;
import au.gov.vic.sro.autopay.model.Message;

public class SaveArrangementProcedure extends StoredProcedure {

	public SaveArrangementProcedure(JdbcTemplate jdbcTemplate) {
		super(jdbcTemplate, PACKAGE_PAYMENT_ARRANGEMENTS_SERVICES + "." + PROCEDURE_SAVE_ARRANGEMENT);
		declareParameter(new SqlParameter(IN_PAYMENT_ARRANGEMENT, STRUCT, TYPE_PAYMENT_ARRANGEMENT));
		declareParameter(new SqlParameter(IN_LIABILITIES, ARRAY, TYPE_LIABILITIES));
		declareParameter(new SqlParameter(IN_INSTALMENTS, ARRAY, TYPE_INSTALMENTS));
		declareParameter(new SqlParameter(IN_CONTACTS, ARRAY, TYPE_CONTACTS));
		declareParameter(new SqlOutParameter(OUT_ARRANGEMENT_ID, NUMERIC));
		declareParameter(new SqlOutParameter(OUT_ARRANGEMENT_VERSION, NUMERIC));
		declareParameter(new SqlOutParameter(OUT_MESSAGES, ARRAY, TYPE_MESSAGES,
				new SqlReturnStructArray<Message>(new MessageMapper())));
		declareParameter(new SqlInOutParameter(IN_OUT_CHECKSUM, VARCHAR));

		compile();
	}

	public SaveArrangementResponse execute(Arrangement arrangement) {
		Map<String, Object> in = new LinkedHashMap<String, Object>();
		in.put(IN_PAYMENT_ARRANGEMENT, new SqlStructValue<Arrangement>(arrangement, new ArrangementMapper()));
		in.put(IN_LIABILITIES,
				new SqlStructArrayValue<Liability>(
						Liability.toArray(arrangement == null ? null : arrangement.getLiabilities(), true),
						new LiabilityMapper(), TYPE_LIABILITY));
		in.put(IN_INSTALMENTS,
				new SqlStructArrayValue<Instalment>(
						Instalment.toArray(arrangement == null ? null : arrangement.getInstalments(), true),
						new InstalmentMapper(), TYPE_INSTALMENT));
		in.put(IN_CONTACTS,
				new SqlStructArrayValue<Contact>(
						Contact.toArray(arrangement == null ? null : arrangement.getContacts(), true),
						new ContactMapper(), TYPE_CONTACT));
		in.put(IN_OUT_CHECKSUM, arrangement == null ? null : arrangement.getChecksum());

		Map<String, Object> out = MapUtils.emptyIfNull(execute(in));

		SaveArrangementResponse response = new SaveArrangementResponse();
		response.setArrangementId(toBigInteger((BigDecimal) out.get(OUT_ARRANGEMENT_ID)));
		response.setArrangementVersion(toIntegerExact((BigDecimal) out.get(OUT_ARRANGEMENT_VERSION)));
		response.setChecksum((String) out.get(IN_OUT_CHECKSUM));
		response.setSaved(response.getArrangementId() != null && response.getArrangementVersion() != null);
		response.setMessages((Object[]) out.get(OUT_MESSAGES));
		return response;
	}

}
