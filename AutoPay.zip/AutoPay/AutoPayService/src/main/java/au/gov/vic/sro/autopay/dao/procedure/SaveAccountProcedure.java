package au.gov.vic.sro.autopay.dao.procedure;

import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.IN_ACCOUNT_TOKEN;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.IN_ARRANGEMENT_ID;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.IN_ARRANGEMENT_VERSION;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.IN_BANK_ACCOUNT_BSB;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.IN_BANK_ACCOUNT_NUMBER;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.IN_CARD_EXPIRY_MONTH;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.IN_CARD_EXPIRY_YEAR;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.IN_CARD_NUMBER;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.IN_OUT_CHECKSUM;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.IN_PAYMENT_METHOD;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.OUT_MESSAGES;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.PACKAGE_PAYMENT_ARRANGEMENTS_SERVICES;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.PROCEDURE_SAVE_ACCOUNT;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.TYPE_MESSAGES;
import static au.gov.vic.sro.util.NumberUtil.toBigDecimal;
import static java.sql.Types.ARRAY;
import static java.sql.Types.NUMERIC;
import static java.sql.Types.VARCHAR;
import static org.apache.commons.collections4.MapUtils.emptyIfNull;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.data.jdbc.support.oracle.SqlReturnStructArray;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlInOutParameter;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import au.gov.vic.sro.autopay.dao.mapper.MessageMapper;
import au.gov.vic.sro.autopay.dto.SaveAccountRequest;
import au.gov.vic.sro.autopay.dto.SaveAccountResponse;
import au.gov.vic.sro.autopay.model.Message;
import au.gov.vic.sro.autopay.model.PaymentMethod;

public class SaveAccountProcedure extends StoredProcedure {

	public SaveAccountProcedure(JdbcTemplate jdbcTemplate) {
		super(jdbcTemplate, PACKAGE_PAYMENT_ARRANGEMENTS_SERVICES + "." + PROCEDURE_SAVE_ACCOUNT);
		declareParameter(new SqlParameter(IN_ARRANGEMENT_ID, NUMERIC));
		declareParameter(new SqlParameter(IN_ARRANGEMENT_VERSION, NUMERIC));
		declareParameter(new SqlParameter(IN_ACCOUNT_TOKEN, VARCHAR));
		declareParameter(new SqlParameter(IN_PAYMENT_METHOD, VARCHAR));
		declareParameter(new SqlParameter(IN_BANK_ACCOUNT_NUMBER, VARCHAR));
		declareParameter(new SqlParameter(IN_BANK_ACCOUNT_BSB, VARCHAR));
		declareParameter(new SqlParameter(IN_CARD_NUMBER, VARCHAR));
		declareParameter(new SqlParameter(IN_CARD_EXPIRY_MONTH, VARCHAR));
		declareParameter(new SqlParameter(IN_CARD_EXPIRY_YEAR, VARCHAR));
		declareParameter(new SqlOutParameter(OUT_MESSAGES, ARRAY, TYPE_MESSAGES,
				new SqlReturnStructArray<Message>(new MessageMapper())));
		declareParameter(new SqlInOutParameter(IN_OUT_CHECKSUM, VARCHAR));

		compile();
	}

	public SaveAccountResponse execute(SaveAccountRequest request) {
		Map<String, Object> in = new LinkedHashMap<String, Object>();
		in.put(IN_ARRANGEMENT_ID, request == null ? null : toBigDecimal(request.getArrangementId()));
		in.put(IN_ARRANGEMENT_VERSION, request == null ? null : toBigDecimal(request.getArrangementVersion()));
		in.put(IN_ACCOUNT_TOKEN, request == null ? null : request.getAccountToken());
		in.put(IN_PAYMENT_METHOD, request == null ? null : PaymentMethod.toCode(request.getPaymentMethod()));
		in.put(IN_BANK_ACCOUNT_NUMBER, request == null ? null : request.getBankAccountNumber());
		in.put(IN_BANK_ACCOUNT_BSB, request == null ? null : request.getBankBsb());
		in.put(IN_CARD_NUMBER, request == null ? null : request.getCardNumber());
		in.put(IN_CARD_EXPIRY_MONTH, request == null ? null : request.getCardExpiryMonth());
		in.put(IN_CARD_EXPIRY_YEAR, request == null ? null : request.getCardExpiryYear());
		in.put(IN_OUT_CHECKSUM, request == null ? null : request.getChecksum());

		Map<String, Object> out = emptyIfNull(execute(in));

		SaveAccountResponse response = new SaveAccountResponse();
		response.setMessages((Object[]) out.get(OUT_MESSAGES));
		response.setSaved(response.getMessages().isEmpty());
		return response;
	}

}
