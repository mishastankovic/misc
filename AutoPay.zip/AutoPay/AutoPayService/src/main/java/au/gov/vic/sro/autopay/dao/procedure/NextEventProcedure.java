package au.gov.vic.sro.autopay.dao.procedure;

import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.OUT_RESULT;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.PACKAGE_PAYMENT_ARRANGEMENTS_EVENTS;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.PROCEDURE_NEXT_EVENT;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.TYPE_EVENT;
import static java.sql.Types.STRUCT;
import static org.apache.commons.collections4.MapUtils.emptyIfNull;

import java.util.Collections;
import java.util.Map;

import org.springframework.data.jdbc.support.oracle.SqlReturnStruct;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.object.StoredProcedure;

import au.gov.vic.sro.autopay.dao.mapper.EventMapper;
import au.gov.vic.sro.autopay.dto.NextEventResponse;
import au.gov.vic.sro.autopay.model.Event;

public class NextEventProcedure extends StoredProcedure {
	private static final Map<String, Object> EMPTY_IN_PARAMS = Collections.emptyMap();

	public NextEventProcedure(JdbcTemplate jdbcTemplate) {
		super(jdbcTemplate, PACKAGE_PAYMENT_ARRANGEMENTS_EVENTS + "." + PROCEDURE_NEXT_EVENT);
		declareParameter(new SqlOutParameter(OUT_RESULT, STRUCT, TYPE_EVENT, new SqlReturnStruct(new EventMapper())));
		setFunction(true);
		compile();
	}

	public NextEventResponse execute() {
		Map<String, Object> out = emptyIfNull(execute(EMPTY_IN_PARAMS));

		NextEventResponse response = new NextEventResponse();
		response.setEvent((Event) out.get(OUT_RESULT));
		return response;
	}

}
