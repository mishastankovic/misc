package au.gov.vic.sro.autopay.dao.mapper;

import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.TYPE_PAYMENT_ARRANGEMENT;
import static au.gov.vic.sro.autopay.dao.support.OracleUtil.createStruct;
import static au.gov.vic.sro.autopay.dao.support.OracleUtil.getValues;
import static au.gov.vic.sro.util.DateUtil.toDate;
import static au.gov.vic.sro.util.DateUtil.toSqlTimestamp;
import static au.gov.vic.sro.util.NumberUtil.toBigDecimal;
import static au.gov.vic.sro.util.NumberUtil.toBigInteger;
import static au.gov.vic.sro.util.NumberUtil.toIntegerExact;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.regex.Pattern;

import org.springframework.data.jdbc.support.oracle.StructMapper;

import au.gov.vic.sro.autopay.model.Arrangement;
import au.gov.vic.sro.autopay.model.ArrangementStatus;
import au.gov.vic.sro.autopay.model.CancelledReason;
import au.gov.vic.sro.autopay.model.PaymentFrequency;
import au.gov.vic.sro.autopay.model.PaymentMethod;
import oracle.sql.STRUCT;

public class ArrangementMapper implements StructMapper<Arrangement> {

	private enum RecField {
		PAYMENT_ARRANGEMENT_ID,
		PAYMENT_ARRANGEMENT_VERSION,
		CUSTOMER_ID,
		PAYMENT_TOKEN,
		ARRANGEMENT_STATUS,
		STATUS_DATE,
		CANCELLATION_DATE,
		CANCELLED_BY,
		CANCELLATION_REASON,
		ARRANGEMENT_START_DATE,
		ARRANGEMENT_END_DATE,
		PAYMENT_FREQUENCY,
		PAYMENT_METHOD,
		DIRECT_DEBIT_ACCOUNT_NUMBER,
		BSB_NUMBER,
		CREDIT_CARD_NUMBER,
		CREDIT_CARD_EXPIRY_MONTH,
		CREDIT_CARD_EXPIRY_YEAR,
		ARRANGEMENT_AMOUNT,
		ARRANGEMENT_SURCHARGE,
		ARRANGEMENT_TOTAL_AMOUNT;
	}

	private static final Pattern TYPE_NAME_PATTERN = Pattern.compile("(.+\\.)*" + TYPE_PAYMENT_ARRANGEMENT);
	private static final int TYPE_LENGTH = RecField.values().length;

	@Override
	public STRUCT toStruct(Arrangement source, Connection connection, String typeName) throws SQLException {
		return createStruct(typeName, connection, toRec(source));
	}

	protected Object[] toRec(Arrangement source) {
		if (source == null) {
			throw new IllegalArgumentException(String.format("source=%s", source));
		}
		Object[] rec = new Object[TYPE_LENGTH];
		rec[RecField.PAYMENT_ARRANGEMENT_ID.ordinal()] = toBigDecimal(source.getId());
		rec[RecField.PAYMENT_ARRANGEMENT_VERSION.ordinal()] = toBigDecimal(source.getVersion());
		rec[RecField.CUSTOMER_ID.ordinal()] = source.getCustomerId();
		rec[RecField.ARRANGEMENT_STATUS.ordinal()] = ArrangementStatus.toCode(source.getStatus());
		rec[RecField.STATUS_DATE.ordinal()] = toSqlTimestamp(source.getStatusDate());
		rec[RecField.CANCELLATION_DATE.ordinal()] = toSqlTimestamp(source.getCancelledDate());
		rec[RecField.CANCELLATION_REASON.ordinal()] = CancelledReason.toCode(source.getCancelledReason());
		rec[RecField.CANCELLED_BY.ordinal()] = source.getCancelledUserId();
		rec[RecField.ARRANGEMENT_START_DATE.ordinal()] = toSqlTimestamp(source.getStartDate());
		rec[RecField.ARRANGEMENT_END_DATE.ordinal()] = toSqlTimestamp(source.getEndDate());
		rec[RecField.PAYMENT_FREQUENCY.ordinal()] = PaymentFrequency.toCode(source.getPaymentFrequency());
		rec[RecField.ARRANGEMENT_AMOUNT.ordinal()] = toBigDecimal(source.getAllInstalmentAmountDollars());
		rec[RecField.ARRANGEMENT_SURCHARGE.ordinal()] = toBigDecimal(source.getAllInstalmentSurchargeDollars());
		rec[RecField.ARRANGEMENT_TOTAL_AMOUNT.ordinal()] = toBigDecimal(source.getAllInstalmentTotalAmountDollars());
		rec[RecField.PAYMENT_TOKEN.ordinal()] = source.getAccountToken();
		rec[RecField.PAYMENT_METHOD.ordinal()] = PaymentMethod.toCode(source.getPaymentMethod());
		rec[RecField.CREDIT_CARD_NUMBER.ordinal()] = source.getCardNumber();
		rec[RecField.CREDIT_CARD_EXPIRY_MONTH.ordinal()] = source.getCardExpiryMonth();
		rec[RecField.CREDIT_CARD_EXPIRY_YEAR.ordinal()] = source.getCardExpiryYear();
		rec[RecField.BSB_NUMBER.ordinal()] = source.getBankBsb();
		rec[RecField.DIRECT_DEBIT_ACCOUNT_NUMBER.ordinal()] = source.getBankAccountNumber();
		return rec;
	}

	@Override
	public Arrangement fromStruct(STRUCT struct) throws SQLException {
		Object[] rec = getValues(struct, TYPE_NAME_PATTERN, TYPE_LENGTH);
		Arrangement target = new Arrangement();
		target.setId(toBigInteger((BigDecimal) rec[RecField.PAYMENT_ARRANGEMENT_ID.ordinal()]));
		target.setVersion(toIntegerExact((BigDecimal) rec[RecField.PAYMENT_ARRANGEMENT_VERSION.ordinal()]));
		target.setCustomerId((String) rec[RecField.CUSTOMER_ID.ordinal()]);
		target.setStatus(ArrangementStatus.fromCode((String) rec[RecField.ARRANGEMENT_STATUS.ordinal()]));
		target.setStatusDate(toDate((Timestamp) rec[RecField.STATUS_DATE.ordinal()]));
		target.setCancelledDate(toDate((Timestamp) rec[RecField.CANCELLATION_DATE.ordinal()]));
		target.setCancelledReason(CancelledReason.fromCode((String) rec[RecField.CANCELLATION_REASON.ordinal()]));
		target.setCancelledUserId((String) rec[RecField.CANCELLED_BY.ordinal()]);
		target.setStartDate(toDate((Timestamp) rec[RecField.ARRANGEMENT_START_DATE.ordinal()]));
		target.setEndDate(toDate((Timestamp) rec[RecField.ARRANGEMENT_END_DATE.ordinal()]));
		target.setPaymentFrequency(PaymentFrequency.fromCode((String) rec[RecField.PAYMENT_FREQUENCY.ordinal()]));
		target.setAllInstalmentAmountDollars((BigDecimal) rec[RecField.ARRANGEMENT_AMOUNT.ordinal()]);
		target.setAllInstalmentSurchargeDollars((BigDecimal) rec[RecField.ARRANGEMENT_SURCHARGE.ordinal()]);
		target.setAllInstalmentTotalAmountDollars((BigDecimal) rec[RecField.ARRANGEMENT_TOTAL_AMOUNT.ordinal()]);
		target.setAccountToken((String) rec[RecField.PAYMENT_TOKEN.ordinal()]);
		target.setPaymentMethod(PaymentMethod.fromCode((String) rec[RecField.PAYMENT_METHOD.ordinal()]));
		target.setCardNumber((String) rec[RecField.CREDIT_CARD_NUMBER.ordinal()]);
		target.setCardExpiryMonth((String) rec[RecField.CREDIT_CARD_EXPIRY_MONTH.ordinal()]);
		target.setCardExpiryYear((String) rec[RecField.CREDIT_CARD_EXPIRY_YEAR.ordinal()]);
		target.setBankBsb((String) rec[RecField.BSB_NUMBER.ordinal()]);
		target.setBankAccountNumber((String) rec[RecField.DIRECT_DEBIT_ACCOUNT_NUMBER.ordinal()]);
		return target;
	}

}
