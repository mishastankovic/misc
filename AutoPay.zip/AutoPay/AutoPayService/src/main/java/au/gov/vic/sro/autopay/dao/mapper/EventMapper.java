package au.gov.vic.sro.autopay.dao.mapper;

import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.TYPE_EVENT;
import static au.gov.vic.sro.autopay.dao.support.OracleUtil.getValues;
import static au.gov.vic.sro.util.NumberUtil.toBigInteger;
import static au.gov.vic.sro.util.NumberUtil.toIntegerExact;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.regex.Pattern;

import org.springframework.data.jdbc.support.oracle.StructMapper;

import au.gov.vic.sro.autopay.model.Event;
import au.gov.vic.sro.autopay.model.EventStatus;
import au.gov.vic.sro.autopay.model.EventType;
import oracle.sql.STRUCT;

public class EventMapper implements StructMapper<Event> {

	private enum RecField {
		PAO_EVENT_NOTIFICATION_ID,
		PAO_EVENT_NOTIFICATION_TYPE,
		PAYMENT_ARRANGEMENT_ID,
		PAYMENT_ARRANGEMENT_VERSION,
		STATUS;
	}

	private static final Pattern TYPE_NAME_PATTERN = Pattern.compile("(.+\\.)*" + TYPE_EVENT);
	private static final int TYPE_LENGTH = RecField.values().length;

	@Override
	public STRUCT toStruct(Event source, Connection connection, String typeName) throws SQLException {
		throw new UnsupportedOperationException();
	}

	@Override
	public Event fromStruct(STRUCT struct) throws SQLException {
		Object[] rec = getValues(struct, TYPE_NAME_PATTERN, TYPE_LENGTH);
		Event target = new Event();
		target.setId(toBigInteger((BigDecimal) rec[RecField.PAO_EVENT_NOTIFICATION_ID.ordinal()]));
		target.setType(EventType.fromCode((String) rec[RecField.PAO_EVENT_NOTIFICATION_TYPE.ordinal()]));
		target.setStatus(EventStatus.fromCode((String) rec[RecField.STATUS.ordinal()]));
		target.setArrangementId(toBigInteger((BigDecimal) rec[RecField.PAYMENT_ARRANGEMENT_ID.ordinal()]));
		target.setArrangementVersion(toIntegerExact((BigDecimal) rec[RecField.PAYMENT_ARRANGEMENT_VERSION.ordinal()]));
		return target;
	}

}
