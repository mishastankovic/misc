package au.gov.vic.sro.autopay.service;

import java.io.IOException;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;
import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import au.gov.vic.sro.autopay.dao.AutoPayDao;
import au.gov.vic.sro.autopay.model.identity.CustomerIdentity;
import au.gov.vic.sro.autopay.model.reference.ReferenceData;
import au.gov.vic.sro.autopay.dto.CalculateScheduleResponse;
import au.gov.vic.sro.autopay.dto.CancelArrangementResponse;
import au.gov.vic.sro.autopay.dto.FindArrangementResponse;
import au.gov.vic.sro.autopay.dto.GetConfirmCancelTextResponse;
import au.gov.vic.sro.autopay.dto.GetDefaultDatesResponse;
import au.gov.vic.sro.autopay.dto.GetEventsResponse;
import au.gov.vic.sro.autopay.dto.GetFrequenciesResponse;
import au.gov.vic.sro.autopay.dto.NextEventResponse;
import au.gov.vic.sro.autopay.dto.SaveAccountRequest;
import au.gov.vic.sro.autopay.dto.SaveAccountResponse;
import au.gov.vic.sro.autopay.dto.SaveArrangementResponse;
import au.gov.vic.sro.autopay.dto.SaveContactsResponse;
import au.gov.vic.sro.autopay.model.Arrangement;
import au.gov.vic.sro.autopay.model.Contact;
import au.gov.vic.sro.autopay.model.Event;
import au.gov.vic.sro.autopay.model.LiabilityType;
import au.gov.vic.sro.autopay.model.PaymentFrequency;
import au.gov.vic.sro.autopay.model.PaymentMethod;
import au.gov.vic.sro.autopay.model.RevenueLine;
import au.gov.vic.sro.autopay.util.FileUtil;
import au.gov.vic.sro.autopay.validation.identity.CustomerIdentityValidator;
import au.gov.vic.sro.autopay.validation.util.ValidationHelper;
import au.gov.vic.sro.autopay.validation.util.ValidationRequest;
import au.gov.vic.sro.communication.model.Communication;
import au.gov.vic.sro.communication.model.CommunicationContent;
import au.gov.vic.sro.communication.service.CommunicationService;

/**
 * Facade service for AutoPay.
 */
@Service("autoPayService")
@Transactional(propagation = Propagation.REQUIRED)
public class AutoPayServiceImpl implements AutoPayService {

	private static final Logger log = LoggerFactory.getLogger(AutoPayServiceImpl.class);

	public static final String TRUST_TYPE = "TrustTypes";
	public static final String POSTAL_BOX_TYPE = "PostalBoxTypes";
	public static final String FLAT_UNIT_TYPE = "FlatUnitTypes";
	public static final String FLOOR_LEVEL_TYPE = "FloorLevelTypes";
	public static final String STREET_TYPE = "StreetTypes";
	public static final String STREET_SUFFIX = "StreetSuffixes";
	public static final String SUBURB_TYPE = "Suburbs";
	public static final String STATE_TYPE = "States";
	public static final String COUNTRY_TYPE = "Countries";

	private static final String REFERENCE_DATA_PROPERIES_FILE = "referencedata.json";

	@Autowired
	private ObjectMapper objectMapper;

	private AutoPayDao autoPayDao;
	private CommunicationService communicationService;

	private List<ReferenceData> referenceData = new ArrayList<>();

	@Autowired
	public AutoPayServiceImpl(AutoPayDao autoPayDao, CommunicationService communicationService) {
		this.autoPayDao = autoPayDao;
		this.communicationService = communicationService;
	}

	private String[] referenceDataTypes = { TRUST_TYPE, POSTAL_BOX_TYPE, FLAT_UNIT_TYPE, FLOOR_LEVEL_TYPE, STREET_TYPE,
			STREET_SUFFIX, SUBURB_TYPE, STATE_TYPE, COUNTRY_TYPE };

	public AutoPayDao getAutoPayDao() {
		return autoPayDao;
	}

	public void setAutoPayDao(AutoPayDao autoPayDao) {
		this.autoPayDao = autoPayDao;
	}

	private boolean validateCustomerIdentity(CustomerIdentity customerIdentity) {
		ValidationRequest<CustomerIdentity> validationRequest =
				new ValidationRequest<CustomerIdentity>().objectToBeValidated(customerIdentity);
		validationRequest.addValidator(new CustomerIdentityValidator());

		return ValidationHelper.validate(validationRequest);
	}


	private Communication logCommunication(String xml, String type, String receiptNumber, byte[] pdf) {
		Communication communication = new Communication();
		communication.setCommunicationType(type);
		communication.setPrimaryCommunicationIdentifier(receiptNumber);
		communication.setDestination("e-Sys");

		List<CommunicationContent> communicationContents = new ArrayList<>();

		CommunicationContent communicationContent = new CommunicationContent();
		communicationContent.setCommunicationContentType(type);
		communicationContent.setCommunicationClobContent(xml);
		communicationContent.setCommunicationBlobContent(pdf);
		communicationContents.add(communicationContent);
		communication.setCommunicationContents(communicationContents);

		communication = communicationService.logCommunication(communication);

		return communication;
	}

	private List<ReferenceData> getReferenceDataProperties() {
		try {
			String json = new FileUtil().resourceToString(REFERENCE_DATA_PROPERIES_FILE);
			return objectMapper.readValue(json, new TypeReference<List<ReferenceData>>() {
			});

		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
	
	@Override
	public FindArrangementResponse findArrangement(String customerId, RevenueLine revenueLine,
			LiabilityType liabilityType, String liabilityId) {
		return getAutoPayDao().findArrangement(customerId, revenueLine, liabilityType, liabilityId);
	}

	@Override
	public FindArrangementResponse findArrangement(BigInteger arrangementId, Integer arrangementVersion) {
		return getAutoPayDao().findNotificationArrangement(arrangementId, arrangementVersion);
	}

	@Override
	public GetDefaultDatesResponse getDefaultDates(String customerId, RevenueLine revenueLine,
			LiabilityType liabilityType, String liabilityId) {
		return getAutoPayDao().getDefaultDates(customerId, revenueLine, liabilityType, liabilityId);
	}

	@Override
	public GetFrequenciesResponse getFrequencies(String customerId, RevenueLine revenueLine,
			LiabilityType liabilityType, String liabilityId, Date arrangementStartDate, Date arrangementEndDate) {
		return getAutoPayDao().getFrequencies(customerId, revenueLine, liabilityType, liabilityId,
				arrangementStartDate, arrangementEndDate);
	}

	@Override
	public CalculateScheduleResponse calculateSchedule(String customerId, RevenueLine revenueLine,
			LiabilityType liabilityType, String liabilityId, Date arrangementStartDate, Date arrangementEndDate,
			PaymentFrequency paymentFrequency, PaymentMethod paymentMethod) {
		return getAutoPayDao().calculateSchedule(customerId, revenueLine, liabilityType, liabilityId,
				arrangementStartDate, arrangementEndDate, paymentFrequency, paymentMethod);
	}

	@Override
	@Transactional(readOnly = false)
	public SaveArrangementResponse saveArrangement(Arrangement arrangement) {
		return getAutoPayDao().saveArrangement(arrangement);
	}

	@Override
	@Transactional(readOnly = false)
	public SaveAccountResponse saveAccount(SaveAccountRequest request) {
		return getAutoPayDao().saveAccount(request);
	}

	@Override
	@Transactional(readOnly = false)
	public SaveContactsResponse saveContacts(List<Contact> contacts, String checksum) {
		return getAutoPayDao().saveContacts(contacts, checksum);
	}

	@Override
	public GetConfirmCancelTextResponse getConfirmCancelText(BigInteger arrangementId, Integer arrangementVersion) {
		return getAutoPayDao().getConfirmCancelText(arrangementId, arrangementVersion);
	}

	@Override
	@Transactional(readOnly = false)
	public CancelArrangementResponse cancelArrangement(BigInteger arrangementId, Integer arrangementVersion) {
		return getAutoPayDao().cancelArrangement(arrangementId, arrangementVersion);
	}

	@Override
	@Transactional(readOnly = false)
	public NextEventResponse nextEvent() {
		return getAutoPayDao().nextEvent();
	}

	@Override
	@Transactional(readOnly = false)
	public void saveEvent(Event event) {
		getAutoPayDao().saveEvent(event);
	}

	@Override
	public GetEventsResponse getEvents(List<BigInteger> eventIds) {
		return getAutoPayDao().getEvents(eventIds);
	}

}