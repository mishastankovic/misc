package au.gov.vic.sro.autopay.service.security;

import org.springframework.security.core.GrantedAuthority;

public enum AutoPayRole implements GrantedAuthority {
    Customer,
    Staff;

    @Override
    public String getAuthority() {
        return name();
    }
}
