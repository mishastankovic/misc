package au.gov.vic.sro.autopay.dao.procedure;

import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.INOUT_CUSTOMER_ID;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.INOUT_REVENUE_LINE;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.IN_LIABILITY_ID;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.IN_LIABILITY_TYPE;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.OUT_MESSAGES;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.OUT_VALID;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.PACKAGE_PAYMENT_ARRANGEMENTS_SERVICES;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.PROCEDURE_AUTHENTICATE;
import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.TYPE_MESSAGES;
import static java.sql.Types.ARRAY;
import static java.sql.Types.VARCHAR;
import static org.apache.commons.collections4.MapUtils.emptyIfNull;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.data.jdbc.support.oracle.SqlReturnStructArray;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlInOutParameter;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import au.gov.vic.sro.autopay.dao.mapper.BooleanReturnType;
import au.gov.vic.sro.autopay.dao.mapper.MessageMapper;
import au.gov.vic.sro.autopay.dto.AuthenticateResponse;
import au.gov.vic.sro.autopay.model.LiabilityType;
import au.gov.vic.sro.autopay.model.Message;
import au.gov.vic.sro.autopay.model.RevenueLine;

public class AuthenticateProcedure extends StoredProcedure {

	public AuthenticateProcedure(JdbcTemplate jdbcTemplate) {
		super(jdbcTemplate, PACKAGE_PAYMENT_ARRANGEMENTS_SERVICES + "." + PROCEDURE_AUTHENTICATE);
		declareParameter(new SqlInOutParameter(INOUT_CUSTOMER_ID, VARCHAR));
		declareParameter(new SqlInOutParameter(INOUT_REVENUE_LINE, VARCHAR));
		declareParameter(new SqlParameter(IN_LIABILITY_TYPE, VARCHAR));
		declareParameter(new SqlParameter(IN_LIABILITY_ID, VARCHAR));
		declareParameter(new SqlOutParameter(OUT_VALID, VARCHAR, null, new BooleanReturnType()));
		declareParameter(new SqlOutParameter(OUT_MESSAGES, ARRAY, TYPE_MESSAGES,
				new SqlReturnStructArray<Message>(new MessageMapper())));
		compile();
	}

	public AuthenticateResponse execute(String customerId, RevenueLine revenueLine, LiabilityType liabilityType,
			String liabilityId) {
		Map<String, Object> in = new LinkedHashMap<String, Object>();
		in.put(INOUT_CUSTOMER_ID, customerId);
		in.put(INOUT_REVENUE_LINE, revenueLine == null ? null : revenueLine.getCode());
		in.put(IN_LIABILITY_TYPE, liabilityType == null ? null : liabilityType.getCode());
		in.put(IN_LIABILITY_ID, liabilityId);

		Map<String, Object> out = emptyIfNull(execute(in));

		AuthenticateResponse response = new AuthenticateResponse();
		response.setCustomerId((String) out.get(INOUT_CUSTOMER_ID));
		response.setRevenueLineCode((String) out.get(INOUT_REVENUE_LINE));
		response.setAuthenticated((Boolean) out.get(OUT_VALID));
		response.setMessages((Object[]) out.get(OUT_MESSAGES));
		return response;
	}

}
