package au.gov.vic.sro.autopay.dao.mapper;

import static au.gov.vic.sro.autopay.dao.AutoPayDaoConstants.TYPE_REFERENCE_DATA;
import static au.gov.vic.sro.autopay.dao.support.OracleUtil.getValues;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.regex.Pattern;
import org.springframework.data.jdbc.support.oracle.StructMapper;

import au.gov.vic.sro.autopay.dto.ReferenceDataRecord;
import oracle.sql.STRUCT;

public class ReferenceDataMapper implements StructMapper<ReferenceDataRecord> {

	private enum RecField {
		CODE,
		DESCRIPTION,
		OTHER_VALUE_1,
		OTHER_VALUE_2;
	}

	private static final Pattern TYPE_NAME_PATTERN = Pattern.compile("(.+\\.)*" + TYPE_REFERENCE_DATA);
	private static final int TYPE_LENGTH = RecField.values().length;

	@Override
	public STRUCT toStruct(ReferenceDataRecord source, Connection connection, String typeName) throws SQLException {
		throw new UnsupportedOperationException();
	}

	@Override
	public ReferenceDataRecord fromStruct(STRUCT struct) throws SQLException {
		Object[] rec = getValues(struct, TYPE_NAME_PATTERN, TYPE_LENGTH);
		ReferenceDataRecord target = new ReferenceDataRecord();
		target.setCode((String) rec[RecField.CODE.ordinal()]);
		target.setDescription((String) rec[RecField.DESCRIPTION.ordinal()]);
		target.setOtherValue1((String) rec[RecField.OTHER_VALUE_1.ordinal()]);
		target.setOtherValue2((String) rec[RecField.OTHER_VALUE_2.ordinal()]);
		return target;
	}

}
