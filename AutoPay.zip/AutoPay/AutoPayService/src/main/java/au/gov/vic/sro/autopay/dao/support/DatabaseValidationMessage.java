package au.gov.vic.sro.autopay.dao.support;

import java.io.Serializable;

public class DatabaseValidationMessage implements Serializable {

	private static final long serialVersionUID = 5459944118755537915L;

	public static final String WARNING_TYPE = "W";

	private final String type;
	private final String message;
	private final String fieldsInError;
	private final String messageIdentifier;
	private final String recordIdentifier;
	private final String recordIdentifierType;

	public DatabaseValidationMessage(String type, String message, String fieldsInError, String messageIdentifier,
			String recordIdentifier, String recordIdentifierType) {
		super();
		this.type = type;
		this.message = message;
		this.fieldsInError = fieldsInError;
		this.messageIdentifier = messageIdentifier;
		this.recordIdentifier = recordIdentifier;
		this.recordIdentifierType = recordIdentifierType;
	}

	public String getType() {
		return type;
	}

	public String getMessage() {
		return message;
	}

	public String getFieldsInError() {
		return fieldsInError;
	}

	public String getMessageIdentifier() {
		return messageIdentifier;
	}

	public String getRecordIdentifier() {
		return recordIdentifier;
	}

	public String getRecordIdentifierType() {
		return recordIdentifierType;
	}

	@Override
	public String toString() {
		return new StringBuilder("DatabaseValidationMessage[type=").append(type).append("; message=").append(message)
				.append("; fieldsInError=").append(fieldsInError).append("; messageIdentifier=")
				.append(messageIdentifier).append("; recordIdentifier=").append(recordIdentifier)
				.append("; recordIdentifierType=").append(recordIdentifierType).append("]").toString();
	}

}
