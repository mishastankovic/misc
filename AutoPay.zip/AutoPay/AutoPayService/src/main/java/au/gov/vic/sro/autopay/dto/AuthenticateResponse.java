package au.gov.vic.sro.autopay.dto;

import static au.gov.vic.sro.builder.ToStringStyleFactory.getToStringStyle;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

public class AuthenticateResponse extends MessageResponse implements Serializable {
	private static final long serialVersionUID = 3634312922926030478L;
	private Boolean authenticated;
	private String revenueLineCode;
	private String customerId;

	public Boolean getAuthenticated() {
		return authenticated;
	}

	public void setAuthenticated(Boolean authenticated) {
		this.authenticated = authenticated;
	}

	public String getRevenueLineCode() {
		return revenueLineCode;
	}

	public void setRevenueLineCode(String revenueLine) {
		this.revenueLineCode = revenueLine;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, getToStringStyle());
	}
}
