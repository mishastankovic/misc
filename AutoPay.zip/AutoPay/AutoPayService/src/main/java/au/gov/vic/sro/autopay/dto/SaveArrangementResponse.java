package au.gov.vic.sro.autopay.dto;

import static au.gov.vic.sro.builder.ToStringStyleFactory.getToStringStyle;

import java.io.Serializable;
import java.math.BigInteger;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

public class SaveArrangementResponse extends MessageResponse implements Serializable {
	private static final long serialVersionUID = 4705017690307550254L;
	private Boolean saved;
	private BigInteger arrangementId;
	private Integer arrangementVersion;
	private String checksum;

	public Boolean getSaved() {
		return saved;
	}

	public void setSaved(Boolean saved) {
		this.saved = saved;
	}

	public BigInteger getArrangementId() {
		return arrangementId;
	}

	public void setArrangementId(BigInteger arrangementId) {
		this.arrangementId = arrangementId;
	}

	public Integer getArrangementVersion() {
		return arrangementVersion;
	}

	public void setArrangementVersion(Integer arrangementVersion) {
		this.arrangementVersion = arrangementVersion;
	}

	public String getChecksum() {
		return checksum;
	}

	public void setChecksum(String checksum) {
		this.checksum = checksum;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, getToStringStyle());
	}

}
