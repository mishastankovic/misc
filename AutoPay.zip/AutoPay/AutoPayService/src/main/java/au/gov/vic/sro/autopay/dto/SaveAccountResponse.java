package au.gov.vic.sro.autopay.dto;

import static au.gov.vic.sro.builder.ToStringStyleFactory.getToStringStyle;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

public class SaveAccountResponse extends MessageResponse implements Serializable {
	private static final long serialVersionUID = 3900338294053794676L;
	private Boolean saved;

	public Boolean getSaved() {
		return saved;
	}

	public void setSaved(Boolean saved) {
		this.saved = saved;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, getToStringStyle());
	}

}
