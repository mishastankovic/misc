package au.gov.vic.sro.autopay.dto;

import java.io.Serializable;

public class AuthenticateUserDataResponse extends MessageResponse implements Serializable {

	private static final long serialVersionUID = -7602199171731811405L;

	private String customerId;
	private String authenticationLevel; // P - Partial, F - Full
	private Boolean registrationExists;
	private Boolean isRegistrationValid;

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getAuthenticationLevel() {
		return authenticationLevel;
	}

	public void setAuthenticationLevel(String authenticationLevel) {
		this.authenticationLevel = authenticationLevel;
	}

	public Boolean getRegistrationExists() {
		return registrationExists;
	}

	public void setRegistrationExists(Boolean registrationExists) {
		this.registrationExists = registrationExists;
	}

	public Boolean getIsRegistrationValid() {
		return isRegistrationValid;
	}

	public void setIsRegistrationValid(Boolean isRegistrationValid) {
		this.isRegistrationValid = isRegistrationValid;
	}

	public boolean determineHasFullOrPartialAuthentication() {
		return "P".equals(authenticationLevel) || "F".equals(authenticationLevel);
	}
}