package au.gov.vic.sro.autopay.service.security;

import au.gov.vic.sro.autopay.model.LiabilityType;
import au.gov.vic.sro.autopay.model.RevenueLine;
import au.gov.vic.sro.autopay.service.security.UserDetailsImpl;
import au.gov.vic.sro.autopay.service.security.UserDetailsServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class UserDetailsServiceImplTest {

    private UserDetailsServiceImpl service;
    private ObjectMapper mapper;

    @Before
    public void init() {
        service = new UserDetailsServiceImpl();
        mapper = new ObjectMapper();
    }

    /**
     * Test round trip Object - JSON - Object
     * @throws Exception
     */
    @Test
    public void testParseUsername() throws Exception {

        UserDetailsImpl inUserDetails = new UserDetailsImpl();
        inUserDetails.setPassword("password");
        inUserDetails.setUsername("userName");
        inUserDetails.setLiabilityType(LiabilityType.ASSESSMENT);
        inUserDetails.setRevenueLine(RevenueLine.LAND_TAX);
        inUserDetails.setCustomerId("customerId");
        inUserDetails.setLiabilityId("1234");

        String userJson = mapper.writeValueAsString(inUserDetails);
        UserDetailsImpl outUserDetails = service.parseUsername(userJson);
        assertNotNull(outUserDetails);
        assertEquals(inUserDetails, outUserDetails);

    }
}
