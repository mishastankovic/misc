package au.gov.vic.sro.autopay.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpHeaders;
import org.junit.Test;

import java.io.UnsupportedEncodingException;
import java.util.Base64;
import java.util.Date;
import java.util.Optional;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class JwtProviderTest {
    private static String secretKey = "secret-key";
    static {
        secretKey = Base64.getEncoder().encodeToString(secretKey.getBytes());
    }

    @Test
    public void testEncodeDecode() throws UnsupportedEncodingException {

        String token = createToken();
        System.out.println("generated token: " + token);
        decodeToken(token);
    }

    /**
     *
     * @return
     * @throws UnsupportedEncodingException
     */
    private String createToken() throws UnsupportedEncodingException {
        String jwt = Jwts.builder()
                .setSubject("users/TzMUocMF4p")
                .setExpiration(new Date(System.currentTimeMillis() + 1000000000))
                .claim("name", "Robert Token Man")
                .claim("scope", "self groups/admins")
                .signWith(
                        SignatureAlgorithm.HS256,
                        secretKey
                )
                .compact();
        return jwt;
    }

    /**
     *
     * @param jwt
     * @throws UnsupportedEncodingException
     */
    private void decodeToken(String jwt) throws UnsupportedEncodingException {
        Jws<Claims> claims = Jwts.parser()
                .setSigningKey(secretKey)
                .parseClaimsJws(jwt);
        String scope = claims.getBody().get("scope", String.class);
        assertEquals(scope, "self groups/admins");
    }

    @Test
    public void tempTest() {
        assertEquals(evaluate("Bearer test"), "test");
        assertTrue(StringUtils.isEmpty(evaluate("test")));
    }

    private String evaluate(String input) {
        return Optional.ofNullable(input).filter(s -> s.startsWith("Bearer ")).map(s -> s.substring(7)).orElseGet(() -> null);
    }
}
