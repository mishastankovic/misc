package au.gov.vic.sro.autopay.security;

import au.gov.vic.sro.autopay.model.RevenueLine;
import au.gov.vic.sro.autopay.service.security.UserDetailsImpl;
import au.gov.vic.sro.autopay.service.security.UserIdentity;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class UserApiTest {
    public static Logger logger = LoggerFactory.getLogger(UserApiTest.class);

    private static UserApi userApi;
    private static ObjectMapper mapper;
    @BeforeClass
    public static void init() {
        userApi = new UserApi();
        mapper = new ObjectMapper();
    }

    @Test
    public void loginTestSuccess() {
        String liabilityId = "1234567";
        String username = "testUser";
        String password = "password";
        String revenueLine = RevenueLine.LAND_TAX.getCode();

        UserIdentity userIdentity = new UserIdentity();
        userIdentity.setLiabilityId(liabilityId);
        userIdentity.setPassword(password);
        userIdentity.setRevenueLine(revenueLine);
        userIdentity.setUsername(username);

        userApi.login(userIdentity);
    }

    @Test
    public void testUserDetailsMappingFromObject() throws Exception {

        String liabilityId = "1234567";
        String username = "testUser";
        String password = "password";
        RevenueLine revenueLine = RevenueLine.LAND_TAX;

        UserDetailsImpl userDetails = new UserDetailsImpl();
        userDetails.setLiabilityId(liabilityId);
        userDetails.setPassword(password);
        userDetails.setRevenueLine(revenueLine);
        userDetails.setUsername(username);


        String userDetailsJson = mapper.writeValueAsString(userDetails);
        logger.info("UserDetailsImpl json: " + userDetailsJson);

        UserDetailsImpl readUserDetails = mapper.readValue(userDetailsJson, UserDetailsImpl.class);
        assertEquals(userDetails, readUserDetails);

    }

    @Test
    public void testUserDetailsMappingFromString() throws Exception {
        String json =
                "{\"authorities\":[],\"password\":null,\"username\":null,\"accountNonExpired\":true,\"accountNonLocked\":true," +
                "\"credentialsNonExpired\":true,\"enabled\":true,\"customerId\":\"misha\",\"revenueLine\":\"LAND_TAX\",\"liabilityType\":\"ASSESSMENT\"," +
                        "\"liabilityId\":\"12345678\"}";
        //json = "{\"authorities\":[],\"password\":null,\"username\":null,\"accountNonExpired\":true,\"accountNonLocked\":true,\"credentialsNonExpired\":true,\"enabled\":true,\"customerId\":\"misha\",\"revenueLine\":\"LAND_TAX\",\"liabilityType\":\"ASSESSMENT\",\"liabilityId\":\"12345678\"}";
        json = "{\"authorities\":[],\"password\":null,\"customerId\":\"83533740\",\"accountNonExpired\":true,\"accountNonLocked\":true,\"credentialsNonExpired\":true,\"enabled\":true,\"username\":null,\"revenueLine\":\"LTX\",\"liabilityType\":\"A\",\"liabilityId\":\"96130209\"}";
        UserDetailsImpl userDetails = mapper.reader(UserDetailsImpl.class).readValue(json);
        assertNotNull(userDetails);
        assertEquals(userDetails.getCustomerId(), "83533740");

        ObjectReader reader = new ObjectMapper().reader(UserDetailsImpl.class);
        reader.readValue(json);

    }

}
