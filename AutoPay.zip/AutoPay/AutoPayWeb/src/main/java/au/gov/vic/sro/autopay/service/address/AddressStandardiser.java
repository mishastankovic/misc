package au.gov.vic.sro.autopay.service.address;

import au.gov.vic.sro.autopay.context.ApplicationContextProvider;
import au.gov.vic.sro.autopay.model.address.Address;
import au.gov.vic.sro.autopay.model.address.AddressFormatType;
import au.gov.vic.sro.autopay.model.address.IntechAddressFormatType;

public class AddressStandardiser {
	
	private Address standardiseAddress(Address address) throws Exception {
		if (address == null) {
			return null;
		}

		if (address.determineIsFreeTextAddress()) {
			String addressLine = address.getAddressLine();
			IntechService intechService = intechService();
			if (intechService != null) {
				try {
					address = intechService.standardiseAddress(addressLine);
					mapIntechAddressFormatType(address);
					address.setAddressLine(addressLine);
				} catch (Exception e) {
					throw new Exception("Standardise Address Error; ", e);
				}
			}
		}
		return address;
	}

	private void mapIntechAddressFormatType(Address address) throws Exception {
		if (IntechAddressFormatType.INTECH_STREET.getCode().equals(address.getAddressFormatType())) {
			address.setAddressFormatType(AddressFormatType.HOUSE_BUILDING_SHOP.getCode());
		} else if (IntechAddressFormatType.INTECH_LOT.getCode().equals(address.getAddressFormatType())) {
			address.setAddressFormatType(AddressFormatType.LOT.getCode());
		} else if (IntechAddressFormatType.INTECH_POSTAL.getCode().equals(address.getAddressFormatType())) {
			address.setAddressFormatType(AddressFormatType.POSTAL_BOX.getCode());
		} else if (IntechAddressFormatType.INTECH_OVERSEAS.getCode().equals(address.getAddressFormatType())) {
			address.setAddressFormatType(AddressFormatType.OVERSEAS.getCode());
		} else {
			throw new Exception("Wrong address format type; ");
		}
	}

	private IntechService intechService() {
		return (IntechService) new ApplicationContextProvider().getApplicationContext().getBean("intechService");
	}
}
