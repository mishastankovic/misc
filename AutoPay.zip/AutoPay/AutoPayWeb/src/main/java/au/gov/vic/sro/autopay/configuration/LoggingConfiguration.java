package au.gov.vic.sro.autopay.configuration;

import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Since Servlet 3.0, log4j2 is automatically configured. If non-standard configuration is required the auto
 * initialisation needs to be disabled and the configuration configured programatically.
 * 
 * {@link https://logging.apache.org/log4j/2.0/manual/webapp.html}
 * 
 * Note: log4j has yet to be configured
 */
public class LoggingConfiguration {

	private static final String EBIZ_CONFIG_ROOT = "ebiz.config.root";

	public String getLocation() {
		// External override file.
		Path path = Paths.get(System.getProperty(EBIZ_CONFIG_ROOT), "autopay.log4j2.properties");
		boolean found = path.toFile().isFile();
		return found ? path.toUri().toString() : null;
	}

}