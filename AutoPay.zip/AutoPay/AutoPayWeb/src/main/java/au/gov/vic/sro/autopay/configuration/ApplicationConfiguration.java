package au.gov.vic.sro.autopay.configuration;

import java.util.Properties;

import au.gov.vic.sro.autopay.service.security.UserDetailsServiceImpl;
import org.apache.commons.configuration2.ex.ConfigurationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import au.gov.vic.sro.applicationservices.configuration.ConfigurationHelper;
import au.gov.vic.sro.autopay.context.ApplicationContextProvider;
import au.gov.vic.sro.autopay.service.address.IntechService;
import au.gov.vic.sro.autopay.service.address.IntechServiceImpl;
import au.gov.vic.sro.autopay.util.RecaptchaUtils;
import org.springframework.jndi.JndiTemplate;
import org.springframework.security.core.userdetails.UserDetailsService;

@Configuration
public class ApplicationConfiguration {

	@Bean
	public static ApplicationContextProvider contextProvider() {
		return new ApplicationContextProvider();
	}

	@Bean
	public static RecaptchaUtils recaptchaUtils() {
		return new RecaptchaUtils();
	}

	@Bean
	public static IntechService intechService() {
		return new IntechServiceImpl();
	}

	@Bean
	public static PropertyPlaceholderConfigurer propertyPlaceholderConfigurer() throws ConfigurationException {

		final String propertiesFile = "autopay";
		Properties properties = ConfigurationHelper.getProperties(propertiesFile);
		PropertyPlaceholderConfigurer propertyPlaceholderConfigurer = new PropertyPlaceholderConfigurer();
		propertyPlaceholderConfigurer.setProperties(properties);
		propertyPlaceholderConfigurer.setIgnoreUnresolvablePlaceholders(true);

		return propertyPlaceholderConfigurer;
	}

	@Bean
	public JndiTemplate jndiTemplate() {
		Properties properties = new Properties();
		properties.put("java.naming.factory.initial", "com.ibm.websphere.naming.WsnInitialContextFactory");
		return new JndiTemplate(properties);
	}

}
