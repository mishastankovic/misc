package au.gov.vic.sro.autopay.web.context;

import static org.apache.logging.log4j.web.Log4jWebSupport.LOG4J_CONFIG_LOCATION;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.ContextLoaderListener;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;

import au.gov.vic.sro.autopay.configuration.LoggingConfiguration;

public class AutoPayApplicationInitialiser implements WebApplicationInitializer {

	private static final Logger log = LoggerFactory.getLogger(AutoPayApplicationInitialiser.class);

	@Override
	public void onStartup(ServletContext servletContext) throws ServletException {
		log.info("###### onStartup");

		// Logging.
		String loggingConfigurationLocation = new LoggingConfiguration().getLocation();
		if (loggingConfigurationLocation != null) {
			servletContext.setInitParameter(LOG4J_CONFIG_LOCATION, loggingConfigurationLocation);
			log.info(String.format("ApplicationInitialiser: %s=%s", LOG4J_CONFIG_LOCATION,
					servletContext.getInitParameter(LOG4J_CONFIG_LOCATION)));
		}

		// Application
		WebApplicationContext context = getContext();

		// Manage the lifecycle of the root application context
		servletContext.addListener(new ContextLoaderListener(context));
	}

	private AnnotationConfigWebApplicationContext getContext() {
		AnnotationConfigWebApplicationContext context = new AnnotationConfigWebApplicationContext();
		// @formatter:off
		context.setConfigLocations(
				"au.gov.vic.sro.autopay.configuration",
				"au.gov.vic.sro.autopay.mapper.configuration",
				"au.gov.vic.sro.autopay.jms.configuration",
				"au.gov.vic.sro.communication.dao.configuration",
				"au.gov.vic.sro.autopay.dao.configuration",
				"au.gov.vic.sro.communication.service.configuration",
				"au.gov.vic.sro.autopays.service.configuration"
				);
		// @formatter:on
		return context;
	}

}