package au.gov.vic.sro.autopay.service.address;

import java.io.IOException;
import java.util.List;

import javax.resource.ResourceException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

import au.gov.vic.sro.autopay.model.address.Address;
import au.gov.vic.sro.service.address.IntechException;
import au.gov.vic.sro.service.address.RapidAddress;
import au.gov.vic.sro.service.address.RapidInterface;
import au.gov.vic.sro.service.address.Standardiser;

@Service("intechService")
public class IntechServiceImpl implements IntechService {

	private static final Logger log = LoggerFactory.getLogger(IntechServiceImpl.class);

	@Value("${intech.host}")
	private String intechHost;

	@Value("${intech.port}")
	private int intechPort;

	public List<String> getMatchingAddresses(String addressLine, boolean vicOnly, boolean nonPostal)
			throws ResourceException, IOException, IntechException {

		RapidAddress rapidAddress = rapidAddress();
		if (rapidAddress == null) throw new ResourceException("Intech service is unavailable");

		RapidInterface rapidSocket = rapidAddress.initialiseRapidSocket();
		List<String> matchingAddresses =
				rapidAddress.getMatchingAddresses(addressLine, vicOnly, nonPostal, null, rapidSocket);
		rapidAddress.closeRapidSocket(rapidSocket);

		if (log.isDebugEnabled()) log.debug(String.format("Matching addresses; addressLine=[%s] matchingAddresses=[%s]",
				addressLine, matchingAddresses));

		return matchingAddresses;
	}

	public Address standardiseAddress(String addressLine)
			throws IOException, IntechException, ReflectiveOperationException, ResourceException {
		Standardiser standardiser = standardiser();
		if (standardiser == null) throw new ResourceException("Intech service is unavailable");

		Address address = standardiser.standardise(Address.class, addressLine);
		if (address.getRoadNumberFrom() != null && address.getRoadNumberFromSuffix() != null) {
			address.setRoadNumberFrom(address.getRoadNumberFrom() + address.getRoadNumberFromSuffix());
		}
		if (address.getRoadNumberTo() != null && address.getRoadNumberToSuffix() != null) {
			address.setRoadNumberTo(address.getRoadNumberTo() + address.getRoadNumberToSuffix());
		}
		return address;
	}

	@Bean
	public RapidAddress rapidAddress() {
		if (log.isDebugEnabled()) log.debug("Configuring intech rapid address bean; bean=[rapidAddress]");
		return new RapidAddress(intechHost, intechPort);
	}

	@Bean
	public Standardiser standardiser() {
		if (log.isDebugEnabled()) log.debug("Configuring intech address standardiser bean; bean=[standardiser]");
		return new Standardiser(intechHost, intechPort);
	}

}