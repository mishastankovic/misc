package au.gov.vic.sro.autopay.web.resource;

import java.util.Arrays;
import java.util.Date;

import javax.servlet.ServletContext;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.FastDateFormat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import au.gov.vic.sro.autopay.model.exception.Error;
import au.gov.vic.sro.autopay.model.exception.ErrorResponse;
import org.springframework.web.context.support.WebApplicationContextUtils;

public abstract class AbstractResource {

	private static final Logger log = LoggerFactory.getLogger(AbstractResource.class);

	public static final String INTERNAL_SERVER_ERROR = "Internal Server Error";
	public static final String VALIDATION_ERROR = "Validation Error";
	private static final String DATA_SOURCE_UNAVAILABLE = "DataSource unavailable";
	public static final String SERVICE_NOT_AVAILABLE_ERROR = "Service Not Available Error";

	private static final FastDateFormat DATE_FORMAT = FastDateFormat.getInstance("ddHHmmss");

	@Context
	private ServletContext context;


	protected Response getInternalServerErrorResponse(Exception e) {
		ErrorResponse errorReponse = null;
		Response response = null;
		if (StringUtils.contains(e.getMessage(), DATA_SOURCE_UNAVAILABLE)) {
			errorReponse =
					generateError(Response.Status.SERVICE_UNAVAILABLE.getReasonPhrase(), SERVICE_NOT_AVAILABLE_ERROR);
			response = Response.status(Response.Status.SERVICE_UNAVAILABLE).entity(errorReponse).build();
			log.error(String.format("Service Not Available Error; errorCode=[%s] message=[%s]",
					errorReponse.getErrors().get(0).getErrorCode(), e.getMessage()), e);
		} else {
			errorReponse =
					generateError(Response.Status.INTERNAL_SERVER_ERROR.getReasonPhrase(), INTERNAL_SERVER_ERROR);
			response = Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(errorReponse).build();
			log.error(String.format("Internal Server Error; errorCode=[%s] message=[%s]",
					errorReponse.getErrors().get(0).getErrorCode(), e.getMessage()), e);
		}
		return response;
	}

	protected Response getInternalServerErrorResponseAsText(Exception e) {
		ErrorResponse errorReponse =
				generateError(Response.Status.INTERNAL_SERVER_ERROR.getReasonPhrase(), INTERNAL_SERVER_ERROR);

		String errorString = String.format("Internal Server Error; errorCode=[%s] message=[%s]",
				errorReponse.getErrors().get(0).getErrorCode(), e.getMessage());

		log.error(errorString, e);

		return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(errorString).type(MediaType.TEXT_PLAIN)
				.build();
	}

	public static ErrorResponse generateError(String errorCode, String errorText) {
		ErrorResponse errorResponse = new ErrorResponse();
		String errorId = DATE_FORMAT.format(new Date()) + (errorCode.hashCode() % 100);
		Error error = new Error();
		error.setErrorCode(errorId);
		error.setErrorText(errorText);
		errorResponse.setErrors(Arrays.asList(error));
		return errorResponse;
	}

	protected Object getService(String serviceName, Class cls) {
		return WebApplicationContextUtils.getWebApplicationContext(context).getBean(serviceName, cls);
	}


}
