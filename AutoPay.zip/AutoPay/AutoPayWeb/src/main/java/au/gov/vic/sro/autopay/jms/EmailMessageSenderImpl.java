package au.gov.vic.sro.autopay.jms;

import java.io.Serializable;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Queue;
import javax.jms.Session;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.stereotype.Component;

@Component("emailMessageSender")
public class EmailMessageSenderImpl implements EmailMessageSender, Serializable {

	private static final long serialVersionUID = -8218358705436633784L;

	private transient JmsTemplate jmsTemplate;

	private transient Queue jmsSendEmailQueue;

	@Autowired
	public EmailMessageSenderImpl(JmsTemplate jmsTemplate, Queue jmsSendEmailQueue) {
		this.jmsTemplate = jmsTemplate;
		this.jmsSendEmailQueue = jmsSendEmailQueue;
	}

	@Override
	public void sendMessage(String messageText) {
		jmsTemplate.send(jmsSendEmailQueue.toString(), new MessageCreator() {

			@Override
			public Message createMessage(Session session) throws JMSException {
				Message message = session.createTextMessage(messageText);
				message.setBooleanProperty("Email", true);
				message.setBooleanProperty("Parked", false);
				return message;
			}
		});
	}

}
