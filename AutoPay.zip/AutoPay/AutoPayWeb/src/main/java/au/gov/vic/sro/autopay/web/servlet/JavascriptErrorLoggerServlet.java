package au.gov.vic.sro.autopay.web.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import au.gov.vic.sro.common.web.servlet.JavascriptErrorLoggerMessage;

/**
 * This servlet is a replicate of au.gov.vic.sro.common.web.servlet.JavascriptErrorLoggerServlet The original servlet
 * class cannot be used here because the logging framework used in this project is SLF4J and the messages do not get
 * logged.
 */
public class JavascriptErrorLoggerServlet extends HttpServlet {

	private static final long serialVersionUID = -7181600496049908013L;

	private static final Logger log = LoggerFactory.getLogger(JavascriptErrorLoggerServlet.class);

	static final String PARAM_MSG = "msg";
	static final String PARAM_ERROR_FILE_URL = "errorfileurl";
	static final String PARAM_LINE_NO = "lineno";
	static final String PARAM_PAGE_URL = "pageurl";
	static final String HEADER_REFERER = "referer";
	static final String HEADER_USER_AGENT = "User-Agent";

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		// @formatter:off
		JavascriptErrorLoggerMessage message =
				new JavascriptErrorLoggerMessage(
						request.getParameter(PARAM_MSG),
						request.getParameter(PARAM_ERROR_FILE_URL),
						request.getParameter(PARAM_LINE_NO),
						request.getParameter(PARAM_PAGE_URL),
						request.getHeader(HEADER_REFERER),
						request.getHeader(HEADER_USER_AGENT));
		// @formatter:on

		if (message.isValid()) log.info(message.toString());
	}
}
