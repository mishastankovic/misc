package au.gov.vic.sro.autopay;

import java.io.Serializable;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/api")
public class AutoPayApplication extends Application implements Serializable {

	private static final long serialVersionUID = 3798257606760801445L;

}
