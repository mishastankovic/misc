package au.gov.vic.sro.autopay.service.email;

import java.io.Serializable;
import java.text.MessageFormat;
import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("emailGenerator")
public class EmailGenerator implements Serializable {

	private static final long serialVersionUID = 2011174939877314436L;

	private static final Logger log = LoggerFactory.getLogger(EmailGenerator.class);
	private static final String ATTACHMENT_TYPE = "application/pdf";
	private static final String ATTACHMENT_FILE_TYPE = ".pdf";
	private static final String SPACE = " ";
	private static final String DASH = "-";

	@Autowired
	private EmailClient emailClient;

	@Value("${email.from.name}")
	private String fromName;

	@Value("${email.from.address}")
	private String fromAddress;

	@Value("${email.sro.logo.link}")
	private String sroLogoLink;

	@Value("${email.security.classification}")
	private String securityClassification;

	protected void createAndSendEmail(String toAddress, String emailSubject, String attachmentName, byte[] attachment,
			String[] replacementParameters, String emailTemplateBody) {
		Email email = createEmail(toAddress, emailSubject, attachmentName, attachment, replacementParameters);

		sendHtmlEmail(email, emailTemplateBody);
	}

	protected void sendHtmlEmail(Email email, String emailTemplateBody) {
		String emailMessageBody = MessageFormat.format(emailTemplateBody,
				appendSroLogoToReplacementParameters(email.getReplacementParameters()));

		emailClient.sendEmail(emailMessageBody, true, email.getSubject(), email.getToAddress(), null, null,
				email.getFromAddress(), email.getFromName(), email.getAttachment(), email.getAttachmentName(),
				email.getAttachmentType());

	}

	private Email createEmail(String toEmailAddress, String subject, String attachmentName, byte[] attachment,
			String[] replacementParameters) {
		if (log.isDebugEnabled()) log.debug(String.format("Creating email, subject=[%s]", subject));

		Email email = new Email();
		email.setToAddress(toEmailAddress);
		email.setFromName(fromName);
		email.setFromAddress(fromAddress);
		email.setSubject(subject);
		email.setReplacementParameters(replacementParameters);

		email.setAttachmentName(attachmentName);
		email.setAttachmentType(ATTACHMENT_TYPE);
		email.setAttachment(attachment);

		return email;
	}

	private Object[] appendSroLogoToReplacementParameters(Object[] replacementParams) {
		Object[] emailParams = Arrays.copyOf(replacementParams, replacementParams.length + 1);
		emailParams[emailParams.length - 1] = sroLogoLink;
		return emailParams;
	}
}