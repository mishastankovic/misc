package au.gov.vic.sro.autopay.service.email;

public class EmailerException extends RuntimeException {

	private static final long serialVersionUID = -7768984807235478078L;

	public EmailerException(String msg) {
		super(msg);
	}

	public EmailerException(String msg, Throwable ex) {
		super(msg, ex);
	}
}