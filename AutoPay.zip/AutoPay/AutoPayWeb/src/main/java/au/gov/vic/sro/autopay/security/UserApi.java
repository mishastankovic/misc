package au.gov.vic.sro.autopay.security;

import au.gov.vic.sro.autopay.dto.AuthenticateUserDataResponse;
import au.gov.vic.sro.autopay.model.exception.ErrorResponse;
import au.gov.vic.sro.autopay.service.security.AutoPaySecurityService;
import au.gov.vic.sro.autopay.service.security.UserIdentity;
import au.gov.vic.sro.autopay.web.resource.AbstractResource;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.CrossOrigin;

import javax.annotation.security.PermitAll;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.Serializable;
import java.util.HashMap;

@Path("/users")

@Api(description = "User API")
@Consumes({ MediaType.APPLICATION_JSON })
@Produces({ MediaType.APPLICATION_JSON })
@CrossOrigin(origins = "*")
public class UserApi extends AbstractResource implements Serializable {

	private static final long serialVersionUID = 1358735196517634877L;
	private static final String AUTO_PAY_SECURITY_SERVICE = "autoPaySecurityService";
	private static final Logger logger = LoggerFactory.getLogger(UserApi.class.getName());


	@POST
	@Path("/login")
	@Consumes({ MediaType.APPLICATION_JSON })
	@Produces({ MediaType.APPLICATION_JSON })
	@PermitAll
	@ApiOperation(value = "login", notes = "", response = String.class, tags = {})
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Status 200", response = String.class),
			@ApiResponse(code = 401, message = "Authorisation refused", response = ErrorResponse.class),
			@ApiResponse(code = 500, message = "Internal server error", response = ErrorResponse.class) })
	public Response login(UserIdentity userIdentity) {

		try {
			logger.info("$$$$$$$$$$$$$$$$ In login for customer " + userIdentity.getCustomerId());
			AutoPaySecurityService securityService =
					(AutoPaySecurityService)getService(AUTO_PAY_SECURITY_SERVICE, AutoPaySecurityService.class);
			String token = securityService.login(userIdentity);
			logger.info("$$$$$$$$$$$$$$$$$ Generated token: " + token);
			return token != null ? Response.ok().entity("{\"token\": \"" + token + "\"}").build() : Response.status(Response.Status.UNAUTHORIZED).build();
		} catch (Exception e) {
			return getInternalServerErrorResponse(e);
		}

	}

	/*
	@OPTIONS
	@Path("{path : .*}")
	public Response options() {
		return Response.ok("")
				.header("Access-Control-Allow-Origin", "*")
				.header("Access-Control-Allow-Headers", "origin, content-type, accept, authorization")
				.header("Access-Control-Allow-Credentials", "true")
				.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, HEAD")
				.header("Access-Control-Max-Age", "1209600")
				.build();
	}
	*/

}
