package au.gov.vic.sro.autopay.service.email;

import java.io.Serializable;
import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Marshaller;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import au.gov.vic.sro.autopay.jms.EmailMessageSender;
import au.gov.vic.sro.emailer.client.EmailRequest;
import au.gov.vic.sro.emailer.client.ObjectFactory;

@Component("emailClient")
public class EmailClient implements Serializable {

	private static final String ERROR_GENERATING_E_MAIL_REQUEST = "Error generating e-mail request";

	private static final long serialVersionUID = -7358304729417124654L;

	private static final Logger log = LoggerFactory.getLogger(EmailClient.class);
	private static final String SESSION_JNDI_NAME = "sromail";
	private static final String JAXB_FORMATTED_OUTPUT = "jaxb.formatted.output";

	@Autowired
	private transient EmailMessageSender emailMessageSender;

	private transient ObjectFactory factory;

	public void sendEmail(String messageBody, boolean isHtmlMessageBody, String messageTitle, String toAddress,
			String[] ccAddresses, String[] bccAddresses, String fromAddress, String fromName, byte[] attachment,
			String attachmentName, String attachmentType) {

		EmailRequest emailRequest = createEmail(messageBody, true, messageTitle, toAddress, null, null, fromAddress,
				fromName, attachment, attachmentName, attachmentType, SESSION_JNDI_NAME);
		sendEmailRequestMessage(convertEmailRequestToXML(emailRequest));
	}

	protected String toString(EmailRequest email) throws EmailerException {
		String emailXMLOutput = null;

		try {
			JAXBContext jaxbContext = JAXBContext.newInstance(new Class[] { EmailRequest.class });
			Marshaller marshaller = jaxbContext.createMarshaller();
			marshaller.setProperty(JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
			StringWriter sw = new StringWriter();

			JAXBElement<EmailRequest> emailRequestElement = getFactory().createEmailRequest(email);
			marshaller.marshal(emailRequestElement, sw);

			emailXMLOutput = sw.toString();

		} catch (Exception e) {
			throw new EmailerException(ERROR_GENERATING_E_MAIL_REQUEST, e);
		}

		if (log.isDebugEnabled()) log.debug(String.format("email output; emailXMLOutput [%s]", emailXMLOutput));
		return emailXMLOutput;
	}

	protected ObjectFactory getFactory() {
		if (this.factory == null) {
			this.factory = new ObjectFactory();
		}
		return this.factory;
	}

	protected EmailRequest createEmail(String messageBody, boolean isHtmlMessageBody, String messageTitle,
			String toAddress, String[] ccAddresses, String[] bccAddresses, String fromAddress, String fromName,
			byte[] attachment, String attachmentName, String attachmentType, String sessionJndiName)
			throws EmailerException {
		try {
			EmailRequest email = getFactory().createEmailRequest();

			EmailRequest.Sender sender = getFactory().createEmailRequestSender();
			EmailRequest.Sender.FromAddress from = getFactory().createEmailRequestSenderFromAddress();
			if (StringUtils.isBlank(fromAddress)) {
				throw new EmailerException(String.format("From email not set for message subject=[%s] emailBody=[%s]",
						messageTitle, messageBody));
			} else {
				from.setValue(fromAddress);
				from.setName(fromName);
			}
			sender.setFromAddress(from);
			email.setSender(sender);

			EmailRequest.Receiver receiver = getFactory().createEmailRequestReceiver();

			if (StringUtils.isEmpty(toAddress)) {
				throw new EmailerException(String.format("To-address not set for message subject=[%s] emailBody=[%s]",
						messageTitle, messageBody));
			} else {
				EmailRequest.Receiver.To recipient = getFactory().createEmailRequestReceiverTo();
				recipient.setValue(toAddress);
				receiver.getTo().add(recipient);
			}

			if (!(ArrayUtils.isEmpty(ccAddresses))) {
				for (String address : ccAddresses) {
					EmailRequest.Receiver.Cc recipient = getFactory().createEmailRequestReceiverCc();
					recipient.setValue(address);
					receiver.getCc().add(recipient);
				}
			}

			if (!(ArrayUtils.isEmpty(bccAddresses))) {
				for (String address : bccAddresses) {
					EmailRequest.Receiver.Bcc recipient = getFactory().createEmailRequestReceiverBcc();
					recipient.setValue(address);
					receiver.getBcc().add(recipient);
				}
			}
			email.setReceiver(receiver);

			EmailRequest.Message message = getFactory().createEmailRequestMessage();

			message.setSubject(messageTitle);

			if (isHtmlMessageBody)
				message.setHtml(messageBody);
			else {
				message.setText(messageBody);
			}

			if (!(ArrayUtils.isEmpty(attachment))) {
				EmailRequest.Message.Attachment msgAttachment = getFactory().createEmailRequestMessageAttachment();

				msgAttachment.setValue(attachment);
				msgAttachment.setName(attachmentName);
				msgAttachment.setMimeType(attachmentType);
				msgAttachment.setDescription(attachmentName);
				message.getAttachment().add(msgAttachment);
			}
			email.setMessage(message);

			EmailRequest.Server server = getFactory().createEmailRequestServer();
			server.setSessionJndiName(sessionJndiName);
			email.setServer(server);
			return email;
		} catch (Exception e) {
			throw new EmailerException(ERROR_GENERATING_E_MAIL_REQUEST, e);
		}
	}

	protected String convertEmailRequestToXML(EmailRequest email) throws EmailerException {
		String emailXMLOutput = null;
		try {
			JAXBContext jaxbContext = JAXBContext.newInstance(new Class[] { EmailRequest.class });
			Marshaller marshaller = jaxbContext.createMarshaller();
			marshaller.setProperty("jaxb.formatted.output", Boolean.TRUE);
			StringWriter sw = new StringWriter();

			JAXBElement<EmailRequest> emailRequestElement = getFactory().createEmailRequest(email);
			marshaller.marshal(emailRequestElement, sw);

			emailXMLOutput = sw.toString();
		} catch (Exception e) {
			throw new EmailerException(ERROR_GENERATING_E_MAIL_REQUEST, e);
		}
		return emailXMLOutput;
	}

	protected void sendEmailRequestMessage(String emailXML) {
		emailMessageSender.sendMessage(emailXML);
	}

}