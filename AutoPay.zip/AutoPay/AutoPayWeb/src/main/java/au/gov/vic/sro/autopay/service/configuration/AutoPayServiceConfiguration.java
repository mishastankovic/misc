package au.gov.vic.sro.autopay.service.configuration;

import au.gov.vic.sro.autopay.service.AutoPayServiceImpl;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.FilterType;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@EnableTransactionManagement
// @formatter:off
@ComponentScan(
		basePackageClasses = { AutoPayServiceImpl.class},
		useDefaultFilters = false,
		includeFilters = {
				@ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE, value = AutoPayServiceImpl.class)
		})
// @formatter:on
@Configuration
public class AutoPayServiceConfiguration {


}
