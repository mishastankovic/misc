package au.gov.vic.sro.autopay.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

import au.gov.vic.sro.autopay.model.recaptcha.RecaptchaVerifyResponse;

@Component("recaptchaUtils")
public class RecaptchaUtils {

	private static final Logger log = LoggerFactory.getLogger(RecaptchaUtils.class);
	private static final String SITE_VERIFY_URL = "https://www.google.com/recaptcha/api/siteverify";
	private static final String SECRET_KEY = "6LeI2SYUAAAAAGpNVluz476O1i65DdOqT6MCQv-3";

	@Value("${google.recaptcha.connection.timeout}")
	private int googleRecaptchaConnectionTimeout;

	private static final int CONNECTION_TIMEOUT = 30000;

	public RecaptchaUtils() {
	}

	public boolean verifyRecaptchaWithGoogleSiteVerify(String gRecaptchaResponse) throws Exception {

		boolean isRecaptchaWithGoogleSiteVerify = false;

		HttpsURLConnection conn;
		try {
			URL verifyUrl = new URL(SITE_VERIFY_URL);

			conn = setConnection(verifyUrl);

			conn.setConnectTimeout(
					googleRecaptchaConnectionTimeout < 0 ? CONNECTION_TIMEOUT : googleRecaptchaConnectionTimeout);

			conn.setRequestMethod("POST");
			String postParams = "secret=" + SECRET_KEY + "&response=" + gRecaptchaResponse;
			conn.setDoOutput(true);

			OutputStream outStream = createOutputStream(conn);
			outStream.write(postParams.getBytes());

			outStream.flush();
			outStream.close();

			int responseCode = conn.getResponseCode();

			BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));

			String inputLine;
			StringBuilder response = new StringBuilder();

			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();

			ObjectMapper objectMapper = new ObjectMapper();
			RecaptchaVerifyResponse recaptchaVerifyResponse =
					objectMapper.readValue(response.toString(), RecaptchaVerifyResponse.class);

			if ((responseCode == 200 && Boolean.TRUE.equals(recaptchaVerifyResponse.isSuccess()))) {
				isRecaptchaWithGoogleSiteVerify = true;
			} else {
				throw new Exception(
						"Recaptcha error Response " + StringUtils.join(recaptchaVerifyResponse.getErrorCodes()));
			}

		} catch (IOException e) {
			log.warn("Error verifyRecaptchaWithGoogleSiteVerify", e);
			isRecaptchaWithGoogleSiteVerify = true;
		}

		return isRecaptchaWithGoogleSiteVerify;

	}

	private static HttpsURLConnection setConnection(URL verifyUrl) throws IOException {
		HttpsURLConnection conn;
		conn = (HttpsURLConnection) verifyUrl.openConnection();
		return conn;
	}

	public static OutputStream createOutputStream(HttpsURLConnection conn) throws IOException {
		return conn.getOutputStream();
	}
}