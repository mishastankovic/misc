package au.gov.vic.sro.autopay.jms;

public interface EmailMessageSender {

	public void sendMessage(String messageText);

}
