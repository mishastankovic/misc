package au.gov.vic.sro.autopay.service.address;

import java.io.IOException;
import java.util.List;

import javax.resource.ResourceException;

import au.gov.vic.sro.autopay.model.address.Address;
import au.gov.vic.sro.service.address.IntechException;

public interface IntechService {

	public List<String> getMatchingAddresses(String addressLine, boolean vicOnly, boolean nonPostal)
			throws IOException, IntechException, ResourceException;

	public Address standardiseAddress(String addressLine)
			throws IOException, IntechException, ReflectiveOperationException, ResourceException;

}
