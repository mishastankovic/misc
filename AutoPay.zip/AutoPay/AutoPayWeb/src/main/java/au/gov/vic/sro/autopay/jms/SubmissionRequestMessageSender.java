package au.gov.vic.sro.autopay.jms;

public interface SubmissionRequestMessageSender {

	public void sendMessage(String xml);

}
