package au.gov.vic.sro.autopay.jms;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Queue;
import javax.jms.Session;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.stereotype.Component;

@Component("submissionRequestMessageSender")
public class SubmissionRequestMessageSenderImpl implements SubmissionRequestMessageSender {

	private JmsTemplate jmsTemplate;

	private Queue jmsToEsysQueue;

	@Autowired
	public SubmissionRequestMessageSenderImpl(JmsTemplate jmsTemplate, Queue jmsToEsysQueue) {
		this.jmsTemplate = jmsTemplate;
		this.jmsToEsysQueue = jmsToEsysQueue;
	}

	@Override
	public void sendMessage(String messageText) {
		jmsTemplate.send(jmsToEsysQueue.toString(), new MessageCreator() {

			@Override
			public Message createMessage(Session session) throws JMSException {
				Message message = session.createTextMessage(messageText);
				message.setJMSType("srovrlt:SubmissionRequest");
				return message;
			}
		});
	}
}
