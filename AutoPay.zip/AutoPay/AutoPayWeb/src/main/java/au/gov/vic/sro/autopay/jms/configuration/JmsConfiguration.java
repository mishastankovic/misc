package au.gov.vic.sro.autopay.jms.configuration;

import javax.jms.ConnectionFactory;
import javax.jms.Queue;
import javax.naming.NamingException;
import javax.resource.ResourceException;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.FilterType;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jndi.JndiObjectFactoryBean;

import au.gov.vic.sro.autopay.jms.EmailMessageSenderImpl;
import au.gov.vic.sro.autopay.jms.SubmissionRequestMessageSenderImpl;

@EnableJms
// @formatter:off
@ComponentScan(
		basePackageClasses = { SubmissionRequestMessageSenderImpl.class, EmailMessageSenderImpl.class },
		useDefaultFilters = false,
		includeFilters = {
			@ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE, value = SubmissionRequestMessageSenderImpl.class),
			@ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE, value = EmailMessageSenderImpl.class)
		})
// @formatter:on
@Configuration
public class JmsConfiguration {

	private static final String JMS_MAIN_QUEUE_JNDI_NAME = "java:comp/env/jms/toEsysQueue";
	private static final String JMS_EMAIL_QUEUE_JNDI_NAME = "java:comp/env/jms/EMAIL";
	private static final String JMS_CONNECTION_FACTORY_JNDI_NAME = "java:comp/env/jms/connectionFactory";

	@Bean
	public JmsTemplate jmsTemplate() throws Exception {
		JmsTemplate template = new JmsTemplate();
		template.setConnectionFactory(jmsConnectionFactory());
		return template;
	}

	@Bean
	public Queue jmsSendEmailQueue() throws ResourceException {
		final JndiObjectFactoryBean jndiFactory = new JndiObjectFactoryBean();

		jndiFactory.setJndiName(JMS_EMAIL_QUEUE_JNDI_NAME);
		jndiFactory.setResourceRef(true);
		jndiFactory.setLookupOnStartup(false);
		jndiFactory.setExpectedType(Queue.class);

		try {
			jndiFactory.afterPropertiesSet();

		} catch (NamingException e) {
			throw new ResourceException(
					"Could not set properties on queue in JNDI; jndiName=" + JMS_EMAIL_QUEUE_JNDI_NAME);
		}

		Queue queue = (Queue) jndiFactory.getObject();
		if (queue == null) {
			throw new ResourceException(
					"Could not locate configured queue in JNDI; jndiName=" + JMS_EMAIL_QUEUE_JNDI_NAME);
		}
		return queue;
	}

	@Bean
	public Queue jmsToEsysQueue() throws ResourceException {
		final JndiObjectFactoryBean jndiFactory = new JndiObjectFactoryBean();

		jndiFactory.setJndiName(JMS_MAIN_QUEUE_JNDI_NAME);
		jndiFactory.setResourceRef(true);
		jndiFactory.setLookupOnStartup(false);
		jndiFactory.setExpectedType(Queue.class);

		try {
			jndiFactory.afterPropertiesSet();

		} catch (NamingException e) {
			throw new ResourceException(
					"Could not set properties on queue in JNDI; jndiName=" + JMS_MAIN_QUEUE_JNDI_NAME);
		}

		Queue queue = (Queue) jndiFactory.getObject();
		if (queue == null) {
			throw new ResourceException(
					"Could not locate configured queue in JNDI; jndiName=" + JMS_MAIN_QUEUE_JNDI_NAME);
		}
		return queue;
	}

	@Bean
	public ConnectionFactory jmsConnectionFactory() throws Exception {
		final JndiObjectFactoryBean jndiFactory = new JndiObjectFactoryBean();

		jndiFactory.setJndiName(JMS_CONNECTION_FACTORY_JNDI_NAME);
		jndiFactory.setResourceRef(true);
		jndiFactory.setLookupOnStartup(false);
		jndiFactory.setExpectedType(ConnectionFactory.class);

		try {
			jndiFactory.afterPropertiesSet();

		} catch (NamingException e) {
			throw new ResourceException("Could not set properties on connection factory in JNDI; jndiName="
					+ JMS_CONNECTION_FACTORY_JNDI_NAME);
		}

		ConnectionFactory connectionFactory = (ConnectionFactory) jndiFactory.getObject();
		if (connectionFactory == null) {
			throw new ResourceException("Could not locate configured connection factory in JNDI; jndiName="
					+ JMS_CONNECTION_FACTORY_JNDI_NAME);
		}
		return connectionFactory;
	}

}
