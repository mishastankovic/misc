package au.gov.vic.sro.autopay.service.configuration;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.FilterType;

import au.gov.vic.sro.autopay.service.address.IntechServiceImpl;

// @formatter:off
@ComponentScan(
		basePackageClasses = { IntechServiceImpl.class },
		useDefaultFilters = false,
		includeFilters = {
				@ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE, value = IntechServiceImpl.class)
		})
// @formatter:on
@Configuration
public class IntechServiceConfiguration {
}
