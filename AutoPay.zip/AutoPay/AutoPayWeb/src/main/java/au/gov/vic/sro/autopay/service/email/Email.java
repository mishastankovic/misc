package au.gov.vic.sro.autopay.service.email;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

public class Email {

	private String toName;
	private String toAddress;
	private String fromName;
	private String fromAddress;
	private String subject;
	private String[] replacementParameters;
	private String attachmentName;
	private String attachmentType;
	private byte[] attachment;

	public String getToName() {
		return toName;
	}

	public void setToName(String toName) {
		this.toName = toName;
	}

	public String getToAddress() {
		return toAddress;
	}

	public void setToAddress(String toAddress) {
		this.toAddress = toAddress;
	}

	public String getFromName() {
		return fromName;
	}

	public void setFromName(String fromName) {
		this.fromName = fromName;
	}

	public String getFromAddress() {
		return fromAddress;
	}

	public void setFromAddress(String fromAddress) {
		this.fromAddress = fromAddress;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String[] getReplacementParameters() {
		return replacementParameters;
	}

	public void setReplacementParameters(String[] replacementParameters) {
		this.replacementParameters = replacementParameters;
	}

	public String getAttachmentName() {
		return attachmentName;
	}

	public void setAttachmentName(String attachmentName) {
		this.attachmentName = attachmentName;
	}

	public String getAttachmentType() {
		return attachmentType;
	}

	public void setAttachmentType(String attachmentType) {
		this.attachmentType = attachmentType;
	}

	public byte[] getAttachment() {
		return attachment;
	}

	public void setAttachment(byte[] attachment) {
		this.attachment = attachment;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}

}
