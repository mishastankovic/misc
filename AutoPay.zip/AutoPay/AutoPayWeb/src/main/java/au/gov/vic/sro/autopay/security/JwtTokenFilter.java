package au.gov.vic.sro.autopay.security;

import java.io.IOException;
import java.util.Optional;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import au.gov.vic.sro.autopay.service.security.jwt.JwtTokenProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.context.support.WebApplicationContextUtils;
import org.springframework.web.filter.GenericFilterBean;

@WebFilter(filterName = "JwtTokenFilter", urlPatterns = {"/*"})
public class JwtTokenFilter extends GenericFilterBean implements Filter {

  // @todo - configure this URI properly
  public static final String LOGIN_URI = "/users/login";
  public static final String JWT_PROVIDER_BEAN = "jwtTokenProvider";


  @Override
  public void doFilter(ServletRequest req, ServletResponse res, FilterChain filterChain)
      throws IOException, ServletException {

    HttpServletRequest sr = (HttpServletRequest)req;
    if (!sr.getPathInfo().contains(LOGIN_URI)) {
      JwtTokenProvider jwtTokenProvider = getJwtTokenProvider(sr.getServletContext());
      String token = jwtTokenProvider.resolveToken((HttpServletRequest) req);
      if (token != null && jwtTokenProvider.validateToken(token)) {
        Authentication auth = jwtTokenProvider.getAuthentication(token);
        SecurityContextHolder.getContext().setAuthentication(auth);
      } else {
        ((HttpServletResponse)res).sendError(HttpServletResponse.SC_FORBIDDEN);
      }
    }
    filterChain.doFilter(req, res);
  }

  private JwtTokenProvider getJwtTokenProvider(ServletContext context ) {
    return WebApplicationContextUtils.getWebApplicationContext(context)
            .getBean(JWT_PROVIDER_BEAN, JwtTokenProvider.class);
  }

}
