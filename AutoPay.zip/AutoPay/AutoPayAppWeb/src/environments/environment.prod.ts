export const baseUrl: string = window.location.protocol + '//' + window.location.hostname + ':' + '8882' + '/autopayservice/api';

export const environment = {
  production: true,
  serviceHostname: '',
  //loginServicePath: window.location.protocol + '//' + window.location.hostname + ':' + '8882' + '/autopayservice/api/users/login'
  loginServicePath: baseUrl + '/users/login',
  liabilityServiceUrl: baseUrl + '/liabilities',
  arrangementsServiceUrl: baseUrl + '/arrangements',
  instalmentServiceUrl: baseUrl + '/instalments'

};
