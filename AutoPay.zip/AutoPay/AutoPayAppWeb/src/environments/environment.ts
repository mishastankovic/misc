// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

//export const baseUrl: string = window.location.protocol + '//' + window.location.hostname + ':' + window.location.port + '/autopayservice/api';
export const baseUrl: string = window.location.protocol + '//' + window.location.hostname + ':' + '8882' + '/autopayservice/api';

export const environment = {
	production: false,
	serviceHostname: '',
  //loginServicePath: window.location.protocol + '//' + window.location.hostname + ':' + '8882' + '/autopayservice/api/users/login'
  loginServicePath: baseUrl + '/users/login',
  liabilityServiceUrl: baseUrl + '/liabilities',
  arrangementsServiceUrl: baseUrl + '/arrangements',
  instalmentServiceUrl: baseUrl + '/instalments'

};
