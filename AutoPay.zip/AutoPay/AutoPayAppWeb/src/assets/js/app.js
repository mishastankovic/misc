
function styleSectionsWithValidationErrors() {
	$(".bs-callout").each(function () {
		$(this).removeClass("bs-callout-danger").addClass("bs-callout-primary");
	});

	$(".ng-invalid").each(function () {
		$(this).closest(".bs-callout").removeClass("bs-callout-primary").addClass("bs-callout-danger");
	});
}
