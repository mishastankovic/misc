import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { NgModule, ApplicationRef, ErrorHandler } from '@angular/core';

import { AutoCompleteModule } from 'primeng/components/autocomplete/autocomplete';
import { CalendarModule } from 'primeng/components/calendar/calendar';
import { InputMaskModule } from 'primeng/components/inputmask/inputmask';

//import { RecaptchaModule } from 'ng-recaptcha';

import { AppRouterModule, routeComponents } from './app.router';
import { AppComponent } from './app.component';
import { AnalyticsService } from './au/gov/vic/sro/autopay/service/analytics.service';
import { AppService } from './au/gov/vic/sro/autopay/service/app.service';
import { AuthGuard } from './au/gov/vic/sro/autopay/component/guard/auth.guard';
import { ErrorHandlerService } from './au/gov/vic/sro/autopay/service/error-handler.service';
import { StepperService } from './au/gov/vic/sro/autopay/component/stepper/stepper.service';
import { ReferenceDataService } from './au/gov/vic/sro/autopay/service/reference-data.service';
import { WindowService } from './au/gov/vic/sro/autopay/service/window.service';

import { ReferenceDataPipe } from './au/gov/vic/sro/autopay/component/pipe/reference-data.pipe';
import { StepperComponent } from './au/gov/vic/sro/autopay/component/stepper/stepper.component';
import { AppErrorHandler } from 'app/au/gov/vic/sro/autopay/util/app-error-handler';

import { TranslateService } from 'app/au/gov/vic/sro/autopay/component/translate/translate.service';
import { TranslatePipe } from 'app/au/gov/vic/sro/autopay/component/translate/translate.pipe';
import { TranslationProvider } from 'app/au/gov/vic/sro/autopay/component/translate/translation';
import { ReferenceDataSortingPipe } from 'app/au/gov/vic/sro/autopay/component/pipe/reference-data-sorting.pipe';
import { ReferenceDataUtils } from 'app/au/gov/vic/sro/autopay/util/reference-data-utils';
import { DeactivationGuard } from 'app/au/gov/vic/sro/autopay/component/guard/deactivation.guard';
import { WelcomeComponent } from './au/gov/vic/sro/autopay/form/welcome/welcome.component';
import { ContactDetailsComponent } from './au/gov/vic/sro/autopay/form/arrangement/contact-details/contact-details.component';
import { FormUtils } from 'app/au/gov/vic/sro/autopay/util/form-utils';
import { UIMessageService } from 'app/au/gov/vic/sro/autopay/service/ui-message.service';
import { BsDropdownConfig, SRONgComponentLibraryModule } from "sro-ngcomponent-library";
import { LoginService } from "./au/gov/vic/sro/autopay/form/identity/login.service";
import { DirectDebitComponent } from './au/gov/vic/sro/autopay/component/direct-debit/direct-debit.component';
import { CreditCardComponent } from './au/gov/vic/sro/autopay/component/credit-card/credit-card.component';
import { LiabilitiesComponent } from './au/gov/vic/sro/autopay/component/liabilities/liabilities-component';
import { ArrangementComponent } from './au/gov/vic/sro/autopay/component/arrangement/arrangement-component';
import { ArrangementService } from "./au/gov/vic/sro/autopay/component/arrangement/arrangement-service";
import { LiabilityService } from "./au/gov/vic/sro/autopay/component/liabilities/liability-service";
import { CreateArrangementWizardComponent } from './au/gov/vic/sro/autopay/component/create-arrangement-wizard/create-arrangement-wizard.component';
import { DebtArrangementWizardComponent } from './au/gov/vic/sro/autopay/component/debt-arrangement-wizard/debt-arrangement-wizard.component';
import { CancelArrangementComponent } from './au/gov/vic/sro/autopay/component/cancel-arrangement/cancel-arrangement.component';
import { CompletedArrangementsComponent } from './au/gov/vic/sro/autopay/component/completed-arrangements/completed-arrangements.component';
import { InstalmentDetailsComponent } from './au/gov/vic/sro/autopay/form/arrangement/instalment-details/instalment-details.component';
import { SelectLiabilityComponent } from 'app/au/gov/vic/sro/autopay/form/arrangement/select-liability/select-liability.component';


@NgModule({
	declarations: [
		AppComponent,
		routeComponents,

		StepperComponent,
		// Pipes
		ReferenceDataPipe,
		TranslatePipe,
		ReferenceDataSortingPipe,
		WelcomeComponent,
		ContactDetailsComponent,
		DirectDebitComponent,
		CreditCardComponent,
		LiabilitiesComponent,
		ArrangementComponent,
		CreateArrangementWizardComponent,
		DebtArrangementWizardComponent,
		CancelArrangementComponent,
		CompletedArrangementsComponent,
		InstalmentDetailsComponent,
		SelectLiabilityComponent
	],
	imports: [
		AppRouterModule,
		BrowserModule,
		BrowserAnimationsModule,
		HttpClientModule,
		ReactiveFormsModule,
		//RecaptchaModule.forRoot(),

		// Primefaces NG components
		AutoCompleteModule,
		CalendarModule,
		InputMaskModule,
		SRONgComponentLibraryModule
	],
	providers: [
		AppService,
		UIMessageService,
		FormUtils,
		AuthGuard,
		AnalyticsService,
		ReferenceDataService,
		StepperService,
		TranslationProvider,
		TranslateService,
		WindowService,
		ErrorHandlerService,
		LoginService,
		{
			provide: ErrorHandler,
			useClass: AppErrorHandler
		},
		ReferenceDataUtils,
		DeactivationGuard,
		LiabilityService,
		ArrangementService,
		BsDropdownConfig

	],
	bootstrap: [AppComponent]
})
export class AppModule {
}
