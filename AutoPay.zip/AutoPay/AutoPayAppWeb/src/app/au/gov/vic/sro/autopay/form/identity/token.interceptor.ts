import {Injectable} from '@angular/core';
import {LoginService} from 'app/au/gov/vic/sro/autopay/form/identity/login.service';
import {Router} from '@angular/router';
import {HttpRequest, HttpHandler, HttpEvent, HttpInterceptor, HttpErrorResponse} from '@angular/common/http';
import {Observable} from 'rxjs';

@Injectable()
export class TokenInterceptor implements HttpInterceptor {
  constructor(private loginService: LoginService, private router: Router) {
  };

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const secured = this.isSecuredUrl(request.url);

    console.log(`secured ? ${secured}`);
    console.log('TokenInterceptor - has valid token ??');
    if (secured) {
      if (this.loginService.hasValidToken()) {
        console.log('TokenInterceptor - DOES have valid token');
        request = request.clone({
          setHeaders: {
            Authorization: `Bearer ${this.loginService.getToken()}`
          }
        });
      } else {
        this.redirectToLogin();
        return;
      }
    }
    return next.handle(request); /*.pipe((event: HttpEvent<any>) => {
    }, (err: any) => {
      console.log(`TokenInterceptor - err: ${err.status}`);
      if (err instanceof HttpErrorResponse) {
        if (secured && (err.status === 401 || err.status === 403)) {
          // redirect to the login route
          this.redirectToLogin();
        }
      }
    });*/
  }

  redirectToLogin() {
    console.log('TokenInterceptor - redirecting to login page');
    this.router.navigate(['/login'], {queryParams: {timedOut: 'true'}});
  }

  isSecuredUrl(url: string): boolean {
    return (url && url.indexOf('/secured/') != -1);
  }
}
