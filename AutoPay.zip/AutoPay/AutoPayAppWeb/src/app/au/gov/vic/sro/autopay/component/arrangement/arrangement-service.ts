import { Injectable } from '@angular/core';
import {AppService} from "../../service/app.service";
import {environment} from "../../../../../../../../environments/environment";
import {HttpClient, HttpParams} from "@angular/common/http";
import {CustomerIdentity} from "../../model/customer-identity";
import {Observable} from "rxjs/internal/Observable";
import {Arrangement} from "../../model/arrangement";

@Injectable({
  providedIn: 'root'
})
export class ArrangementService {

  constructor(private appService: AppService, private http: HttpClient) { }

  /**
   *
   * @returns {Observable<Arrangement[]>}
   */
  getCustomerArrangements(): Observable<Arrangement[]> {
    let customerIdentity: CustomerIdentity = this.appService.getCustomerIdentity();
    if(customerIdentity) {
      let url: string = environment.arrangementsServiceUrl;
      const params: HttpParams = new HttpParams().set('revenueLine', customerIdentity.revenueLine).set('customer', customerIdentity.customerId);
      return this.http.get<Arrangement[]>(url, {params});
    }
  }

  getArrangement(arrangementId: string): Observable<Arrangement> {
    let customerIdentity: CustomerIdentity = this.appService.getCustomerIdentity();
    if(customerIdentity) {
      let url: string = environment.arrangementsServiceUrl + '/' + arrangementId;
      const params: HttpParams = new HttpParams().set('revenueLine', customerIdentity.revenueLine).set('customer', customerIdentity.customerId);
      return this.http.get<Arrangement>(url, {params});
    }
  }
}
