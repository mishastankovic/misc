
import { Pipe, PipeTransform } from '@angular/core';
import { TranslateService } from 'app/au/gov/vic/sro/autopay/component/translate/translate.service';
@Pipe({
	name: 'translate',
})

export class TranslatePipe implements PipeTransform {

	constructor(private _translate: TranslateService) { }

	transform(value: string, args: any[]): any {
		if (!value) return;
		return this._translate.translate(value);
	}
}