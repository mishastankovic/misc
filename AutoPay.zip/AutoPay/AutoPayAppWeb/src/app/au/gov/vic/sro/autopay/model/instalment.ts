import {ArrangementAction} from "./arrangement-action";

export interface Instalment {
  instalmentNo	: number;
  paymentArrangementId	: string;
  paymentArrangementVersion	: string;
  instalmentStatus	: string;
  dueDate	: Date;
  amount	: number;
  surcharge	: number;
  interest	: number;
  totalAmount	: number;
  requestSentCode	: string;
  dateRequestSent	: Date;
  paoTransactionNumber: string;
  quickbatchSummaryCode	: string;
  quickbatchResponseCode	: string;
  arrangementAction:	ArrangementAction;
}
