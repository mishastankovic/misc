import {LiabilityAction} from "./liability-action";
import {LiabilityId} from "./liability-id";

export interface Liability {
  liabilityId: LiabilityId;
  liabilityYear: string;
  liabilityIssueDate: Date;
  liabilityDueDate: Date;
  extendedDueDate: Date;
  paymentArrangementId: string;
  paymentArrangementVersion: string;
  outstandingLiabilityAmount:	number;
  overdue	: boolean;
  serviceList: LiabilityAction[];
}
