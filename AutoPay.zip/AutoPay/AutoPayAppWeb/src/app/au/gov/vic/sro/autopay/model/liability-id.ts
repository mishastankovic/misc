export interface LiabilityId {
  liabilityReferenceType: string;
  liabilityReferenceId: string;
  liabilityReferenceVersion: string;
  revenueType: string;
  checksum: string;
}
