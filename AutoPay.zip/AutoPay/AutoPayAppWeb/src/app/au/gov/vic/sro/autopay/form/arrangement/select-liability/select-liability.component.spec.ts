import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectLiabilityComponent } from './select-liability.component';

describe('SelectLiabilityComponent', () => {
  let component: SelectLiabilityComponent;
  let fixture: ComponentFixture<SelectLiabilityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SelectLiabilityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectLiabilityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
