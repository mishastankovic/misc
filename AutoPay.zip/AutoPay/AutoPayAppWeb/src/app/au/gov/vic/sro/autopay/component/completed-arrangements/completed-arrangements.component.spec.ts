import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompletedArrangementsComponent } from './completed-arrangements.component';

describe('CompletedArrangementsComponent', () => {
  let component: CompletedArrangementsComponent;
  let fixture: ComponentFixture<CompletedArrangementsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompletedArrangementsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompletedArrangementsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
