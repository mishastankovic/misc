import {AppService} from "./app.service";
import {Observable} from "rxjs/internal/Observable";
import {HttpClient, HttpParams} from "@angular/common/http";
import {CustomerIdentity} from "../model/customer-identity";
import {Injectable} from "@angular/core";
import {environment} from "../../../../../../../environments/environment";
import {Instalment} from "../model/instalment";
import {LiabilityId} from "../model/liability-id";
import {CreateInstalmentResponse} from "../model/create-instalment-response";

@Injectable({
  providedIn: 'root'
})
export class InstalmentService {

  constructor(private appService: AppService, private http: HttpClient) {
  }

  /**
   *
   * @returns {Observable<Liability[]>}
   */
  createInstalments(liabilities: LiabilityId[]): Observable<CreateInstalmentResponse> {
    let customerIdentity: CustomerIdentity = this.appService.getCustomerIdentity();
    if (customerIdentity) {
      let url: string = environment.instalmentServiceUrl;
      const data = {
        "customer": customerIdentity.customerId,
        "revenueLine": customerIdentity.revenueLine,
        "liabilities": liabilities
      };
      return this.http.post<CreateInstalmentResponse>(url, {data});
    }
  }

}

