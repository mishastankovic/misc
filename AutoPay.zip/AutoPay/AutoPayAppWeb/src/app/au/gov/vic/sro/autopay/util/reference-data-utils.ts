import { Injectable } from "@angular/core";

import { ReferenceDataService } from "app/au/gov/vic/sro/autopay/service/reference-data.service";
import { ReferenceData } from "app/au/gov/vic/sro/autopay/model/reference-data";

@Injectable()
export class ReferenceDataUtils {

	referenceData: ReferenceData[];

	constructor(private referenceDataService: ReferenceDataService) {
		this.referenceData = this.referenceDataService.getReferenceData();
	}

	getTrusteeLabel(code: string): string {
		const refData: ReferenceData = this.referenceData.find(item => item.type === ReferenceDataService.TRUSTEE_TYPES && item.code === code);
		return refData ? refData.label : ' ';
	}

	getLandOwnerTypeLabel(code: string): string {
		const refData: ReferenceData = this.referenceData.find(item => item.type === ReferenceDataService.LAND_OWNER_TYPES && item.code === code);
		return refData ? refData.label : ' ';
	}

	getLandOwnerTypeShortLabel(code: string): string {
		const refData: ReferenceData = this.referenceData.find(item => item.type === ReferenceDataService.LAND_OWNER_TYPES && item.code === code);
		return refData ? refData.shortLabel : ' ';
	}

	getExemptionTypeLabel(code: string): string {
		const refData: ReferenceData = this.referenceData.find(item => item.type === ReferenceDataService.EXEMPTION_TYPES && item.code === code);
		return refData ? refData.label : ' ';
	}

	getCommunicationChannelsLabel(code: string): string {
		const refData: ReferenceData = this.referenceData.find(item => item.type === ReferenceDataService.COMMUNICATION_CHANNELS && item.code === code);
		return refData ? refData.label : ' ';
	}

	getCommunicationRecipientsLabel(code: string): string {
		const refData: ReferenceData = this.referenceData.find(item => item.type === ReferenceDataService.COMMUNICATION_RECIPIENTS && item.code === code);
		return refData ? refData.label : ' ';
	}

	getCompletionTypesLabel(code: string): string {
		const refData: ReferenceData = this.referenceData.find(item => item.type === ReferenceDataService.COMPLETION_TYPES && item.code === code);
		return refData ? refData.label : ' ';
	}

	getPropertyOwnershipTypesLabel(code: string): string {
		const refData: ReferenceData = this.referenceData.find(item => item.type === ReferenceDataService.PROPERTY_OWNERSHIP_TYPES && item.code === code);
		return refData ? refData.label : ' ';
	}

	getNotificationTypesLabel(code: string): string {
		const refData: ReferenceData = this.referenceData.find(item => item.type === ReferenceDataService.NOTIFICATION_TYPES && item.code === code);
		return refData ? refData.label : ' ';
	}

	getFlatUnitTypesLabel(code: string): string {
		const refData: ReferenceData = this.referenceData.find(item => item.type === ReferenceDataService.FLAT_UNIT_TYPES && item.code === code);
		return refData ? refData.label : ' ';
	}

	getFloorLevelTypesLabel(code: string): string {
		const refData: ReferenceData = this.referenceData.find(item => item.type === ReferenceDataService.FLOOR_LEVEL_TYPES && item.code === code);
		return refData ? refData.label : ' ';
	}

	getRoadSuffixTypesLabel(code: string): string {
		const refData: ReferenceData = this.referenceData.find(item => item.type === ReferenceDataService.STREET_SUFFIXES && item.code === code);
		return refData ? refData.label : ' ';
	}

	getRoadTypesLabel(code: string): string {
		const refData: ReferenceData = this.referenceData.find(item => item.type === ReferenceDataService.STREET_TYPES && item.code === code);
		return refData ? refData.label : ' ';
	}

	getPostalDeliveryTypesLabel(code: string): string {
		const refData: ReferenceData = this.referenceData.find(item => item.type === ReferenceDataService.POSTAL_BOX_TYPES && item.code === code);
		return refData ? refData.label : ' ';
	}

	getCountryLabel(code: string): string {
		const refData: ReferenceData = this.referenceData.find(item => item.type === ReferenceDataService.COUNTRIES && item.code === code);
		return refData ? refData.label : ' ';
	}

	getTrustTypeLabel(code: string): string {
		const refData: ReferenceData = this.referenceData.find(item => item.type === ReferenceDataService.TRUST_TYPES && item.code === code);
		return refData ? refData.label : ' ';
	}
}