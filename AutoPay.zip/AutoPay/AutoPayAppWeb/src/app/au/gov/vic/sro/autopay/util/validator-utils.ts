import { Validators, ValidatorFn } from '@angular/forms';

import { DateValidator } from 'app/au/gov/vic/sro/autopay/util/validator/date.validator';
import { EmailValidator } from 'app/au/gov/vic/sro/autopay/util/validator/email.validator';
import { PhoneNumberValidator } from 'app/au/gov/vic/sro/autopay/util/validator/phone-number.validator';

export class ValidatorConfig {
	public key: string;
	public validators: ValidatorFn | null;

	constructor(
		key: string,
		validators: ValidatorFn
	) {
		this.key = key;
		this.validators = validators;
	}
}

export class ValidatorUtil {

	static VALIDATOR_CONFIG: ValidatorConfig[] = [
		// Common
		new ValidatorConfig('postalAddressSame', Validators.compose([Validators.required])),
		// Identity
		new ValidatorConfig('customerId', Validators.compose([Validators.required, Validators.maxLength(9)])),
		new ValidatorConfig('revenueLine', Validators.compose([Validators.required])),
		new ValidatorConfig('issueDate', Validators.compose([Validators.required, DateValidator.validateFormat(), DateValidator.validateNotFuture()])),
		new ValidatorConfig('ltxAssessmentId', Validators.compose([Validators.required, Validators.maxLength(8)])),
		new ValidatorConfig('assessmentId', Validators.compose([Validators.required, Validators.maxLength(8)])),
		new ValidatorConfig('partialCorrespondenceId', Validators.compose([Validators.required, Validators.maxLength(16)])),
		new ValidatorConfig('correspondenceId', Validators.compose([Validators.required, Validators.maxLength(16)]))];


	static get(key: string): ValidatorFn {

		let item = this.VALIDATOR_CONFIG.filter(config => config.key === key);
		return item && item.length > 0 ? item[0].validators : null;
	}

}