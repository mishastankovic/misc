import { AbstractControl, ValidatorFn } from '@angular/forms';

export class PhoneNumberValidator {

	static validate(): ValidatorFn {
		var pattern = /^(\+ ?)?(?:[0-9()] ?){1,16}[0-9]$/;
		return (control: AbstractControl): { [key: string]: any } => {
			let valid = true;
			if (control && control.value) {
				valid = pattern.test(control.value);
				if (valid) {
					var regExp = /\$\d+(?=\))/;
					var matches = regExp.exec(control.value);
					let array: string[] = control.value.match(/(?:\()[^\(\)]*?(?:\))/g);
					if (array && array[0]) {
						valid = array[0].length > 2
					}
				}
			}
			return valid ? null : { 'phoneNumberFormat': { value: control.value } };
		};
	}

} 