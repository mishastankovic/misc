import { Router } from '@angular/router';
import { async, fakeAsync, tick, ComponentFixture, TestBed, inject } from "@angular/core/testing";
import { AppService } from 'app/au/gov/vic/sro/autopay/service/app.service';
import { AuthGuard } from './auth.guard';

describe('AuthGuard', () => {
	beforeEach(() => {
		TestBed.configureTestingModule({
			providers: [AppService, AuthGuard, { provide: Router, useClass: RouterStub }]
		})
			.compileComponents();
	});

	it('should be created', () => {
		inject([AuthGuard], (authGuard) => {
			expect(authGuard).toBeDefined();
		})
	});

	it('should be activated when navigate to non identity pages', () => {
		inject([AuthGuard], (authGuard) => {
			expect(authGuard.canActivate()).toBeTruthy();
		})
	});
});

class RouterStub {
	navigate(obj: any) {
		return obj;
	}
}