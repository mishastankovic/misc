import { Component, OnDestroy, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Subscription } from "rxjs";

//import { RecaptchaModule } from 'ng-recaptcha';
//import { RecaptchaFormsModule } from 'ng-recaptcha/forms';

import { CustomerIdentity } from 'app/au/gov/vic/sro/autopay/model/customer-identity';
import { AppService } from 'app/au/gov/vic/sro/autopay/service/app.service';
import { FormUtils } from 'app/au/gov/vic/sro/autopay/util/form-utils';
import { ValidatorUtil } from 'app/au/gov/vic/sro/autopay/util/validator-utils';
import { ErrorResponse } from 'app/au/gov/vic/sro/autopay/model/error-response';
import { RecaptchaResponse } from 'app/au/gov/vic/sro/autopay/model/recaptcha-response';
import { ReferenceDataService } from 'app/au/gov/vic/sro/autopay/service/reference-data.service';
import { ReferenceData } from 'app/au/gov/vic/sro/autopay/model/reference-data';
import { LoginService } from "./login.service";
import { SpinnerService } from "sro-ngcomponent-library";

const LOCAL_STORAGE_KEY: string = "vlt";

@Component({
	selector: 'app-identity',
	templateUrl: './identity.component.html'
})
export class IdentityComponent implements OnInit, OnDestroy {

	form: FormGroup;
	customerIdentity: CustomerIdentity;
	private subscriptions: Subscription[] = [];
	authenticationFailed: boolean = false;
	serverError: boolean = false;
	serverDataError: boolean = false;
	dataSourceError: boolean = false;
	errorReferenceNumber: string;
	captchaResponse: string = '';
	verifyRecaptchaPassed: boolean = false;
	loadRecaptcha: boolean = false;
	captchaError: boolean = false;
	referenceData: ReferenceData[];
	identifierType: string = '';

	constructor(public appService: AppService, private formBuilder: FormBuilder, private router: Router,
		public referenceDataService: ReferenceDataService, private loginService: LoginService, private spinnerService: SpinnerService) {
	}

	ngOnInit() {
		this.appService.resetApplication();
		this.customerIdentity = this.appService.getCustomerIdentity();
		this.referenceData = this.referenceDataService.getReferenceData();
		this.buildForm();

		/*
		if (this.isLocalStorageSupports()) {
		  this.increaseLocalStorageCounter();
		} else {
		  this.loadRecaptcha = true;
		}
		*/
	}

	ngOnDestroy() {
		this.subscriptions.forEach(subscription => subscription.unsubscribe());
	}

	onSubmit() {
		this.validateForm();
		if (this.form.valid) {
			this.customerIdentity = this.mapFormToCustomerIdentity();
			this.spinnerService.showSpinner();
			this.authenticateCustomer();
		}
	}


	/*
	recaptchaVerification() {
	  this.loaderService.showSpinner();
	  if (this.loadRecaptcha) {
		if (this.captchaResponse) {
		  let verifyResult = this.appService.verifyRecaptcha(this.captchaResponse).subscribe(
			results => {
			  this.loaderService.hideSpinner();
			  let recaptchaResponse: RecaptchaResponse = JSON.parse(JSON.stringify(results));
			  this.verifyRecaptchaPassed = recaptchaResponse.verifyRecaptcha;
  
			  if (this.verifyRecaptchaPassed) {
				this.submitIdentity();
			  }
  
			},
			error => {
			  this.loaderService.hideSpinner();
			  var errorResponse = error;
			  try {
				let errorResponseObjec: ErrorResponse = JSON.parse(errorResponse._body);
				this.errorReferenceNumber = errorResponseObjec.errors[0].errorCode;
				FormUtils.focusError(document);
				this.serverError = true;
			  }
			  catch (e) {
				this.serverDataError = true;
			  }
			}
		  );
		} else {
		  this.captchaError = true;
		  this.loaderService.hideSpinner();
		  FormUtils.focusError(document);
		}
	  } else {
		this.submitIdentity();
	  }
  
	}
  
	resolved(captchaResponse: string) {
	  this.captchaResponse = captchaResponse;
	  this.verifyRecaptchaPassed = false;
	  this.captchaError = false;
	  localStorage.clear();
	}
	*/

	submitIdentity() {
		// Make authentication call
		this.customerIdentity = this.appService.getCustomerIdentity();
		this.authenticateCustomer();
		this.appService.setValidUser(true);
	}


	authenticateCustomer() {
		let result = this.loginService.login(this.customerIdentity)
			.subscribe(
			(result: any) => {
				this.spinnerService.hideSpinner();
				if (result) {
					this.loginService.saveToken(result.token);
					this.router.navigate(['/welcome']);
				}
			},
			error => {
				this.spinnerService.hideSpinner();
				this.router.navigate(['/login']);
				var errorResponse = error;
				try {
					let errorResponseObjec: ErrorResponse = JSON.parse(errorResponse._body);
					this.errorReferenceNumber = errorResponseObjec.errors[0].errorCode;
					if (errorResponseObjec.errors[0].errorText && errorResponseObjec.errors[0].errorText === ErrorResponse.SERVICE_NOT_AVAILABLE_ERROR_TEXT) {
						this.dataSourceError = true;
					} else {
						this.serverError = true;
					}
					FormUtils.focusError(document);
					//this.increaseLocalStorageCounter();
				}
				catch (e) {
					this.serverDataError = true;
				}
			}
			);
	}

	/**
	 * !!!!!!!!!! @mishas todo - check whether this function is required
	 * @param {AbstractControl} control
	 * @param {string} type
	 * @returns {boolean}
	 */
	isNotValid(control: AbstractControl, type?: string): boolean {
		if (!control) return;
		return FormUtils.isNotValid(control, type);
	}

	buildForm() {
		this.form = this.formBuilder.group({
			customerId: [this.customerIdentity.customerId, ValidatorUtil.get("customerId")],
			revenueLine: [this.customerIdentity.revenueLine, ValidatorUtil.get("revenueLine")],
			assessmentId: [this.customerIdentity.assessmentId, ValidatorUtil.get("assessmentId")]
		});
		this.onExistingCustomerValueChanged();
	}

	onExistingCustomerValueChanged(data?: any) {
		this.authenticationFailed = false;
		if (!this.form) return;
	}

	validateForm() {
		FormUtils.validate(this.form);
		this.form.updateValueAndValidity();
		if (!this.form.valid) FormUtils.focusError(document);
	}

	static assessmentNumbersValidator(group: FormGroup): { assessmentNumberRequired: boolean } {
		const assessmentId: AbstractControl = group.get('assessmentId');
		return (assessmentId && assessmentId.value != '') ? null : { assessmentNumberRequired: true };
	}

	mapFormToCustomerIdentity(): CustomerIdentity {
		const customerIdentity: CustomerIdentity = CustomerIdentity.createCustomerIdentity();
		customerIdentity.customerId = this.form.get('customerId').value;
		customerIdentity.revenueLine = this.form.get('revenueLine').value;
		customerIdentity.assessmentId = this.form.get('assessmentId').value;
		return customerIdentity;
	}

	getRevenueTypes(): string {
		return ReferenceDataService.REVENUE_TYPES;
	}

	/*
	isLocalStorageSupports(): boolean {
	  return 'localStorage' in window && window['localStorage'] !== null;
	}
  
  
	increaseLocalStorageCounter() {
	  if (localStorage.getItem(LOCAL_STORAGE_KEY)) {
		let number = parseInt(localStorage.getItem(LOCAL_STORAGE_KEY)) + 1;
		localStorage.setItem(LOCAL_STORAGE_KEY, number.toString());
		if (parseInt(localStorage.getItem(LOCAL_STORAGE_KEY)) >= 999999) {
		  this.loadRecaptcha = true;
		}
	  } else {
		if (this.captchaResponse) {
		  this.captchaResponse = '';
		  this.loadRecaptcha = false;
		  this.captchaError = false;
		}
		localStorage.setItem(LOCAL_STORAGE_KEY, "" + 1);
	  }
  
	}
	*/
}
