import { Component, OnInit } from '@angular/core';
import { ViewChild } from '@angular/core';
import { StepperComponent } from "sro-ngcomponent-library";

@Component({
	selector: 'ap-create-arrangement-wizard',
	templateUrl: './create-arrangement-wizard.component.html',
	styleUrls: ['./create-arrangement-wizard.component.scss']
})
export class CreateArrangementWizardComponent implements OnInit {

	@ViewChild('createArrangementStepper') createArrangementStepper: StepperComponent;

	constructor() { }

	ngOnInit() {
	}

	gotoNextStep() {
		const currentStepIndex = this.createArrangementStepper.steps.indexOf(this.createArrangementStepper.currentStep);
		if (this.createArrangementStepper.steps[currentStepIndex + 1]) {
			this.createArrangementStepper.steps[currentStepIndex + 1].active = true;
		}
	}

	gotoPreviousStep() {
		const currentStepIndex = this.createArrangementStepper.steps.indexOf(this.createArrangementStepper.currentStep);
		if (this.createArrangementStepper.steps[currentStepIndex - 1]) {
			this.createArrangementStepper.steps[currentStepIndex - 1].active = true;
		}
	}

}
