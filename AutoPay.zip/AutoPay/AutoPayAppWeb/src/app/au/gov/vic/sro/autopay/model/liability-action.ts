export interface LiabilityAction {
  serviceTypeId: string;
  available: boolean;
  notAvailableReason:	string;
}
