import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FormControl } from '@angular/forms';
import { AppService } from 'app/au/gov/vic/sro/autopay/service/app.service';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { Validators } from '@angular/forms';
import { BankAccountNameValidator } from 'app/au/gov/vic/sro/autopay/util/validator/bank-account-name.validator';
import { BsbValidator } from 'app/au/gov/vic/sro/autopay/util/validator/bsb.validator';
import { BankAccountNumberValidator } from 'app/au/gov/vic/sro/autopay/util/validator/bank-account-number.validator';
import { FormUtils } from 'app/au/gov/vic/sro/autopay/util/form-utils';

@Component({
	selector: 'app-direct-debit',
	templateUrl: './direct-debit.component.html',
	styleUrls: ['./direct-debit.component.css']
})
export class DirectDebitComponent implements OnInit {

	directDebitForm: FormGroup;

	accountName: FormControl;
	bsb: FormControl;
	accountNumber: FormControl;

	constructor(public appService: AppService, private formBuilder: FormBuilder, private router: Router, public formUtils: FormUtils) { }

	ngOnInit() {
		this.accountName = this.formBuilder.control('', Validators.compose([Validators.required, BankAccountNameValidator.validate()]));
		this.bsb = this.formBuilder.control('', Validators.compose([Validators.required, BsbValidator.validate()]));
		this.accountNumber = this.formBuilder.control('', Validators.compose([Validators.required, BankAccountNumberValidator.validate()]));
		this.directDebitForm = this.formBuilder.group({
			accountName: this.accountName,
			bsb: this.bsb,
			accountNumber: this.accountNumber
		});
	}

	onSubmit() {
		this.validateForm();
	}

	validateForm() {
		FormUtils.validate(this.directDebitForm);
		this.directDebitForm.updateValueAndValidity();
		if (!this.directDebitForm.valid) FormUtils.focusError(document);
	}

}
