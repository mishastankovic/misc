import {Contact} from "./contact";
import {Liability} from "./liability";
import {ArrangementAction} from "./arrangement-action";
import {Instalment} from "./instalment";

export interface Arrangement {
  paymentArrangementId	: string;
  paymentArrangementVersion	: string;
  customerId	: string;
  paymentToken	: string;
  arrangementStatus	: string;
  statusDate:	Date;
  cancellationDate:	Date;
  cancelledBy	: string;
  cancellationReason	: string;
  arrangementStartDate:	Date;
  arrangementEndDate: Date;
  paymentFrequency	: string;
  paymentMethod	: string;
  directDebitAccountNumber	: string;
  bsbNumber	: string;
  creditCardNumber	: string;
  creditCardExpiryMonth	: string;
  creditCardExpiryYear	: string;
  arrangementAmount: number;
  arrangementSurcharge:	number;
  arrangementInterest:	number;
  arrangementTotalAmount:	number;
  liabilities:	Liability[];
  instalments:	Instalment[];
  contacts:	Contact[];
  actions:	ArrangementAction[];
}
