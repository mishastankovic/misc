export interface ArrangementAction {
  actionTypeId: string;
  available: boolean;
  notAvailableReason:	string;
}
