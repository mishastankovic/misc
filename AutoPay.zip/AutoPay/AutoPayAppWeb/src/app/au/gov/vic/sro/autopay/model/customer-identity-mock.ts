import { CustomerIdentity } from "app/au/gov/vic/sro/autopay/model/customer-identity";

export const VALID_WALKIN_CUSTOMER: CustomerIdentity = new CustomerIdentity(
	'',
	'',
	''
);

export const INVALID_WALKIN_CUSTOMER: CustomerIdentity = new CustomerIdentity(
	'',
	'',
	''
);

export const VALID_CUSTOMER_WITH_ASSESSMENT_ID: CustomerIdentity = new CustomerIdentity(
	'',
	'',
	''
);

export const CUSTOMER_WITH_INVALID_CUSTOMER_ID: CustomerIdentity = new CustomerIdentity(
	'',
	'',
	''
);

export const CUSTOMER_WITH_EMPTY_DATA: CustomerIdentity = new CustomerIdentity(
	'',
	'',
	''
);

export const CUSTOMER_WITH_INCOMPLETE_CORRESPONDENCE_DATA: CustomerIdentity = new CustomerIdentity(
	'',
	'',
	''
);

export const CUSTOMER_WITH_VALID_CORRESPONDENCE_DATA: CustomerIdentity = new CustomerIdentity(
	'',
	'01/01/2017',
	''
);