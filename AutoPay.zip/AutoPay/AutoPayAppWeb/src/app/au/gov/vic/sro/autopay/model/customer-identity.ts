export class CustomerIdentity {

	constructor(

		public customerId?: string,
		public revenueLine?: string,
		public assessmentId?: string,
		public authenticationLevel?: string,

	) { }

	static createCustomerIdentity(): CustomerIdentity {
		return new CustomerIdentity('', '', '');
	}

	isFullyAuthenticated(): boolean {
		return this.authenticationLevel && this.authenticationLevel === 'F';
	}

	isPartiallyAuthenticated(): boolean {
		return this.authenticationLevel && this.authenticationLevel === 'P';
	}

	isNotAuthenticated(): boolean {
		return !this.isFullyAuthenticated() && !this.isPartiallyAuthenticated();
	}
}