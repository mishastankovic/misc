import {Instalment} from "./instalment";

export interface CreateInstalmentResponse {
  arrangementAmount:  number;
  arrangementSurcharge: number;
  arrangementInterest:  number;
  arrangementTotalAmount: number;
  instalments:  Instalment[];
}
