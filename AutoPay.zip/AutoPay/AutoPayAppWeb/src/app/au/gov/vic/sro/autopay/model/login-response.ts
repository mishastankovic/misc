export class LoginResponse {
}
