import { AbstractControl, FormControl } from '@angular/forms'

import { NumberValidator } from './number.validator';

describe('NumberValidator', () => {
	let validatorFn = new NumberValidator();

	it('should create an instance', () => {
		const directive = new NumberValidator();
		expect(directive).toBeTruthy();
	});

	it('should not error on an empty number', () => {
		expect(NumberValidator.validate()(new FormControl(''))).toBeNull();
	});

	it('should not error on an null number', () => {
		expect(NumberValidator.validate()(new FormControl(null))).toBeNull();
	});

	it('should not error on an undefined number', () => {
		expect(NumberValidator.validate()(new FormControl(null))).toBeNull();
	});

	it('should not error on an valid number', () => {
		expect(NumberValidator.validate()(new FormControl("2334135314"))).toBeNull();
	});

	it('should error on an invalid number', () => {
		expect(NumberValidator.validate()(new FormControl("xe"))).toEqual({ numberFormat: Object({ value: 'xe' }) });
	});

	it('should not error on an valid large number', () => {
		expect(NumberValidator.validate()(new FormControl("2465364365645643"))).toBeNull();
	});

});
