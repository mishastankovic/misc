import { Observable, of } from "rxjs";
import { CanDeactivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from "@angular/router";
import { Injectable } from "@angular/core";
import { SpinnerService } from "sro-ngcomponent-library";

export interface CanNavigate {
	canNavigateAway: () => boolean;
}

@Injectable()
export class DeactivationGuard implements CanDeactivate<CanNavigate>{

	static readonly SUBMISSION_DEACTIVATION_MESSAGE = 'You have not downloaded the PDF document. Do you wish to leave this page?';

	constructor(private spinnerService: SpinnerService) { }

	canDeactivate(component: CanNavigate, currentRoute: ActivatedRouteSnapshot, currentState: RouterStateSnapshot, nextState?: RouterStateSnapshot):
		Observable<boolean> {

		if (nextState.url === '/identity') {
			let leavePage = component.canNavigateAway();
			if (leavePage)
				return of(true);
			else {
				let confirmed = confirm(DeactivationGuard.SUBMISSION_DEACTIVATION_MESSAGE);
				if (!confirmed)
					this.spinnerService.hideSpinner();
				return of(confirmed);
			}
		} else {
			return of(true);
		}
	}
}
