import { Error } from 'app/au/gov/vic/sro/autopay/model/error';

export class ErrorResponse {

	static readonly SERVICE_NOT_AVAILABLE_ERROR_TEXT = 'Service Not Available Error';

	constructor(
		public errors: Error[] = []
	) { }
}