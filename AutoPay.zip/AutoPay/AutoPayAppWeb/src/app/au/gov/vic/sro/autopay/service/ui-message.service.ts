import { Injectable } from '@angular/core';
@Injectable()
export class UIMessageService {

	private uiValidationMessages: Map<string, string>;

	constructor() {
		this.loadReferenceData();
	}

	loadReferenceData() {
		this.uiValidationMessages = new Map<string, string>();
		let messages = [
			['LOGIN_PASSWORD_MANDATORY', 'You must provide your password.'],
			['TIMED_OUT_LOG_IN_AGAIN', 'You have timed out. Please log in again'],
			['CUSTOMER_NUMBER_MANDATORY', 'You must provide your State Revenue Office customer number.'],
			['ACCEPT_DECLARATION_MANDATORY', 'You must accept the declaration to continue.'],
			['CONTACT_NAME_MANDATORY', 'You must provide a contact name.'],
			['CONTACT_NAME_MAXLENGTH', 'The name must not exceed 120 characters in length.'],
			['MOBILE_NUMBER_MAXLENGTH', 'Your mobile telephone number must not exceed 16 characters in length.'],
			['MOBILE_NUMBER_MANDATORY', 'You must provide a mobile number.'],
			['PHONE_NUMBER_MAXLENGTH', 'Your phone number must not exceed 16 characters in length.'],
			['EMAIL_ADDRESS_MANDATORY', 'You must provide an email address.'],
			['CONFIRM_EMAIL_ADDRESS_MANDATORY', 'You must confirm your email address.'],
			['EMAIL_ADDRESS_INVALID', 'This email address is invalid.'],
			['EMAIL_ADDRESS_MAXLENGTH', 'Your email address must not exceed 60 characters in length.'],
			['EMAIL_ADDRESS_MISMATCH', 'Your email addresses do not match.'],
			['MOBILE_OR_PHONE_NUMBER_MANDATORY', 'You must provide at least one phone number.'],
			['MOBILE_NUMBER_INVALID', 'This mobile number is invalid.'],
			['PHONE_NUMBER_INVALID', 'This phone number is invalid.'],
			['CUSTOMER_NUMBER_MAXLENGTH', 'Your customer number must not exceed 9 characters in length.'],
			['CUSTOMER_NUMBER_FORMAT', 'This customer number is invalid. Please check and re-enter.'],
			['ADDRESS_MANDATORY', 'You must provide an address.'],
			['ADDRESS_INVALID', 'You must provide a valid address.'],
			['ADDRESS_TYPE_MANDATORY', 'You must provide an address type.'],
			['ADDRESS_POSTAL_BOX_TYPE_MANDATORY', 'You must select a postal box type.'],
			['ADDRESS_POSTAL_BOX_NUMBER_MANDATORY', 'You must provide a postal box number.'],
			['ADDRESS_FLAT_UNIT_TYPE_MAXLENGTH', 'Flat/unit type is too long.'],
			['ADDRESS_FLAT_UNIT_NUMBER_MAXLENGTH', 'Flat/unit number is too long.'],
			['ADDRESS_FLOOR_LEVEL_TYPE_MAXLENGTH', 'Floor/level type is too long.'],
			['ADDRESS_FLOOR_LEVEL_NUMBER_MAXLENGTH', 'Floor/level number is too long.'],
			['ADDRESS_BUILDING_NAME_MAXLENGTH', 'Building name is too long.'],
			['ADDRESS_STREET_NUMBER_FROM_MANDATORY', 'You must provide a street number from.'],
			['ADDRESS_STREET_NUMBER_MAXLENGTH', 'Street number is too long.'],
			['ADDRESS_STREET_NUMBER_FROM_FORMAT', 'You must enter a valid street number from.'],
			['ADDRESS_STREET_NUMBER_TO_FORMAT', 'You must enter a valid street number to.'],
			['ADDRESS_LOT_NUMBER_MANDATORY', 'You must provide a lot number.'],
			['ADDRESS_LOT_NUMBER_MAXLENGTH', 'Lot number is too long.'],
			['ADDRESS_STREET_NAME_MANDATORY', 'You must provide a street name.'],
			['ADDRESS_STREET_NAME_MAXLENGTH', 'Street name is too long.'],
			['ADDRESS_STREET_TYPE_MANDATORY', 'You must select a street type.'],
			['ADDRESS_STREET_TYPE_MAXLENGTH', 'Street type is too long.'],
			['ADDRESS_STREET_SUFFIX_TYPE_MAXLENGTH', 'Street suffix type is too long.'],
			['ADDRESS_SUBURB_MANDATORY', 'You must provide a suburb.'],
			['ADDRESS_SUBURB_MAXLENGTH', 'Suburb is too long.'],
			['ADDRESS_POSTCODE_MANDATORY', 'You must provide a postcode.'],
			['ADDRESS_POSTCOE_MAXLENGTH', 'Postcode is too long.'],
			['ADDRESS_POSTCOE_INVALID', 'You must enter a valid postcode.'],
			['ADDRESS_STATE_MANDATORY', 'You must select a state.'],
			['ADDRESS_OVERSEAS_MANDATORY', 'You must provide an overseas address.'],
			['ADDRESS_COUNTRY_MANDATORY', 'You must select a country.'],
			['INTRUDER_LOCKOUT', 'Too many failed attempts. Your account is locked.'],
			['SERVER_ERROR', 'There was an error processing your request.'],
			['CARD_NUMBER_INVALID', 'This card number is invalid.'],
			['CARD_NUMBER_MANDATORY', 'You must provide a card number.'],
			['PAYMENT_METHOD_MANDATORY', 'You must provide a payment method.'],
		];

		for (let i = 0; i < messages.length; i++) {
			this.uiValidationMessages.set(messages[i][0], messages[i][1]);
		}
	}

	getMessage(key: string): string {
		return this.uiValidationMessages.get(key);
	}
}
