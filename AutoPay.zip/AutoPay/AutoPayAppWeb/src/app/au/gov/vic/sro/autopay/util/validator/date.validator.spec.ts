import { AbstractControl, FormControl } from '@angular/forms'

import { DateValidator } from './date.validator';

describe('DateValidator', () => {
	let validatorFn = new DateValidator();

	it('should create an instance', () => {
		const directive = new DateValidator();
		expect(directive).toBeTruthy();
	});

	it('should not error on an empty date', () => {
		expect(DateValidator.validateFormat()(new FormControl(''))).toBeNull();
	});

	it('should not error on an null date', () => {
		expect(DateValidator.validateFormat()(new FormControl(null))).toBeNull();
	});

	it('should not error on an undefined date', () => {
		expect(DateValidator.validateFormat()(new FormControl(null))).toBeNull();
	});

	it('should not error on an valid date', () => {
		expect(DateValidator.validateFormat()(new FormControl("11/11/1991"))).toBeNull();
	});

	it('should error on an invalid date 1', () => {
		expect(DateValidator.validateFormat()(new FormControl("11/11/2092"))).toEqual({ dateFormat: Object({ value: '11/11/2092' }) });
	});

	it('should error on an invalid date 2', () => {
		expect(DateValidator.validateFormat()(new FormControl("11/20/1990"))).toEqual({ dateFormat: Object({ value: '11/20/1990' }) });
	});

	it('should error on an invalid date 2', () => {
		expect(DateValidator.validateFormat()(new FormControl("dates"))).toEqual({ dateFormat: Object({ value: 'dates' }) });
	});

	it('should not error on an empty future date', () => {
		expect(DateValidator.validateNotFuture()(new FormControl(''))).toBeNull();
	});

	it('should not error on an null future date', () => {
		expect(DateValidator.validateNotFuture()(new FormControl(null))).toBeNull();
	});

	it('should not error on an undefined future date', () => {
		expect(DateValidator.validateNotFuture()(new FormControl(null))).toBeNull();
	});

	it('should not error on an valid future date', () => {
		expect(DateValidator.validateNotFuture()(new FormControl("11/20/3013"))).toBeNull();
	});

	it('should not error on an valid not future date', () => {
		expect(DateValidator.validateNotFuture()(new FormControl("11/11/1991"))).toBeNull();
	});

});
