const SESSION_KEY_CUSTOMER_ID = "customerId";
const SESSION_KEY_REVENUE_LINE = 'revenueLine';
const SESSION_KEY_ACCESS_TOKEN = 'accessToken';
