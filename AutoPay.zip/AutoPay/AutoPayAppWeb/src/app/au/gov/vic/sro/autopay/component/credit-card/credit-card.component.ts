import { Component, OnInit } from '@angular/core';
import { FormUtils } from 'app/au/gov/vic/sro/autopay/util/form-utils';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { AppService } from 'app/au/gov/vic/sro/autopay/service/app.service';
import { FormGroup } from '@angular/forms';
import { FormControl } from '@angular/forms';
import { Validators } from '@angular/forms';
import { CreditCardNumberValidator } from 'app/au/gov/vic/sro/autopay/util/validator/credit-card-number.validator';
import * as moment from 'moment';
import { CreditCardHolderNameValidator } from 'app/au/gov/vic/sro/autopay/util/validator/credit-card-holder-name.validator';
import { CreditCardSecurityCodeValidator } from 'app/au/gov/vic/sro/autopay/util/validator/credit-card-security-code.validator';

@Component({
	selector: 'app-credit-card',
	templateUrl: './credit-card.component.html',
	styleUrls: ['./credit-card.component.css']
})
export class CreditCardComponent implements OnInit {

	creditCardForm: FormGroup;
	cardNumber: FormControl;
	expiryDateMonth: FormControl;
	expiryDateYear: FormControl;
	cvn: FormControl;
	cardHolderName: FormControl;
	expiryDateYearOptions: { value: string, label: string }[];

	constructor(public appService: AppService, private formBuilder: FormBuilder, private router: Router, public formUtils: FormUtils) { }

	ngOnInit() {

		this.cardHolderName = this.formBuilder.control('', Validators.compose([Validators.required, CreditCardHolderNameValidator.validate()]));
		this.cardNumber = this.formBuilder.control('', Validators.compose([Validators.required, CreditCardNumberValidator.validate()]));
		this.expiryDateMonth = this.formBuilder.control('', Validators.compose([Validators.required]));
		this.expiryDateYear = this.formBuilder.control('', Validators.compose([Validators.required]));
		this.cvn = this.formBuilder.control('', Validators.compose([Validators.required, CreditCardSecurityCodeValidator.validate()]));

		this.creditCardForm = this.formBuilder.group({
			cardHolderName: this.cardHolderName,
			cardNumber: this.cardNumber,
			cvn: this.cvn,
			creditCardExpiryDate: this.formBuilder.group({
				expiryDateMonth: this.expiryDateMonth,
				expiryDateYear: this.expiryDateYear,
			})
		});
		this.expiryDateYearOptions = Array(20).fill(moment().year()).map((v, i) => {
			const year = String(v + i);
			return { value: year, label: year };
		});
	}

	onSubmit() {
		this.validateForm();
	}

	validateForm() {
		FormUtils.validate(this.creditCardForm);
		this.creditCardForm.updateValueAndValidity();
		if (!this.creditCardForm.valid) FormUtils.focusError(document);
	}

}
