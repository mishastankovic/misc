import { AbstractControl } from "@angular/forms";
import { ValidatorFn } from "@angular/forms";

export class CreditCardHolderNameValidator {

	static validate(): ValidatorFn {
		let patternMin4Chars = /^.{4,}$/;
		let patternContainsOnlyNumbersSpacesHyphen = /^[0-9\-\s]*$/;

		return (control: AbstractControl): { [key: string]: any } => {
			let valid = true;
			if (control && control.value) {
				valid = patternMin4Chars.test(String(control.value).trim()) &&
					!patternContainsOnlyNumbersSpacesHyphen.test(control.value);
			}
			return valid ? null : { 'invalidFormat': { value: control.value } };
		};
	}

} 