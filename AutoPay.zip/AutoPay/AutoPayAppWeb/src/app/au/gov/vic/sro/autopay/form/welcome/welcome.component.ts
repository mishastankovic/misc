import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TabsetComponent } from "sro-ngcomponent-library/lib/tabs/tabset.component";

@Component({
	selector: 'ap-welcome',
	templateUrl: './welcome.component.html'
})
export class WelcomeComponent implements OnInit {

	constructor(private router: Router) { }

	ngOnInit() {
	}

}
