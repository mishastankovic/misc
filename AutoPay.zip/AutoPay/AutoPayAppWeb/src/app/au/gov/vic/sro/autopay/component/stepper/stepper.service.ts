import { Injectable } from "@angular/core";
import { Subject } from "rxjs";

import { StepperState } from "app/au/gov/vic/sro/autopay/component/stepper/stepper-state";

@Injectable()
export class StepperService {

	private stepperSubject = new Subject<StepperState>();

	stepperState = this.stepperSubject.asObservable();

	constructor() { }

	updateStepper(currentPage: string) {
		this.stepperSubject.next(<StepperState>{ page: currentPage });
	}
}