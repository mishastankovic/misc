import { TestBed, inject } from '@angular/core/testing';
import { Injectable, Injector } from '@angular/core';

import { LoginService } from './login.service';
import {HttpClient} from "@angular/common/http";

class MockHttp {
	post() {

	}
}
const mockHttp = new MockHttp();

describe('LoginService', () => {
	beforeEach(() => {

		TestBed.configureTestingModule({
			providers: [LoginService, { provide: HttpClient, useValue: mockHttp }]
		});
	});

	fit('should be created', inject([LoginService], (service: LoginService) => {
		expect(service).toBeTruthy();
	}));

	fit('token should be valid after creation', inject([LoginService], (service: LoginService) => {
		let token = { access_token: 'TOK1', expires_in: 3600 };
		service.saveToken(token);
		let accessToken = sessionStorage.getItem('access_token');
		let expireDateString = sessionStorage.getItem('access_token_expires');
		console.log(`accessToken=${accessToken}; expireDateString=${expireDateString}`);

		expect(service.hasValidToken()).toBeTruthy();
	}));

	fit('session storage should contain token after creation', inject([LoginService], (service: LoginService) => {
		let token = { access_token: 'TOK1', expires_in: 3600 };
		service.saveToken(token);
		let accessToken = sessionStorage.getItem('access_token');
		let expireDateString = sessionStorage.getItem('access_token_expires');
		console.log(`accessToken=${accessToken}; expireDateString=${expireDateString}`);

		expect(accessToken).toEqual('TOK1');
		//		expect(expireDateString).toEqual('expireDateString');
	}));



});
