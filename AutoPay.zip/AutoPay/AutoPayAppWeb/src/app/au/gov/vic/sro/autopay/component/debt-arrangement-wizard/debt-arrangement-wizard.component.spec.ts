import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DebtArrangementWizardComponent } from './debt-arrangement-wizard.component';

describe('DebtArrangementWizardComponent', () => {
  let component: DebtArrangementWizardComponent;
  let fixture: ComponentFixture<DebtArrangementWizardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DebtArrangementWizardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DebtArrangementWizardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
