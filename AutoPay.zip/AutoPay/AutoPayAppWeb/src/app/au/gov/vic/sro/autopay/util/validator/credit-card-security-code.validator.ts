import { AbstractControl, ValidatorFn } from '@angular/forms';

export class CreditCardSecurityCodeValidator {

	static validate(): ValidatorFn {
		var pattern = /^[0-9]{3}$/;

		return (control: AbstractControl): { [key: string]: any } => {
			let valid = true;
			if (control && control.value) {
				valid = pattern.test(control.value);
			}
			return valid ? null : { 'invalidFormat': { value: control.value } };
		};
	}

} 