import { Component, OnInit } from '@angular/core';
import { ReferenceDataService } from 'app/au/gov/vic/sro/autopay/service/reference-data.service';
import { AppService } from 'app/au/gov/vic/sro/autopay/service/app.service';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { FormUtils } from 'app/au/gov/vic/sro/autopay/util/form-utils';
import { UIMessageService } from 'app/au/gov/vic/sro/autopay/service/ui-message.service';
import { FormGroup } from '@angular/forms';
import { FormControl } from '@angular/forms';
import { Validators } from '@angular/forms';
import { ReferenceData } from 'app/au/gov/vic/sro/autopay/model/reference-data';

@Component({
	selector: 'app-instalment-details',
	templateUrl: './instalment-details.component.html',
	styleUrls: ['./instalment-details.component.scss']
})
export class InstalmentDetailsComponent implements OnInit {

	instalmentDetailsFormGroup: FormGroup;

	instalmentFrequency: FormControl;
	firstInstalmentDate: FormControl;
	lastInstalmentDate: FormControl;
	paymentMethod: FormControl;
	referenceData: ReferenceData[];
	constructor(public appService: AppService, private formBuilder: FormBuilder, private router: Router, public referenceDataService: ReferenceDataService,
		public formUtils: FormUtils, public uiMessageService: UIMessageService) { }

	ngOnInit() {
		this.referenceData = this.referenceDataService.getReferenceData();

		this.instalmentFrequency = this.formBuilder.control('', Validators.compose([Validators.required]));
		this.paymentMethod = this.formBuilder.control('', Validators.compose([Validators.required]));

		this.instalmentDetailsFormGroup = this.formBuilder.group({
			instalmentFrequency: this.instalmentFrequency,
			paymentMethod: this.paymentMethod
		});

		//FormUtils.validate(this.instalmentDetailsFormGroup);
	}

	getInstalmentFrequencies(): string {
		return ReferenceDataService.INSTALMENT_FREQUENCY;
	}

	getPaymentMethods(): string {
		return ReferenceDataService.PAYMENT_METHOD;
	}
	onSubmit() {

  }
}
