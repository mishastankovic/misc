import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateArrangementWizardComponent } from './create-arrangement-wizard.component';

describe('CreateArrangementWizardComponent', () => {
  let component: CreateArrangementWizardComponent;
  let fixture: ComponentFixture<CreateArrangementWizardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateArrangementWizardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateArrangementWizardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
