import { ErrorHandler, Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { environment } from 'environments/environment';
import {HttpClient, HttpHeaders} from "@angular/common/http";

@Injectable()
export class ErrorHandlerService {

	private baseServiceUrl: string = '';

	constructor(private http: HttpClient) {
		this.baseServiceUrl = environment.serviceHostname + "/autopayservice/";
	}

	logErrorsToFile(errorMessage: URLSearchParams) {
		const path: string = "jserror";
		console.log("POST URL: " + this.baseServiceUrl + path);
		return this.http.post(this.baseServiceUrl + path, errorMessage.toString(), { headers: this.getHeaders() });
	}

	private getHeaders(): HttpHeaders {
		let headers = new HttpHeaders();
		headers.append('Accept', 'application/json');
		headers.append('Content-Type', 'application/x-www-form-urlencoded');
		return headers;
	}
}
