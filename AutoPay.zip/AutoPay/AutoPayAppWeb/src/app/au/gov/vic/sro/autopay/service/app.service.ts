import { Injectable } from '@angular/core';

import { environment } from 'environments/environment';
import { Observable, Subject } from "rxjs";
import { CustomerIdentity } from 'app/au/gov/vic/sro/autopay/model/customer-identity';

import { AuthenticationService } from 'app/au/gov/vic/sro/autopay/service/authentication.service';
import { RecaptchaService } from 'app/au/gov/vic/sro/autopay/service/recaptcha.service';

import { MapperUtils } from 'app/au/gov/vic/sro/autopay/util/mapper-utils';
import {HttpClient, HttpHeaders} from "@angular/common/http";

@Injectable()
export class AppService {
	private customerIdentity: CustomerIdentity;
	private baseServiceUrl: string = '';
	private validUser: boolean = false;


	constructor(private http: HttpClient) {
		this.baseServiceUrl = environment.serviceHostname + "/autopayservice/";
		this.initialize();
	}

	initialize() {
		this.customerIdentity = CustomerIdentity.createCustomerIdentity();
	}

	resetApplication() {
		this.initialize();
	}

	getCustomerIdentity(): CustomerIdentity {
		return this.customerIdentity;
	}

	setCustomerIdentity(customerIdentity: CustomerIdentity) {
		this.customerIdentity = customerIdentity;
	}

	setValidUser(validUser: boolean) {
		this.validUser = validUser;
	}

	isValidUser(): boolean {
		return this.validUser === true;
	}

	// REST Service calls
	authenticate(customerIdentity: CustomerIdentity): Observable<string[]> {
		return new AuthenticationService(this.http).authenticate(this.baseServiceUrl, this.getHeaders(), customerIdentity);
	}

	verifyRecaptcha(captchaResponse: string): Observable<string[]> {
		return new RecaptchaService(this.http).verify(this.baseServiceUrl, this.getHeaders(), captchaResponse);
	}

	private getHeaders(): HttpHeaders {
		let headers = new HttpHeaders();
		headers.append('Accept', 'application/json');
		headers.append('Content-Type', 'application/json');
		return headers;
	}
}
