import { AbstractControl, ValidatorFn } from '@angular/forms';

export class CreditCardNumberValidator {

	static validate(): ValidatorFn {
		let pattern = /^[0-9]{4}[- ]{0,1}[0-9]{4}[- ]{0,1}[0-9]{4}[- ]{0,1}[0-9]{4}$/;

		return (control: AbstractControl): { [key: string]: any } => {
			let valid = true;
			if (control && control.value) {
				valid = pattern.test(control.value);
			}
			return valid ? null : { 'invalidFormat': { value: control.value } };
		};
	}

} 