import { ReferenceDataPipe } from './reference-data.pipe';

import { ReferenceData } from 'app/au/gov/vic/sro/autopay/model/reference-data';
import { REFERENCE_DATA } from 'app/au/gov/vic/sro/autopay/model/reference-data-mock';

describe('ReferenceDataPipe', () => {
	let pipe: ReferenceDataPipe;
	const referenceData: ReferenceData[] = REFERENCE_DATA;

	beforeEach(() => {
		pipe = new ReferenceDataPipe();
	})

	it('create an instance', () => {
		expect(pipe).toBeTruthy();
	});

	it('transform type does not exist in reference data list', () => {
		let type: string = 'NONEXISTENTTYPE';

		const refData: ReferenceData[] = pipe.transform(referenceData, type);
		expect(refData.length).toEqual(0);
	});

	it('transform type exists in reference data list', () => {
		let type: string = 'ADDRESS_TYPES';

		const refData: ReferenceData[] = pipe.transform(referenceData, type);
		expect(refData.length).toEqual(4);
		expect(refData[0]).toEqual(new ReferenceData('ADDRESS_TYPES', 'B', 'Street'));
		expect(refData[1]).toEqual(new ReferenceData('ADDRESS_TYPES', 'L', 'Lot'));
		expect(refData[2]).toEqual(new ReferenceData('ADDRESS_TYPES', 'P', 'Postal'));
	});

	it('transform empty reference data list', () => {
		let type: string = 'TYPE1';

		const refData: ReferenceData[] = pipe.transform([], type);
		expect(refData.length).toEqual(0);
	});
});