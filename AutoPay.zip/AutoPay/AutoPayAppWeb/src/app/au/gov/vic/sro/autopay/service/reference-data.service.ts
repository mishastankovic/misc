import { Injectable } from "@angular/core";


import { map, first } from 'rxjs/operators';
import { environment } from 'environments/environment';
import { REFERENCE_DATA } from 'app/au/gov/vic/sro/autopay/model/reference-data-mock';
import { ReferenceData } from 'app/au/gov/vic/sro/autopay/model/reference-data';
import { HttpClient } from "@angular/common/http";


@Injectable()
export class ReferenceDataService {

	// fixed reference data
	static readonly ADDRESS_TYPES = 'ADDRESS_TYPES';
	static readonly COMMUNICATION_CHANNELS = 'COMMUNICATION_CHANNELS';
	static readonly COMMUNICATION_RECIPIENTS = 'COMMUNICATION_RECIPIENTS';
	static readonly COMPLETION_TYPES = 'COMPLETION_TYPES';
	static readonly EXEMPTION_TYPES = 'EXEMPTION_TYPES';
	static readonly LAND_OWNER_TYPES = 'LAND_OWNER_TYPES';
	static readonly NON_POSTAL_ADDRESS_TYPES = 'NON_POSTAL_ADDRESS_TYPES';
	static readonly NOTIFICATION_TYPES = 'NOTIFICATION_TYPES';
	static readonly PROPERTY_OWNERSHIP_TYPES = 'PROPERTY_OWNERSHIP_TYPES';
	static readonly TRUSTEE_TYPES = 'TRUSTEE_TYPES';
	static readonly CUSTOMER_IDENTIFIERS = 'CUSTOMER_IDENTIFIERS';

	static readonly COUNTRIES = 'Countries';
	static readonly FLAT_UNIT_TYPES = 'FlatUnitTypes';
	static readonly FLOOR_LEVEL_TYPES = 'FloorLevelTypes';
	static readonly POSTAL_BOX_TYPES = 'PostalBoxTypes';
	static readonly STATES = 'States';
	static readonly STREET_SUFFIXES = 'StreetSuffixes';
	static readonly STREET_TYPES = 'StreetTypes';
	static readonly TRUST_TYPES = 'TrustTypes';

	//AutoPay ref data

	static readonly COMMUNICATION_PERSON = 'COMMUNICATION_PERSON';
	static readonly REVENUE_TYPES = 'REVENUE_TYPES';
	static readonly INSTALMENT_FREQUENCY = 'INSTALMENT_FREQUENCY';
	static readonly PAYMENT_METHOD = 'PAYMENT_METHOD';

	private referenceData: ReferenceData[];
	private baseServiceUrl: string = '';

	constructor(private http: HttpClient) {
		this.referenceData = REFERENCE_DATA;
		this.baseServiceUrl = environment.serviceHostname + "/autopayservice/";
	}

	loadReferenceData() {
		const path: string = "referencedata";
		console.log("Base URL: " + this.baseServiceUrl);
		this.http
			.get(this.baseServiceUrl + path)
			.pipe(map(response => response))
			.subscribe((data: any[]) => {
				let result = [];
				if (data) {
					data.forEach(item => (
						result.push(new ReferenceData(item.type, item.code, item.description, item.shortLabel)))
					);
				}
				this.referenceData = result;
			},
			error => {
				this.loadStaticReferenceData();
			},
			() => { });
	}

	loadStaticReferenceData() {
		this.http
			.get('assets/data/reference-data.json')
			.pipe(
			map(response => {
				return response;
			}),
			map((items: ReferenceData[]) => {
				let result: ReferenceData[] = [];
				if (items) {
					items.forEach(item => result.push(new ReferenceData(item.type, item.code, item.label, item.shortLabel)));
				}
				return result;
			}))
			.subscribe(data => {
				if (data && data.length > 0) this.referenceData = data;
			},
			error => { },
			() => { });
	}

	getReferenceData(): ReferenceData[] {
		return this.referenceData;
	}
}
