import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ap-debt-arrangement-wizard',
  templateUrl: './debt-arrangement-wizard.component.html',
  styleUrls: ['./debt-arrangement-wizard.component.scss']
})
export class DebtArrangementWizardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
