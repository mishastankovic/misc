import { Injectable, Inject } from '@angular/core';
import { TRANSLATIONS } from 'app/au/gov/vic/sro/autopay/component/translate/translation'

@Injectable()
export class TranslateService {

	// inject our translations
	constructor( @Inject(TRANSLATIONS) private _translations: any) {
	}

	public translate(key: string): string {
		let value = this._translations['resources'][key];
		if (this._translations && value) {
			return value;
		}

		return key;
	}
}