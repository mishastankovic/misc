import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CancelArrangementComponent } from './cancel-arrangement.component';

describe('CancelArrangementComponent', () => {
  let component: CancelArrangementComponent;
  let fixture: ComponentFixture<CancelArrangementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CancelArrangementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CancelArrangementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
