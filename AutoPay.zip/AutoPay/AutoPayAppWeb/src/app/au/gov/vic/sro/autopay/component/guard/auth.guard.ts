import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { AppService } from 'app/au/gov/vic/sro/autopay/service/app.service';
import { Observable, of } from 'rxjs';

@Injectable()
export class AuthGuard implements CanActivate {

	constructor(private appService: AppService, private router: Router) { }

	canActivate(): Observable<boolean> {
		return this.isAllowedAccess();
	}

	private isAllowedAccess() {
		if (!this.appService.isValidUser()) {
			this.router.navigate(['/identity']);
			return of(false);
		} else {
			return of(true);
		}
	}
}