import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';

import { IDENTITY_PAGE, WELCOME_PAGE, CONTACT_PAGE } from 'app/app.router';

import { StepperService } from 'app/au/gov/vic/sro/autopay/component/stepper/stepper.service';
import { StepperState } from 'app/au/gov/vic/sro/autopay/component/stepper/stepper-state';

import { AppService } from 'app/au/gov/vic/sro/autopay/service/app.service';

const DONE = 'done';
const PENDING = 'pending';
const CURRENT = 'current';

@Component({
	selector: 'app-stepper',
	templateUrl: './stepper.component.html'
})
export class StepperComponent implements OnInit {

	currentStep: string;

	steps = [
		{ page: IDENTITY_PAGE, label: 'Login', state: PENDING, path: "/identity", optional: false },
		{ page: WELCOME_PAGE, label: 'Welcome', state: PENDING, path: "/welcome", optional: false },
		{ page: CONTACT_PAGE, label: 'Contact details', state: PENDING, path: "/contact", optional: false },
	];

	private stepsClone = [];


	private subscription: Subscription;

	constructor(public appService: AppService, private stepperService: StepperService, private router: Router) { }

	ngOnInit() {
		this.stepsClone = Object.assign([], this.steps);
		this.subscription = this.stepperService.stepperState
			.subscribe((state: StepperState) => {
				this.updateStep(state);
			});
	}

	onClick(i: number) {
		this.router.navigate([this.steps[i].path]);
	}

	updateStep(stepperState: StepperState) {
		this.currentStep = stepperState.page;

		const currentStepIndex: number = this.steps.map(function (data) { return data['page']; }).indexOf(this.currentStep);
		this.steps.forEach((step, index) => {
			if (index < currentStepIndex) {
				this.steps[index].state = DONE;
			} else if (index === currentStepIndex) {
				this.steps[index].state = CURRENT;
			} else {
				this.steps[index].state = PENDING;
			}
		})
	}

	getStateStatus(index, currentStateIndex) {
		let status = CURRENT;
		const step = this.steps[index];

		if (currentStateIndex < index) {
			status = PENDING;
		} else if (currentStateIndex > index) {
			status = DONE;
		}

		return status;
	}

	getStepperClass(status: string): string {
		if (status === 'done') {
			return "active-step step-done"
		} else if (status === 'current') {
			return "active-step active-editable"
		}
	}


}
