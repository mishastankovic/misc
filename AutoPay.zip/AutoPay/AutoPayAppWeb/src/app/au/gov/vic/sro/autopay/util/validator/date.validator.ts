import { AbstractControl, ValidatorFn } from '@angular/forms';
import { DateUtils } from 'app/au/gov/vic/sro/autopay/util/date-utils';

export class DateValidator {

	static validateFormat(): ValidatorFn {
		return (control: AbstractControl): { [key: string]: any } => {
			let dateOfBirth;
			if (control && control.value) {
				dateOfBirth = DateUtils.getDateFromInput(control.value);
			}
			return (control && control.value && dateOfBirth == null) ? { 'dateFormat': { value: control.value } } : null;
		};
	}

	static validateNotFuture(): ValidatorFn {
		return (control: AbstractControl): { [key: string]: any } => {
			let invalid = false;
			let today = new Date();
			let controlDate = null;
			if (control && control.value) {
				if (typeof control.value === "string") {
					controlDate = DateUtils.getDateFromInput(control.value);
				} else {
					controlDate = control.value;
				}

				if (controlDate && controlDate.getTime() > today.getTime()) {
					invalid = true;
				}

			}

			return invalid ? { 'dateFuture': { value: control.value } } : null;
		};
	}
} 