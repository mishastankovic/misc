export class RecaptchaResponse {
	public verifyRecaptcha: boolean = false

	constructor(

	) { }
}