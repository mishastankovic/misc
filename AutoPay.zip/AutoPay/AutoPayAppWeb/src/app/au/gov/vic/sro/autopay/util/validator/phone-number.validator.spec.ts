import { AbstractControl, FormControl } from '@angular/forms'

import { PhoneNumberValidator } from './phone-number.validator';

describe('PhoneNumberValidator', () => {
	let validatorFn = new PhoneNumberValidator();

	it('should create an instance', () => {
		const directive = new PhoneNumberValidator();
		expect(directive).toBeTruthy();
	});

	it('should not error on an empty phonenumber', () => {
		expect(PhoneNumberValidator.validate()(new FormControl(''))).toBeNull();
	});

	it('should not error on an null phonenumber', () => {
		expect(PhoneNumberValidator.validate()(new FormControl(null))).toBeNull();
	});

	it('should not error on an undefined phonenumber', () => {
		expect(PhoneNumberValidator.validate()(new FormControl(null))).toBeNull();
	});

	it('should not error on an valid mobile phonenumber', () => {
		expect(PhoneNumberValidator.validate()(new FormControl("0452741974"))).toBeNull();
	});

	it('should not error on an valid landline phonenumber', () => {
		expect(PhoneNumberValidator.validate()(new FormControl("96289365"))).toBeNull();
	});

	it('should not error on an valid phonenumber with state codes', () => {
		expect(PhoneNumberValidator.validate()(new FormControl("(03)49531351"))).toBeNull();
	});

	it('should not error on an valid international phonenumber format 1', () => {
		expect(PhoneNumberValidator.validate()(new FormControl("+61412531987"))).toBeNull();
	});

	it('should not error on an valid international phonenumber format 2', () => {
		expect(PhoneNumberValidator.validate()(new FormControl("(61) 412531987"))).toBeNull();
	});

	it('should error on an invalid phonenumber', () => {
		expect(PhoneNumberValidator.validate()(new FormControl("xe"))).toEqual({ phoneNumberFormat: Object({ value: 'xe' }) });
	});

	it('should error on an invalid international phonenumber', () => {
		expect(PhoneNumberValidator.validate()(new FormControl("+(aus) 342454252"))).toEqual({ phoneNumberFormat: Object({ value: '+(aus) 342454252' }) });
	});

});
