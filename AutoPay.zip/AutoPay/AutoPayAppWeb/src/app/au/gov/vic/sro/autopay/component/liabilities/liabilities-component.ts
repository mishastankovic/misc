import { Component, OnInit } from '@angular/core';
import { LiabilityService } from "./liability-service";
import { Liability } from "../../model/liability";

@Component({
	selector: 'ap-liabilities',
	templateUrl: './liabilities-component.html',
	styleUrls: ['./liabilities-component.scss']
})
export class LiabilitiesComponent implements OnInit {

	static today: Date = new Date();

	constructor(private liabilityService: LiabilityService) {
	}

	ngOnInit() {
		this.liabilityService.getAllCustomerLiabilities();
	}

	overdueLiabilities(): Liability[] {
		return this.liabilityService.getOverdueLiabilities();
	}

	otherLiabilities(): Liability[] {
		return this.liabilityService.getNonOverdueLiabilities();
	}

}
