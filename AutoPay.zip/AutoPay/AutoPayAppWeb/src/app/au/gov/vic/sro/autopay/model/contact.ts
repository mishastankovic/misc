export interface Contact {
	preferredContactPerson?: 'CUSTOMER' | 'CUSTOMER_REP';
	contactName: string;
	emailAddress: string;
	mobilePhoneNumber?: string;
	emailReminders?: boolean
}
