import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { ContactDetailsComponent } from './contact-details.component';
import { ReferenceDataPipe } from 'app/au/gov/vic/sro/autopay/component/pipe/reference-data.pipe';
import { ReferenceDataService } from 'app/au/gov/vic/sro/autopay/service/reference-data.service';
import { TranslatePipe } from 'app/au/gov/vic/sro/autopay/component/translate/translate.pipe';
import { AppService } from 'app/au/gov/vic/sro/autopay/service/app.service';
import { HttpModule } from '@angular/http';
import { Router } from '@angular/router';
import { FormUtils } from 'app/au/gov/vic/sro/autopay/util/form-utils';
import { UIMessageService } from 'app/au/gov/vic/sro/autopay/service/ui-message.service';
import { TranslateService } from 'app/au/gov/vic/sro/autopay/component/translate/translate.service';
import { TranslationProvider } from 'app/au/gov/vic/sro/autopay/component/translate/translation';

describe('ContactDetailsComponent', () => {
	let component: ContactDetailsComponent;
	let fixture: ComponentFixture<ContactDetailsComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [ReactiveFormsModule, HttpModule],
			declarations: [ContactDetailsComponent, ReferenceDataPipe, TranslatePipe],
			providers: [AppService, ReferenceDataService, FormUtils, UIMessageService, TranslationProvider, TranslateService, { provide: Router, useClass: RouterStub }]
		})
			.compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(ContactDetailsComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should be created', () => {
		expect(component).toBeTruthy();
	});
});

class RouterStub {
	navigate(obj: any) {
		return obj;
	}
}
