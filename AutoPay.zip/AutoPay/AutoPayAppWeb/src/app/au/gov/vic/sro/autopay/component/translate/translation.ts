import { MESSAGE_RESOURCES } from './message-resources';
import { InjectionToken } from '@angular/core';

export const TRANSLATIONS = new InjectionToken('translations');

const messages = {
	'resources': MESSAGE_RESOURCES,
};

export const TranslationProvider = [
	{ provide: TRANSLATIONS, useValue: messages },
];