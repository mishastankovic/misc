import { AbstractControl, ValidatorFn } from '@angular/forms';

export class CompanyNumberUtils {

	static isValidAbn(abn: string): boolean {
		if (!abn || abn === '') return true;

		let isValid = false;

		const WEIGHTING_FACTORS: number[] = [10, 1, 3, 5, 7, 9, 11, 13, 15, 17, 19];
		const ABN_PATTERN: string = "[0-9]{11}";

		if (abn.match(ABN_PATTERN)) {
			let weightedSum: number = 0;

			for (let i: number = 0; i < abn.length; i++) {
				let currentDigit: number = parseInt(abn[i], 10);
				if (i === 0) {
					currentDigit = Math.abs(currentDigit - 1);
				}
				let weightedDigit = currentDigit * WEIGHTING_FACTORS[i];
				weightedSum += weightedDigit;
			}

			let remainder: number = weightedSum % 89;
			isValid = (remainder === 0);
		}

		return isValid;
	}

	static isValidAcn(acn: string): boolean {
		if (!acn || acn === '') return true;

		let isValid = false;

		const ACN_PATTERN: string = "[0-9]{9}";
		const ACN_LENGTH: number = 9;

		if (acn.match(ACN_PATTERN)) {
			let cumulativeTotal: number = 0;

			let maxIndex: number = ACN_LENGTH - 1;
			for (let i = 0; i < maxIndex; i++) {
				const currentDigit: number = parseInt(acn.substring(i, i + 1));
				const multiplier: number = maxIndex - i;
				cumulativeTotal += currentDigit * multiplier;
			}
			const remainder: number = cumulativeTotal % 10;
			// Cater for case where remainder = 0
			const complementRemainder: number = (10 - remainder) % 10;
			const checkDigit: number = parseInt(acn.substring(ACN_LENGTH - 1));

			isValid = checkDigit == complementRemainder;
		}

		return isValid;
	}
}