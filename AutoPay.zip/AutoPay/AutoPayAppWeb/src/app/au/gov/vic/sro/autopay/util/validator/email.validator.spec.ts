
import { AbstractControl, FormControl } from '@angular/forms'

import { EmailValidator } from './email.validator';


describe('EmailValidator', () => {
	let validatorFn;

	beforeEach(() => {
		validatorFn = EmailValidator.validate();
	});

	it('should create an instance', () => {
		const directive = new EmailValidator();
		expect(directive).toBeTruthy();
	});

	it('should not error on an empty email', () => {
		expect(EmailValidator.validate()(new FormControl(''))).toBeNull();
	});

	it('should not error on an null email', () => {
		expect(EmailValidator.validate()(new FormControl(null))).toBeNull();
	});

	it('should not error on an undefined email', () => {
		expect(EmailValidator.validate()(new FormControl(null))).toBeNull();
	});

	it('should not error on an valid email', () => {
		expect(EmailValidator.validate()(new FormControl("test@test.com"))).toBeNull();
	});

	it('should error on an invalid email', () => {
		let valueToTest = 'testtest.com';
		let formControl: FormControl = new FormControl(valueToTest);
		let result = validatorFn(formControl);
		expect(result).toBeDefined();
		let resultStr = result['emailAddressFormat']['value'] as string;
		expect(resultStr).toBe(valueToTest);
	});

	it('should error on an invalid email with invalid charactors', () => {
		let valueToTest = '2####@.com';
		let formControl: FormControl = new FormControl(valueToTest);
		let result = validatorFn(formControl);
		expect(result).toBeDefined();
		let resultStr = result['emailAddressFormat']['value'] as string;
		expect(resultStr).toBe(valueToTest);
	});

});
