import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpModule } from '@angular/http';
import { StepperComponent } from './stepper.component';
import { AppService } from 'app/au/gov/vic/sro/autopay/service/app.service';
import { RouterTestingModule } from '@angular/router/testing';
import { StepperService } from 'app/au/gov/vic/sro/autopay/component/stepper/stepper.service';
import { Router } from '@angular/router';


describe('StepperComponent', () => {
	let component: StepperComponent;
	let fixture: ComponentFixture<StepperComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [RouterTestingModule, HttpModule],
			declarations: [StepperComponent],
			providers: [AppService, StepperService, { provide: Router, useClass: RouterStub }]
		})
			.compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(StepperComponent);
		component = fixture.componentInstance;
	});

	it('should be created', () => {
		expect(component).toBeTruthy();
	});

	it('should be getting stepper class when status is done', () => {
		expect(component.getStepperClass('done')).toEqual('active-step step-done');
	});

	it('should be getting stepper class when status is current', () => {
		expect(component.getStepperClass('current')).toEqual('active-step active-editable');
	});

	it('should be getting pending status when current status less than index', () => {
		expect(component.getStateStatus(3, 1)).toEqual('pending');
	});

	it('should be getting done status when current status larger than index', () => {
		expect(component.getStateStatus(1, 5)).toEqual('done');
	});

	it('should be getting current status when current status equal to index', () => {
		expect(component.getStateStatus(2, 2)).toEqual('current');
	});

});

class RouterStub {
	navigate(obj: any) {
		return obj;
	}
}
