
import { Observable } from "rxjs";
import { map } from 'rxjs/operators';
import {HttpClient, HttpHeaders} from "@angular/common/http";

export class RecaptchaService {


	constructor(private http: HttpClient) {
	}

	verify(baseUrl: String, httpHeaders: HttpHeaders, gRecaptchaResponse: string): Observable<string[]> {
		const path: string = "recaptcha/verify";
		console.log("POST:" + baseUrl + path);
		return <Observable<string[]>>this.http.post(baseUrl + path, gRecaptchaResponse, { headers: httpHeaders });
	}
}
