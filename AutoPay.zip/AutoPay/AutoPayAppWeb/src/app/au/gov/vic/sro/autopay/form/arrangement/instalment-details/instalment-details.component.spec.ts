import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InstalmentDetailsComponent } from './instalment-details.component';

describe('InstalmentDetailsComponent', () => {
	let component: InstalmentDetailsComponent;
	let fixture: ComponentFixture<InstalmentDetailsComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [InstalmentDetailsComponent]
		})
			.compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(InstalmentDetailsComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
