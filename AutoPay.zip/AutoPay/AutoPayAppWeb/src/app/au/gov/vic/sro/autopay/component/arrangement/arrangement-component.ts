import { Component, OnInit } from '@angular/core';
import {ArrangementService} from "./arrangement-service";
import {Arrangement} from "../../model/arrangement";

@Component({
  selector: 'ap-arrangements',
  templateUrl: './arrangement-component.html',
  styleUrls: ['./arrangement-component.scss']
})
export class ArrangementComponent implements OnInit {

  arrangements: Arrangement[];

  constructor(private arrangementsService: ArrangementService) {
  }

  ngOnInit() {
    this.getCustomerArrangements();
  }

  getCustomerArrangements() {
    this.arrangementsService.getCustomerArrangements()
      .subscribe( data => {
        this.arrangements = data;
      });
  }

}
