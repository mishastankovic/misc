import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders, HttpResponse} from '@angular/common/http';
import {CustomerIdentity} from 'app/au/gov/vic/sro/autopay/model/customer-identity';
import {environment} from 'environments/environment';
import {Observable } from "rxjs";
import {JwtHelperService} from '@auth0/angular-jwt';


@Injectable()
export class LoginService {

  static SESSION_KEY_CUSTOMER_ID: string = "customerId";
  static SESSION_KEY_REVENUE_LINE: string = 'revenueLine';
  static SESSION_KEY_ACCESS_TOKEN: string = 'accessToken';
  static SESSION_KEY_ASSESSMENT_ID: string = 'assessmentId';
  static SESSION_KEY_USERNAME: string = "username";

  jwtHelper: JwtHelperService;

  constructor(private _http: HttpClient) {
    this.jwtHelper = new JwtHelperService();
  }

  login(loginData: CustomerIdentity): Observable<HttpResponse<any>> {
    let params = new URLSearchParams();

    sessionStorage.setItem( LoginService.SESSION_KEY_ASSESSMENT_ID, loginData.assessmentId);
    let headers = new HttpHeaders({'Content-Type': 'application/json', 'Accept': 'application/json'} );
    let options = {headers: headers};
    return <Observable<HttpResponse<any>>>this._http.post(environment.loginServicePath,
      {"customerId": loginData.customerId, "revenueLine": loginData.revenueLine, "liabilityId": loginData.assessmentId }, options);
  }

  getToken(): string {
    return sessionStorage.getItem('accessToken');
  }

  hasValidToken(): boolean {
    const accessToken = sessionStorage.getItem(LoginService.SESSION_KEY_ACCESS_TOKEN);
    return accessToken && !this.jwtHelper.isTokenExpired(accessToken);
  }

  /**
   * Clears customer login information from the session storage. This function is called
   * when the user clicks on the Logout button.
   */
  logout() {
    sessionStorage.removeItem(LoginService.SESSION_KEY_ACCESS_TOKEN);
    sessionStorage.removeItem(LoginService.SESSION_KEY_CUSTOMER_ID);
    sessionStorage.removeItem(LoginService.SESSION_KEY_REVENUE_LINE);
  }

  saveToken(token) {
    const decodedToken: any = this.jwtHelper.decodeToken(token);
    decodedToken.token = token;
    sessionStorage.setItem("customerId", decodedToken.customerId);
    sessionStorage.setItem('revenueLine', decodedToken.revenueLine);
    sessionStorage.setItem('accessToken', token);
  }

}
