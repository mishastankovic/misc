import { ErrorHandler, Injectable } from "@angular/core";
import { ErrorHandlerService } from 'app/au/gov/vic/sro/autopay/service/error-handler.service';

@Injectable()
export class AppErrorHandler extends ErrorHandler {

	constructor(private errorHandlerService: ErrorHandlerService) {
		super();
	}

	handleError(error: any): void {

		var errorStack = error.stack;
		var errorLocation = window.location.href;

		let errorMessage = new URLSearchParams();
		errorMessage.set('msg', errorStack);
		errorMessage.set('pageurl', errorLocation);

		this.errorHandlerService.logErrorsToFile(errorMessage).subscribe(
			(response) => console.log(response),
			(error) => console.log("Logger error: " + error)
		);

		super.handleError(error);
	}
}