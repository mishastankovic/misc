export class Error {

	constructor(
		public errorCode: string = "",
		public errorText: string = ""
	) { }
}