import { Injectable } from '@angular/core';
import { AppService } from "../../service/app.service";
import { CustomerIdentity } from "../../model/customer-identity";
import { HttpClient, HttpHeaders, HttpParams } from "@angular/common/http";
import { Observable } from "rxjs/internal/Observable";
import { environment } from 'environments/environment';
import { Liability } from "../../model/liability";


@Injectable({
	providedIn: 'root'
})
export class LiabilityService {

	liabilities: Liability[];

	constructor(private appService: AppService, private http: HttpClient) { }

	/**
   *
   * @returns {Observable<Liability[]>}
   */
	getCustomerLiabilities(): Observable<Liability[]> {
		let customerIdentity: CustomerIdentity = this.appService.getCustomerIdentity();
		if (customerIdentity) {
			let url: string = environment.liabilityServiceUrl;
			const params: HttpParams = new HttpParams().set('revenueLine', customerIdentity.revenueLine).set('customer', customerIdentity.customerId);
			return this.http.get<Liability[]>(url, { params });
		}
	}

	getLiability(liabilityId: string): Observable<Liability> {
		let customerIdentity: CustomerIdentity = this.appService.getCustomerIdentity();
		if (customerIdentity) {
			let url: string = environment.liabilityServiceUrl + "/" + liabilityId;
			const params: HttpParams = new HttpParams().set('revenueLine', customerIdentity.revenueLine).set('customer', customerIdentity.customerId);
			return this.http.get<Liability>(url, { params });
		}
	}

	getAllCustomerLiabilities() {
		this.getCustomerLiabilities()
			.subscribe(data => {
				this.liabilities = data;
			});
	}

	getNonOverdueLiabilities(): Liability[] {
		return this.liabilities ? this.liabilities.filter((l: Liability) => {
			return !l.overdue;
		}) : [];
	}

	getOverdueLiabilities(): Liability[] {
		return this.liabilities ? this.liabilities.filter((l: Liability) => {
			return l.overdue;
		}) : [];
	}
}
