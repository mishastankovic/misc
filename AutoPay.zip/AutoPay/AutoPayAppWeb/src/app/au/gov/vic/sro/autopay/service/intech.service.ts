import { Injectable } from '@angular/core';

import { Observable, Subject, of } from "rxjs";
import { map, debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { environment } from 'environments/environment';
import { Address } from 'app/au/gov/vic/sro/autopay/model/address';
import {HttpClient} from "@angular/common/http";


@Injectable()
export class IntechService {
	baseUrl: string = '';

	constructor(private http: HttpClient) {
		if (environment.serviceHostname !== '') this.baseUrl = environment.serviceHostname;
	}

	mockSearch(addressLine: Observable<string>): Observable<string[]> {
		return addressLine
			.pipe(debounceTime(500),
			distinctUntilChanged(),
			switchMap(queryString => of([
				'40 Mary St, Hawthorn VIC 3122',
				'40 Mary St, Kew VIC 3101',
				'40 Mary St, Richmond VIC 3121',
				'40 Mary St, St Kilda VIC 3182',
				'40 Mary St, Spotswood VIC 3015',
				"Flat 1, Central Towers, 22 Melbourne Rd, Melbourne 3000",
				"12 Main St, Fitzroy VIC  3065"])));
	};

	search(addressLine: Observable<string>, vicOnly?: string, excludePostal?: string): Observable<string[]> {
		return addressLine
			.pipe(debounceTime(500),
			distinctUntilChanged(),
			switchMap(queryString => this.searchAddress(queryString, vicOnly, excludePostal)));
	}

	searchAddress(queryString: string, vicOnly?: string, excludePostal?: string): Observable<string[]> {
		const basePath: string = "/autopayservice/intech/search";
		const queryUrl: string = '?addressLine=';
		const victorianAddressesOnly: string = "&victorianAddressesOnly=";
		const excludePostalAddress: string = "&excludePostalAddress=";

		return this.http
			.get(this.baseUrl + basePath + queryUrl + queryString + victorianAddressesOnly + vicOnly + excludePostalAddress + excludePostal)
			.pipe(map((addresses: string[]) => {
				let result: string[] = [];
				if (addresses) addresses.forEach(item => result.push(item));
				return result;
			}));
	}

	standardiseAddress(queryString: string): Observable<Address> {
		const basePath: string = "/autopayservice/intech/standardise";
		const queryUrl: string = '?addressLine=';

		return <Observable<Address>>this.http
			.get(this.baseUrl + basePath + queryUrl + queryString);
	}

	private getHeaders() {
		let headers = new Headers();
		headers.append('Accept', 'application/json');
		headers.append('Content-Type', 'application/json');
		return headers;
	}

}
