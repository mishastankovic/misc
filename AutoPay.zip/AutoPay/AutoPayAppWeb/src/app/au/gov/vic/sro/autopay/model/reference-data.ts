export class ReferenceData {

	public type: string;
	public code: string;
	public label: string;
	public shortLabel?: string;

	constructor(
		type: string,
		code: string,
		label: string,
		shortLabel?: string
	) {
		this.type = type;
		this.code = code;
		this.label = label;
		this.shortLabel = shortLabel;
	}
}