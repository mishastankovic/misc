
import { environment } from 'environments/environment';
import { CustomerIdentity } from 'app/au/gov/vic/sro/autopay/model/customer-identity';
import { Observable } from "rxjs";
import { map } from 'rxjs/operators';
import {HttpClient, HttpHeaders} from "@angular/common/http";

export class AuthenticationService {
	private customerIdentity: CustomerIdentity;

	constructor(private http: HttpClient) {
	}

	authenticate(baseUrl: String, httpHeaders: HttpHeaders, customerIdentity: CustomerIdentity): Observable<string[]> {
		const path: string = "customer/authenticate";
		console.log("POST:" + baseUrl + path);
		return <Observable<string[]>>this.http.post(baseUrl + path, customerIdentity, { headers: httpHeaders });
	}
}
