import { Component, OnInit } from '@angular/core';
import { AppService } from 'app/au/gov/vic/sro/autopay/service/app.service';
import { FormBuilder, FormGroup, FormControl, Validators, AbstractControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ReferenceDataService } from 'app/au/gov/vic/sro/autopay/service/reference-data.service';
import { Contact } from 'app/au/gov/vic/sro/autopay/model/contact';
import { PhoneNumberValidator } from 'app/au/gov/vic/sro/autopay/util/validator/phone-number.validator';
import { ReferenceData } from 'app/au/gov/vic/sro/autopay/model/reference-data';
import { FormUtils } from 'app/au/gov/vic/sro/autopay/util/form-utils';
import { UIMessageService } from 'app/au/gov/vic/sro/autopay/service/ui-message.service';
import { EmailValidator } from 'app/au/gov/vic/sro/autopay/util/validator/email.validator';
import { SpinnerService } from "sro-ngcomponent-library";

@Component({
	selector: 'app-contact-details',
	templateUrl: './contact-details.component.html',
	styleUrls: ['./contact-details.component.scss']
})
export class ContactDetailsComponent implements OnInit {

	contactDetailsFormGroup: FormGroup;
	customerId: string;
	contact: Contact;

	preferredCommunicationPerson: FormControl;
	contactPersonName: FormControl;
	emailAddress: FormControl;
	emailAddressRepeat: FormControl;
	emailReminder: FormControl;
	mobilePhoneNumber: FormControl;
	referenceData: ReferenceData[];

	constructor(public appService: AppService, private formBuilder: FormBuilder, private router: Router, private spinnerService: SpinnerService,
		public referenceDataService: ReferenceDataService, public formUtils: FormUtils, public uiMessageService: UIMessageService) { }

	ngOnInit() {

		//this.customerId = this.tokenService.getCustomerId();
		this.referenceData = this.referenceDataService.getReferenceData();
		//TODO: set up reference data for preferredCommunicationPerson

		this.contactPersonName = this.formBuilder.control('', Validators.compose([Validators.required, Validators.maxLength(120)]));
		this.mobilePhoneNumber = this.formBuilder.control('', Validators.compose([Validators.required, Validators.maxLength(16), PhoneNumberValidator.validate()]));
		this.preferredCommunicationPerson = this.formBuilder.control('', Validators.compose([Validators.required]));
		this.emailAddress = this.formBuilder.control('', Validators.compose([Validators.required, Validators.maxLength(60), EmailValidator.validate()]));
		this.emailAddressRepeat = this.formBuilder.control('', Validators.compose([Validators.required, Validators.maxLength(60)]));
		this.contactDetailsFormGroup = this.formBuilder.group({
			preferredCommunicationPerson: this.preferredCommunicationPerson,
			contactPersonName: this.contactPersonName,
			emailAddress: this.emailAddress,
			emailAddressRepeat: this.emailAddressRepeat,
			mobilePhoneNumber: this.mobilePhoneNumber,
			emailReminder: this.emailReminder
		}, {
				validator: formGroupValidator
			});
	}

	static emailAddressMismatch(group: FormGroup) {
		const emailAddress: FormControl = group.get('emailAddress') as FormControl;
		const emailAddressRepeat: FormControl = group.get('emailAddressRepeat') as FormControl;

		return (emailAddress.value && emailAddressRepeat.value) && (emailAddress.value !== emailAddressRepeat.value);
	}

	static contactNumberBlank(group: FormGroup) {
		const mobileNumber: FormControl = group.get('mobilePhoneNumber') as FormControl;
		return this.isBlank(mobileNumber)
	}
	static isBlank(formControl: FormControl): boolean {
		return !formControl || !formControl.value || formControl.value == "";
	}

	onSubmit() {
		this.validateForm();
	}

	onPrevious() {

	}

	validateForm() {
		FormUtils.validate(this.contactDetailsFormGroup);
		this.contactDetailsFormGroup.updateValueAndValidity();
		if (!this.contactDetailsFormGroup.valid) FormUtils.focusError(document);
	}

	getCommunicationPerson(): string {
		return ReferenceDataService.COMMUNICATION_PERSON;
	}

	isNotValid(control: AbstractControl, type?: string): boolean {
		if (!control) return;
		return FormUtils.isNotValid(control, type);
	}
}


function formGroupValidator(formGroup: AbstractControl) {
	let hasErrors: boolean = false;
	let errors = {};
	const form: FormGroup = formGroup as FormGroup;

	if (ContactDetailsComponent.contactNumberBlank(form)) {
		errors['contactNumberBlank'] = true;
		hasErrors = true;
	}

	if (ContactDetailsComponent.emailAddressMismatch(form)) {
		errors['emailMismatch'] = true;
		hasErrors = true;
	}

	if (hasErrors) {
		return errors;
	} else {
		return null;
	}
}
