import { LoginService } from 'app/au/gov/vic/sro/autopay/form/identity/login.service';
import { Router } from '@angular/router';
import { Injectable } from '@angular/core';

@Injectable()
export class OnlyLoggedInUsersGuard {
	constructor(private tokenService: LoginService, private router: Router) { };
	canActivate() {
		//		return true;
		console.log("OnlyLoggedInUsers");
		if (this.tokenService.hasValidToken()) {
			return true;
		} else {
			this.router.navigate(['/login'], { queryParams: { timedOut: 'true' } });
			return false;
		}

	}
}
