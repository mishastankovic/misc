export interface StepperState {
	page: string;
}