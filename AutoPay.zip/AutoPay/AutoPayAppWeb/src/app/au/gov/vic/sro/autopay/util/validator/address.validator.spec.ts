import { AbstractControl, FormControl } from '@angular/forms'

import { AddressValidator } from './address.validator';

describe('AddressValidator', () => {
	let validatorFn = new AddressValidator();

	it('should create an instance', () => {
		const directive = new AddressValidator();
		expect(directive).toBeTruthy();
	});

	it('should not error on an empty road number', () => {
		expect(AddressValidator.validateRoadNumber()(new FormControl(''))).toBeNull();
	});

	it('should not error on an null road number', () => {
		expect(AddressValidator.validateRoadNumber()(new FormControl(null))).toBeNull();
	});

	it('should not error on an undefined road number', () => {
		expect(AddressValidator.validateRoadNumber()(new FormControl(null))).toBeNull();
	});

	it('should error on an invalid road number 1', () => {
		expect(AddressValidator.validateRoadNumber()(new FormControl("2334135314"))).toEqual({ roadNumberFormat: Object({ value: '2334135314' }) });
	});

	it('should error on an invalid road number 2', () => {
		expect(AddressValidator.validateRoadNumber()(new FormControl("xe"))).toEqual({ roadNumberFormat: Object({ value: 'xe' }) });
	});

	it('should not error on an empty postcode', () => {
		expect(AddressValidator.validatePostcode()(new FormControl(''))).toBeNull();
	});

	it('should not error on an null postcode', () => {
		expect(AddressValidator.validatePostcode()(new FormControl(null))).toBeNull();
	});

	it('should not error on an undefined postcode', () => {
		expect(AddressValidator.validatePostcode()(new FormControl(null))).toBeNull();
	});

	it('should not error on an valid postcode', () => {
		expect(AddressValidator.validatePostcode()(new FormControl("3000"))).toBeNull();
	});

	it('should error on an invalid postcode 1', () => {
		expect(AddressValidator.validatePostcode()(new FormControl("2334135314"))).toEqual({ postcodeFormat: Object({ value: '2334135314' }) });
	});

	it('should error on an invalid postcode 2', () => {
		expect(AddressValidator.validatePostcode()(new FormControl("xe"))).toEqual({ postcodeFormat: Object({ value: 'xe' }) });
	});

	it('should error on an large postcode', () => {
		expect(AddressValidator.validatePostcode()(new FormControl("2465364365645643"))).toEqual({ postcodeFormat: Object({ value: '2465364365645643' }) });
	});

	it('should not error on an empty state', () => {
		expect(AddressValidator.validateState(true)(new FormControl(''))).toBeNull();
	});

	it('should not error on an null state', () => {
		expect(AddressValidator.validateState(true)(new FormControl(null))).toBeNull();
	});

	it('should not error on an undefined state', () => {
		expect(AddressValidator.validateState(true)(new FormControl(null))).toBeNull();
	});

	it('should not error on an valid state', () => {
		expect(AddressValidator.validateState(true)(new FormControl("VIC"))).toBeNull();
	});

	it('should error on an when state is not victoria', () => {
		expect(AddressValidator.validateState(true)(new FormControl("NSW"))).toEqual({ stateFormat: Object({ value: 'NSW' }) });
	});

	it('should error on an when state is invalid', () => {
		expect(AddressValidator.validateState(true)(new FormControl("xxxx"))).toEqual({ stateFormat: Object({ value: 'xxxx' }) });
	});

});
