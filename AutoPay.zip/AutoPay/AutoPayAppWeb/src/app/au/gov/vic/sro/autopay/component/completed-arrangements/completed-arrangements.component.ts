import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ap-completed-arrangements',
  templateUrl: './completed-arrangements.component.html',
  styleUrls: ['./completed-arrangements.component.scss']
})
export class CompletedArrangementsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
