/****
 * Known issue with selected date 1970 and prior being one day off
 * https://github.com/primefaces/primeng/issues/2426
 */
export class DateUtils {

	static minYear: number = 1900;
	static maxYear: number = new Date().getFullYear();
	static yearRange: string = (DateUtils.minYear) + ':' + (DateUtils.maxYear);

	static getDateFromInput(inputString: string): Date {
		let day = 0;
		let month = 0;
		let year = 0;
		if (inputString.length === 10) {
			day = day + parseInt(inputString.substring(0, 2), 10);
			month = month + parseInt(inputString.substring(3, 5), 10);
			year = year + parseInt(inputString.substring(6, 10), 10);
		}
		let newDate = new Date(month + "/" + day + "/" + year);
		if ('' + newDate === 'Invalid Date' || newDate.getDate() != day || newDate.getMonth() + 1 != month || newDate.getFullYear() != year || newDate.getFullYear() < this.minYear || newDate.getFullYear() > this.maxYear) {
			newDate = null;
		}
		return newDate;
	}

	static getStringFromDate(dateObject: Date): string {
		if (dateObject != null && typeof dateObject === "object") {
			dateObject = new Date(dateObject.getTime() + Math.abs(dateObject.getTimezoneOffset() * 60000));
			return dateObject.toLocaleDateString('en-gb').replace(/[^ -~]/g, ''); //IE added some control chars, this line removes them
		}
		return '';
	}

	static formatYear(inputString: string): string {
		let day = 0;
		let month = 0;
		let year = 0;
		let yearString = "";
		let formattedString = inputString;
		if (inputString.length === 10) {
			day = day + parseInt(inputString.substring(0, 2), 10);
			month = month + parseInt(inputString.substring(3, 5), 10);
			yearString = inputString.substring(6, 10);
		}
		if (yearString.endsWith("yy")) {
			year = year + parseInt(yearString.substring(0, 2), 10);

			let currentYear = new Date().getFullYear() - 2000;
			if (year > (currentYear))
				yearString = '19' + (year < 10 ? '0' + year : year);
			else
				yearString = '20' + (year < 10 ? '0' + year : year);

			formattedString = this.getStringFromDate(new Date(month + "/" + day + "/" + yearString));
		}

		return formattedString;
	}
}