import { Component, OnInit } from '@angular/core';
import { LiabilityService } from 'app/au/gov/vic/sro/autopay/component/liabilities/liability-service';
import { Liability } from 'app/au/gov/vic/sro/autopay/model/liability';

@Component({
	selector: 'ap-select-liability',
	templateUrl: './select-liability.component.html',
	styleUrls: ['./select-liability.component.scss']
})
export class SelectLiabilityComponent implements OnInit {

	liabilities: Liability[];

	constructor(private liabilityService: LiabilityService) { }

	ngOnInit() {

	}

	getEligibleNonOverdueLiabilities(): Liability[] {
		this.liabilities = this.liabilityService.getNonOverdueLiabilities();

		let eligibleLib: Liability[] = [];

		if (this.liabilities) {
			this.liabilities.filter((l: Liability) => {
				l.serviceList.filter(a => {
					if (a.serviceTypeId === 'SP' && a.available) {
						eligibleLib.push(l);
					}
				});

			});
		}
		return eligibleLib;
	}

}
