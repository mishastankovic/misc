import { Injectable } from '@angular/core';

declare let ga: any;

@Injectable()
export class AnalyticsService {

	constructor() { }

	sendPageView(page: string) {
		if (!this.useGA()) return;
		if (!page.startsWith('/')) page = `/${page}`;
		//Send SRO Google Analytics
		ga('set', 'page', "autopay" + page);
		ga('send', 'pageview');


		//Send Victorian Government Google Analytics
		ga('WoVG.set', 'page', "DTF/e-business.sro.vic.gov.au/autopay" + page);
		ga('WoVG.send', 'pageview');
	}

	/**
	 * No requirement to send events to DTF (trackerId: WoGV)
	 */
	sendEvent(eventCategory: string, eventAction: string) {
		if (!this.useGA()) return;
		ga('send', 'event', {
			'eventCategory': eventCategory,
			'eventAction': eventAction
		});
	}

	private useGA(): boolean {
		return ga && typeof ga === "function";
	}
}
