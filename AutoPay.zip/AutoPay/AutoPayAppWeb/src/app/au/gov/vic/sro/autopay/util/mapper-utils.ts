import { AbstractControl, FormGroup } from '@angular/forms';

import { Address } from 'app/au/gov/vic/sro/autopay/model/address';
import { ReferenceDataUtils } from 'app/au/gov/vic/sro/autopay/util/reference-data-utils';

export class MapperUtils {

	static mapFormToAddress(control: AbstractControl): Address {
		if (!(control instanceof FormGroup)) return Address.createAddress();
		const formGroup: FormGroup = <FormGroup>control;

		const address: Address = Address.createAddress();
		address.addressFormatType = formGroup.get('addressFormatType').value;

		if (address.isFreeTextAddress()) {
			address.addressLine = formGroup.get('addressLine').value;

		} else if (address.isStreetAddress()) {
			address.flatUnitType = formGroup.get('flatUnitType').value;
			address.flatUnitNumber = formGroup.get('flatUnitNumber').value;
			address.floorLevelType = formGroup.get('floorLevelType').value;
			address.floorLevelNumber = formGroup.get('floorLevelNumber').value;
			address.buildingName = formGroup.get('buildingName').value;
			address.roadNumberFrom = formGroup.get('streetNumberFrom').value;
			address.roadNumberTo = formGroup.get('streetNumberTo').value;
			address.roadName = formGroup.get('streetName').value;
			address.roadType = formGroup.get('streetType').value;
			address.roadSuffixType = formGroup.get('streetSuffixType').value;
			address.localityName = formGroup.get('locality').value;
			address.stateTerritory = formGroup.get('state').value;
			address.postcode = formGroup.get('postcode').value;

		} else if (address.isLotAddress()) {
			address.lotNumber = formGroup.get('lotNumber').value;
			address.roadName = formGroup.get('streetName').value;
			address.roadType = formGroup.get('streetType').value;
			address.roadSuffixType = formGroup.get('streetSuffixType').value;
			address.localityName = formGroup.get('locality').value;
			address.stateTerritory = formGroup.get('state').value;
			address.postcode = formGroup.get('postcode').value;

		} else if (address.isPostalAddress()) {
			address.postalDeliveryType = formGroup.get('postalBoxType').value;
			address.postalDeliveryPrefix = formGroup.get('postalBoxPrefix').value;
			address.postalDeliveryNumber = formGroup.get('postalBoxDeliveryNumber').value;
			address.postalDeliverySuffix = formGroup.get('postalBoxSuffix').value;
			address.buildingName = formGroup.get('buildingName').value;
			address.localityName = formGroup.get('locality').value;
			address.stateTerritory = formGroup.get('state').value;
			address.postcode = formGroup.get('postcode').value;

		} else if (address.isOverseasAddress()) {
			address.overseasAddressLine1 = formGroup.get('overseasAddressLine1').value;
			address.overseasAddressLine2 = formGroup.get('overseasAddressLine2').value;
			address.overseasAddressLine3 = formGroup.get('overseasAddressLine3').value;
			address.country = formGroup.get('country').value;
		}

		return address;
	}

	static mapAddressToForm(control: AbstractControl, address: Address) {
		if (!(control instanceof FormGroup) || !address) return;
		const formGroup: FormGroup = <FormGroup>control;

		formGroup.get('addressFormatType').setValue(address.addressFormatType);

		if (address.isFreeTextAddress()) {
			formGroup.get('addressLine').setValue(address.addressLine);

		} else if (address.isStreetAddress()) {
			formGroup.get('flatUnitType').setValue(address.flatUnitType);
			formGroup.get('flatUnitNumber').setValue(address.flatUnitNumber);
			formGroup.get('floorLevelType').setValue(address.floorLevelType);
			formGroup.get('floorLevelNumber').setValue(address.floorLevelNumber);
			formGroup.get('buildingName').setValue(address.buildingName);
			formGroup.get('streetNumberFrom').setValue(address.roadNumberFrom);
			formGroup.get('streetNumberTo').setValue(address.roadNumberTo);
			formGroup.get('streetName').setValue(address.roadName);
			formGroup.get('streetType').setValue(address.roadType);
			formGroup.get('streetSuffixType').setValue(address.roadSuffixType);
			formGroup.get('locality').setValue(address.localityName);
			formGroup.get('state').setValue(address.stateTerritory);
			formGroup.get('postcode').setValue(address.postcode);

		} else if (address.isPostalAddress()) {
			formGroup.get('postalBoxType').setValue(address.postalDeliveryType);
			formGroup.get('postalBoxPrefix').setValue(address.postalDeliveryPrefix);
			formGroup.get('postalBoxDeliveryNumber').setValue(address.postalDeliveryNumber);
			formGroup.get('postalBoxSuffix').setValue(address.postalDeliverySuffix);
			formGroup.get('buildingName').setValue(address.buildingName);
			formGroup.get('locality').setValue(address.localityName);
			formGroup.get('state').setValue(address.stateTerritory);
			formGroup.get('postcode').setValue(address.postcode);

		} else if (address.isOverseasAddress()) {
			formGroup.get('overseasAddressLine1').setValue(address.overseasAddressLine1);
			formGroup.get('overseasAddressLine2').setValue(address.overseasAddressLine2);
			formGroup.get('overseasAddressLine3').setValue(address.overseasAddressLine3);
			formGroup.get('country').setValue(address.country);
		}
	}

	static toFormattedAddress(address: Address, referenceDataUtils: ReferenceDataUtils): string {
		if (!address || !referenceDataUtils) return "";

		if (address.isFreeTextAddress()) {
			return address.addressLine;
		}

		var formattedAddress: string = '';
		const SPACE: string = ' ';

		if (address.isStreetAddress()) {
			if (address.flatUnitType && address.flatUnitType != '') {
				formattedAddress += referenceDataUtils.getFlatUnitTypesLabel(address.flatUnitType);
				formattedAddress += SPACE;
			}

			if (address.flatUnitNumber && address.flatUnitNumber != '') {
				formattedAddress += address.flatUnitNumber.toUpperCase();
				formattedAddress += SPACE;
			}

			if (address.floorLevelType && address.floorLevelType != '') {
				formattedAddress += referenceDataUtils.getFloorLevelTypesLabel(address.floorLevelType);
				formattedAddress += SPACE;
			}

			if (address.floorLevelNumber && address.floorLevelNumber != '') {
				formattedAddress += address.floorLevelNumber.toUpperCase();
				formattedAddress += SPACE;
			}

			if (address.buildingName && address.buildingName != '') {
				formattedAddress += address.buildingName.toUpperCase();
				formattedAddress += SPACE;
			}

			if (address.roadNumberFrom && address.roadNumberFrom != '') {
				formattedAddress += address.roadNumberFrom.toUpperCase();
				formattedAddress += SPACE;
			}

			if (address.roadNumberTo && address.roadNumberTo != '') {
				formattedAddress += address.roadNumberTo.toUpperCase();
				formattedAddress += SPACE;
			}

			if (address.roadName && address.roadName != '') {
				formattedAddress += address.roadName.toUpperCase();
				formattedAddress += SPACE;
			}

			if (address.roadType && address.roadType != null) {
				formattedAddress += referenceDataUtils.getRoadTypesLabel(address.roadType);
				formattedAddress += SPACE;
			}

			if (address.roadSuffixType && address.roadSuffixType != null) {
				formattedAddress += referenceDataUtils.getRoadSuffixTypesLabel(address.roadSuffixType);
				formattedAddress += SPACE;
			}

			if (address.localityName && address.localityName != '') {
				formattedAddress += address.localityName.toUpperCase();
				formattedAddress += SPACE;
			}

			if (address.stateTerritory && address.stateTerritory != null) {
				formattedAddress += address.stateTerritory.toUpperCase();
				formattedAddress += SPACE;
			}

			if (address.postcode && address.postcode != '') {
				formattedAddress += address.postcode;
			}

		} else if (address.isLotAddress()) {

			if (address.lotNumber && address.lotNumber != '') {
				formattedAddress += address.lotNumber.toUpperCase();
				formattedAddress += SPACE;
			}

			if (address.roadName && address.roadName != '') {
				formattedAddress += address.roadName.toUpperCase();
				formattedAddress += SPACE;
			}

			if (address.roadType && address.roadType != null) {
				formattedAddress += referenceDataUtils.getRoadTypesLabel(address.roadType);
				formattedAddress += SPACE;
			}

			if (address.roadSuffixType && address.roadSuffixType != null) {
				formattedAddress += referenceDataUtils.getRoadSuffixTypesLabel(address.roadSuffixType);;
				formattedAddress += SPACE;
			}

			if (address.localityName && address.localityName != '') {
				formattedAddress += address.localityName.toUpperCase();
				formattedAddress += SPACE;
			}

			if (address.stateTerritory && address.stateTerritory != null) {
				formattedAddress += address.stateTerritory.toUpperCase();
				formattedAddress += SPACE;
			}

			if (address.postcode && address.postcode != '') {
				formattedAddress += address.postcode;
			}

		} else if (address.isPostalAddress()) {

			if (address.postalDeliveryType && address.postalDeliveryType != null) {
				formattedAddress += referenceDataUtils.getPostalDeliveryTypesLabel(address.postalDeliveryType);
				formattedAddress += SPACE;
			}

			if (address.postalDeliveryPrefix && address.postalDeliveryPrefix != '') {
				formattedAddress += address.postalDeliveryPrefix.toUpperCase();
				formattedAddress += SPACE;
			}

			if (address.postalDeliveryNumber && address.postalDeliveryNumber != '') {
				formattedAddress += address.postalDeliveryNumber.toUpperCase();
				formattedAddress += SPACE;
			}

			if (address.postalDeliverySuffix && address.postalDeliverySuffix != '') {
				formattedAddress += address.postalDeliverySuffix.toUpperCase();
				formattedAddress += SPACE;
			}

			if (address.buildingName && address.buildingName != '') {
				formattedAddress += address.buildingName.toUpperCase();
				formattedAddress += SPACE;
			}

			if (address.localityName && address.localityName != '') {
				formattedAddress += address.localityName.toUpperCase();
				formattedAddress += SPACE;
			}

			if (address.stateTerritory && address.stateTerritory != '') {
				formattedAddress += address.stateTerritory.toUpperCase();
				formattedAddress += SPACE;
			}

			if (address.postcode && address.postcode != '') {
				formattedAddress += address.postcode;
			}

		} else if (address.isOverseasAddress()) {
			if (address.overseasAddressLine1 && address.overseasAddressLine1 != '') {
				formattedAddress += address.overseasAddressLine1.toUpperCase();
				formattedAddress += SPACE;
			}

			if (address.overseasAddressLine2 && address.overseasAddressLine2 != '') {
				formattedAddress += address.overseasAddressLine2.toUpperCase();
				formattedAddress += SPACE;
			}

			if (address.overseasAddressLine3 && address.overseasAddressLine3 != '') {
				formattedAddress += address.overseasAddressLine3.toUpperCase();
				formattedAddress += SPACE;
			}

			if (address.country && address.country != '') {
				formattedAddress += referenceDataUtils.getCountryLabel(address.country);
			}
		}

		return formattedAddress;

	}
}