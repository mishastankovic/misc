import { AbstractControl, ValidatorFn } from '@angular/forms';

export class EmailValidator {

	static validate(): ValidatorFn {
		var pattern = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
		return (control: AbstractControl): { [key: string]: any } => {
			let valid = true;
			if (control && control.value) {
				valid = pattern.test(control.value);
			}
			return valid ? null : { 'emailAddressFormat': { value: control.value } };
		};
	}

} 