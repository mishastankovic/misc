import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ap-cancel-arrangement',
  templateUrl: './cancel-arrangement.component.html',
  styleUrls: ['./cancel-arrangement.component.scss']
})
export class CancelArrangementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
