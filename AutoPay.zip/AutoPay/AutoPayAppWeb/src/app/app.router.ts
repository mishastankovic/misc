import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AuthGuard } from './au/gov/vic/sro/autopay/component/guard/auth.guard';
import { IdentityComponent } from './au/gov/vic/sro/autopay/form/identity/identity.component';
import { DeactivationGuard } from 'app/au/gov/vic/sro/autopay/component/guard/deactivation.guard';
import { WelcomeComponent } from 'app/au/gov/vic/sro/autopay/form/welcome/welcome.component';
import { ContactDetailsComponent } from 'app/au/gov/vic/sro/autopay/form/arrangement/contact-details/contact-details.component';
import { DirectDebitComponent } from 'app/au/gov/vic/sro/autopay/component/direct-debit/direct-debit.component';
import { CreditCardComponent } from 'app/au/gov/vic/sro/autopay/component/credit-card/credit-card.component';
import { CreateArrangementWizardComponent } from 'app/au/gov/vic/sro/autopay/component/create-arrangement-wizard/create-arrangement-wizard.component';
import { InstalmentDetailsComponent } from 'app/au/gov/vic/sro/autopay/form/arrangement/instalment-details/instalment-details.component';

export const IDENTITY_PAGE: string = 'Identity';
export const WELCOME_PAGE: string = 'Welcome';
export const CONTACT_PAGE: string = 'Contact details';
export const DIRECT_DEBIT_PAGE: string = 'Direct debit';
export const CREDIT_CARD_PAGE: string = 'Credit card';
export const CREATE_ARRANGEMENT: string = 'Create arrangement';
export const INSTALMENT_DETAILS: string = 'Instalment details';
export const SUMMARY_PAGE: string = 'Summary';
export const COMPLETED_PAGE: string = 'Done';

const appRoutes: Routes = [
	{ path: 'identity', component: IdentityComponent, data: { page: IDENTITY_PAGE } },
	{ path: 'welcome', component: WelcomeComponent, data: { page: WELCOME_PAGE } },
	{ path: 'contact', component: ContactDetailsComponent, data: { page: CONTACT_PAGE } },
	{ path: 'paymentdd', component: DirectDebitComponent, data: { page: DIRECT_DEBIT_PAGE } },
	{ path: 'paymentcc', component: CreditCardComponent, data: { page: CREDIT_CARD_PAGE } },
	{ path: 'createarr', component: CreateArrangementWizardComponent, data: { page: CREATE_ARRANGEMENT } },
	{ path: 'instalments', component: InstalmentDetailsComponent, data: { page: INSTALMENT_DETAILS } },
	{ path: '', redirectTo: 'identity', pathMatch: "full" },
];

@NgModule({
	imports: [RouterModule.forRoot(appRoutes)],
	exports: [RouterModule]
})
export class AppRouterModule {
}

export const routeComponents = [
	IdentityComponent,
	WelcomeComponent,
	ContactDetailsComponent
];