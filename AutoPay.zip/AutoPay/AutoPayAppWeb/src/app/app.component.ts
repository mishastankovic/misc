import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Event, NavigationEnd, NavigationStart, Router } from '@angular/router';
import { filter } from 'rxjs/operators';
import { environment } from 'environments/environment';
import { AnalyticsService } from 'app/au/gov/vic/sro/autopay/service/analytics.service';
import { ReferenceDataService } from './au/gov/vic/sro/autopay/service/reference-data.service';
import { TranslateService } from 'app/au/gov/vic/sro/autopay/component/translate/translate.service';
import { StepperService } from 'app/au/gov/vic/sro/autopay/component/stepper/stepper.service';
import { WindowService } from './au/gov/vic/sro/autopay/service/window.service';
import { SpinnerService } from "sro-ngcomponent-library";

@Component({
	selector: 'app-root',
	templateUrl: './app.component.html'
})
export class AppComponent implements OnInit {

	private baseServiceUrl: string = '';

	constructor(private referenceDataService: ReferenceDataService,
		private stepperService: StepperService, private analyticsService: AnalyticsService,
		private windowService: WindowService, private router: Router, private route: ActivatedRoute, private spinnerService: SpinnerService) {
	}

	ngOnInit() {
		this.referenceDataService.loadReferenceData();

		this.router.events
			.pipe(filter((event: Event) =>
				event instanceof NavigationStart || event instanceof NavigationEnd
			))
			.subscribe((event: Event) => {
				if (event instanceof NavigationStart) {
					this.spinnerService.showSpinner();
				}

				if (event instanceof NavigationEnd) {
					this.analyticsService.sendPageView(event.urlAfterRedirects);
					this.stepperService.updateStepper(this.route.root.firstChild.snapshot.data['page']);

					this.windowService.nativeWindow.scroll(0, 0);
					this.spinnerService.hideSpinner();
				}
			});
	}
}
