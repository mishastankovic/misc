// Karma configuration file, see link for more information
// https://karma-runner.github.io/0.13/config/configuration-file.html

const path = require('path');

module.exports = function (config) {
	config.set({
		basePath: '',
		frameworks: ['jasmine', '@angular/cli'],
		plugins: [
			require('karma-jasmine'),
			require('karma-phantomjs-launcher'),
			require('karma-jasmine-html-reporter'),
			require('karma-coverage-istanbul-reporter'),
			require('@angular/cli/plugins/karma')
		],
		client: {
			clearContext: false // leave Jasmine Spec Runner output visible in browser
		},
		coverageIstanbulReporter: {
			reports: ['html', 'lcovonly', 'text-summary'],
			fixWebpackSourcePaths: true,
			// base output directory. If you include %browser% in the path it will be replaced with the karma browser name
		    dir: path.join(__dirname, 'coverage'),
		    // stop istanbul outputting messages like `File [${filename}] ignored, nothing could be mapped`
		    skipFilesWithNoCoverage: true,
		    // Most reporters accept additional config options. You can pass these through the `report-config` option
		    'report-config': {
		        // all options available at: https://github.com/istanbuljs/istanbuljs/blob/aae256fb8b9a3d19414dcf069c592e88712c32c6/packages/istanbul-reports/lib/html/index.js#L135-L137
		        html: {
		          // outputs the report in ./coverage/html
		          subdir: 'html'
		        }
		    }
		},
		angularCli: {
			environment: 'dev'
		},
		reporters: ['progress', 'kjhtml','coverage-istanbul'],
		port: 9876,
		colors: true,
		logLevel: config.LOG_INFO,
		autoWatch: true,
		browsers: ['PhantomJS'],
		singleRun: false
	});
};
