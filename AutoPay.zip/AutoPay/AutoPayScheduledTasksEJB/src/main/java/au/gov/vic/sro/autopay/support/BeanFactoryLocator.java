package au.gov.vic.sro.autopay.support;

import java.util.Map;
import java.util.Properties;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import au.gov.vic.sro.autopay.model.EventType;
import au.gov.vic.sro.autopay.service.AutoPayService;
import au.gov.vic.sro.autopay.service.events.EventHandler;

public class BeanFactoryLocator {
	private static final String AUTO_PAY_PROPERTIES = "autoPayProperties";
	private static final String EVENT_HANDLERS = "eventHandlers";
	private static final String AUTO_PAY_SERVICE_BEAN = "autoPayService";

	// @formatter:off
	private static final BeanFactory BEAN_FACTORY = new ClassPathXmlApplicationContext(
			"classpath:autoPayContextConfig.xml",
			"classpath:autoPayContextLogging.xml",
			"classpath:autoPayContextDataSource.xml",
			"classpath:autoPayContextPersistence.xml",
			"classpath:autoPayContextServices.xml");
	// @formatter:on

	public BeanFactory getBeanFactory() {
		return BEAN_FACTORY;
	}

	public Properties getAutoPayProperties() {
		return (Properties) getBeanFactory().getBean(AUTO_PAY_PROPERTIES);
	}

	@SuppressWarnings("unchecked")
	public Map<EventType, EventHandler> getEventHandlers() {
		return (Map<EventType, EventHandler>) getBeanFactory().getBean(EVENT_HANDLERS);
	}

	public AutoPayService getAutoPayService() {
		return (AutoPayService) getBeanFactory().getBean(AUTO_PAY_SERVICE_BEAN);
	}

}
