package au.gov.vic.sro.autopay.mte;

import static au.gov.vic.sro.mte.router.ScheduledTaskListenerHelper.performExecution;
import static au.gov.vic.sro.mte.router.ScheduledTaskListenerHelper.Application.PaymentArrangements;

import javax.annotation.Resource;
import javax.ejb.ActivationConfigProperty;
import javax.ejb.EJBContext;
import javax.ejb.MessageDriven;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.jms.Message;
import javax.jms.MessageListener;

/**
 * Message-Driven Bean implementation class for: ScheduledTaskListenerBean
 */
@MessageDriven(activationConfig = {
		@ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue"),
		@ActivationConfigProperty(propertyName = "destination", propertyValue = "jms/SCHEDULER") },
		mappedName = "ScheduledTaskListenerBean")
@TransactionManagement(TransactionManagementType.BEAN)
public class ScheduledTaskListenerBean implements MessageListener {

	@Resource
	private EJBContext context;

	@Override
	public void onMessage(Message message) {
		try {
			performExecution(context, message, PaymentArrangements, null);
		} catch (RuntimeException e) {
			throw e;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

}
