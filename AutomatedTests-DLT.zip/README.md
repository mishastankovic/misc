# AngularJS 4 Project for BDD with Cucumber.js

##### How to build:
  - npm install  
##### How to run test:  
	1. Make sure the website is up and running. The website for testing is configured in the baseURL property of the  protractor-xxx.conf.js files  
	2. start selenium webdriver. For chromedrive go to the installation folder and run run.bat  
	3. Run the test by running -> npm run e2echrome  

#### Angular routing with access to inner pages:  
https://codecraft.tv/courses/angular/routing/routing-strategies/#_hashlocationstrategy
