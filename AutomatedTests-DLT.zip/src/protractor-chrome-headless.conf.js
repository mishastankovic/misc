let protractor = require('../src/protractor-base.conf.js');

let config = protractor.config;


config.seleniumAddress = 'http://10.4.17.110:4444/wd/hub';

config.baseUrl = 'https://mcidev01.sro.vic.gov.au/cpvsl';

config.accessibility.acheckerTempFolder = '/tmp/achecker/';

//use chrome browser.
config.capabilities = {
	browserName: 'chrome',
	chromeOptions: {
		args: ["--headless", "--disable-gpu", "--window-size=800,600", "--no-sandbox"],
	},
	acceptInsecureCerts: true

}

config.cucumberOpts.tags = ["~@fail", "~@exclude"];
//config.cucumberOpts.tags= ['@LoginLogout'];
//oracleNodeRestUlr= "http://mcidev01.sro.vic.gov.au:3000/sql",
config.oracleNodeRestUlr = "http://localhost:3000/sql",

	exports.config = config;