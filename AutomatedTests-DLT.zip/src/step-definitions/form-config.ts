export class FormConfig {
    auditCreateInformation?;
    status : "EDIT_IN_PROGRESS";
    formCode?;
    address?;
    propertyType?;
    representativeList;
    offThePlan?;
    subSale?;
    additionalLandNotIncludedInContract?;
    transaction?;
    concessionExemptionSection?;
    foreignNationalDetails?;
    signature?;
}