import { defineSupportCode, setDefaultTimeout } from "cucumber";
import { browser, element, by, By } from "protractor";
import { CucumberUtils, CacheObj } from 'sro-bdd-cucumber';
import { VerificationXmlToSoapJson } from './verification-xml-to-form-json'; 

import { FormConfig } from "./form-config";


let chai = require('chai')
    .use(require('chai-as-promised'))
    .use(require('chai-match-pattern'));
let expect = chai.expect;
let cucumberUtils = new CucumberUtils();
const loadJsonFile = require('load-json-file');
const soapToDutiesJson = new VerificationXmlToSoapJson();


defineSupportCode(({ Given, When, Then, setWorldConstructor }) => {

    setDefaultTimeout(10 * 1000);

	Given(/^I login to DOL with username as '(.+)' with password '(.+)'$/, async (username, password) => {
		let config = await browser.getProcessedConfig();
		let dolUrl = config.dolUrl;
		await browser.waitForAngularEnabled(false);
		await browser.get(dolUrl);
		await browser.element(By.id("j_username")).sendKeys(username);
		await browser.element(By.id("j_password")).sendKeys(password);
		await browser.element(By.buttonText("Sign In")).click();
		let a = await browser.manage().getCookies();
		let cookie = await browser.manage().getCookie('access_token');
		cucumberUtils.getVarCache().putCacheObj('access_token', CacheObj.fromValue(cookie.value));
	});

	Then('I click on dol menu item {string} in {string} menu group', async function (menuItem, menuHeading) {
		browser.actions().mouseMove(element(by.partialLinkText(menuHeading))).perform();
		await browser.driver.sleep(2 * 1000);
		await browser.element(By.id(menuItem)).click();
	});


	Then('Class Check that {string} has the value {string}', async  function (fieldName, fieldValue) {
		cucumberUtils.waitForElement(fieldName);
		await expect(element(by.className(fieldName)).getText()).to.eventually.equal(fieldValue);
	});
	
	Then('Tag Name Check that {string} has the value {string}', async  function (fieldName, fieldValue) {
		cucumberUtils.waitForElement(fieldName);
		await expect(element(by.tagName(fieldName)).getText()).to.eventually.equal(fieldValue);
	});

	Given('I am on the {string} page with parameter {string}', async function (url, paramValue) {
		//console.log('paramValue: ' + paramValue);
		//console.log('url: ' + url);
		let cachedParamValue = cucumberUtils.getVarValue(paramValue);
		let completeUrl = url + cachedParamValue;
		await cucumberUtils.debug();
		await browser.get(browser.baseUrl + "/" + completeUrl);
	});
	Then('I wait for {string} seconds', async function (numOfSeconds) {
		// Write code here that turns the phrase above into concrete actions
		await browser.driver.sleep(parseInt(numOfSeconds) * 1000);
	});
		
	Then('I tick option item for {string}', async function (elementName) {
		await cucumberUtils.debug();
		let message = 'Element taking too long to load :' + elementName;
			await element(by.for(elementName)).click();
	});

  Then('Check that {string} is disabled', async function (fieldName) {
		await cucumberUtils.debug();
		cucumberUtils.waitForElement(fieldName);
    await expect(element(by.id(fieldName)).getAttribute('disabled')).to.eventually.contains.valueOf('true');
  });

  Then('Check that {string} is enabled', async function (fieldName) {
		await cucumberUtils.debug();
		cucumberUtils.waitForElement(fieldName);
    await expect(element(by.id(fieldName)).isPresent()).to.eventually.be.true;
    await expect(element(by.id(fieldName)).getAttribute('disabled')).to.eventually.contains.valueOf(null);
  });

  Then('Check that {string} is present', async function (fieldName) {
		cucumberUtils.waitForElement(fieldName);
    await expect(element(by.id(fieldName)).isPresent()).to.eventually.be.true;
  });

  Then('Check that {string} is not present', async function (fieldName) {
    await expect(element(by.id(fieldName)).isPresent()).to.eventually.be.false;
  });

	Then('Create duties form json from verification xml stored in {string} and form config json from {string} and store in variable {string}', 
		async (verificationResult: string, jsonFile: string, resultVariable : string) => {
			debugger;
			let config = await browser.getProcessedConfig();
			let verificationResultInfo = cucumberUtils.getVarCache().getObj(verificationResult);
			
			let formConfig: FormConfig = new FormConfig();
			try {
				let configJson = loadJsonFile.sync(config.jsonfolder + jsonFile + ".json");
				formConfig = configJson.formConfig;
			} catch (error) {
				console.log(`json file '${jsonFile}' for form configuration not found. using default json in create duties from verification request step.`)
				//use the default json
			}
			let dutiesFormJs = soapToDutiesJson.createFromVerificationRequest(verificationResultInfo.requestJson, formConfig);
			let dutiesFormJson = JSON.stringify(dutiesFormJs);
			cucumberUtils.getVarCache().putCacheObj(resultVariable, CacheObj.fromValue(dutiesFormJson));
	});

	Then('Create signature json from Form response in {string} with form config json from {string} and store in variable {string}', 
		async(response, jsonFile: string, resultVariable :string) => {
		debugger;
		let config = await browser.getProcessedConfig();
		let formConfig: FormConfig = new FormConfig();
		try {
			let configJson = loadJsonFile.sync(config.jsonfolder + jsonFile + ".json");
			formConfig = configJson.formConfig;
		} catch (error) {
			console.log(`json file '${jsonFile}' for form configuration not found. using default json in create signature json step.`)
			//use the default json
		}
		let formResponse = cucumberUtils.getVarCache().getObj(response);
		let signatureJs = soapToDutiesJson.createSignatureJson(formResponse.data, formConfig);
		let signatuerJson = JSON.stringify(signatureJs);
		debugger;
		await cucumberUtils.getVarCache().putCacheObj(`${resultVariable}`, CacheObj.fromValue(signatuerJson));
	})
});
