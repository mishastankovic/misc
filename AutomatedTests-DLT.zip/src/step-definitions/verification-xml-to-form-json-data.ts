
import {FormConfig} from './form-config';
import { element } from 'protractor';

export class VerificationXmlToSoapJsonData {
  

    public createAddress(formConfig : FormConfig) : any {
        let address;
        if (formConfig && formConfig.address) {
            return formConfig.address;
        }
        return {
            "addressFormatType": "FREETEXT",
            "addressLine": "121 Exhibition St, MELBOURNE  VIC  3000",
            "roadNumberFrom": "121",
            "roadName": "EXHIBITION",
            "roadType": "STREET",
            "localityName": "MELBOURNE",
            "postcode": "3000",
            "stateTerritoryCode": "VIC",
            "empty": false,
            "structuredAddress": false,
            "formattedAddress": "121 Exhibition St, MELBOURNE  VIC  3000"
        };
    }


    public getForeignNationalDetails(formConfig: FormConfig) : any {
        if (formConfig && formConfig.foreignNationalDetails) {
            return formConfig.foreignNationalDetails;
        }
        return {
            "nationality": "AUSTRALIA",
            "taxResidenceCountry": "AUSTRALIA",
            "visaPanelRendered": false,
            "visaForeignDetailsRequired": false
        };
    }

    public getAuditCreateInformation(formConfig? : FormConfig) : any {
        if (formConfig && formConfig.auditCreateInformation) {
            return formConfig.auditCreateInformation;
        } else {
            let auditCreateInformation = {
                "createdByRegistrationId": "47062507",
                "createdByUserId": "PASVER0001",
                "created": "2019-02-28T00:48:44.188+0000",
                "createdBy": {
                    "userId": "PASVER0001",
                    "registrationId": "47062507",
                    "registrationType": "DUTIES_ONLINE",
                    "dolCustomerId": "47062507",
                    "dolUserId": "PASVER0001",
                    "dolRegistration": true
                }
            }
            return auditCreateInformation;
        }
    }

    public getOffThePlan(formConfig : FormConfig) : any {
        if (formConfig && formConfig.offThePlan) {
            return formConfig.offThePlan;
        }
        return {
            "offThePlanConcessionSubjected": false,
            "contractPrice": 100000,
            "auditUpdateInformation": {
                "updatedByRegistrationId": "47062507",
                "updatedByUserId": "PASVER0001",
                "updated": "2019-03-06T03:08:20.869+0000",
                "updatedBy": {
                    "userId": "PASVER0001",
                    "registrationId": "47062507",
                    "registrationType": "DUTIES_ONLINE",
                    "dolCustomerId": "47062507",
                    "dolUserId": "PASVER0001",
                    "dolRegistration": true
                }
            },
            "readOnlyLessTheTotalGst": false
        };
    }

    public getSubSale(formConfig : FormConfig) : any {
        if (formConfig && formConfig.subSale) {
            return formConfig.subSale;
        }
        return {
            "notSubSale": true,
            "applicable": false,
            "purchaserTransferRightsChanged": false,
            "purchasers": [],
            "option": {
                "optionGrantedToProperty": false
            },
            "landDevelopment": {},
            "additionalConsideration": {
                "paidToVendor": 0,
                "paidToFirstPurchaser": 0,
                "paidToOtherParties": 0,
                "underParallelArrangement": 0,
                "totalConsideration": 0,
                "considerationExcludedCostsValue": 0
            },
            "auditUpdateInformation": {
                "updatedByRegistrationId": "47062507",
                "updatedByUserId": "PASVER0001",
                "updated": "2019-03-06T03:08:20.851+0000",
                "updatedBy": {
                    "userId": "PASVER0001",
                    "registrationId": "47062507",
                    "registrationType": "DUTIES_ONLINE",
                    "dolCustomerId": "47062507",
                    "dolUserId": "PASVER0001",
                    "dolRegistration": true
                }
            },
            "version": 0,
            "purchaserListSize": 0,
            "optionApplicable": true,
            "transferRightsApplicable": true
        };
    }

    public getTransaction(formConfig : FormConfig) : any {
        if (formConfig && formConfig.transaction) {
            return formConfig.transaction;
        }
        return {
            "transactionSectionId": 3337644,
            "transferOfLandType": "TRANSFER_OF_LAND",
            "transferDetails": {
              "transactionType": "TransferBetweenSpousesDeFactoOrDomesticPartners",
              "transactionInvolvesMonetaryConsideration": false,
              "transferDate": "2019-01-31",
              "involvesMonetaryConsideration": false,
              "other": false,
              "fullPath": false,
              "transferBetweenSpousesDefactoOrDomesticPartnersWithNoConsiderationPath": true,
              "deviseInAccordanceWithAWillOrProbate": false,
              "transferBetweenSpousesDeFactoOrDomesticPartners": true,
              "transactionInvolvesMonetaryConsiderationRendered": true,
              "optionDateRendered": false,
              "contractDateRendered": false,
              "limitedPath": false
            },
            "relatedParty": {
              "relatedParty": false,
              "relationshipTypeRendered": false
            },
            "considerationAndValue": {
              "marketValueDate": "2019-01-06",
              "marketValue": 1000000,
              "nonMonetaryDetailsRendered": false,
              "marketValueDetailsRendered": false,
              "otherNonMonetaryConsiderationDetailsRendered": false
            },
            "gst": {
              "gstDetailsRendered": false,
              "gstAmountsRendered": false,
              "explainDoesNotMakeTaxableSupplyRendered": false
            },
            "saleOfBusinessGoods": {
              "saleOfGoodsDetailsRendered": false,
              "saleOfBusinessDetailsRendered": false
            },
            "waterRights": {
              "considerationForWaterRightsRendered": false
            },
            "dutiesFormId": 2293463,
            "auditUpdateInformation": {
              "updatedByRegistrationId": "47062507",
              "updatedByUserId": "PASVER0001",
              "updated": "2019-01-21T22:57:10.437+0000",
              "updatedBy": {
                "userId": "PASVER0001",
                "registrationId": "47062507",
                "registrationType": "DUTIES_ONLINE",
                "dolCustomerId": "47062507",
                "dolUserId": "PASVER0001",
                "dolRegistration": true
              }
            },
            "version": 1,
            "id": "sl68krrduz52",
            "fullPath": false,
            "transferBetweenSpousesDefactoOrDomesticPartnersWithNoConsiderationPath": true,
            "limitedPath": false,
            "transferBetweenSpousesDeFactoOrDomesticPartners": true,
            "transactionInvolvesMonetaryConsideration": false,
            "considerationGreaterThanZero": false,
            "changeOfBeneficialOwnership": false
          };
    }

    public getaAditionalLandNotIncludedInContract(formConfig : FormConfig) : any {
        if (formConfig && formConfig.additionalLandNotIncludedInContract) {
            return formConfig.additionalLandNotIncludedInContract;
        }
        return {
            "additionalSaleOfLand": false,
            "propertyList": [],
            "auditUpdateInformation": {
                "updatedByRegistrationId": "47062507",
                "updatedByUserId": "PASVER0001",
                "updated": "2019-03-06T03:08:20.847+0000",
                "updatedBy": {
                    "userId": "PASVER0001",
                    "registrationId": "47062507",
                    "registrationType": "DUTIES_ONLINE",
                    "dolCustomerId": "47062507",
                    "dolUserId": "PASVER0001",
                    "dolRegistration": true
                }
            },
            "version": 0
        };
    }

    public getStatus(formConfig : FormConfig) : string {
        if( formConfig && formConfig.status) {
            return formConfig.status;
        }
        return 'SIGNED';
        // return 'EDIT_IN_PROGRESS';
    }

    public getConcessionExemptionSection( formConfig : FormConfig) : any {
        if (formConfig && formConfig.concessionExemptionSection) {
            return formConfig.concessionExemptionSection;
        }
        return {
            "applyConcessionOrExemption": false,
            "concessions": [],
            "version": 0,
            "auditUpdateInformation": {
                "updatedByRegistrationId": "47062507",
                "updatedByUserId": "PASVER0001",
                "updated": "2019-02-25T06:46:21.786+0000",
                "updatedBy": {
                    "userId": "PASVER0001",
                    "registrationId": "47062507",
                    "registrationType": "DUTIES_ONLINE",
                    "dolCustomerId": "47062507",
                    "dolUserId": "PASVER0001",
                    "dolRegistration": true
                }
            }
        };
    }

    public getSignature(formConfig : FormConfig) : any {
        if (formConfig && formConfig.signature) {
            return formConfig.signature;
        }

        return    {
            "dutiesFormId": 2440311,
            "partyId": 8283477,
            "transferPartyType": "TRANSFEROR",
            "signedDolCustomerId": "47062507",
            "signedTimestamp": "2019-02-25T06:47:06.000+0000",
            "signatoryType": "ATTESTOR",
            "status": "SIGNED",
            "signedByName": "PASQUALE VERDINI",
            "signedAddress": {
                "addressFormatType": "FREETEXT",
                "addressLine": "Shop 1, Ground Floor  121 Exhibition St, MELBOURNE  VIC  3000",
                "flatUnitType": "SHOP",
                "flatUnitNumber": "1",
                "floorLevelNumber": "1",
                "roadNumberFrom": "121",
                "roadName": "EXHIBITION",
                "roadType": "STREET",
                "localityName": "MELBOURNE",
                "postcode": "3000",
                "stateTerritoryCode": "VIC",
                "empty": false,
                "structuredAddress": false,
                "formattedAddress": "Shop 1, Ground Floor  121 Exhibition St, MELBOURNE  VIC  3000"
            },
            "email": "test@test.com",
            "invitations": [],
            "version": 1,
            "auditCreateInformation": {
                "createdByRegistrationId": "47062507",
                "createdByUserId": "PASVER0001",
                "created": "2019-02-25T06:46:40.696+0000",
                "createdBy": {
                    "userId": "PASVER0001",
                    "registrationId": "47062507",
                    "registrationType": "DUTIES_ONLINE",
                    "dolCustomerId": "47062507",
                    "dolUserId": "PASVER0001",
                    "dolRegistration": true
                }
            },
            "auditUpdateInformation": {
                "updatedByRegistrationId": "47062507",
                "updatedByUserId": "PASVER0001",
                "updated": "2019-02-25T06:47:06.924+0000",
                "updatedBy": {
                    "userId": "PASVER0001",
                    "registrationId": "47062507",
                    "registrationType": "DUTIES_ONLINE",
                    "dolCustomerId": "47062507",
                    "dolUserId": "PASVER0001",
                    "dolRegistration": true
                }
            },
            "hardcopyHeld": false,
            "formReviewed": false,
            "voiIndicator": false,
            "publicSigning": false,
            "contentsApproved": false,
            "dolRepresented": false,
            "dolRepresentingOrganisationAssociation": false,
            "signedAsPowerOfAttorney": false
        };


    }

    public getRepresentativeList(formConfig: FormConfig) : any {
        if (formConfig && formConfig.representativeList) {
            return formConfig.representativeList;
        }
        return [
            {
              "dutiesFormClientReference": "generated Form Request",
              "representativeRole": "BOTH",
              "dateAcknowledged": "2019-02-22T13:37:58.973+0000",
              "acknowledged": true,
              "dateCompletedTransferor": "2019-02-25T06:45:26.949+0000",
              "dateCompletedTransferee": "2019-02-25T06:46:40.650+0000",
              "representativeRoleUpgradedBySystem": false,
              "auditCreateInformation": {
                "createdByRegistrationId": "47062507",
                "createdByUserId": "PASVER0001",
                "created": "2019-02-28T00:48:44.232+0000",
                "createdBy": {
                  "userId": "PASVER0001",
                  "registrationId": "47062507",
                  "registrationType": "DUTIES_ONLINE",
                  "dolCustomerId": "47062507",
                  "dolUserId": "PASVER0001",
                  "dolRegistration": true
                }
              },
              "auditUpdateInformation": {
                "updatedByRegistrationId": "47062507",
                "updatedByUserId": "PASVER0001",
                "updated": "2019-02-25T06:46:40.699+0000",
                "updatedBy": {
                  "userId": "PASVER0001",
                  "registrationId": "47062507",
                  "registrationType": "DUTIES_ONLINE",
                  "dolCustomerId": "47062507",
                  "dolUserId": "PASVER0001",
                  "dolRegistration": true
                }
              },
              "version": 3,
              "registrationIdentifier": {
                "userId": "PASVER0001",
                "registrationId": "47062507",
                "registrationType": "DUTIES_ONLINE",
                "dolCustomerId": "47062507",
                "dolUserId": "PASVER0001",
                "dolRegistration": true
              },
              "completedTransferor": true,
              "completedTransferee": true
            }
          ];


    }

}

