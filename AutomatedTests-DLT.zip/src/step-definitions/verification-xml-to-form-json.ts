
import {FormConfig} from './form-config';
import { element } from 'protractor';
import { VerificationXmlToSoapJsonData } from './verification-xml-to-form-json-data'
import {CucumberUtils} from 'sro-bdd-cucumber';

export class VerificationXmlToSoapJson {
    verificationXmlToSoapJsonData : VerificationXmlToSoapJsonData = new VerificationXmlToSoapJsonData();
    cucumberUtils: CucumberUtils = new CucumberUtils();

    public createSignatureJson(form: any, formConfig : FormConfig) : any {
        let signatures = [];
        let signatureTemplate = this.verificationXmlToSoapJsonData.getSignature(formConfig);
        form.dutiesFormData.transfereeSection.transfereeList.forEach((transferee) => {
            let signature = JSON.parse(JSON.stringify(signatureTemplate));
            signature.partyId = transferee.id;
            signature.dutiesFormId = form.dutiesFormId;
            signature.transferPartyType = 'TRANSFEREE'
            signatures.push(signature);
        });
        form.dutiesFormData.transferorSection.transferorList.forEach((transferor) => {
            let signature = JSON.parse(JSON.stringify(signatureTemplate));
            signature.partyId = transferor.id;
            signature.dutiesFormId = form.dutiesFormId;
            signature.transferPartyType = 'TRANSFEROR'
            signatures.push(signature);
        });
        return signatures;
    }

    public createFormJson(verificationJson: any, formConfig: FormConfig) : any {
        let verificationObject = JSON.parse(verificationJson);
        let formRequest = this.createFromVerificationRequest(verificationObject, formConfig);
        }

    public createFromVerificationRequest(verificationJsonReqest: any , formConfig : FormConfig) : any {

        let parties = this.getParties(verificationJsonReqest, formConfig);
        let transfereeSection = this.createTransfereeSection(verificationJsonReqest.StampDutyVerification.DocumentData, parties, formConfig);
        let transferrorSection = this.createTransferorSection(verificationJsonReqest.StampDutyVerification.DocumentData, parties, formConfig);
        let propertySection = this.createPropertySection(verificationJsonReqest.StampDutyVerification.DocumentData, formConfig);
        let representativeList = this.verificationXmlToSoapJsonData.getRepresentativeList(formConfig);
        let transaction = this.verificationXmlToSoapJsonData.getTransaction(formConfig);
        let offThePlan = this.verificationXmlToSoapJsonData.getOffThePlan(formConfig);
        let subSale = this.verificationXmlToSoapJsonData.getSubSale(formConfig);
        let concessionExemptionSection = this.verificationXmlToSoapJsonData.getConcessionExemptionSection(formConfig);
        let additionalLandNotIncludedInContract = this.verificationXmlToSoapJsonData.getaAditionalLandNotIncludedInContract(formConfig);
        let status = this.verificationXmlToSoapJsonData.getStatus(formConfig);

        let dutiesForm = {
            dutiesFormData : {
                transfereeSection : transfereeSection,
                transferorSection : transferrorSection,
                propertySection : propertySection,
                transaction : transaction,
                offThePlan : offThePlan,
                subSale : subSale,
                concessionExemptionSection : concessionExemptionSection,
                additionalLandNotIncludedInContract : additionalLandNotIncludedInContract
            },
            auditCreateInformation : this.verificationXmlToSoapJsonData.getAuditCreateInformation(formConfig),
            representativeList : representativeList,
            dutiesFormStatus : status,
            limitedPath: false  
        };

        return dutiesForm;
    }


    private createPropertySection(documentData : any[], formConfig : FormConfig) {


        let propertyList = [];
        let docs : any[] = this.handleSingleObjectJson(documentData);
        for(const doc of docs) {
            let property = {
                propertyAddress : this.verificationXmlToSoapJsonData.createAddress(formConfig),
                auditCreateInformation : this.verificationXmlToSoapJsonData.getAuditCreateInformation(formConfig),
                propertyType : formConfig.propertyType ? formConfig.propertyType : "ResidentialPrivateDwelling",
                landIdentifierList : this.createLandIdentifierList(doc, formConfig),
            }
            propertyList.push(property);            
        }
        
        let propertySection = {
            percentInterestTransferred: 100,
            propertyList : propertyList,
            auditCreateInformation : this.verificationXmlToSoapJsonData.getAuditCreateInformation(formConfig)
        }
        return propertySection;
    }

    private handleSingleObjectJson(objs : any) {
        if (Array.isArray(objs)) {
            return objs;
        }
        else if (objs) {
            return [objs];
        }
    }

    private createLandIdentifierList(doc: any, formConfig: FormConfig) {
        let subjectTitles = [];
        //get from array or object, this is due to the json generated from xml could be an array or an object based on number of SubjectOLandTitle objects found.
        if (Array.isArray(doc.SubjectLandTitle)) {
            for (let title of doc.SubjectLandTitle) {
                subjectTitles.push(title);
            }
        }
        else if (doc.SubjectLandTitle) {
            subjectTitles.push(doc.SubjectLandTitle);
        }
        let landIdentifierList = [];
        for (let title of subjectTitles) {
            let volume;
            let folio;
            title.LandTitleReference.Component
                .filter(identifier => { return identifier.Name === 'Volume' || identifier.Name === 'Folio'; })
                .forEach(component => {
                    switch (component.Name) {
                        case 'Volume':
                            volume = component.Value;
                            break;
                        case 'Folio':
                            folio = component.Value;
                            break;
                    }
                });
            let volfol = this.createVolumeFolio(volume, folio, formConfig);
            landIdentifierList.push(volfol);
        }
        return landIdentifierList;
    }

    private createVolumeFolio(volume : String, folio : String, formConfig : FormConfig) {
        return {
            landIdentifierType : "VOLUME_FOLIO",
            volume : volume,
            folio : folio,
            auditCreateInformation : this.verificationXmlToSoapJsonData.getAuditCreateInformation(formConfig),
            formattedDescription : `Volume: ${volume} Folio: ${folio}`,
            new : false
        }
    }

    private createTransferorSection(documentData : any[], parties: any, formConfig: FormConfig) {
        let transferorList = [];
        let docs : any[] = this.handleSingleObjectJson(documentData);
        for(const doc of docs ) {
            let a = doc;
            let tenancyGroup = doc.PartyReceivingDetail.Tenancy.TenancyGroup;
            let interestHolding = {
                "totalShares": tenancyGroup.ShareFraction.Denominator,
                "sharesOwned": tenancyGroup.ShareFraction.Numerator
            }
            let transferor = {
                 "interestHolding" : interestHolding,
            };

            let party = parties[tenancyGroup.TenantHolding.PartyId];

            switch(party.partyType) {
                case 'INDIVIDUAL_NATURAL_PERSON':

                    transferor['naturalPerson'] = {
                        personName: party.personName, 
                        dateOfBirth: party.dateOfBirth, 
                        mobileNumber: party.mobileNumber, 
                        emailAddress: party.emailAddress, 
                        foreignNaturalPerson: false,
                        foreignNationalDetails : this.verificationXmlToSoapJsonData.getForeignNationalDetails(formConfig)
                    };
                    transferor['partyType'] = party.partyType;
                    transferor['auditCreateInformation'] = this.verificationXmlToSoapJsonData.getAuditCreateInformation(formConfig);
                    transferor['currentAddress'] = this.verificationXmlToSoapJsonData.createAddress(formConfig);
                    transferor['behalfOfTrust'] = false;
                    transferor['remainingOnTitle'] = false;
                    transferor['sameAddress'] = true;
                    break;
            }
            transferorList.push(transferor);        
        }
        let transferorSection = {
            transferorList : transferorList,
            auditCreateInformation : this.verificationXmlToSoapJsonData.getAuditCreateInformation(formConfig)
        }
        return transferorSection;
    }

    private createTransfereeSection(documentData : any[], parties: any, formConfig: FormConfig) {
        let transfereeList = [];
        let docs : any[] = this.handleSingleObjectJson(documentData);
        for(const doc of docs ) {
            let a = doc;
            let tenancyGroup = doc.PartyReceivingDetail.Tenancy.TenancyGroup;
            let interestHolding = {
                "totalShares": tenancyGroup.ShareFraction.Denominator,
                "sharesOwned": tenancyGroup.ShareFraction.Numerator
            }
            let transferee = {
                "interestHolding" : interestHolding,
            };

            let party = parties[tenancyGroup.TenantHolding.PartyId];
            switch(party.partyType) {
                case 'INDIVIDUAL_NATURAL_PERSON':

                    transferee['naturalPerson'] = {
                        personName: party.personName, 
                        dateOfBirth: party.dateOfBirth, 
                        mobileNumber: party.mobileNumber, 
                        emailAddress: party.emailAddress, 
                        foreignNaturalPerson: false,
                        foreignNationalDetails : this.verificationXmlToSoapJsonData.getForeignNationalDetails(formConfig)
                    };
                    transferee['partyType'] = party.partyType;
                    transferee['currentAddress'] = this.verificationXmlToSoapJsonData.createAddress(formConfig);                    
                    transferee['behalfOfTrust'] = false;
                    transferee['auditCreateInformation'] = this.verificationXmlToSoapJsonData.getAuditCreateInformation(formConfig);
                    transferee['sameAddress'] = true;
                    break;
            }
            transfereeList.push(transferee);        
        }
        let transfereeSection = {
            transfereeList : transfereeList,
            auditCreateInformation : this.verificationXmlToSoapJsonData.getAuditCreateInformation(formConfig)
        }
        return transfereeSection;
    }

    // private getForeignNationalDetails(formconfig: FormConfig) : any {
    //     if (formconfig.foreignNationalDetails) {
    //         return formconfig.foreignNationalDetails;
    //     }
    //     return {
    //         "nationality": "AUSTRALIA",
    //         "taxResidenceCountry": "AUSTRALIA",
    //         "visaPanelRendered": false,
    //         "visaForeignDetailsRequired": false
    //     };
    // }

    // private getAuditCreateInformation(formConfig? : FormConfig) : any {
    //     if (formConfig.auditCreateInformation) {
    //         return formConfig.auditCreateInformation;
    //     } else {
    //         let auditCreateInformation = {
    //             "createdByRegistrationId": "47062507",
    //             "createdByUserId": "PASVER0001",
    //             "created": "2019-02-28T00:48:44.188+0000",
    //             "createdBy": {
    //                 "userId": "PASVER0001",
    //                 "registrationId": "47062507",
    //                 "registrationType": "DUTIES_ONLINE",
    //                 "dolCustomerId": "47062507",
    //                 "dolUserId": "PASVER0001",
    //                 "dolRegistration": true
    //             }
    //         }
    //         return auditCreateInformation;
    //     }
    // }

    // private getOffThePlan(formConfig : FormConfig) : any {
    //     if (formConfig.offThePlan) {
    //         return formConfig.offThePlan;
    //     }
    //     return {
    //         "offThePlanConcessionSubjected": false,
    //         "contractPrice": 100000,
    //         "auditUpdateInformation": {
    //             "updatedByRegistrationId": "47062507",
    //             "updatedByUserId": "PASVER0001",
    //             "updated": "2019-03-06T03:08:20.869+0000",
    //             "updatedBy": {
    //                 "userId": "PASVER0001",
    //                 "registrationId": "47062507",
    //                 "registrationType": "DUTIES_ONLINE",
    //                 "dolCustomerId": "47062507",
    //                 "dolUserId": "PASVER0001",
    //                 "dolRegistration": true
    //             }
    //         },
    //         "readOnlyLessTheTotalGst": false
    //     };
    // }

    // private getSubSale(formConfig : FormConfig) : any {
    //     if (formConfig.subSale) {
    //         return formConfig.subSale;
    //     }
    //     return {
    //         "notSubSale": true,
    //         "applicable": false,
    //         "purchaserTransferRightsChanged": false,
    //         "purchasers": [],
    //         "option": {
    //             "optionGrantedToProperty": false
    //         },
    //         "landDevelopment": {},
    //         "additionalConsideration": {
    //             "paidToVendor": 0,
    //             "paidToFirstPurchaser": 0,
    //             "paidToOtherParties": 0,
    //             "underParallelArrangement": 0,
    //             "totalConsideration": 0,
    //             "considerationExcludedCostsValue": 0
    //         },
    //         "auditUpdateInformation": {
    //             "updatedByRegistrationId": "47062507",
    //             "updatedByUserId": "PASVER0001",
    //             "updated": "2019-03-06T03:08:20.851+0000",
    //             "updatedBy": {
    //                 "userId": "PASVER0001",
    //                 "registrationId": "47062507",
    //                 "registrationType": "DUTIES_ONLINE",
    //                 "dolCustomerId": "47062507",
    //                 "dolUserId": "PASVER0001",
    //                 "dolRegistration": true
    //             }
    //         },
    //         "version": 0,
    //         "purchaserListSize": 0,
    //         "optionApplicable": true,
    //         "transferRightsApplicable": true
    //     };
    // }

    // private getTransaction(formConfig : FormConfig) : any {
    //     if (formConfig.transaction) {
    //         return formConfig.transaction;
    //     }
    //     return {
    //         "transactionSectionId": 3337644,
    //         "transferOfLandType": "TRANSFER_OF_LAND",
    //         "transferDetails": {
    //           "transactionType": "TransferBetweenSpousesDeFactoOrDomesticPartners",
    //           "transactionInvolvesMonetaryConsideration": false,
    //           "transferDate": "2019-01-31",
    //           "involvesMonetaryConsideration": false,
    //           "other": false,
    //           "fullPath": false,
    //           "transferBetweenSpousesDefactoOrDomesticPartnersWithNoConsiderationPath": true,
    //           "deviseInAccordanceWithAWillOrProbate": false,
    //           "transferBetweenSpousesDeFactoOrDomesticPartners": true,
    //           "transactionInvolvesMonetaryConsiderationRendered": true,
    //           "optionDateRendered": false,
    //           "contractDateRendered": false,
    //           "limitedPath": false
    //         },
    //         "relatedParty": {
    //           "relatedParty": false,
    //           "relationshipTypeRendered": false
    //         },
    //         "considerationAndValue": {
    //           "marketValueDate": "2019-01-06",
    //           "marketValue": 1000000,
    //           "nonMonetaryDetailsRendered": false,
    //           "marketValueDetailsRendered": false,
    //           "otherNonMonetaryConsiderationDetailsRendered": false
    //         },
    //         "gst": {
    //           "gstDetailsRendered": false,
    //           "gstAmountsRendered": false,
    //           "explainDoesNotMakeTaxableSupplyRendered": false
    //         },
    //         "saleOfBusinessGoods": {
    //           "saleOfGoodsDetailsRendered": false,
    //           "saleOfBusinessDetailsRendered": false
    //         },
    //         "waterRights": {
    //           "considerationForWaterRightsRendered": false
    //         },
    //         "dutiesFormId": 2293463,
    //         "auditUpdateInformation": {
    //           "updatedByRegistrationId": "47062507",
    //           "updatedByUserId": "PASVER0001",
    //           "updated": "2019-01-21T22:57:10.437+0000",
    //           "updatedBy": {
    //             "userId": "PASVER0001",
    //             "registrationId": "47062507",
    //             "registrationType": "DUTIES_ONLINE",
    //             "dolCustomerId": "47062507",
    //             "dolUserId": "PASVER0001",
    //             "dolRegistration": true
    //           }
    //         },
    //         "version": 1,
    //         "id": "sl68krrduz52",
    //         "fullPath": false,
    //         "transferBetweenSpousesDefactoOrDomesticPartnersWithNoConsiderationPath": true,
    //         "limitedPath": false,
    //         "transferBetweenSpousesDeFactoOrDomesticPartners": true,
    //         "transactionInvolvesMonetaryConsideration": false,
    //         "considerationGreaterThanZero": false,
    //         "changeOfBeneficialOwnership": false
    //       };
    // }

    // private getaAditionalLandNotIncludedInContract(formConfig : FormConfig) : any {
    //     if (formConfig.additionalLandNotIncludedInContract) {
    //         return formConfig.additionalLandNotIncludedInContract;
    //     }
    //     return {
    //         "additionalSaleOfLand": false,
    //         "propertyList": [],
    //         "auditUpdateInformation": {
    //             "updatedByRegistrationId": "47062507",
    //             "updatedByUserId": "PASVER0001",
    //             "updated": "2019-03-06T03:08:20.847+0000",
    //             "updatedBy": {
    //                 "userId": "PASVER0001",
    //                 "registrationId": "47062507",
    //                 "registrationType": "DUTIES_ONLINE",
    //                 "dolCustomerId": "47062507",
    //                 "dolUserId": "PASVER0001",
    //                 "dolRegistration": true
    //             }
    //         },
    //         "version": 0
    //     };
    // }

    // private getConcessionExemptionSection( formConfig : FormConfig) : any {
    //     if (formConfig.concessionExemptionSection) {
    //         return formConfig.concessionExemptionSection;
    //     }
    //     return {
    //         "applyConcessionOrExemption": false,
    //         "concessions": [],
    //         "version": 0,
    //         "auditUpdateInformation": {
    //             "updatedByRegistrationId": "47062507",
    //             "updatedByUserId": "PASVER0001",
    //             "updated": "2019-02-25T06:46:21.786+0000",
    //             "updatedBy": {
    //                 "userId": "PASVER0001",
    //                 "registrationId": "47062507",
    //                 "registrationType": "DUTIES_ONLINE",
    //                 "dolCustomerId": "47062507",
    //                 "dolUserId": "PASVER0001",
    //                 "dolRegistration": true
    //             }
    //         }
    //     };
    // }

    private createForm(verificationObject: any, formConfig : FormConfig) : any {
        let documentData = verificationObject.StampDutyVerification.DocumentData;
        documentData.forEach(document => {
            
        })
        return null;
    }

    private getParties(verificationObject: any, formConfig : FormConfig) {
        let parties = {};
        let personNames = {};
        verificationObject.StampDutyVerification.InvolvedParty.forEach(party => {
            let obj = null;
            let partyType = null;
            switch (party.PartyType) {
                case 'Individual' :
                    obj = this.getIndividual(party, formConfig);
                    break;

                default:
            } 
            parties[party.PartyId] = obj;
        });
        return parties
    }

    private getIndividual(party: any, formConfig : FormConfig) :any {
        let nameCopy = JSON.parse(JSON.stringify(party.PersonFullName.GivenName));
        let person = {
            personName: {
                firstName: nameCopy.splice(0,1)[0]['$value'],
                middleName: nameCopy.length === 0 ? undefined : nameCopy.map(part => {return part.$value}).join(), 
                surname: party.PersonFullName.FamilyName,
                
                acceptBlankSurname : true
            },
            dateOfBirth: party.BirthDate,
            mobileNumber: "044555222",
            emailAddress: "test@test.com",
            foreignNaturalPerson: false,
            partyType : "INDIVIDUAL_NATURAL_PERSON"
        };
        return person;
    }

}



let jsonString:string = '{ "StampDutyVerification": { "ContractForSaleDate": "2014-03-18T04:56:34.34", "DocumentData": { "Consideration": { "ConsiderationType": "Monetary", "GrossConsiderationAmount": "510000" }, "DocumentId": "12322323", "PartyReceivingDetail": { "Tenancy": { "TenancyGroup": { "ShareFraction": { "Denominator": "1", "Numerator": "1" }, "TenantHolding": { "PartyId": "T_111111_1", "attributes": { "order": "1" } }, "attributes": { "order": "1" } }, "TenancyType": "Tenants in Common" } }, "PartyRelinquishingDetail": { "Tenancy": { "TenancyGroup": { "TenantHolding": { "PartyId": "T_222222_2", "attributes": { "order": "1" } }, "attributes": { "order": "1" } }, "TenancyType": "Tenants in Common" } }, "SubjectLandTitle": { "EstateType": "Fee Simple", "LandDescription": { "Component": [ { "Name": "Type", "Value": "C" }, { "Name": "Spi", "Value": "67A\\\\PP3416B" }, { "Name": "Allotment", "Value": "67A" }, { "Name": "ParishCode", "Value": "3416B" }, { "Name": "ParishName", "Value": "Parish of Smith East of Melbourne" } ], "LegalDescription": "Crown Allotment 67A Parish of Smith East of Melbourne." }, "LandTitleReference": { "Component": [ { "Name": "Volume", "Value": "12548" }, { "Name": "Folio", "Value": "125" } ] }, "StreetAddress": { "StructuredAddress": { "LocalityName": "ORMOND", "Postcode": "3204", "Road": { "RoadName": "KATANDRA", "RoadNumber": { "$value": "18", "attributes": { "order": "1" } }, "RoadTypeCode": "RD", "attributes": { "order": "1" } }, "State": "VIC" } } } }, "ElnLodgementCaseId": "g2pc7q58jspc5aeo", "IntendedSettlementDate": "2014-03-18T15:30:00+11:00", "InvolvedParty": [ { "BirthDate": "1982-02-12T12:00:00+11:00", "LegalEntityName": "Bubba Lester Watson", "PartyCorrespondenceAddress": { "StreetAddress": { "StructuredAddress": { "LocalityName": "Alexandra", "Postcode": "4740", "Road": [ { "RoadName": "Moreland", "RoadNumber": [ { "$value": "98", "attributes": { "order": "1" } }, { "$value": "100", "attributes": { "order": "2" } } ], "RoadTypeCode": "ST", "attributes": { "order": "2" } }, { "RoadName": "Moreland", "RoadNumber": { "$value": "298", "attributes": { "order": "1" } }, "RoadTypeCode": "ST", "attributes": { "order": "1" } } ], "State": "QLD" } } }, "PartyId": "T_111111_1", "PartyType": "Individual", "PersonFullName": { "FamilyName": "Watson", "GivenName": [ { "$value": "Bubba", "attributes": { "order": "1" } }, { "$value": "Lester", "attributes": { "order": "2" } } ] } }, { "BirthDate": "1982-02-12T12:00:00+11:00", "LegalEntityName": "Bubba Lester Watson", "PartyCorrespondenceAddress": { "StreetAddress": { "StructuredAddress": { "LocalityName": "Alexandra", "Postcode": "4740", "Road": [ { "RoadName": "Moreland", "RoadNumber": [ { "$value": "102", "attributes": { "order": "1" } }, { "$value": "104", "attributes": { "order": "2" } } ], "RoadTypeCode": "ST", "attributes": { "order": "1" } }, { "RoadName": "Moreland", "RoadNumber": { "$value": "112", "attributes": { "order": "2" } }, "RoadTypeCode": "ST", "attributes": { "order": "2" } } ], "State": "QLD" } } }, "PartyId": "T_222222_2", "PartyType": "Individual", "PersonFullName": { "FamilyName": "Watson", "GivenName": [ { "$value": "Bubba", "attributes": { "order": "1" } }, { "$value": "Lester", "attributes": { "order": "2" } } ] } } ], "Jurisdiction": "VIC", "MessageHeader": { "Environment": "Development", "MessageCategory": "Request", "MessageDestination": "sro:vic:gov:au", "MessageId": "8daf77a0-e76b-11e2-91e2-0800200c9a66", "MessageOrigin": "urn:necd.com.au:PEXA", "MessageService": "Stamp Duty Verification", "TransmissionTimestamp": "2009-06-02T04:56:34.34" }, "PaymentMethod": "PEXA", "SettlementStatus": "Verify", "SubscriberDetails": { "RevenueOfficeClientId": "SRO_987", "Subscriber": { "BusinessName": "ABC Conveyancing", "BusinessUnit": "Far West", "LegalEntityName": "Michael John Smith", "PartyType": "Sole Trader", "PersonFullName": { "FamilyName": "Smith", "GivenName": [ { "$value": "Michael", "attributes": { "order": "1" } }, { "$value": "John", "attributes": { "order": "2" } } ] } }, "SubscriberId": "200" } } }';

let converter: VerificationXmlToSoapJson = new VerificationXmlToSoapJson();

//let obj = converter.createFormJson(jsonString, formConfig);
