protractor = require('../src/protractor-base.conf.js');
var config = protractor.config;
config.seleniumAddress = 'http://localhost:9515'
config.capabilities = {
	browserName: 'phantomjs',
}

config.cucumberOpts.tags = ["~@fail", "~@exclude"];


config.accessibility.acheckerTempFolder = '/tmp/achecker/';

exports.config = config;