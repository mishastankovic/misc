let protractor = require('../src/protractor-base.conf.js');
let config = protractor.config;

//config.seleniumAddress = 'http://localhost:9515'
//config.seleniumAddress = 'http://192.168.99.100:4444/wd/hub';
//config.baseUrl = 'https://mcidev01.sro.vic.gov.au/',
	//config.baseUrl= 'https://10.4.14.76/cpvsl/login'
	//config.baseUrl = 'https://cseintegration2.e-business.sro.vic.gov.au/wbt/login'
config.baseUrl ='https://localtest.e-business.sro.vic.gov.au/dutieslandtransfer',	
config.dolUrl = "https://localtest.e-business.sro.vic.gov.au/duties/faces/public/login.xhtml",
config.webserviceBaseUrl = 'https://localtestsecure.e-business.sro.vic.gov.au/',	
config.dutiesLansTransferRestUrl = 'https://localtest.e-business.sro.vic.gov.au/dutiesformrest/',


// config.baseUrl ='https://development.e-business.sro.vic.gov.au/dutieslandtransfer',	
// config.dolUrl = "https://development.e-business.sro.vic.gov.au/duties/faces/public/login.xhtml",
// config.webserviceBaseUrl = 'https://development.e-business.sro.vic.gov.au/',	
// config.dutiesLansTransferRestUrl = 'https://development.e-business.sro.vic.gov.au/dutiesformrest/',


// config.baseUrl ='https://mcidev01.sro.vic.gov.au/dutieslandtransfer',	
// config.dolUrl = "https://mcidev01.sro.vic.gov.au/duties/faces/public/login.xhtml",
	//use chrome browser.
	config.capabilities = {
		browserName: 'chrome',
	}
config.jsonfolder = "./src/features/";
//config.cucumberOpts.tags = ["~@fail", "~@exclude"];
config.cucumberOpts.tags = ["@current"];
oracleNodeRestUlr: "http://mcidev01.sro.vic.gov.au:3000/sql";

exports.config = config;