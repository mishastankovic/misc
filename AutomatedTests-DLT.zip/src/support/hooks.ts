const { BeforeAll, After, AfterAll, Status } = require("cucumber");
import * as fs from "fs";
import { browser } from "protractor";

BeforeAll({timeout: 100 * 1000}, async () => {
});

After(async function(scenario) {
});

AfterAll({timeout: 100 * 1000}, async () => {
});
