const loadJsonFile = require('load-json-file');
protractor = require('sro-bdd-cucumber/dist/protractor-base.conf.js');
var config = protractor.config;

//configure the selenium server.
config.seleniumAddress = 'http://localhost:4444/wd/hub';


//where the feature files are
config.specs = [
	'../src/features/**/*.feature'
],

	//step definition files and other typescript files. sro-bdd-cucumber js files conatin the common steps difined in sro-bdd-cucumber package.
	config.cucumberOpts.require = ['./**/*.ts', '../node_modules/sro-bdd-cucumber/dist/**/*.js']

//compile ts files before running each test.
config.beforeLaunch = () => {
	require('ts-node')
		.register({
			project: 'src/tsconfig.src.json'
		});
},

	//cucumber tags.
	config.cucumberOpts.tags = ["~@fail", "~@exclude"];

//achecker accessibility checking temp folder.
config.accessibility.acheckerTempFolder = 'C:/Temp/achecker/';

//accessbility enable/disable
config.accessibility.runAxeAccessibilityTests = false;
config.accessibility.runAcheckerAccessibilityTests = false;


config.connectionNames = {
	'cpvsl_db': 'DEVEL_cpvsl'
};

//load the sql json file. 
config.sql = loadJsonFile.sync('./src/support/sql.json');


exports.config = config;