import { HttpClient } from '@angular/common/http';
import { Injectable, EventEmitter } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Lodgement, Form } from 'src/app/au/gov/vic/sro/dol-claim/model/claim.interface';
import { fetch } from 'node-fetch';


@Injectable()
export class DolClaimService {
	protected basePath = environment.apiBasePath;

	constructor(protected http: HttpClient) { }

	public async getLodgement(lodgementId: string): Promise<Lodgement> {
		const url = this.basePath + 'lodgement/' + lodgementId;
		return this.http.get<Lodgement>(url).toPromise();
	}

	public async getJsfHeaderForm() : Promise<string> {
		const url = environment.dolApiBasePath +  "faces/common/header.xhtml";
		return this.http.get(url, {responseType: 'text'}).toPromise();
	}
}
