import { Injectable } from "@angular/core";
import { Lodgement, ClaimedForm } from "../model/claim.interface";


@Injectable()
export class DolClaimUIService {

    public lodgementCaseId: string;
    public sroReferenceId: string;
    public lodgement : Lodgement;
    
    private claimedForms : Map<string, ClaimedForm> = new Map<string, ClaimedForm>();


    constructor () {
        let a = 1;
    }

    clear() {
        this.lodgementCaseId = undefined;
        this.sroReferenceId = undefined;
        this.lodgement = undefined;
        this.claimedForms = new Map<string, ClaimedForm>();

    }

    public setClaimedForm(claimedForm: ClaimedForm) :void {
        this.claimedForms.set(claimedForm.documentId, claimedForm);
    }

    public getClaimLodgementData() {
        let data = {
            lodgementCaseId: this.lodgementCaseId,
            sroReferenceId: this.sroReferenceId,
            forms: []
        }

        this.claimedForms.forEach( (claimedForm) => {
            data.forms.push(claimedForm);
        });
        return data;
    }
}